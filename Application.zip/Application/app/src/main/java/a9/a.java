package a9;

import b6.i;

/* loaded from: classes.dex */
public interface a {

    /* renamed from: a9.a$a, reason: collision with other inner class name */
    public interface InterfaceC0004a {
        void a(String str);
    }

    String a();

    i<String> b();

    void c(String str, String str2);

    void d(InterfaceC0004a interfaceC0004a);
}
