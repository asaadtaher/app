package b9;

/* loaded from: classes.dex */
public interface a<T> {

    /* renamed from: b9.a$a, reason: collision with other inner class name */
    public interface InterfaceC0092a<T> {
        void a(b<T> bVar);
    }

    void a(InterfaceC0092a<T> interfaceC0092a);
}
