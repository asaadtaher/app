package b9;

/* loaded from: classes.dex */
public interface b<T> {
    T get();
}
