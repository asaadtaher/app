package ca;

import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Iterator;

/* loaded from: classes.dex */
class a extends e {

    /* renamed from: c, reason: collision with root package name */
    private int[] f6723c;

    /* renamed from: d, reason: collision with root package name */
    private String[] f6724d;

    @Override // ca.e
    public String a(int i10) {
        return this.f6724d[i10];
    }

    @Override // ca.e
    public int d(int i10) {
        return this.f6723c[i10];
    }

    @Override // ca.e
    public void e(ObjectInput objectInput) {
        int i10 = objectInput.readInt();
        this.f6737a = i10;
        int[] iArr = this.f6723c;
        if (iArr == null || iArr.length < i10) {
            this.f6723c = new int[i10];
        }
        String[] strArr = this.f6724d;
        if (strArr == null || strArr.length < i10) {
            this.f6724d = new String[i10];
        }
        for (int i11 = 0; i11 < this.f6737a; i11++) {
            this.f6723c[i11] = objectInput.readInt();
            this.f6724d[i11] = objectInput.readUTF();
        }
        int i12 = objectInput.readInt();
        this.f6738b.clear();
        for (int i13 = 0; i13 < i12; i13++) {
            this.f6738b.add(Integer.valueOf(objectInput.readInt()));
        }
    }

    @Override // ca.e
    public void f(ObjectOutput objectOutput) {
        objectOutput.writeInt(this.f6737a);
        for (int i10 = 0; i10 < this.f6737a; i10++) {
            objectOutput.writeInt(this.f6723c[i10]);
            objectOutput.writeUTF(this.f6724d[i10]);
        }
        objectOutput.writeInt(this.f6738b.size());
        Iterator<Integer> it = this.f6738b.iterator();
        while (it.hasNext()) {
            objectOutput.writeInt(it.next().intValue());
        }
    }
}
