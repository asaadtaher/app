package ca;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import x9.l;

/* loaded from: classes.dex */
public class f {

    /* Logger */
    private static final Logger f6739d = Logger.getLogger(f.class.getName());

    /* Variables */
    private final String f6740a;
    private c f6741b = new c();
    private Map<String, d> f6742c = new HashMap<>();

    public f(String str) throws Throwable {
        this.f6740a = str;
        d();
    }

    /** Utility: close stream safely */
    private static void a(InputStream inputStream) throws IOException {
        if (inputStream != null) {
            try {
                inputStream.close();
            } catch (IOException e10) {
                f6739d.log(Level.WARNING, e10.toString());
            }
        }
    }

    /** Get d instance */
    private d c(int i10, String str, String str2, String str3) throws Throwable {
        String strD = this.f6741b.d(i10, str, str2, str3);
        if (strD.length() == 0) {
            return null;
        }
        if (!this.f6742c.containsKey(strD)) {
            e(strD);
        }
        return this.f6742c.get(strD);
    }

    /** Load config */
    private void d() throws Throwable {
        ObjectInputStream objectInputStream = null;
        try {
            ObjectInputStream objectInputStream2 =
                    new ObjectInputStream(f.class.getResourceAsStream(this.f6740a + "config"));
            try {
                this.f6741b.readExternal(objectInputStream2);
                a(objectInputStream2);
            } catch (IOException e10) {
                objectInputStream = objectInputStream2;
                f6739d.log(Level.WARNING, e10.toString());
                a(objectInputStream);
            } catch (Throwable th) {
                objectInputStream = objectInputStream2;
                a(objectInputStream);
                throw th;
            }
        } catch (IOException e11) {
            f6739d.log(Level.WARNING, e11.toString());
        }
    }

    /** Load d object by key */
    private void e(String str) throws Throwable {
        ObjectInputStream objectInputStream = null;
        try {
            ObjectInputStream objectInputStream3 =
                    new ObjectInputStream(f.class.getResourceAsStream(this.f6740a + str));
            try {
                d dVar = new d();
                dVar.readExternal(objectInputStream3);

                // ✅ التصحيح: إضافة إلى الـ Map مباشرة
                this.f6742c.put(str, dVar);

                a(objectInputStream3);
                objectInputStream = objectInputStream3;
            } catch (IOException e10) {
                f6739d.log(Level.WARNING, e10.toString());
                a(objectInputStream3);
                objectInputStream = objectInputStream3;
            } catch (Throwable th) {
                a(objectInputStream3);
                throw th;
            }
        } catch (IOException e11) {
            f6739d.log(Level.WARNING, e11.toString());
        }
    }

    /** Language check */
    private boolean f(String str) {
        return (!str.equals("zh") && !str.equals("ja") && !str.equals("ko"));
    }

    /** Main API */
    public String b(l lVar, String str, String str2, String str3) throws Throwable {
        int iC = lVar.c();
        if (iC == 1) {
            iC = ((int) (lVar.f() / 10000000)) + 1000;
        }
        d dVarC = c(iC, str, str2, str3);
        String strC = dVarC != null ? dVarC.c(lVar) : null;
        if ((strC == null || strC.length() == 0) && f(str)) {
            d dVarC2 = c(iC, "en", "", "");
            if (dVarC2 == null) {
                return "";
            }
            strC = dVarC2.c(lVar);
        }
        return strC != null ? strC : "";
    }
}
