package ca;

import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.nio.ByteBuffer;
import java.util.Iterator;

/* loaded from: classes.dex */
final class b extends e {

    /* renamed from: c, reason: collision with root package name */
    private int f6725c;

    /* renamed from: d, reason: collision with root package name */
    private int f6726d;

    /* renamed from: e, reason: collision with root package name */
    private ByteBuffer f6727e;

    /* renamed from: f, reason: collision with root package name */
    private ByteBuffer f6728f;

    /* renamed from: g, reason: collision with root package name */
    private String[] f6729g;

    b() {
    }

    private void g(ObjectInput objectInput) {
        this.f6737a = objectInput.readInt();
        ByteBuffer byteBuffer = this.f6727e;
        if (byteBuffer == null || byteBuffer.capacity() < this.f6737a) {
            this.f6727e = ByteBuffer.allocate(this.f6737a * this.f6725c);
        }
        ByteBuffer byteBuffer2 = this.f6728f;
        if (byteBuffer2 == null || byteBuffer2.capacity() < this.f6737a) {
            this.f6728f = ByteBuffer.allocate(this.f6737a * this.f6726d);
        }
        for (int i10 = 0; i10 < this.f6737a; i10++) {
            h(objectInput, this.f6725c, this.f6727e, i10);
            h(objectInput, this.f6726d, this.f6728f, i10);
        }
    }

    private static void h(ObjectInput objectInput, int i10, ByteBuffer byteBuffer, int i11) {
        int i12 = i11 * i10;
        if (i10 == 2) {
            byteBuffer.putShort(i12, objectInput.readShort());
        } else {
            byteBuffer.putInt(i12, objectInput.readInt());
        }
    }

    private static int i(ByteBuffer byteBuffer, int i10, int i11) {
        int i12 = i11 * i10;
        return i10 == 2 ? byteBuffer.getShort(i12) : byteBuffer.getInt(i12);
    }

    private static void j(ObjectOutput objectOutput, int i10, ByteBuffer byteBuffer, int i11) {
        int i12 = i11 * i10;
        if (i10 == 2) {
            objectOutput.writeShort(byteBuffer.getShort(i12));
        } else {
            objectOutput.writeInt(byteBuffer.getInt(i12));
        }
    }

    @Override // ca.e
    public String a(int i10) {
        return this.f6729g[i(this.f6728f, this.f6726d, i10)];
    }

    @Override // ca.e
    public int d(int i10) {
        return i(this.f6727e, this.f6725c, i10);
    }

    @Override // ca.e
    public void e(ObjectInput objectInput) {
        this.f6725c = objectInput.readInt();
        this.f6726d = objectInput.readInt();
        int i10 = objectInput.readInt();
        this.f6738b.clear();
        for (int i11 = 0; i11 < i10; i11++) {
            this.f6738b.add(Integer.valueOf(objectInput.readInt()));
        }
        int i12 = objectInput.readInt();
        String[] strArr = this.f6729g;
        if (strArr == null || strArr.length < i12) {
            this.f6729g = new String[i12];
        }
        for (int i13 = 0; i13 < i12; i13++) {
            this.f6729g[i13] = objectInput.readUTF();
        }
        g(objectInput);
    }

    @Override // ca.e
    public void f(ObjectOutput objectOutput) {
        objectOutput.writeInt(this.f6725c);
        objectOutput.writeInt(this.f6726d);
        objectOutput.writeInt(this.f6738b.size());
        Iterator<Integer> it = this.f6738b.iterator();
        while (it.hasNext()) {
            objectOutput.writeInt(it.next().intValue());
        }
        objectOutput.writeInt(this.f6729g.length);
        for (String str : this.f6729g) {
            objectOutput.writeUTF(str);
        }
        objectOutput.writeInt(this.f6737a);
        for (int i10 = 0; i10 < this.f6737a; i10++) {
            j(objectOutput, this.f6725c, this.f6727e, i10);
            j(objectOutput, this.f6726d, this.f6728f, i10);
        }
    }
}
