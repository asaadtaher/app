package ca;

import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.TreeSet;

/* loaded from: classes.dex */
abstract class e {

    /* renamed from: a, reason: collision with root package name */
    protected int f6737a = 0;

    /* renamed from: b, reason: collision with root package name */
    protected final TreeSet<Integer> f6738b = new TreeSet<>();

    e() {
    }

    public abstract String a(int i10);

    public int b() {
        return this.f6737a;
    }

    public TreeSet<Integer> c() {
        return this.f6738b;
    }

    public abstract int d(int i10);

    public abstract void e(ObjectInput objectInput);

    public abstract void f(ObjectOutput objectOutput);

    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        int iB = b();
        for (int i10 = 0; i10 < iB; i10++) {
            sb2.append(d(i10));
            sb2.append("|");
            sb2.append(a(i10));
            sb2.append("\n");
        }
        return sb2.toString();
    }
}
