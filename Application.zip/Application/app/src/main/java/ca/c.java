package ca;

import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/* loaded from: classes.dex */
public class c implements Externalizable {

    /* renamed from: d, reason: collision with root package name */
    private static final Map<String, String> f6730d;

    /* renamed from: a, reason: collision with root package name */
    private int f6731a = 0;

    /* renamed from: b, reason: collision with root package name */
    private int[] f6732b;

    /* renamed from: c, reason: collision with root package name */
    private List<Set<String>> f6733c;

    static {
        HashMap map = new HashMap();
        map.put("zh_TW", "zh_Hant");
        map.put("zh_HK", "zh_Hant");
        map.put("zh_MO", "zh_Hant");
        f6730d = Collections.unmodifiableMap(map);
    }

    private void a(String str, StringBuilder sb2) {
        if (str.length() > 0) {
            sb2.append('_');
            sb2.append(str);
        }
    }

    private StringBuilder b(String str, String str2, String str3) {
        StringBuilder sb2 = new StringBuilder(str);
        a(str2, sb2);
        a(str3, sb2);
        return sb2;
    }

    private String c(Set<String> set, String str, String str2, String str3) {
        String string = b(str, str2, str3).toString();
        String str4 = f6730d.get(string);
        if (str4 != null && set.contains(str4)) {
            return str4;
        }
        if (set.contains(string)) {
            return string;
        }
        if (e(str2, str3)) {
            return set.contains(str) ? str : "";
        }
        if (str2.length() <= 0 || str3.length() <= 0) {
            return "";
        }
        String str5 = str + '_' + str2;
        if (set.contains(str5)) {
            return str5;
        }
        String str6 = str + '_' + str3;
        return set.contains(str6) ? str6 : set.contains(str) ? str : "";
    }

    private boolean e(String str, String str2) {
        return (str.length() == 0 && str2.length() > 0) || (str2.length() == 0 && str.length() > 0);
    }

    String d(int i10, String str, String str2, String str3) {
        int iBinarySearch;
        if (str.length() == 0 || (iBinarySearch = Arrays.binarySearch(this.f6732b, i10)) < 0) {
            return "";
        }
        Set<String> set = this.f6733c.get(iBinarySearch);
        if (set.size() > 0) {
            String strC = c(set, str, str2, str3);
            if (strC.length() > 0) {
                return i10 + '_' + strC;
            }
        }
        return "";
    }

    @Override // java.io.Externalizable
    public void readExternal(ObjectInput objectInput) {
        int i10 = objectInput.readInt();
        this.f6731a = i10;
        int[] iArr = this.f6732b;
        if (iArr == null || iArr.length < i10) {
            this.f6732b = new int[i10];
        }
        if (this.f6733c == null) {
            this.f6733c = new ArrayList();
        }
        for (int i11 = 0; i11 < this.f6731a; i11++) {
            this.f6732b[i11] = objectInput.readInt();
            int i12 = objectInput.readInt();
            HashSet hashSet = new HashSet();
            for (int i13 = 0; i13 < i12; i13++) {
                hashSet.add(objectInput.readUTF());
            }
            this.f6733c.add(hashSet);
        }
    }

    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        for (int i10 = 0; i10 < this.f6731a; i10++) {
            sb2.append(this.f6732b[i10]);
            sb2.append('|');
            Iterator it = new TreeSet(this.f6733c.get(i10)).iterator();
            while (it.hasNext()) {
                sb2.append((String) it.next());
                sb2.append(',');
            }
            sb2.append('\n');
        }
        return sb2.toString();
    }

    @Override // java.io.Externalizable
    public void writeExternal(ObjectOutput objectOutput) {
        objectOutput.writeInt(this.f6731a);
        for (int i10 = 0; i10 < this.f6731a; i10++) {
            objectOutput.writeInt(this.f6732b[i10]);
            Set<String> set = this.f6733c.get(i10);
            objectOutput.writeInt(set.size());
            Iterator<String> it = set.iterator();
            while (it.hasNext()) {
                objectOutput.writeUTF(it.next());
            }
        }
    }
}
