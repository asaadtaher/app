package ca;

import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.SortedSet;
import java.util.logging.Logger;
import x9.g;
import x9.l;

/* loaded from: classes.dex */
public class d implements Externalizable {

    /* renamed from: c, reason: collision with root package name */
    private static final Logger f6734c = Logger.getLogger(d.class.getName());

    /* renamed from: a, reason: collision with root package name */
    private final g f6735a = g.v();

    /* renamed from: b, reason: collision with root package name */
    private e f6736b;

    private int a(int i10, int i11, long j10) {
        int i12 = 0;
        while (i10 <= i11) {
            i12 = (i10 + i11) >>> 1;
            long jD = this.f6736b.d(i12);
            if (jD == j10) {
                return i12;
            }
            if (jD > j10) {
                i12--;
                i11 = i12;
            } else {
                i10 = i12 + 1;
            }
        }
        return i12;
    }

    String b(long j10) throws NumberFormatException {
        int iB = this.f6736b.b();
        if (iB == 0) {
            return null;
        }
        int iA = iB - 1;
        SortedSet sortedSetC = this.f6736b.c();
        while (sortedSetC.size() > 0) {
            Integer num = (Integer) sortedSetC.last();
            String strValueOf = String.valueOf(j10);
            if (strValueOf.length() > num.intValue()) {
                j10 = Long.parseLong(strValueOf.substring(0, num.intValue()));
            }
            iA = a(0, iA, j10);
            if (iA < 0) {
                return null;
            }
            if (j10 == this.f6736b.d(iA)) {
                return this.f6736b.a(iA);
            }
            sortedSetC = sortedSetC.headSet(num);
        }
        return null;
    }

    public String c(l lVar) {
        return b(Long.parseLong(lVar.c() + this.f6735a.z(lVar)));
    }

    @Override // java.io.Externalizable
    public void readExternal(ObjectInput objectInput) {
        this.f6736b = objectInput.readBoolean() ? new b() : new a();
        this.f6736b.e(objectInput);
    }

    public String toString() {
        return this.f6736b.toString();
    }

    @Override // java.io.Externalizable
    public void writeExternal(ObjectOutput objectOutput) {
        objectOutput.writeBoolean(this.f6736b instanceof b);
        this.f6736b.f(objectOutput);
    }
}
