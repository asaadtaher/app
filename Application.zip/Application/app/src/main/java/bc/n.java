package bc;

import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class n {

    public static class a extends RuntimeException {

        /* renamed from: a, reason: collision with root package name */
        public final String f6039a;

        /* renamed from: b, reason: collision with root package name */
        public final Object f6040b;

        public a(String str, String str2, Object obj) {
            super(str2);
            this.f6039a = str;
            this.f6040b = obj;
        }
    }

    public interface b {
        void a(e<g> eVar);

        void b(d dVar);

        void c(List<String> list, e<Boolean> eVar);

        void d(String str, Boolean bool, e<String> eVar);

        Boolean e();

        void f(e<Void> eVar);

        void g(String str, e<Void> eVar);

        void h(e<Void> eVar);

        void i(e<g> eVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    static class c extends tb.r {

        /* renamed from: d, reason: collision with root package name */
        public static final c f6041d = new c();

        private c() {
        }

        @Override // tb.r
        protected Object g(byte b10, ByteBuffer byteBuffer) {
            return b10 != Byte.MIN_VALUE ? b10 != -127 ? super.g(b10, byteBuffer) : g.a((ArrayList) f(byteBuffer)) : d.a((ArrayList) f(byteBuffer));
        }

        @Override // tb.r
        protected void p(ByteArrayOutputStream byteArrayOutputStream, Object obj) {
            ArrayList<Object> arrayListH;
            if (obj instanceof d) {
                byteArrayOutputStream.write(128);
                arrayListH = ((d) obj).n();
            } else if (!(obj instanceof g)) {
                super.p(byteArrayOutputStream, obj);
                return;
            } else {
                byteArrayOutputStream.write(129);
                arrayListH = ((g) obj).h();
            }
            p(byteArrayOutputStream, arrayListH);
        }
    }

    public static final class d {

        /* renamed from: a, reason: collision with root package name */
        private List<String> f6042a;

        /* renamed from: b, reason: collision with root package name */
        private f f6043b;

        /* renamed from: c, reason: collision with root package name */
        private String f6044c;

        /* renamed from: d, reason: collision with root package name */
        private String f6045d;

        /* renamed from: e, reason: collision with root package name */
        private String f6046e;

        /* renamed from: f, reason: collision with root package name */
        private Boolean f6047f;

        d() {
        }

        static d a(ArrayList<Object> arrayList) {
            d dVar = new d();
            dVar.k((List) arrayList.get(0));
            Object obj = arrayList.get(1);
            dVar.m(obj == null ? null : f.values()[((Integer) obj).intValue()]);
            dVar.j((String) arrayList.get(2));
            dVar.h((String) arrayList.get(3));
            dVar.l((String) arrayList.get(4));
            dVar.i((Boolean) arrayList.get(5));
            return dVar;
        }

        public String b() {
            return this.f6045d;
        }

        public Boolean c() {
            return this.f6047f;
        }

        public String d() {
            return this.f6044c;
        }

        public List<String> e() {
            return this.f6042a;
        }

        public String f() {
            return this.f6046e;
        }

        public f g() {
            return this.f6043b;
        }

        public void h(String str) {
            this.f6045d = str;
        }

        public void i(Boolean bool) {
            if (bool == null) {
                throw new IllegalStateException("Nonnull field \"forceCodeForRefreshToken\" is null.");
            }
            this.f6047f = bool;
        }

        public void j(String str) {
            this.f6044c = str;
        }

        public void k(List<String> list) {
            if (list == null) {
                throw new IllegalStateException("Nonnull field \"scopes\" is null.");
            }
            this.f6042a = list;
        }

        public void l(String str) {
            this.f6046e = str;
        }

        public void m(f fVar) {
            if (fVar == null) {
                throw new IllegalStateException("Nonnull field \"signInType\" is null.");
            }
            this.f6043b = fVar;
        }

        ArrayList<Object> n() {
            ArrayList<Object> arrayList = new ArrayList<>(6);
            arrayList.add(this.f6042a);
            f fVar = this.f6043b;
            arrayList.add(fVar == null ? null : Integer.valueOf(fVar.f6051a));
            arrayList.add(this.f6044c);
            arrayList.add(this.f6045d);
            arrayList.add(this.f6046e);
            arrayList.add(this.f6047f);
            return arrayList;
        }
    }

    public interface e<T> {
        void a(T t10);

        void b(Throwable th);
    }

    public enum f {
        STANDARD(0),
        GAMES(1);


        /* renamed from: a, reason: collision with root package name */
        final int f6051a;

        f(int i10) {
            this.f6051a = i10;
        }
    }

    public static final class g {

        /* renamed from: a, reason: collision with root package name */
        private String f6052a;

        /* renamed from: b, reason: collision with root package name */
        private String f6053b;

        /* renamed from: c, reason: collision with root package name */
        private String f6054c;

        /* renamed from: d, reason: collision with root package name */
        private String f6055d;

        /* renamed from: e, reason: collision with root package name */
        private String f6056e;

        /* renamed from: f, reason: collision with root package name */
        private String f6057f;

        public static final class a {

            /* renamed from: a, reason: collision with root package name */
            private String f6058a;

            /* renamed from: b, reason: collision with root package name */
            private String f6059b;

            /* renamed from: c, reason: collision with root package name */
            private String f6060c;

            /* renamed from: d, reason: collision with root package name */
            private String f6061d;

            /* renamed from: e, reason: collision with root package name */
            private String f6062e;

            /* renamed from: f, reason: collision with root package name */
            private String f6063f;

            public g a() {
                g gVar = new g();
                gVar.b(this.f6058a);
                gVar.c(this.f6059b);
                gVar.d(this.f6060c);
                gVar.f(this.f6061d);
                gVar.e(this.f6062e);
                gVar.g(this.f6063f);
                return gVar;
            }

            public a b(String str) {
                this.f6058a = str;
                return this;
            }

            public a c(String str) {
                this.f6059b = str;
                return this;
            }

            public a d(String str) {
                this.f6060c = str;
                return this;
            }

            public a e(String str) {
                this.f6062e = str;
                return this;
            }

            public a f(String str) {
                this.f6061d = str;
                return this;
            }

            public a g(String str) {
                this.f6063f = str;
                return this;
            }
        }

        g() {
        }

        static g a(ArrayList<Object> arrayList) {
            g gVar = new g();
            gVar.b((String) arrayList.get(0));
            gVar.c((String) arrayList.get(1));
            gVar.d((String) arrayList.get(2));
            gVar.f((String) arrayList.get(3));
            gVar.e((String) arrayList.get(4));
            gVar.g((String) arrayList.get(5));
            return gVar;
        }

        public void b(String str) {
            this.f6052a = str;
        }

        public void c(String str) {
            if (str == null) {
                throw new IllegalStateException("Nonnull field \"email\" is null.");
            }
            this.f6053b = str;
        }

        public void d(String str) {
            if (str == null) {
                throw new IllegalStateException("Nonnull field \"id\" is null.");
            }
            this.f6054c = str;
        }

        public void e(String str) {
            this.f6056e = str;
        }

        public void f(String str) {
            this.f6055d = str;
        }

        public void g(String str) {
            this.f6057f = str;
        }

        ArrayList<Object> h() {
            ArrayList<Object> arrayList = new ArrayList<>(6);
            arrayList.add(this.f6052a);
            arrayList.add(this.f6053b);
            arrayList.add(this.f6054c);
            arrayList.add(this.f6055d);
            arrayList.add(this.f6056e);
            arrayList.add(this.f6057f);
            return arrayList;
        }
    }

    protected static ArrayList<Object> a(Throwable th) {
        Object obj;
        ArrayList<Object> arrayList = new ArrayList<>(3);
        if (th instanceof a) {
            a aVar = (a) th;
            arrayList.add(aVar.f6039a);
            arrayList.add(aVar.getMessage());
            obj = aVar.f6040b;
        } else {
            arrayList.add(th.toString());
            arrayList.add(th.getClass().getSimpleName());
            obj = "Cause: " + th.getCause() + ", Stacktrace: " + Log.getStackTraceString(th);
        }
        arrayList.add(obj);
        return arrayList;
    }
}
