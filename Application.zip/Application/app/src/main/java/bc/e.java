package bc;

import android.accounts.Account;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import bc.c;
import bc.e;
import bc.n;
import com.google.android.gms.auth.UserRecoverableAuthException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import kb.a;

/* loaded from: classes.dex */
public class e implements kb.a, lb.a {

    /* renamed from: a, reason: collision with root package name */
    private b f6009a;

    /* renamed from: b, reason: collision with root package name */
    private tb.c f6010b;

    /* renamed from: c, reason: collision with root package name */
    private lb.c f6011c;

    static /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f6012a;

        static {
            int[] iArr = new int[n.f.values().length];
            f6012a = iArr;
            try {
                iArr[n.f.GAMES.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f6012a[n.f.STANDARD.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    public static class b implements tb.m, n.b {

        /* renamed from: a, reason: collision with root package name */
        private final Context f6013a;

        /* renamed from: b, reason: collision with root package name */
        private tb.o f6014b;

        /* renamed from: c, reason: collision with root package name */
        private Activity f6015c;

        /* renamed from: d, reason: collision with root package name */
        private final c f6016d = new c(1);

        /* renamed from: e, reason: collision with root package name */
        private final m f6017e;

        /* renamed from: f, reason: collision with root package name */
        private com.google.android.gms.auth.api.signin.b f6018f;

        /* renamed from: g, reason: collision with root package name */
        private List<String> f6019g;

        /* renamed from: h, reason: collision with root package name */
        private a f6020h;

        private static class a {

            /* renamed from: a, reason: collision with root package name */
            final String f6021a;

            /* renamed from: b, reason: collision with root package name */
            final n.e<n.g> f6022b;

            /* renamed from: c, reason: collision with root package name */
            final n.e<Void> f6023c;

            /* renamed from: d, reason: collision with root package name */
            final n.e<Boolean> f6024d;

            /* renamed from: e, reason: collision with root package name */
            final n.e<String> f6025e;

            /* renamed from: f, reason: collision with root package name */
            final Object f6026f;

            a(String str, n.e<n.g> eVar, n.e<Void> eVar2, n.e<Boolean> eVar3, n.e<String> eVar4, Object obj) {
                this.f6021a = str;
                this.f6022b = eVar;
                this.f6023c = eVar2;
                this.f6024d = eVar3;
                this.f6025e = eVar4;
                this.f6026f = obj;
            }
        }

        public b(Context context, m mVar) {
            this.f6013a = context;
            this.f6017e = mVar;
        }

        private void A(n.g gVar) {
            n.e<n.g> eVar = this.f6020h.f6022b;
            Objects.requireNonNull(eVar);
            eVar.a(gVar);
            this.f6020h = null;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ Void C(String str) throws IOException, o4.a {
            o4.b.a(this.f6013a, str);
            return null;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ void D(n.e eVar, Future future) {
            try {
                eVar.a((Void) future.get());
            } catch (InterruptedException e10) {
                eVar.b(new n.a("exception", e10.getMessage(), null));
                Thread.currentThread().interrupt();
            } catch (ExecutionException e11) {
                Throwable cause = e11.getCause();
                eVar.b(new n.a("exception", cause == null ? null : cause.getMessage(), null));
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void E(b6.i iVar) {
            if (iVar.r()) {
                z();
            } else {
                y("status", "Failed to disconnect.");
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ String F(String str) {
            return o4.b.b(this.f6013a, new Account(str, "com.google"), "oauth2:" + c7.e.e(' ').c(this.f6019g));
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void G(n.e eVar, Boolean bool, String str, Future future) {
            n.a aVar;
            try {
                eVar.a((String) future.get());
            } catch (InterruptedException e10) {
                eVar.b(new n.a("exception", e10.getMessage(), null));
                Thread.currentThread().interrupt();
            } catch (ExecutionException e11) {
                if (!(e11.getCause() instanceof UserRecoverableAuthException)) {
                    Throwable cause = e11.getCause();
                    eVar.b(new n.a("exception", cause == null ? null : cause.getMessage(), null));
                    return;
                }
                if (bool.booleanValue() && this.f6020h == null) {
                    Activity activityB = B();
                    if (activityB != null) {
                        q("getTokens", eVar, str);
                        activityB.startActivityForResult(((UserRecoverableAuthException) e11.getCause()).a(), 53294);
                        return;
                    } else {
                        aVar = new n.a("user_recoverable_auth", "Cannot recover auth because app is not in foreground. " + e11.getLocalizedMessage(), null);
                    }
                } else {
                    aVar = new n.a("user_recoverable_auth", e11.getLocalizedMessage(), null);
                }
                eVar.b(aVar);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void H(b6.i iVar) {
            if (iVar.r()) {
                z();
            } else {
                y("status", "Failed to signout.");
            }
        }

        private void I(GoogleSignInAccount googleSignInAccount) {
            n.g.a aVarB = new n.g.a().c(googleSignInAccount.k()).d(googleSignInAccount.o()).e(googleSignInAccount.q()).g(googleSignInAccount.w()).b(googleSignInAccount.j());
            if (googleSignInAccount.s() != null) {
                aVarB.f(googleSignInAccount.s().toString());
            }
            A(aVarB.a());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void J(b6.i<GoogleSignInAccount> iVar) {
            String strW;
            String string;
            try {
                I(iVar.o(y4.b.class));
            } catch (b6.g e10) {
                string = e10.toString();
                strW = "exception";
                y(strW, string);
            } catch (y4.b e11) {
                strW = w(e11.b());
                string = e11.toString();
                y(strW, string);
            }
        }

        private void q(String str, n.e<String> eVar, Object obj) {
            u(str, eVar, obj);
        }

        private void r(String str, n.e<Boolean> eVar) {
            s(str, null, null, eVar, null, null);
        }

        private void s(String str, n.e<n.g> eVar, n.e<Void> eVar2, n.e<Boolean> eVar3, n.e<String> eVar4, Object obj) {
            if (this.f6020h == null) {
                this.f6020h = new a(str, eVar, eVar2, eVar3, eVar4, obj);
                return;
            }
            throw new IllegalStateException("Concurrent operations detected: " + this.f6020h.f6021a + ", " + str);
        }

        private void t(String str, n.e<n.g> eVar) {
            s(str, eVar, null, null, null, null);
        }

        private void u(String str, n.e<String> eVar, Object obj) {
            s(str, null, null, null, eVar, obj);
        }

        private void v(String str, n.e<Void> eVar) {
            s(str, null, eVar, null, null, null);
        }

        private String w(int i10) {
            return i10 != 4 ? i10 != 7 ? i10 != 12501 ? "sign_in_failed" : "sign_in_canceled" : "network_error" : "sign_in_required";
        }

        private void x(Boolean bool) {
            n.e<Boolean> eVar = this.f6020h.f6024d;
            Objects.requireNonNull(eVar);
            eVar.a(bool);
            this.f6020h = null;
        }

        private void y(String str, String str2) {
            a aVar = this.f6020h;
            n.e eVar = aVar.f6022b;
            if (eVar == null && (eVar = aVar.f6024d) == null && (eVar = aVar.f6025e) == null) {
                eVar = aVar.f6023c;
            }
            Objects.requireNonNull(eVar);
            eVar.b(new n.a(str, str2, null));
            this.f6020h = null;
        }

        private void z() {
            n.e<Void> eVar = this.f6020h.f6023c;
            Objects.requireNonNull(eVar);
            eVar.a(null);
            this.f6020h = null;
        }

        public Activity B() {
            tb.o oVar = this.f6014b;
            return oVar != null ? oVar.c() : this.f6015c;
        }

        public void K(Activity activity) {
            this.f6015c = activity;
        }

        @Override // bc.n.b
        public void a(n.e<n.g> eVar) {
            t("signInSilently", eVar);
            b6.i<GoogleSignInAccount> iVarD = this.f6018f.D();
            if (iVarD.q()) {
                J(iVarD);
            } else {
                iVarD.b(new b6.d() { // from class: bc.h
                    @Override // b6.d
                    public final void a(b6.i iVar) {
                        this.f6029a.J(iVar);
                    }
                });
            }
        }

        @Override // bc.n.b
        public void b(n.d dVar) {
            GoogleSignInOptions.a aVar;
            int identifier;
            try {
                int i10 = a.f6012a[dVar.g().ordinal()];
                if (i10 == 1) {
                    aVar = new GoogleSignInOptions.a(GoogleSignInOptions.f7202r);
                } else {
                    if (i10 != 2) {
                        throw new IllegalStateException("Unknown signInOption");
                    }
                    aVar = new GoogleSignInOptions.a(GoogleSignInOptions.f7201l).b();
                }
                String strF = dVar.f();
                if (!c7.n.b(dVar.b()) && c7.n.b(strF)) {
                    Log.w("google_sign_in", "clientId is not supported on Android and is interpreted as serverClientId. Use serverClientId instead to suppress this warning.");
                    strF = dVar.b();
                }
                if (c7.n.b(strF) && (identifier = this.f6013a.getResources().getIdentifier("default_web_client_id", "string", this.f6013a.getPackageName())) != 0) {
                    strF = this.f6013a.getString(identifier);
                }
                if (!c7.n.b(strF)) {
                    aVar.d(strF);
                    aVar.g(strF, dVar.c().booleanValue());
                }
                List<String> listE = dVar.e();
                this.f6019g = listE;
                Iterator<String> it = listE.iterator();
                while (it.hasNext()) {
                    aVar.f(new Scope(it.next()), new Scope[0]);
                }
                if (!c7.n.b(dVar.d())) {
                    aVar.i(dVar.d());
                }
                this.f6018f = this.f6017e.a(this.f6013a, aVar.a());
            } catch (Exception e10) {
                throw new n.a("exception", e10.getMessage(), null);
            }
        }

        @Override // bc.n.b
        public void c(List<String> list, n.e<Boolean> eVar) {
            r("requestScopes", eVar);
            GoogleSignInAccount googleSignInAccountB = this.f6017e.b(this.f6013a);
            if (googleSignInAccountB == null) {
                y("sign_in_required", "No account to grant scopes.");
                return;
            }
            ArrayList arrayList = new ArrayList();
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                Scope scope = new Scope(it.next());
                if (!this.f6017e.c(googleSignInAccountB, scope)) {
                    arrayList.add(scope);
                }
            }
            if (arrayList.isEmpty()) {
                x(Boolean.TRUE);
            } else {
                this.f6017e.d(B(), 53295, googleSignInAccountB, (Scope[]) arrayList.toArray(new Scope[0]));
            }
        }

        @Override // bc.n.b
        public void d(final String str, final Boolean bool, final n.e<String> eVar) {
            this.f6016d.f(new Callable() { // from class: bc.k
                @Override // java.util.concurrent.Callable
                public final Object call() {
                    return this.f6035a.F(str);
                }
            }, new c.a() { // from class: bc.i
                @Override // bc.c.a
                public final void a(Future future) {
                    this.f6030a.G(eVar, bool, str, future);
                }
            });
        }

        @Override // bc.n.b
        public Boolean e() {
            return Boolean.valueOf(com.google.android.gms.auth.api.signin.a.b(this.f6013a) != null);
        }

        @Override // bc.n.b
        public void f(n.e<Void> eVar) {
            v("disconnect", eVar);
            this.f6018f.B().b(new b6.d() { // from class: bc.f
                @Override // b6.d
                public final void a(b6.i iVar) {
                    this.f6027a.E(iVar);
                }
            });
        }

        @Override // bc.n.b
        public void g(final String str, final n.e<Void> eVar) {
            this.f6016d.f(new Callable() { // from class: bc.l
                @Override // java.util.concurrent.Callable
                public final Object call() {
                    return this.f6037a.C(str);
                }
            }, new c.a() { // from class: bc.j
                @Override // bc.c.a
                public final void a(Future future) {
                    e.b.D(eVar, future);
                }
            });
        }

        @Override // bc.n.b
        public void h(n.e<Void> eVar) {
            v("signOut", eVar);
            this.f6018f.C().b(new b6.d() { // from class: bc.g
                @Override // b6.d
                public final void a(b6.i iVar) {
                    this.f6028a.H(iVar);
                }
            });
        }

        @Override // bc.n.b
        public void i(n.e<n.g> eVar) {
            if (B() == null) {
                throw new IllegalStateException("signIn needs a foreground activity");
            }
            t("signIn", eVar);
            B().startActivityForResult(this.f6018f.A(), 53293);
        }

        @Override // tb.m
        public boolean onActivityResult(int i10, int i11, Intent intent) {
            a aVar = this.f6020h;
            if (aVar == null) {
                return false;
            }
            switch (i10) {
                case 53293:
                    if (intent == null) {
                        y("sign_in_failed", "Signin failed");
                        break;
                    } else {
                        J(com.google.android.gms.auth.api.signin.a.c(intent));
                        break;
                    }
                case 53294:
                    if (i11 != -1) {
                        y("failed_to_recover_auth", "Failed attempt to recover authentication");
                        break;
                    } else {
                        n.e<String> eVar = aVar.f6025e;
                        Objects.requireNonNull(eVar);
                        Object obj = this.f6020h.f6026f;
                        Objects.requireNonNull(obj);
                        this.f6020h = null;
                        d((String) obj, Boolean.FALSE, eVar);
                        break;
                    }
                case 53295:
                    x(Boolean.valueOf(i11 == -1));
                    break;
            }
            return false;
        }
    }

    private void a(lb.c cVar) {
        this.f6011c = cVar;
        cVar.a(this.f6009a);
        this.f6009a.K(cVar.c());
    }

    private void b() {
        this.f6009a = null;
        tb.c cVar = this.f6010b;
        if (cVar != null) {
            x.t(cVar, null);
            this.f6010b = null;
        }
    }

    private void c() {
        this.f6011c.e(this.f6009a);
        this.f6009a.K(null);
        this.f6011c = null;
    }

    public void d(tb.c cVar, Context context, m mVar) {
        this.f6010b = cVar;
        b bVar = new b(context, mVar);
        this.f6009a = bVar;
        x.t(cVar, bVar);
    }

    @Override // lb.a
    public void onAttachedToActivity(lb.c cVar) {
        a(cVar);
    }

    @Override // kb.a
    public void onAttachedToEngine(a.b bVar) {
        d(bVar.b(), bVar.a(), new m());
    }

    @Override // lb.a
    public void onDetachedFromActivity() {
        c();
    }

    @Override // lb.a
    public void onDetachedFromActivityForConfigChanges() {
        c();
    }

    @Override // kb.a
    public void onDetachedFromEngine(a.b bVar) {
        b();
    }

    @Override // lb.a
    public void onReattachedToActivityForConfigChanges(lb.c cVar) {
        a(cVar);
    }
}
