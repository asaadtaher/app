package bc;

import bc.n;
import java.util.ArrayList;
import java.util.List;
import tb.a;

/* loaded from: classes.dex */
public final /* synthetic */ class x {

    class a implements n.e<n.g> {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ArrayList f6073a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ a.e f6074b;

        a(ArrayList arrayList, a.e eVar) {
            this.f6073a = arrayList;
            this.f6074b = eVar;
        }

        @Override // bc.n.e
        public void b(Throwable th) {
            this.f6074b.a(n.a(th));
        }

        @Override // bc.n.e
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void a(n.g gVar) {
            this.f6073a.add(0, gVar);
            this.f6074b.a(this.f6073a);
        }
    }

    class b implements n.e<n.g> {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ArrayList f6075a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ a.e f6076b;

        b(ArrayList arrayList, a.e eVar) {
            this.f6075a = arrayList;
            this.f6076b = eVar;
        }

        @Override // bc.n.e
        public void b(Throwable th) {
            this.f6076b.a(n.a(th));
        }

        @Override // bc.n.e
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void a(n.g gVar) {
            this.f6075a.add(0, gVar);
            this.f6076b.a(this.f6075a);
        }
    }

    class c implements n.e<String> {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ArrayList f6077a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ a.e f6078b;

        c(ArrayList arrayList, a.e eVar) {
            this.f6077a = arrayList;
            this.f6078b = eVar;
        }

        @Override // bc.n.e
        public void b(Throwable th) {
            this.f6078b.a(n.a(th));
        }

        @Override // bc.n.e
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void a(String str) {
            this.f6077a.add(0, str);
            this.f6078b.a(this.f6077a);
        }
    }

    class d implements n.e<Void> {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ArrayList f6079a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ a.e f6080b;

        d(ArrayList arrayList, a.e eVar) {
            this.f6079a = arrayList;
            this.f6080b = eVar;
        }

        @Override // bc.n.e
        public void b(Throwable th) {
            this.f6080b.a(n.a(th));
        }

        @Override // bc.n.e
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void a(Void r32) {
            this.f6079a.add(0, null);
            this.f6080b.a(this.f6079a);
        }
    }

    class e implements n.e<Void> {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ArrayList f6081a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ a.e f6082b;

        e(ArrayList arrayList, a.e eVar) {
            this.f6081a = arrayList;
            this.f6082b = eVar;
        }

        @Override // bc.n.e
        public void b(Throwable th) {
            this.f6082b.a(n.a(th));
        }

        @Override // bc.n.e
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void a(Void r32) {
            this.f6081a.add(0, null);
            this.f6082b.a(this.f6081a);
        }
    }

    class f implements n.e<Void> {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ArrayList f6083a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ a.e f6084b;

        f(ArrayList arrayList, a.e eVar) {
            this.f6083a = arrayList;
            this.f6084b = eVar;
        }

        @Override // bc.n.e
        public void b(Throwable th) {
            this.f6084b.a(n.a(th));
        }

        @Override // bc.n.e
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void a(Void r32) {
            this.f6083a.add(0, null);
            this.f6084b.a(this.f6083a);
        }
    }

    class g implements n.e<Boolean> {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ArrayList f6085a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ a.e f6086b;

        g(ArrayList arrayList, a.e eVar) {
            this.f6085a = arrayList;
            this.f6086b = eVar;
        }

        @Override // bc.n.e
        public void b(Throwable th) {
            this.f6086b.a(n.a(th));
        }

        @Override // bc.n.e
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void a(Boolean bool) {
            this.f6085a.add(0, bool);
            this.f6086b.a(this.f6085a);
        }
    }

    public static tb.i<Object> j() {
        return n.c.f6041d;
    }

    public static /* synthetic */ void k(n.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        try {
            bVar.b((n.d) ((ArrayList) obj).get(0));
            arrayList.add(0, null);
        } catch (Throwable th) {
            arrayList = n.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void l(n.b bVar, Object obj, a.e eVar) {
        bVar.a(new a(new ArrayList(), eVar));
    }

    public static /* synthetic */ void m(n.b bVar, Object obj, a.e eVar) {
        bVar.i(new b(new ArrayList(), eVar));
    }

    public static /* synthetic */ void n(n.b bVar, Object obj, a.e eVar) {
        ArrayList arrayList = (ArrayList) obj;
        bVar.d((String) arrayList.get(0), (Boolean) arrayList.get(1), new c(new ArrayList(), eVar));
    }

    public static /* synthetic */ void o(n.b bVar, Object obj, a.e eVar) {
        bVar.h(new d(new ArrayList(), eVar));
    }

    public static /* synthetic */ void p(n.b bVar, Object obj, a.e eVar) {
        bVar.f(new e(new ArrayList(), eVar));
    }

    public static /* synthetic */ void q(n.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        try {
            arrayList.add(0, bVar.e());
        } catch (Throwable th) {
            arrayList = n.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void r(n.b bVar, Object obj, a.e eVar) {
        bVar.g((String) ((ArrayList) obj).get(0), new f(new ArrayList(), eVar));
    }

    public static /* synthetic */ void s(n.b bVar, Object obj, a.e eVar) {
        bVar.c((List) ((ArrayList) obj).get(0), new g(new ArrayList(), eVar));
    }

    public static void t(tb.c cVar, final n.b bVar) {
        tb.a aVar = new tb.a(cVar, "dev.flutter.pigeon.GoogleSignInApi.init", j());
        if (bVar != null) {
            aVar.e(new a.d() { // from class: bc.u
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    x.k(bVar, obj, eVar);
                }
            });
        } else {
            aVar.e(null);
        }
        tb.a aVar2 = new tb.a(cVar, "dev.flutter.pigeon.GoogleSignInApi.signInSilently", j());
        if (bVar != null) {
            aVar2.e(new a.d() { // from class: bc.r
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    x.l(bVar, obj, eVar);
                }
            });
        } else {
            aVar2.e(null);
        }
        tb.a aVar3 = new tb.a(cVar, "dev.flutter.pigeon.GoogleSignInApi.signIn", j());
        if (bVar != null) {
            aVar3.e(new a.d() { // from class: bc.v
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    x.m(bVar, obj, eVar);
                }
            });
        } else {
            aVar3.e(null);
        }
        tb.a aVar4 = new tb.a(cVar, "dev.flutter.pigeon.GoogleSignInApi.getAccessToken", j());
        if (bVar != null) {
            aVar4.e(new a.d() { // from class: bc.o
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    x.n(bVar, obj, eVar);
                }
            });
        } else {
            aVar4.e(null);
        }
        tb.a aVar5 = new tb.a(cVar, "dev.flutter.pigeon.GoogleSignInApi.signOut", j());
        if (bVar != null) {
            aVar5.e(new a.d() { // from class: bc.p
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    x.o(bVar, obj, eVar);
                }
            });
        } else {
            aVar5.e(null);
        }
        tb.a aVar6 = new tb.a(cVar, "dev.flutter.pigeon.GoogleSignInApi.disconnect", j());
        if (bVar != null) {
            aVar6.e(new a.d() { // from class: bc.s
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    x.p(bVar, obj, eVar);
                }
            });
        } else {
            aVar6.e(null);
        }
        tb.a aVar7 = new tb.a(cVar, "dev.flutter.pigeon.GoogleSignInApi.isSignedIn", j());
        if (bVar != null) {
            aVar7.e(new a.d() { // from class: bc.q
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    x.q(bVar, obj, eVar);
                }
            });
        } else {
            aVar7.e(null);
        }
        tb.a aVar8 = new tb.a(cVar, "dev.flutter.pigeon.GoogleSignInApi.clearAuthCache", j());
        if (bVar != null) {
            aVar8.e(new a.d() { // from class: bc.t
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    x.r(bVar, obj, eVar);
                }
            });
        } else {
            aVar8.e(null);
        }
        tb.a aVar9 = new tb.a(cVar, "dev.flutter.pigeon.GoogleSignInApi.requestScopes", j());
        if (bVar != null) {
            aVar9.e(new a.d() { // from class: bc.w
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    x.s(bVar, obj, eVar);
                }
            });
        } else {
            aVar9.e(null);
        }
    }
}
