package bc;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class d {

    static final class a implements Executor {

        /* renamed from: a, reason: collision with root package name */
        private static final Handler f6008a = new Handler(Looper.getMainLooper());

        a() {
        }

        @Override // java.util.concurrent.Executor
        public void execute(Runnable runnable) {
            f6008a.post(runnable);
        }
    }

    public static Executor a() {
        return new a();
    }
}
