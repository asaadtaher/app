package a2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import kb.a;
import tb.j;
import tb.k;
import uc.x;
import x9.e;
import x9.g;
import x9.l;

/* loaded from: classes.dex */
public final class a implements kb.a, k.c {

    public static final C0000a f17b = new C0000a(null);
    private static final g f18c = g.v();
    private k f19a;

    public static final class C0000a {
        private C0000a() {
        }

        public /* synthetic */ C0000a(Object unused) {
            this();
        }
    }

    public static final class b {
        public static final int[] f20a;

        static {
            int[] iArr = new int[g.c.values().length];
            try {
                iArr[g.c.FIXED_LINE.ordinal()] = 1;
            } catch (NoSuchFieldError ignored) {}
            try {
                iArr[g.c.MOBILE.ordinal()] = 2;
            } catch (NoSuchFieldError ignored) {}
            try {
                iArr[g.c.FIXED_LINE_OR_MOBILE.ordinal()] = 3;
            } catch (NoSuchFieldError ignored) {}
            try {
                iArr[g.c.TOLL_FREE.ordinal()] = 4;
            } catch (NoSuchFieldError ignored) {}
            try {
                iArr[g.c.PREMIUM_RATE.ordinal()] = 5;
            } catch (NoSuchFieldError ignored) {}
            try {
                iArr[g.c.SHARED_COST.ordinal()] = 6;
            } catch (NoSuchFieldError ignored) {}
            try {
                iArr[g.c.VOIP.ordinal()] = 7;
            } catch (NoSuchFieldError ignored) {}
            try {
                iArr[g.c.PERSONAL_NUMBER.ordinal()] = 8;
            } catch (NoSuchFieldError ignored) {}
            try {
                iArr[g.c.PAGER.ordinal()] = 9;
            } catch (NoSuchFieldError ignored) {}
            try {
                iArr[g.c.UAN.ordinal()] = 10;
            } catch (NoSuchFieldError ignored) {}
            try {
                iArr[g.c.VOICEMAIL.ordinal()] = 11;
            } catch (NoSuchFieldError ignored) {}
            f20a = iArr;
        }
    }

    private int a(g.c cVar) {
        switch (b.f20a[cVar.ordinal()]) {
            case 1: return 0;
            case 2: return 1;
            case 3: return 2;
            case 4: return 3;
            case 5: return 4;
            case 6: return 5;
            case 7: return 6;
            case 8: return 7;
            case 9: return 8;
            case 10: return 9;
            case 11: return 10;
            default: return -1;
        }
    }

    private g.b b(int i) {
        if (i == 1) return g.b.INTERNATIONAL;
        if (i == 2) return g.b.NATIONAL;
        if (i == 3) return g.b.RFC3966;
        return g.b.E164;
    }

    private g.c c(int i) {
        switch (i) {
            case 0: return g.c.FIXED_LINE;
            case 1: return g.c.MOBILE;
            case 2: return g.c.FIXED_LINE_OR_MOBILE;
            case 3: return g.c.TOLL_FREE;
            case 4: return g.c.PREMIUM_RATE;
            case 5: return g.c.SHARED_COST;
            case 6: return g.c.VOIP;
            case 7: return g.c.PERSONAL_NUMBER;
            case 8: return g.c.PAGER;
            case 9: return g.c.UAN;
            case 10: return g.c.VOICEMAIL;
            default: return g.c.UNKNOWN;
        }
    }

    private void d(j jVar, k.d dVar) {
        String str = (String) jVar.a("phoneNumber");
        x9.a aVarR = f18c.r((String) jVar.a("isoCode"));
        int length = str != null ? str.length() : 0;
        String strM = null;
        for (int i = 0; i < length; i++) {
            Objects.requireNonNull(str);
            strM = aVarR.m(str.charAt(i));
        }
        dVar.a(strM);
    }

    private void e(k.d dVar) {
        dVar.a(x.a0(new ArrayList<>(f18c.G())));
    }

    private void f(j jVar, k.d dVar) {
        String str = (String) jVar.a("isoCode");
        Object objA = jVar.a("type");
        Objects.requireNonNull(objA);
        int iIntValue = ((Number) objA).intValue();
        Object objA2 = jVar.a("format");
        Objects.requireNonNull(objA2);
        int iIntValue2 = ((Number) objA2).intValue();
        g.c cVarC = c(iIntValue);
        g.b bVarB = b(iIntValue2);
        g gVar = f18c;
        dVar.a(gVar.l(gVar.u(str, cVarC), bVarB));
    }

    private void g(j jVar, k.d dVar) {
        String str = (String) jVar.a("phoneNumber");
        String str2 = (String) jVar.a("isoCode");
        try {
            g gVar = f18c;
            g.c t10 = gVar.B(gVar.X(str, str2));
            Objects.requireNonNull(t10, "t is null");
            dVar.a(Integer.valueOf(a(t10)));
        } catch (e e10) {
            dVar.b("NumberParseException", e10.getMessage(), null);
        }
    }

    private void h(j jVar, k.d dVar) throws NumberFormatException {
        String str = (String) jVar.a("phoneNumber");
        String str2 = (String) jVar.a("isoCode");
        try {
            g gVar = f18c;
            l lVarX = gVar.X(str, str2);
            String regionCode = gVar.E(lVarX);
            String strValueOf = String.valueOf(lVarX.c());
            String formattedNumber = gVar.l(lVarX, g.b.NATIONAL);
            HashMap<String, String> map = new HashMap<>();
            Objects.requireNonNull(regionCode, "regionCode is null");
            map.put("isoCode", regionCode);
            map.put("regionCode", strValueOf);
            Objects.requireNonNull(formattedNumber, "formattedNumber is null");
            map.put("formattedPhoneNumber", formattedNumber);
            dVar.a(map);
        } catch (e e10) {
            dVar.b("NumberParseException", e10.getMessage(), null);
        }
    }

    private void i(j jVar, k.d dVar) {
        String str = (String) jVar.a("phoneNumber");
        String str2 = (String) jVar.a("isoCode");
        try {
            g gVar = f18c;
            dVar.a(Boolean.valueOf(gVar.J(gVar.X(str, str2))));
        } catch (e e10) {
            dVar.b("NumberParseException", e10.getMessage(), null);
        }
    }

    private void j(j jVar, k.d dVar) {
        String str = (String) jVar.a("phoneNumber");
        String str2 = (String) jVar.a("isoCode");
        try {
            g gVar = f18c;
            dVar.a(gVar.l(gVar.X(str, str2), g.b.E164));
        } catch (e e10) {
            dVar.b("NumberParseException", e10.getMessage(), null);
        }
    }

    @Override
    public void onAttachedToEngine(a.b flutterPluginBinding) {
        Objects.requireNonNull(flutterPluginBinding, "flutterPluginBinding is null");
        k kVar = new k(flutterPluginBinding.b(), "plugin.libphonenumber");
        this.f19a = kVar;
        Objects.requireNonNull(kVar);
        kVar.e(this);
    }

    @Override
    public void onDetachedFromEngine(a.b binding) {
        Objects.requireNonNull(binding, "binding is null");
        k kVar = this.f19a;
        Objects.requireNonNull(kVar);
        kVar.e(null);
    }

    @Override
    public void onMethodCall(j call, k.d result) throws NumberFormatException {
        Objects.requireNonNull(call, "call is null");
        Objects.requireNonNull(result, "result is null");
        String str = call.f21944a;
        if (str != null) {
            switch (str.hashCode()) {
                case -1952995091:
                    if (str.equals("getFormattedExampleNumber")) {
                        f(call, result);
                        return;
                    }
                    break;
                case -854151888:
                    if (str.equals("formatAsYouType")) {
                        d(call, result);
                        return;
                    }
                    break;
                case -689911271:
                    if (str.equals("getNumberType")) {
                        g(call, result);
                        return;
                    }
                    break;
                case -364250619:
                    if (str.equals("isValidPhoneNumber")) {
                        i(call, result);
                        return;
                    }
                    break;
                case -221570935:
                    if (str.equals("getAllCountries")) {
                        e(result);
                        return;
                    }
                    break;
                case 1784154378:
                    if (str.equals("normalizePhoneNumber")) {
                        j(call, result);
                        return;
                    }
                    break;
                case 2006392248:
                    if (str.equals("getRegionInfo")) {
                        h(call, result);
                        return;
                    }
                    break;
            }
        }
        result.c();
    }
}
