package c0;

import r.a1;
import r.b1;

/* loaded from: classes.dex */
public class a {

    /* renamed from: a, reason: collision with root package name */
    private static final b1 f6108a = new b1(b.a());

    public static <T extends a1> T a(Class<T> cls) {
        return (T) f6108a.b(cls);
    }
}
