package c0;

import android.os.Build;
import r.a1;

/* loaded from: classes.dex */
public class c implements a1 {
    static boolean a() {
        return "XIAOMI".equalsIgnoreCase(Build.MANUFACTURER) && "M2101K7AG".equalsIgnoreCase(Build.MODEL);
    }
}
