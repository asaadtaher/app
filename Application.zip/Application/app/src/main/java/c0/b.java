package c0;

import java.util.ArrayList;
import java.util.List;
import r.a1;

/* loaded from: classes.dex */
public class b {
    static List<a1> a() {
        ArrayList arrayList = new ArrayList();
        if (d.d()) {
            arrayList.add(new d());
        }
        if (c.a()) {
            arrayList.add(new c());
        }
        return arrayList;
    }
}
