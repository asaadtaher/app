package aa;

import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import x9.c;

/* loaded from: classes.dex */
public final class a implements c {

    /* renamed from: a, reason: collision with root package name */
    private static final Logger f389a = Logger.getLogger(a.class.getName());

    @Override // x9.c
    public InputStream a(String str) {
        InputStream resourceAsStream = a.class.getResourceAsStream(str);
        if (resourceAsStream == null) {
            f389a.log(Level.WARNING, String.format("File %s not found", str));
        }
        return resourceAsStream;
    }
}
