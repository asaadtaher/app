package aa;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import x9.i;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: b, reason: collision with root package name */
    private static final Logger f390b = Logger.getLogger(b.class.getName());

    /* renamed from: a, reason: collision with root package name */
    private final boolean f391a;

    private b(boolean z10) {
        this.f391a = z10;
    }

    private void a(InputStream inputStream) throws IOException {
        try {
            inputStream.close();
        } catch (IOException e10) {
            f390b.log(Level.WARNING, "Error closing input stream (ignored)", (Throwable) e10);
        }
    }

    private List<i> b() {
        if (this.f391a) {
            throw new IllegalArgumentException("Source cannot be null");
        }
        return Collections.emptyList();
    }

    public static b c() {
        return new b(false);
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0045  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0049  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.util.Collection<x9.i> d(java.io.InputStream r6) throws java.lang.Throwable {
        /*
            r5 = this;
            if (r6 != 0) goto L7
            java.util.List r6 = r5.b()
            return r6
        L7:
            r0 = 0
            java.io.ObjectInputStream r1 = new java.io.ObjectInputStream     // Catch: java.lang.Throwable -> L31 java.io.IOException -> L36
            r1.<init>(r6)     // Catch: java.lang.Throwable -> L31 java.io.IOException -> L36
            x9.j r0 = new x9.j     // Catch: java.io.IOException -> L2f java.lang.Throwable -> L42
            r0.<init>()     // Catch: java.io.IOException -> L2f java.lang.Throwable -> L42
            r0.readExternal(r1)     // Catch: java.io.IOException -> L2f java.lang.Throwable -> L42
            java.util.List r2 = r0.b()     // Catch: java.io.IOException -> L2f java.lang.Throwable -> L42
            boolean r2 = r2.isEmpty()     // Catch: java.io.IOException -> L2f java.lang.Throwable -> L42
            if (r2 != 0) goto L27
            java.util.List r6 = r0.b()     // Catch: java.io.IOException -> L2f java.lang.Throwable -> L42
            r5.a(r1)
            return r6
        L27:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch: java.io.IOException -> L2f java.lang.Throwable -> L42
            java.lang.String r2 = "Empty metadata"
            r0.<init>(r2)     // Catch: java.io.IOException -> L2f java.lang.Throwable -> L42
            throw r0     // Catch: java.io.IOException -> L2f java.lang.Throwable -> L42
        L2f:
            r0 = move-exception
            goto L3a
        L31:
            r1 = move-exception
            r4 = r1
            r1 = r0
            r0 = r4
            goto L43
        L36:
            r1 = move-exception
            r4 = r1
            r1 = r0
            r0 = r4
        L3a:
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException     // Catch: java.lang.Throwable -> L42
            java.lang.String r3 = "Unable to parse metadata file"
            r2.<init>(r3, r0)     // Catch: java.lang.Throwable -> L42
            throw r2     // Catch: java.lang.Throwable -> L42
        L42:
            r0 = move-exception
        L43:
            if (r1 == 0) goto L49
            r5.a(r1)
            goto L4c
        L49:
            r5.a(r6)
        L4c:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: aa.b.d(java.io.InputStream):java.util.Collection");
    }
}
