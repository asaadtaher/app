package a0;

import android.util.Size;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: c, reason: collision with root package name */
    public static final d f13c = new d();

    /* renamed from: a, reason: collision with root package name */
    private Size f14a;

    /* renamed from: b, reason: collision with root package name */
    private int f15b;

    private d() {
        this.f14a = null;
        this.f15b = 0;
    }

    public d(Size size, int i10) {
        this.f14a = null;
        this.f15b = 0;
        this.f14a = size;
        this.f15b = i10;
    }

    public Size a() {
        return this.f14a;
    }

    public int b() {
        return this.f15b;
    }
}
