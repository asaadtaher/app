package a0;

import android.util.Size;
import java.util.List;

/* loaded from: classes.dex */
public interface b {
    List<Size> a(List<Size> list, int i10);
}
