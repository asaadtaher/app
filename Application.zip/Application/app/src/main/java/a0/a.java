package a0;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: c, reason: collision with root package name */
    public static final a f1c = new a(0, 1);

    /* renamed from: d, reason: collision with root package name */
    public static final a f2d = new a(1, 1);

    /* renamed from: a, reason: collision with root package name */
    private final int f3a;

    /* renamed from: b, reason: collision with root package name */
    private final int f4b;

    public a(int i10, int i11) {
        this.f3a = i10;
        this.f4b = i11;
    }

    public int a() {
        return this.f4b;
    }

    public int b() {
        return this.f3a;
    }
}
