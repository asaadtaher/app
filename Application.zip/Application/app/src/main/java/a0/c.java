package a0;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    private final a0.a f5a;

    /* renamed from: b, reason: collision with root package name */
    private final d f6b;

    /* renamed from: c, reason: collision with root package name */
    private final b f7c;

    /* renamed from: d, reason: collision with root package name */
    private final int f8d;

    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        private a0.a f9a;

        /* renamed from: b, reason: collision with root package name */
        private d f10b;

        /* renamed from: c, reason: collision with root package name */
        private b f11c;

        /* renamed from: d, reason: collision with root package name */
        private int f12d;

        public a() {
            this.f9a = a0.a.f1c;
            this.f10b = null;
            this.f11c = null;
            this.f12d = 0;
        }

        private a(c cVar) {
            this.f9a = a0.a.f1c;
            this.f10b = null;
            this.f11c = null;
            this.f12d = 0;
            this.f9a = cVar.b();
            this.f10b = cVar.d();
            this.f11c = cVar.c();
            this.f12d = cVar.a();
        }

        public static a b(c cVar) {
            return new a(cVar);
        }

        public c a() {
            return new c(this.f9a, this.f10b, this.f11c, this.f12d);
        }

        public a c(int i10) {
            this.f12d = i10;
            return this;
        }

        public a d(a0.a aVar) {
            this.f9a = aVar;
            return this;
        }

        public a e(b bVar) {
            this.f11c = bVar;
            return this;
        }

        public a f(d dVar) {
            this.f10b = dVar;
            return this;
        }
    }

    c(a0.a aVar, d dVar, b bVar, int i10) {
        this.f5a = aVar;
        this.f6b = dVar;
        this.f7c = bVar;
        this.f8d = i10;
    }

    public int a() {
        return this.f8d;
    }

    public a0.a b() {
        return this.f5a;
    }

    public b c() {
        return this.f7c;
    }

    public d d() {
        return this.f6b;
    }
}
