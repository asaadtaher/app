package ac;

import kb.a;

/* loaded from: classes.dex */
public class a implements kb.a {
    @Override // kb.a
    public void onAttachedToEngine(a.b bVar) {
    }

    @Override // kb.a
    public void onDetachedFromEngine(a.b bVar) {
    }
}
