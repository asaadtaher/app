package ce;

import java.util.Arrays;
import java.util.logging.Logger;
import kotlin.jvm.internal.m;
import kotlin.jvm.internal.w;

/* loaded from: classes2.dex */
public final class b {
    public static final String b(long j10) {
        StringBuilder sb2;
        long j11;
        StringBuilder sb3;
        long j12;
        long j13;
        String string;
        if (j10 > -999500000) {
            if (j10 > -999500) {
                if (j10 <= 0) {
                    sb3 = new StringBuilder();
                    j13 = j10 - 500;
                } else if (j10 < 999500) {
                    sb3 = new StringBuilder();
                    j13 = j10 + 500;
                } else if (j10 < 999500000) {
                    sb3 = new StringBuilder();
                    j12 = j10 + 500000;
                } else {
                    sb2 = new StringBuilder();
                    j11 = j10 + 500000000;
                }
                sb3.append(j13 / 1000);
                sb3.append(" µs");
                string = sb3.toString();
                w wVar = w.f17306a;
                String str = String.format("%6s", Arrays.copyOf(new Object[]{string}, 1));
                m.f(str, "format(format, *args)");
                return str;
            }
            sb3 = new StringBuilder();
            j12 = j10 - 500000;
            sb3.append(j12 / 1000000);
            sb3.append(" ms");
            string = sb3.toString();
            w wVar2 = w.f17306a;
            String str2 = String.format("%6s", Arrays.copyOf(new Object[]{string}, 1));
            m.f(str2, "format(format, *args)");
            return str2;
        }
        sb2 = new StringBuilder();
        j11 = j10 - 500000000;
        sb2.append(j11 / 1000000000);
        sb2.append(" s ");
        string = sb2.toString();
        w wVar22 = w.f17306a;
        String str22 = String.format("%6s", Arrays.copyOf(new Object[]{string}, 1));
        m.f(str22, "format(format, *args)");
        return str22;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void c(a aVar, d dVar, String str) {
        Logger loggerA = e.f6786h.a();
        StringBuilder sb2 = new StringBuilder();
        sb2.append(dVar.f());
        sb2.append(' ');
        w wVar = w.f17306a;
        String str2 = String.format("%-22s", Arrays.copyOf(new Object[]{str}, 1));
        m.f(str2, "format(format, *args)");
        sb2.append(str2);
        sb2.append(": ");
        sb2.append(aVar.b());
        loggerA.fine(sb2.toString());
    }
}
