package ce;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;
import java.util.logging.Level;
import kotlin.jvm.internal.m;
import tc.x;

/* loaded from: classes2.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    private final e f6780a;

    /* renamed from: b, reason: collision with root package name */
    private final String f6781b;

    /* renamed from: c, reason: collision with root package name */
    private boolean f6782c;

    /* renamed from: d, reason: collision with root package name */
    private a f6783d;

    /* renamed from: e, reason: collision with root package name */
    private final List<a> f6784e;

    /* renamed from: f, reason: collision with root package name */
    private boolean f6785f;

    public d(e taskRunner, String name) {
        m.g(taskRunner, "taskRunner");
        m.g(name, "name");
        this.f6780a = taskRunner;
        this.f6781b = name;
        this.f6784e = new ArrayList();
    }

    public static /* synthetic */ void j(d dVar, a aVar, long j10, int i10, Object obj) {
        if ((i10 & 2) != 0) {
            j10 = 0;
        }
        dVar.i(aVar, j10);
    }

    public final void a() {
        if (zd.d.f25117h && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
        }
        synchronized (this.f6780a) {
            if (b()) {
                this.f6780a.h(this);
            }
            x xVar = x.f21992a;
        }
    }

    public final boolean b() {
        a aVar = this.f6783d;
        if (aVar != null) {
            m.d(aVar);
            if (aVar.a()) {
                this.f6785f = true;
            }
        }
        boolean z10 = false;
        for (int size = this.f6784e.size() - 1; -1 < size; size--) {
            if (this.f6784e.get(size).a()) {
                a aVar2 = this.f6784e.get(size);
                if (e.f6786h.a().isLoggable(Level.FINE)) {
                    b.c(aVar2, this, "canceled");
                }
                this.f6784e.remove(size);
                z10 = true;
            }
        }
        return z10;
    }

    public final a c() {
        return this.f6783d;
    }

    public final boolean d() {
        return this.f6785f;
    }

    public final List<a> e() {
        return this.f6784e;
    }

    public final String f() {
        return this.f6781b;
    }

    public final boolean g() {
        return this.f6782c;
    }

    public final e h() {
        return this.f6780a;
    }

    public final void i(a task, long j10) {
        m.g(task, "task");
        synchronized (this.f6780a) {
            if (!this.f6782c) {
                if (k(task, j10, false)) {
                    this.f6780a.h(this);
                }
                x xVar = x.f21992a;
            } else if (task.a()) {
                if (e.f6786h.a().isLoggable(Level.FINE)) {
                    b.c(task, this, "schedule canceled (queue is shutdown)");
                }
            } else {
                if (e.f6786h.a().isLoggable(Level.FINE)) {
                    b.c(task, this, "schedule failed (queue is shutdown)");
                }
                throw new RejectedExecutionException();
            }
        }
    }

    public final boolean k(a task, long j10, boolean z10) {
        StringBuilder sb2;
        String str;
        m.g(task, "task");
        task.e(this);
        long jC = this.f6780a.g().c();
        long j11 = jC + j10;
        int iIndexOf = this.f6784e.indexOf(task);
        if (iIndexOf != -1) {
            if (task.c() <= j11) {
                if (e.f6786h.a().isLoggable(Level.FINE)) {
                    b.c(task, this, "already scheduled");
                }
                return false;
            }
            this.f6784e.remove(iIndexOf);
        }
        task.g(j11);
        if (e.f6786h.a().isLoggable(Level.FINE)) {
            if (z10) {
                sb2 = new StringBuilder();
                str = "run again after ";
            } else {
                sb2 = new StringBuilder();
                str = "scheduled after ";
            }
            sb2.append(str);
            sb2.append(b.b(j11 - jC));
            b.c(task, this, sb2.toString());
        }
        Iterator<a> it = this.f6784e.iterator();
        int size = 0;
        while (true) {
            if (!it.hasNext()) {
                size = -1;
                break;
            }
            if (it.next().c() - jC > j10) {
                break;
            }
            size++;
        }
        if (size == -1) {
            size = this.f6784e.size();
        }
        this.f6784e.add(size, task);
        return size == 0;
    }

    public final void l(a aVar) {
        this.f6783d = aVar;
    }

    public final void m(boolean z10) {
        this.f6785f = z10;
    }

    public final void n() {
        if (zd.d.f25117h && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
        }
        synchronized (this.f6780a) {
            this.f6782c = true;
            if (b()) {
                this.f6780a.h(this);
            }
            x xVar = x.f21992a;
        }
    }

    public String toString() {
        return this.f6781b;
    }
}
