package ce;

import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;

/* loaded from: classes2.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    private final String f6775a;

    /* renamed from: b, reason: collision with root package name */
    private final boolean f6776b;

    /* renamed from: c, reason: collision with root package name */
    private d f6777c;

    /* renamed from: d, reason: collision with root package name */
    private long f6778d;

    public a(String name, boolean z10) {
        m.g(name, "name");
        this.f6775a = name;
        this.f6776b = z10;
        this.f6778d = -1L;
    }

    public /* synthetic */ a(String str, boolean z10, int i10, g gVar) {
        this(str, (i10 & 2) != 0 ? true : z10);
    }

    public final boolean a() {
        return this.f6776b;
    }

    public final String b() {
        return this.f6775a;
    }

    public final long c() {
        return this.f6778d;
    }

    public final d d() {
        return this.f6777c;
    }

    public final void e(d queue) {
        m.g(queue, "queue");
        d dVar = this.f6777c;
        if (dVar == queue) {
            return;
        }
        if (!(dVar == null)) {
            throw new IllegalStateException("task is in multiple queues".toString());
        }
        this.f6777c = queue;
    }

    public abstract long f();

    public final void g(long j10) {
        this.f6778d = j10;
    }

    public String toString() {
        return this.f6775a;
    }
}
