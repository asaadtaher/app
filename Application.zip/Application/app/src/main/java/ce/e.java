package ce;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;
import tc.x;

/* loaded from: classes2.dex */
public final class e {

    /* renamed from: h, reason: collision with root package name */
    public static final b f6786h = new b(null);

    /* renamed from: i, reason: collision with root package name */
    public static final e f6787i = new e(new c(zd.d.M(zd.d.f25118i + " TaskRunner", true)));

    /* renamed from: j, reason: collision with root package name */
    private static final Logger f6788j;

    /* renamed from: a, reason: collision with root package name */
    private final a f6789a;

    /* renamed from: b, reason: collision with root package name */
    private int f6790b;

    /* renamed from: c, reason: collision with root package name */
    private boolean f6791c;

    /* renamed from: d, reason: collision with root package name */
    private long f6792d;

    /* renamed from: e, reason: collision with root package name */
    private final List<ce.d> f6793e;

    /* renamed from: f, reason: collision with root package name */
    private final List<ce.d> f6794f;

    /* renamed from: g, reason: collision with root package name */
    private final Runnable f6795g;

    public interface a {
        void a(e eVar);

        void b(e eVar, long j10);

        long c();

        void execute(Runnable runnable);
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(g gVar) {
            this();
        }

        public final Logger a() {
            return e.f6788j;
        }
    }

    public static final class c implements a {

        /* renamed from: a, reason: collision with root package name */
        private final ThreadPoolExecutor f6796a;

        public c(ThreadFactory threadFactory) {
            m.g(threadFactory, "threadFactory");
            this.f6796a = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS, new SynchronousQueue(), threadFactory);
        }

        @Override // ce.e.a
        public void a(e taskRunner) {
            m.g(taskRunner, "taskRunner");
            taskRunner.notify();
        }

        @Override // ce.e.a
        public void b(e taskRunner, long j10) throws InterruptedException {
            m.g(taskRunner, "taskRunner");
            long j11 = j10 / 1000000;
            long j12 = j10 - (1000000 * j11);
            if (j11 > 0 || j10 > 0) {
                taskRunner.wait(j11, (int) j12);
            }
        }

        @Override // ce.e.a
        public long c() {
            return System.nanoTime();
        }

        @Override // ce.e.a
        public void execute(Runnable runnable) {
            m.g(runnable, "runnable");
            this.f6796a.execute(runnable);
        }
    }

    public static final class d implements Runnable {
        d() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ce.a aVarD;
            while (true) {
                e eVar = e.this;
                synchronized (eVar) {
                    aVarD = eVar.d();
                }
                if (aVarD == null) {
                    return;
                }
                ce.d dVarD = aVarD.d();
                m.d(dVarD);
                e eVar2 = e.this;
                long jC = -1;
                boolean zIsLoggable = e.f6786h.a().isLoggable(Level.FINE);
                if (zIsLoggable) {
                    jC = dVarD.h().g().c();
                    ce.b.c(aVarD, dVarD, "starting");
                }
                try {
                    try {
                        eVar2.j(aVarD);
                        x xVar = x.f21992a;
                        if (zIsLoggable) {
                            ce.b.c(aVarD, dVarD, "finished run in " + ce.b.b(dVarD.h().g().c() - jC));
                        }
                    } finally {
                    }
                } catch (Throwable th) {
                    if (zIsLoggable) {
                        ce.b.c(aVarD, dVarD, "failed a run in " + ce.b.b(dVarD.h().g().c() - jC));
                    }
                    throw th;
                }
            }
        }
    }

    static {
        Logger logger = Logger.getLogger(e.class.getName());
        m.f(logger, "getLogger(TaskRunner::class.java.name)");
        f6788j = logger;
    }

    public e(a backend) {
        m.g(backend, "backend");
        this.f6789a = backend;
        this.f6790b = 10000;
        this.f6793e = new ArrayList();
        this.f6794f = new ArrayList();
        this.f6795g = new d();
    }

    private final void c(ce.a aVar, long j10) {
        if (zd.d.f25117h && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
        }
        ce.d dVarD = aVar.d();
        m.d(dVarD);
        if (!(dVarD.c() == aVar)) {
            throw new IllegalStateException("Check failed.".toString());
        }
        boolean zD = dVarD.d();
        dVarD.m(false);
        dVarD.l(null);
        this.f6793e.remove(dVarD);
        if (j10 != -1 && !zD && !dVarD.g()) {
            dVarD.k(aVar, j10, true);
        }
        if (!dVarD.e().isEmpty()) {
            this.f6794f.add(dVarD);
        }
    }

    private final void e(ce.a aVar) {
        if (zd.d.f25117h && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
        }
        aVar.g(-1L);
        ce.d dVarD = aVar.d();
        m.d(dVarD);
        dVarD.e().remove(aVar);
        this.f6794f.remove(dVarD);
        dVarD.l(aVar);
        this.f6793e.add(dVarD);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void j(ce.a aVar) {
        if (zd.d.f25117h && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
        }
        Thread threadCurrentThread = Thread.currentThread();
        String name = threadCurrentThread.getName();
        threadCurrentThread.setName(aVar.b());
        try {
            long jF = aVar.f();
            synchronized (this) {
                c(aVar, jF);
                x xVar = x.f21992a;
            }
            threadCurrentThread.setName(name);
        } catch (Throwable th) {
            synchronized (this) {
                c(aVar, -1L);
                x xVar2 = x.f21992a;
                threadCurrentThread.setName(name);
                throw th;
            }
        }
    }

    public final ce.a d() {
        boolean z10;
        if (zd.d.f25117h && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
        }
        while (!this.f6794f.isEmpty()) {
            long jC = this.f6789a.c();
            long jMin = Long.MAX_VALUE;
            Iterator<ce.d> it = this.f6794f.iterator();
            ce.a aVar = null;
            while (true) {
                if (!it.hasNext()) {
                    z10 = false;
                    break;
                }
                ce.a aVar2 = it.next().e().get(0);
                long jMax = Math.max(0L, aVar2.c() - jC);
                if (jMax > 0) {
                    jMin = Math.min(jMax, jMin);
                } else {
                    if (aVar != null) {
                        z10 = true;
                        break;
                    }
                    aVar = aVar2;
                }
            }
            if (aVar != null) {
                e(aVar);
                if (z10 || (!this.f6791c && (!this.f6794f.isEmpty()))) {
                    this.f6789a.execute(this.f6795g);
                }
                return aVar;
            }
            if (this.f6791c) {
                if (jMin < this.f6792d - jC) {
                    this.f6789a.a(this);
                }
                return null;
            }
            this.f6791c = true;
            this.f6792d = jC + jMin;
            try {
                try {
                    this.f6789a.b(this, jMin);
                } catch (InterruptedException unused) {
                    f();
                }
            } finally {
                this.f6791c = false;
            }
        }
        return null;
    }

    public final void f() {
        int size = this.f6793e.size();
        while (true) {
            size--;
            if (-1 >= size) {
                break;
            } else {
                this.f6793e.get(size).b();
            }
        }
        for (int size2 = this.f6794f.size() - 1; -1 < size2; size2--) {
            ce.d dVar = this.f6794f.get(size2);
            dVar.b();
            if (dVar.e().isEmpty()) {
                this.f6794f.remove(size2);
            }
        }
    }

    public final a g() {
        return this.f6789a;
    }

    public final void h(ce.d taskQueue) {
        m.g(taskQueue, "taskQueue");
        if (zd.d.f25117h && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
        }
        if (taskQueue.c() == null) {
            if (!taskQueue.e().isEmpty()) {
                zd.d.c(this.f6794f, taskQueue);
            } else {
                this.f6794f.remove(taskQueue);
            }
        }
        if (this.f6791c) {
            this.f6789a.a(this);
        } else {
            this.f6789a.execute(this.f6795g);
        }
    }

    public final ce.d i() {
        int i10;
        synchronized (this) {
            i10 = this.f6790b;
            this.f6790b = i10 + 1;
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append('Q');
        sb2.append(i10);
        return new ce.d(this, sb2.toString());
    }
}
