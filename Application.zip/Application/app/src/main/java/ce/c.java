package ce;

import tc.x;

/* loaded from: classes2.dex */
public final class c extends a {

    /* renamed from: e, reason: collision with root package name */
    final /* synthetic */ ed.a<x> f6779e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(String str, boolean z10, ed.a<x> aVar) {
        super(str, z10);
        this.f6779e = aVar;
    }

    @Override // ce.a
    public long f() {
        this.f6779e.invoke();
        return -1L;
    }
}
