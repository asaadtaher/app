package ad;

import kotlin.jvm.internal.m;

/* loaded from: classes2.dex */
public class a extends zc.a {

    /* renamed from: ad.a$a, reason: collision with other inner class name */
    private static final class C0005a {

        /* renamed from: a, reason: collision with root package name */
        public static final C0005a f393a = new C0005a();

        /* renamed from: b, reason: collision with root package name */
        public static final Integer f394b;

        static {
            Object obj;
            Integer num = null;
            try {
                obj = Class.forName("android.os.Build$VERSION").getField("SDK_INT").get(null);
            } catch (Throwable unused) {
            }
            Integer num2 = obj instanceof Integer ? (Integer) obj : null;
            if (num2 != null) {
                if (num2.intValue() > 0) {
                    num = num2;
                }
            }
            f394b = num;
        }

        private C0005a() {
        }
    }

    private final boolean c(int i10) {
        Integer num = C0005a.f394b;
        return num == null || num.intValue() >= i10;
    }

    @Override // zc.a
    public void a(Throwable cause, Throwable exception) {
        m.g(cause, "cause");
        m.g(exception, "exception");
        if (c(19)) {
            cause.addSuppressed(exception);
        } else {
            super.a(cause, exception);
        }
    }
}
