package b8;

import b6.i;

/* loaded from: classes.dex */
public interface b {
    i<a8.a> b(boolean z10);

    void c(a aVar);

    void d(a aVar);
}
