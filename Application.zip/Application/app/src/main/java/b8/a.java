package b8;

/* loaded from: classes.dex */
public interface a {
}
