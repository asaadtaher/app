package c8;

/* loaded from: classes.dex */
public class a {

    /* renamed from: a, reason: collision with root package name */
    private String f6713a;

    public String a() {
        return this.f6713a;
    }
}
