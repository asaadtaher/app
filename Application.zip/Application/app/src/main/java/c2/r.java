package c2;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import b2.r0;
import c2.o;
import c2.r;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.Currency;
import java.util.HashSet;
import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import r2.l0;
import r2.m0;
import r2.n;
import r2.y;

/* loaded from: classes.dex */
public final class r {

    /* renamed from: c, reason: collision with root package name */
    public static final a f6234c = new a(null);

    /* renamed from: d, reason: collision with root package name */
    private static final String f6235d;

    /* renamed from: e, reason: collision with root package name */
    private static ScheduledThreadPoolExecutor f6236e;

    /* renamed from: f, reason: collision with root package name */
    private static o.b f6237f;

    /* renamed from: g, reason: collision with root package name */
    private static final Object f6238g;

    /* renamed from: h, reason: collision with root package name */
    private static String f6239h;

    /* renamed from: i, reason: collision with root package name */
    private static boolean f6240i;

    /* renamed from: j, reason: collision with root package name */
    private static String f6241j;

    /* renamed from: a, reason: collision with root package name */
    private final String f6242a;

    /* renamed from: b, reason: collision with root package name */
    private c2.a f6243b;

    public static final class a {

        /* renamed from: c2.r$a$a, reason: collision with other inner class name */
        public static final class C0104a implements y.a {
            C0104a() {
            }

            @Override // r2.y.a
            public void a(String str) {
                r.f6234c.t(str);
            }
        }

        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void n(Context context, r logger) throws ClassNotFoundException {
            kotlin.jvm.internal.m.g(context, "$context");
            kotlin.jvm.internal.m.g(logger, "$logger");
            Bundle bundle = new Bundle();
            String[] strArr = {"com.facebook.core.Core", "com.facebook.login.Login", "com.facebook.share.Share", "com.facebook.places.Places", "com.facebook.messenger.Messenger", "com.facebook.applinks.AppLinks", "com.facebook.marketing.Marketing", "com.facebook.gamingservices.GamingServices", "com.facebook.all.All", "com.android.billingclient.api.BillingClient", "com.android.vending.billing.IInAppBillingService"};
            String[] strArr2 = {"core_lib_included", "login_lib_included", "share_lib_included", "places_lib_included", "messenger_lib_included", "applinks_lib_included", "marketing_lib_included", "gamingservices_lib_included", "all_lib_included", "billing_client_lib_included", "billing_service_lib_included"};
            int i10 = 0;
            int i11 = 0;
            while (true) {
                int i12 = i10 + 1;
                String str = strArr[i10];
                String str2 = strArr2[i10];
                try {
                    Class.forName(str);
                    bundle.putInt(str2, 1);
                    i11 |= 1 << i10;
                } catch (ClassNotFoundException unused) {
                }
                if (i12 > 10) {
                    break;
                } else {
                    i10 = i12;
                }
            }
            SharedPreferences sharedPreferences = context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0);
            if (sharedPreferences.getInt("kitsBitmask", 0) != i11) {
                sharedPreferences.edit().putInt("kitsBitmask", i11).apply();
                logger.o("fb_sdk_initialize", null, bundle);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final void o() {
            synchronized (r.e()) {
                if (r.b() != null) {
                    return;
                }
                a aVar = r.f6234c;
                r.i(new ScheduledThreadPoolExecutor(1));
                tc.x xVar = tc.x.f21992a;
                q qVar = new Runnable() { // from class: c2.q
                    @Override // java.lang.Runnable
                    public final void run() throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
                        r.a.p();
                    }
                };
                ScheduledThreadPoolExecutor scheduledThreadPoolExecutorB = r.b();
                if (scheduledThreadPoolExecutorB == null) {
                    throw new IllegalStateException("Required value was null.".toString());
                }
                scheduledThreadPoolExecutorB.scheduleAtFixedRate(qVar, 0L, 86400L, TimeUnit.SECONDS);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void p() throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
            HashSet<String> hashSet = new HashSet();
            m mVar = m.f6216a;
            Iterator<c2.a> it = m.p().iterator();
            while (it.hasNext()) {
                hashSet.add(it.next().b());
            }
            for (String str : hashSet) {
                r2.v vVar = r2.v.f20292a;
                r2.v.n(str, true);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final void q(d dVar, c2.a aVar) {
            m mVar = m.f6216a;
            m.g(aVar, dVar);
            r2.n nVar = r2.n.f20187a;
            if (r2.n.g(n.b.OnDevicePostInstallEventProcessing)) {
                m2.c cVar = m2.c.f17685a;
                if (m2.c.d()) {
                    m2.c.e(aVar.b(), dVar);
                }
            }
            if (dVar.c() || r.f()) {
                return;
            }
            if (kotlin.jvm.internal.m.b(dVar.f(), "fb_mobile_activate_app")) {
                r.g(true);
            } else {
                r2.c0.f20089e.b(r0.APP_EVENTS, "AppEvents", "Warning: Please call AppEventsLogger.activateApp(...)from the long-lived activity's onResume() methodbefore logging other app events.");
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final void r(String str) {
            r2.c0.f20089e.b(r0.DEVELOPER_ERRORS, "AppEvents", str);
        }

        public final void f(Application application, String str) {
            kotlin.jvm.internal.m.g(application, "application");
            b2.f0 f0Var = b2.f0.f5388a;
            if (!b2.f0.F()) {
                throw new b2.s("The Facebook sdk must be initialized before calling activateApp");
            }
            c cVar = c.f6162a;
            c.d();
            g0 g0Var = g0.f6203a;
            g0.e();
            if (str == null) {
                str = b2.f0.m();
            }
            b2.f0.K(application, str);
            k2.f fVar = k2.f.f16906a;
            k2.f.x(application, str);
        }

        public final void g() {
            if (j() != o.b.EXPLICIT_ONLY) {
                m mVar = m.f6216a;
                m.l(z.EAGER_FLUSHING_EVENT);
            }
        }

        public final Executor h() {
            if (r.b() == null) {
                o();
            }
            ScheduledThreadPoolExecutor scheduledThreadPoolExecutorB = r.b();
            if (scheduledThreadPoolExecutorB != null) {
                return scheduledThreadPoolExecutorB;
            }
            throw new IllegalStateException("Required value was null.".toString());
        }

        public final String i(Context context) {
            kotlin.jvm.internal.m.g(context, "context");
            if (r.a() == null) {
                synchronized (r.e()) {
                    if (r.a() == null) {
                        SharedPreferences sharedPreferences = context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0);
                        a aVar = r.f6234c;
                        r.h(sharedPreferences.getString("anonymousAppDeviceGUID", null));
                        if (r.a() == null) {
                            UUID uuidRandomUUID = UUID.randomUUID();
                            kotlin.jvm.internal.m.f(uuidRandomUUID, "randomUUID()");
                            r.h(kotlin.jvm.internal.m.n("XZ", uuidRandomUUID));
                            context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).edit().putString("anonymousAppDeviceGUID", r.a()).apply();
                        }
                    }
                    tc.x xVar = tc.x.f21992a;
                }
            }
            String strA = r.a();
            if (strA != null) {
                return strA;
            }
            throw new IllegalStateException("Required value was null.".toString());
        }

        public final o.b j() {
            o.b bVarC;
            synchronized (r.e()) {
                bVarC = r.c();
            }
            return bVarC;
        }

        public final String k() {
            r2.y yVar = r2.y.f20310a;
            r2.y.d(new C0104a());
            b2.f0 f0Var = b2.f0.f5388a;
            return b2.f0.l().getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).getString("install_referrer", null);
        }

        public final String l() {
            String strD;
            synchronized (r.e()) {
                strD = r.d();
            }
            return strD;
        }

        public final void m(final Context context, String str) {
            kotlin.jvm.internal.m.g(context, "context");
            b2.f0 f0Var = b2.f0.f5388a;
            if (b2.f0.p()) {
                final r rVar = new r(context, str, (b2.a) null);
                ScheduledThreadPoolExecutor scheduledThreadPoolExecutorB = r.b();
                if (scheduledThreadPoolExecutorB == null) {
                    throw new IllegalStateException("Required value was null.".toString());
                }
                scheduledThreadPoolExecutorB.execute(new Runnable() { // from class: c2.p
                    @Override // java.lang.Runnable
                    public final void run() throws ClassNotFoundException {
                        r.a.n(context, rVar);
                    }
                });
            }
        }

        public final void s() {
            m mVar = m.f6216a;
            m.s();
        }

        public final void t(String str) {
            b2.f0 f0Var = b2.f0.f5388a;
            SharedPreferences sharedPreferences = b2.f0.l().getSharedPreferences("com.facebook.sdk.appEventPreferences", 0);
            if (str != null) {
                sharedPreferences.edit().putString("install_referrer", str).apply();
            }
        }
    }

    static {
        String canonicalName = r.class.getCanonicalName();
        if (canonicalName == null) {
            canonicalName = "com.facebook.appevents.AppEventsLoggerImpl";
        }
        f6235d = canonicalName;
        f6237f = o.b.AUTO;
        f6238g = new Object();
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public r(Context context, String str, b2.a aVar) {
        this(l0.t(context), str, aVar);
        l0 l0Var = l0.f20174a;
    }

    public r(String activityName, String str, b2.a aVar) {
        c2.a aVar2;
        kotlin.jvm.internal.m.g(activityName, "activityName");
        m0 m0Var = m0.f20185a;
        m0.l();
        this.f6242a = activityName;
        aVar = aVar == null ? b2.a.f5323l.e() : aVar;
        if (aVar == null || aVar.y() || !(str == null || kotlin.jvm.internal.m.b(str, aVar.i()))) {
            if (str == null) {
                l0 l0Var = l0.f20174a;
                b2.f0 f0Var = b2.f0.f5388a;
                str = l0.F(b2.f0.l());
            }
            if (str == null) {
                throw new IllegalStateException("Required value was null.".toString());
            }
            aVar2 = new c2.a(null, str);
        } else {
            aVar2 = new c2.a(aVar);
        }
        this.f6243b = aVar2;
        f6234c.o();
    }

    public static final /* synthetic */ String a() {
        if (w2.a.d(r.class)) {
            return null;
        }
        try {
            return f6239h;
        } catch (Throwable th) {
            w2.a.b(th, r.class);
            return null;
        }
    }

    public static final /* synthetic */ ScheduledThreadPoolExecutor b() {
        if (w2.a.d(r.class)) {
            return null;
        }
        try {
            return f6236e;
        } catch (Throwable th) {
            w2.a.b(th, r.class);
            return null;
        }
    }

    public static final /* synthetic */ o.b c() {
        if (w2.a.d(r.class)) {
            return null;
        }
        try {
            return f6237f;
        } catch (Throwable th) {
            w2.a.b(th, r.class);
            return null;
        }
    }

    public static final /* synthetic */ String d() {
        if (w2.a.d(r.class)) {
            return null;
        }
        try {
            return f6241j;
        } catch (Throwable th) {
            w2.a.b(th, r.class);
            return null;
        }
    }

    public static final /* synthetic */ Object e() {
        if (w2.a.d(r.class)) {
            return null;
        }
        try {
            return f6238g;
        } catch (Throwable th) {
            w2.a.b(th, r.class);
            return null;
        }
    }

    public static final /* synthetic */ boolean f() {
        if (w2.a.d(r.class)) {
            return false;
        }
        try {
            return f6240i;
        } catch (Throwable th) {
            w2.a.b(th, r.class);
            return false;
        }
    }

    public static final /* synthetic */ void g(boolean z10) {
        if (w2.a.d(r.class)) {
            return;
        }
        try {
            f6240i = z10;
        } catch (Throwable th) {
            w2.a.b(th, r.class);
        }
    }

    public static final /* synthetic */ void h(String str) {
        if (w2.a.d(r.class)) {
            return;
        }
        try {
            f6239h = str;
        } catch (Throwable th) {
            w2.a.b(th, r.class);
        }
    }

    public static final /* synthetic */ void i(ScheduledThreadPoolExecutor scheduledThreadPoolExecutor) {
        if (w2.a.d(r.class)) {
            return;
        }
        try {
            f6236e = scheduledThreadPoolExecutor;
        } catch (Throwable th) {
            w2.a.b(th, r.class);
        }
    }

    public final void j() {
        if (w2.a.d(this)) {
            return;
        }
        try {
            m mVar = m.f6216a;
            m.l(z.EXPLICIT);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void k(String str, double d10, Bundle bundle) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            Double dValueOf = Double.valueOf(d10);
            k2.f fVar = k2.f.f16906a;
            m(str, dValueOf, bundle, false, k2.f.m());
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void l(String str, Bundle bundle) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            k2.f fVar = k2.f.f16906a;
            m(str, null, bundle, false, k2.f.m());
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void m(String str, Double d10, Bundle bundle, boolean z10, UUID uuid) {
        if (w2.a.d(this) || str == null) {
            return;
        }
        try {
            if (str.length() == 0) {
                return;
            }
            r2.q qVar = r2.q.f20221a;
            b2.f0 f0Var = b2.f0.f5388a;
            if (r2.q.d("app_events_killswitch", b2.f0.m(), false)) {
                r2.c0.f20089e.c(r0.APP_EVENTS, "AppEvents", "KillSwitch is enabled and fail to log app event: %s", str);
                return;
            }
            try {
                String str2 = this.f6242a;
                k2.f fVar = k2.f.f16906a;
                f6234c.q(new d(str2, str, d10, bundle, z10, k2.f.o(), uuid), this.f6243b);
            } catch (b2.s e10) {
                r2.c0.f20089e.c(r0.APP_EVENTS, "AppEvents", "Invalid app event: %s", e10.toString());
            } catch (JSONException e11) {
                r2.c0.f20089e.c(r0.APP_EVENTS, "AppEvents", "JSON encoding for app event failed: '%s'", e11.toString());
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void n(String str, String str2) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            Bundle bundle = new Bundle();
            bundle.putString("_is_suggested_event", "1");
            bundle.putString("_button_text", str2);
            l(str, bundle);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void o(String str, Double d10, Bundle bundle) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            k2.f fVar = k2.f.f16906a;
            m(str, d10, bundle, true, k2.f.m());
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void p(String str, BigDecimal bigDecimal, Currency currency, Bundle bundle) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            if (bigDecimal == null || currency == null) {
                l0 l0Var = l0.f20174a;
                l0.e0(f6235d, "purchaseAmount and currency cannot be null");
                return;
            }
            if (bundle == null) {
                bundle = new Bundle();
            }
            Bundle bundle2 = bundle;
            bundle2.putString("fb_currency", currency.getCurrencyCode());
            Double dValueOf = Double.valueOf(bigDecimal.doubleValue());
            k2.f fVar = k2.f.f16906a;
            m(str, dValueOf, bundle2, true, k2.f.m());
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void q(BigDecimal bigDecimal, Currency currency, Bundle bundle, boolean z10) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            if (bigDecimal == null) {
                f6234c.r("purchaseAmount cannot be null");
                return;
            }
            if (currency == null) {
                f6234c.r("currency cannot be null");
                return;
            }
            if (bundle == null) {
                bundle = new Bundle();
            }
            Bundle bundle2 = bundle;
            bundle2.putString("fb_currency", currency.getCurrencyCode());
            Double dValueOf = Double.valueOf(bigDecimal.doubleValue());
            k2.f fVar = k2.f.f16906a;
            m("fb_mobile_purchase", dValueOf, bundle2, z10, k2.f.m());
            f6234c.g();
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void r(BigDecimal bigDecimal, Currency currency, Bundle bundle) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            q(bigDecimal, currency, bundle, true);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }
}
