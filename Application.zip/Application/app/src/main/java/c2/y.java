package c2;

import c2.y;
import r2.n;
import r2.v;

/* loaded from: classes.dex */
public final class y {

    /* renamed from: a, reason: collision with root package name */
    public static final y f6250a = new y();

    public static final class a implements v.b {
        a() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void i(boolean z10) {
            if (z10) {
                d2.b bVar = d2.b.f11246a;
                d2.b.b();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void j(boolean z10) {
            if (z10) {
                n2.a aVar = n2.a.f18082a;
                n2.a.a();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void k(boolean z10) {
            if (z10) {
                l2.f fVar = l2.f.f17356a;
                l2.f.f();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void l(boolean z10) {
            if (z10) {
                h2.a aVar = h2.a.f13031a;
                h2.a.a();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void m(boolean z10) {
            if (z10) {
                i2.k kVar = i2.k.f13362a;
                i2.k.a();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void n(boolean z10) {
            if (z10) {
                e2.d dVar = e2.d.f11483a;
                e2.d.b();
            }
        }

        @Override // r2.v.b
        public void a(r2.r rVar) {
            r2.n nVar = r2.n.f20187a;
            r2.n.a(n.b.AAM, new n.a() { // from class: c2.u
                @Override // r2.n.a
                public final void a(boolean z10) {
                    y.a.i(z10);
                }
            });
            r2.n.a(n.b.RestrictiveDataFiltering, new n.a() { // from class: c2.x
                @Override // r2.n.a
                public final void a(boolean z10) {
                    y.a.j(z10);
                }
            });
            r2.n.a(n.b.PrivacyProtection, new n.a() { // from class: c2.s
                @Override // r2.n.a
                public final void a(boolean z10) {
                    y.a.k(z10);
                }
            });
            r2.n.a(n.b.EventDeactivation, new n.a() { // from class: c2.w
                @Override // r2.n.a
                public final void a(boolean z10) {
                    y.a.l(z10);
                }
            });
            r2.n.a(n.b.IapLogging, new n.a() { // from class: c2.v
                @Override // r2.n.a
                public final void a(boolean z10) {
                    y.a.m(z10);
                }
            });
            r2.n.a(n.b.CloudBridge, new n.a() { // from class: c2.t
                @Override // r2.n.a
                public final void a(boolean z10) {
                    y.a.n(z10);
                }
            });
        }

        @Override // r2.v.b
        public void b() {
        }
    }

    private y() {
    }

    public static final void a() {
        if (w2.a.d(y.class)) {
            return;
        }
        try {
            r2.v vVar = r2.v.f20292a;
            r2.v.d(new a());
        } catch (Throwable th) {
            w2.a.b(th, y.class);
        }
    }
}
