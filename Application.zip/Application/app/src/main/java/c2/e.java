package c2;

import android.content.Context;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    private final HashMap<a, e0> f6185a = new HashMap<>();

    private final synchronized e0 e(a aVar) {
        e0 e0Var = this.f6185a.get(aVar);
        if (e0Var == null) {
            b2.f0 f0Var = b2.f0.f5388a;
            Context contextL = b2.f0.l();
            r2.a aVarE = r2.a.f20067f.e(contextL);
            if (aVarE != null) {
                e0Var = new e0(aVarE, o.f6225b.b(contextL));
            }
        }
        if (e0Var == null) {
            return null;
        }
        this.f6185a.put(aVar, e0Var);
        return e0Var;
    }

    public final synchronized void a(a accessTokenAppIdPair, d appEvent) {
        kotlin.jvm.internal.m.g(accessTokenAppIdPair, "accessTokenAppIdPair");
        kotlin.jvm.internal.m.g(appEvent, "appEvent");
        e0 e0VarE = e(accessTokenAppIdPair);
        if (e0VarE != null) {
            e0VarE.a(appEvent);
        }
    }

    public final synchronized void b(d0 d0Var) {
        if (d0Var == null) {
            return;
        }
        for (Map.Entry<a, List<d>> entry : d0Var.b()) {
            e0 e0VarE = e(entry.getKey());
            if (e0VarE != null) {
                Iterator<d> it = entry.getValue().iterator();
                while (it.hasNext()) {
                    e0VarE.a(it.next());
                }
            }
        }
    }

    public final synchronized e0 c(a accessTokenAppIdPair) {
        kotlin.jvm.internal.m.g(accessTokenAppIdPair, "accessTokenAppIdPair");
        return this.f6185a.get(accessTokenAppIdPair);
    }

    public final synchronized int d() {
        int iC;
        iC = 0;
        Iterator<e0> it = this.f6185a.values().iterator();
        while (it.hasNext()) {
            iC += it.next().c();
        }
        return iC;
    }

    public final synchronized Set<a> f() {
        Set<a> setKeySet;
        setKeySet = this.f6185a.keySet();
        kotlin.jvm.internal.m.f(setKeySet, "stateMap.keys");
        return setKeySet;
    }
}
