package c2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import b2.j0;
import b2.o0;
import b2.r0;
import c2.o;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONException;
import r2.c0;

/* loaded from: classes.dex */
public final class m {

    /* renamed from: f, reason: collision with root package name */
    private static ScheduledFuture<?> f6221f;

    /* renamed from: a, reason: collision with root package name */
    public static final m f6216a = new m();

    /* renamed from: b, reason: collision with root package name */
    private static final String f6217b = m.class.getName();

    /* renamed from: c, reason: collision with root package name */
    private static final int f6218c = 100;

    /* renamed from: d, reason: collision with root package name */
    private static volatile e f6219d = new e();

    /* renamed from: e, reason: collision with root package name */
    private static final ScheduledExecutorService f6220e = Executors.newSingleThreadScheduledExecutor();

    /* renamed from: g, reason: collision with root package name */
    private static final Runnable f6222g = new Runnable() { // from class: c2.l
        @Override // java.lang.Runnable
        public final void run() {
            m.o();
        }
    };

    private m() {
    }

    public static final void g(final a accessTokenAppId, final d appEvent) {
        if (w2.a.d(m.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(accessTokenAppId, "accessTokenAppId");
            kotlin.jvm.internal.m.g(appEvent, "appEvent");
            f6220e.execute(new Runnable() { // from class: c2.h
                @Override // java.lang.Runnable
                public final void run() {
                    m.h(accessTokenAppId, appEvent);
                }
            });
        } catch (Throwable th) {
            w2.a.b(th, m.class);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void h(a accessTokenAppId, d appEvent) {
        if (w2.a.d(m.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(accessTokenAppId, "$accessTokenAppId");
            kotlin.jvm.internal.m.g(appEvent, "$appEvent");
            f6219d.a(accessTokenAppId, appEvent);
            if (o.f6225b.c() != o.b.EXPLICIT_ONLY && f6219d.d() > f6218c) {
                n(z.EVENT_THRESHOLD);
            } else if (f6221f == null) {
                f6221f = f6220e.schedule(f6222g, 15L, TimeUnit.SECONDS);
            }
        } catch (Throwable th) {
            w2.a.b(th, m.class);
        }
    }

    public static final j0 i(final a accessTokenAppId, final e0 appEvents, boolean z10, final b0 flushState) {
        if (w2.a.d(m.class)) {
            return null;
        }
        try {
            kotlin.jvm.internal.m.g(accessTokenAppId, "accessTokenAppId");
            kotlin.jvm.internal.m.g(appEvents, "appEvents");
            kotlin.jvm.internal.m.g(flushState, "flushState");
            String strB = accessTokenAppId.b();
            r2.v vVar = r2.v.f20292a;
            r2.r rVarN = r2.v.n(strB, false);
            j0.c cVar = j0.f5454n;
            kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
            String str = String.format("%s/activities", Arrays.copyOf(new Object[]{strB}, 1));
            kotlin.jvm.internal.m.f(str, "java.lang.String.format(format, *args)");
            final j0 j0VarA = cVar.A(null, str, null, null);
            j0VarA.E(true);
            Bundle bundleU = j0VarA.u();
            if (bundleU == null) {
                bundleU = new Bundle();
            }
            bundleU.putString("access_token", accessTokenAppId.a());
            String strD = c0.f6167b.d();
            if (strD != null) {
                bundleU.putString("device_token", strD);
            }
            String strK = r.f6234c.k();
            if (strK != null) {
                bundleU.putString("install_referrer", strK);
            }
            j0VarA.H(bundleU);
            boolean zL = rVarN != null ? rVarN.l() : false;
            b2.f0 f0Var = b2.f0.f5388a;
            int iE = appEvents.e(j0VarA, b2.f0.l(), zL, z10);
            if (iE == 0) {
                return null;
            }
            flushState.c(flushState.a() + iE);
            j0VarA.D(new j0.b() { // from class: c2.g
                @Override // b2.j0.b
                public final void b(o0 o0Var) {
                    m.j(accessTokenAppId, j0VarA, appEvents, flushState, o0Var);
                }
            });
            return j0VarA;
        } catch (Throwable th) {
            w2.a.b(th, m.class);
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void j(a accessTokenAppId, j0 postRequest, e0 appEvents, b0 flushState, o0 response) {
        if (w2.a.d(m.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(accessTokenAppId, "$accessTokenAppId");
            kotlin.jvm.internal.m.g(postRequest, "$postRequest");
            kotlin.jvm.internal.m.g(appEvents, "$appEvents");
            kotlin.jvm.internal.m.g(flushState, "$flushState");
            kotlin.jvm.internal.m.g(response, "response");
            q(accessTokenAppId, postRequest, response, appEvents, flushState);
        } catch (Throwable th) {
            w2.a.b(th, m.class);
        }
    }

    public static final List<j0> k(e appEventCollection, b0 flushResults) {
        if (w2.a.d(m.class)) {
            return null;
        }
        try {
            kotlin.jvm.internal.m.g(appEventCollection, "appEventCollection");
            kotlin.jvm.internal.m.g(flushResults, "flushResults");
            b2.f0 f0Var = b2.f0.f5388a;
            boolean z10 = b2.f0.z(b2.f0.l());
            ArrayList arrayList = new ArrayList();
            for (a aVar : appEventCollection.f()) {
                e0 e0VarC = appEventCollection.c(aVar);
                if (e0VarC == null) {
                    throw new IllegalStateException("Required value was null.".toString());
                }
                j0 j0VarI = i(aVar, e0VarC, z10, flushResults);
                if (j0VarI != null) {
                    arrayList.add(j0VarI);
                    if (e2.d.f11483a.f()) {
                        e2.g gVar = e2.g.f11509a;
                        e2.g.l(j0VarI);
                    }
                }
            }
            return arrayList;
        } catch (Throwable th) {
            w2.a.b(th, m.class);
            return null;
        }
    }

    public static final void l(final z reason) {
        if (w2.a.d(m.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(reason, "reason");
            f6220e.execute(new Runnable() { // from class: c2.j
                @Override // java.lang.Runnable
                public final void run() {
                    m.m(reason);
                }
            });
        } catch (Throwable th) {
            w2.a.b(th, m.class);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void m(z reason) {
        if (w2.a.d(m.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(reason, "$reason");
            n(reason);
        } catch (Throwable th) {
            w2.a.b(th, m.class);
        }
    }

    public static final void n(z reason) {
        if (w2.a.d(m.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(reason, "reason");
            f fVar = f.f6194a;
            f6219d.b(f.a());
            try {
                b0 b0VarU = u(reason, f6219d);
                if (b0VarU != null) {
                    Intent intent = new Intent("com.facebook.sdk.APP_EVENTS_FLUSHED");
                    intent.putExtra("com.facebook.sdk.APP_EVENTS_NUM_EVENTS_FLUSHED", b0VarU.a());
                    intent.putExtra("com.facebook.sdk.APP_EVENTS_FLUSH_RESULT", b0VarU.b());
                    b2.f0 f0Var = b2.f0.f5388a;
                    d1.a.b(b2.f0.l()).d(intent);
                }
            } catch (Exception e10) {
                Log.w(f6217b, "Caught unexpected exception while flushing app events: ", e10);
            }
        } catch (Throwable th) {
            w2.a.b(th, m.class);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void o() {
        if (w2.a.d(m.class)) {
            return;
        }
        try {
            f6221f = null;
            if (o.f6225b.c() != o.b.EXPLICIT_ONLY) {
                n(z.TIMER);
            }
        } catch (Throwable th) {
            w2.a.b(th, m.class);
        }
    }

    public static final Set<a> p() {
        if (w2.a.d(m.class)) {
            return null;
        }
        try {
            return f6219d.f();
        } catch (Throwable th) {
            w2.a.b(th, m.class);
            return null;
        }
    }

    public static final void q(final a accessTokenAppId, j0 request, o0 response, final e0 appEvents, b0 flushState) {
        String string;
        if (w2.a.d(m.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(accessTokenAppId, "accessTokenAppId");
            kotlin.jvm.internal.m.g(request, "request");
            kotlin.jvm.internal.m.g(response, "response");
            kotlin.jvm.internal.m.g(appEvents, "appEvents");
            kotlin.jvm.internal.m.g(flushState, "flushState");
            b2.v vVarB = response.b();
            String str = "Success";
            a0 a0Var = a0.SUCCESS;
            boolean z10 = true;
            if (vVarB != null) {
                if (vVarB.h() == -1) {
                    str = "Failed: No Connectivity";
                    a0Var = a0.NO_CONNECTIVITY;
                } else {
                    kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
                    str = String.format("Failed:\n  Response: %s\n  Error %s", Arrays.copyOf(new Object[]{response.toString(), vVarB.toString()}, 2));
                    kotlin.jvm.internal.m.f(str, "java.lang.String.format(format, *args)");
                    a0Var = a0.SERVER_ERROR;
                }
            }
            b2.f0 f0Var = b2.f0.f5388a;
            if (b2.f0.H(r0.APP_EVENTS)) {
                try {
                    string = new JSONArray((String) request.w()).toString(2);
                    kotlin.jvm.internal.m.f(string, "{\n            val jsonArray = JSONArray(eventsJsonString)\n            jsonArray.toString(2)\n          }");
                } catch (JSONException unused) {
                    string = "<Can't encode events for debug logging>";
                }
                c0.a aVar = r2.c0.f20089e;
                r0 r0Var = r0.APP_EVENTS;
                String TAG = f6217b;
                kotlin.jvm.internal.m.f(TAG, "TAG");
                aVar.c(r0Var, TAG, "Flush completed\nParams: %s\n  Result: %s\n  Events JSON: %s", String.valueOf(request.q()), str, string);
            }
            if (vVarB == null) {
                z10 = false;
            }
            appEvents.b(z10);
            a0 a0Var2 = a0.NO_CONNECTIVITY;
            if (a0Var == a0Var2) {
                b2.f0 f0Var2 = b2.f0.f5388a;
                b2.f0.t().execute(new Runnable() { // from class: c2.i
                    @Override // java.lang.Runnable
                    public final void run() {
                        m.r(accessTokenAppId, appEvents);
                    }
                });
            }
            if (a0Var == a0.SUCCESS || flushState.b() == a0Var2) {
                return;
            }
            flushState.d(a0Var);
        } catch (Throwable th) {
            w2.a.b(th, m.class);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void r(a accessTokenAppId, e0 appEvents) {
        if (w2.a.d(m.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(accessTokenAppId, "$accessTokenAppId");
            kotlin.jvm.internal.m.g(appEvents, "$appEvents");
            n nVar = n.f6223a;
            n.a(accessTokenAppId, appEvents);
        } catch (Throwable th) {
            w2.a.b(th, m.class);
        }
    }

    public static final void s() {
        if (w2.a.d(m.class)) {
            return;
        }
        try {
            f6220e.execute(new Runnable() { // from class: c2.k
                @Override // java.lang.Runnable
                public final void run() {
                    m.t();
                }
            });
        } catch (Throwable th) {
            w2.a.b(th, m.class);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void t() {
        if (w2.a.d(m.class)) {
            return;
        }
        try {
            n nVar = n.f6223a;
            n.b(f6219d);
            f6219d = new e();
        } catch (Throwable th) {
            w2.a.b(th, m.class);
        }
    }

    public static final b0 u(z reason, e appEventCollection) {
        if (w2.a.d(m.class)) {
            return null;
        }
        try {
            kotlin.jvm.internal.m.g(reason, "reason");
            kotlin.jvm.internal.m.g(appEventCollection, "appEventCollection");
            b0 b0Var = new b0();
            List<j0> listK = k(appEventCollection, b0Var);
            if (!(!listK.isEmpty())) {
                return null;
            }
            c0.a aVar = r2.c0.f20089e;
            r0 r0Var = r0.APP_EVENTS;
            String TAG = f6217b;
            kotlin.jvm.internal.m.f(TAG, "TAG");
            aVar.c(r0Var, TAG, "Flushing %d events due to %s.", Integer.valueOf(b0Var.a()), reason.toString());
            Iterator<j0> it = listK.iterator();
            while (it.hasNext()) {
                it.next().k();
            }
            return b0Var;
        } catch (Throwable th) {
            w2.a.b(th, m.class);
            return null;
        }
    }
}
