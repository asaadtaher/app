package c2;

/* loaded from: classes.dex */
public final class n {

    /* renamed from: a, reason: collision with root package name */
    public static final n f6223a = new n();

    /* renamed from: b, reason: collision with root package name */
    private static final String f6224b = n.class.getName();

    private n() {
    }

    public static final synchronized void a(a accessTokenAppIdPair, e0 appEvents) {
        if (w2.a.d(n.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(accessTokenAppIdPair, "accessTokenAppIdPair");
            kotlin.jvm.internal.m.g(appEvents, "appEvents");
            k2.g gVar = k2.g.f16918a;
            k2.g.b();
            f fVar = f.f6194a;
            d0 d0VarA = f.a();
            d0VarA.a(accessTokenAppIdPair, appEvents.d());
            f.b(d0VarA);
        } catch (Throwable th) {
            w2.a.b(th, n.class);
        }
    }

    public static final synchronized void b(e eventsToPersist) {
        if (w2.a.d(n.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(eventsToPersist, "eventsToPersist");
            k2.g gVar = k2.g.f16918a;
            k2.g.b();
            f fVar = f.f6194a;
            d0 d0VarA = f.a();
            for (a aVar : eventsToPersist.f()) {
                e0 e0VarC = eventsToPersist.c(aVar);
                if (e0VarC == null) {
                    throw new IllegalStateException("Required value was null.".toString());
                }
                d0VarA.a(aVar, e0VarC.d());
            }
            f fVar2 = f.f6194a;
            f.b(d0VarA);
        } catch (Throwable th) {
            w2.a.b(th, n.class);
        }
    }
}
