package c2;

import android.content.Context;
import android.util.Log;
import c2.a;
import c2.d;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import r2.l0;

/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    public static final f f6194a = new f();

    /* renamed from: b, reason: collision with root package name */
    private static final String f6195b = f.class.getName();

    private static final class a extends ObjectInputStream {

        /* renamed from: a, reason: collision with root package name */
        public static final C0103a f6196a = new C0103a(null);

        /* renamed from: c2.f$a$a, reason: collision with other inner class name */
        public static final class C0103a {
            private C0103a() {
            }

            public /* synthetic */ C0103a(kotlin.jvm.internal.g gVar) {
                this();
            }
        }

        public a(InputStream inputStream) {
            super(inputStream);
        }

        @Override // java.io.ObjectInputStream
        protected ObjectStreamClass readClassDescriptor() throws ClassNotFoundException, IOException {
            Class cls;
            ObjectStreamClass resultClassDescriptor = super.readClassDescriptor();
            if (!kotlin.jvm.internal.m.b(resultClassDescriptor.getName(), "com.facebook.appevents.AppEventsLogger$AccessTokenAppIdPair$SerializationProxyV1")) {
                cls = kotlin.jvm.internal.m.b(resultClassDescriptor.getName(), "com.facebook.appevents.AppEventsLogger$AppEvent$SerializationProxyV2") ? d.b.class : a.b.class;
                kotlin.jvm.internal.m.f(resultClassDescriptor, "resultClassDescriptor");
                return resultClassDescriptor;
            }
            resultClassDescriptor = ObjectStreamClass.lookup(cls);
            kotlin.jvm.internal.m.f(resultClassDescriptor, "resultClassDescriptor");
            return resultClassDescriptor;
        }
    }

    private f() {
    }

    /* JADX WARN: Removed duplicated region for block: B:45:0x00a5 A[Catch: all -> 0x00ac, TRY_LEAVE, TryCatch #7 {, blocks: (B:4:0x0003, B:10:0x002c, B:11:0x0031, B:45:0x00a5, B:14:0x003c, B:25:0x005c, B:26:0x0061, B:29:0x006c, B:30:0x0070, B:32:0x0075, B:33:0x007a, B:37:0x008c, B:36:0x0085, B:39:0x008e, B:40:0x0093, B:43:0x009e), top: B:61:0x0003, inners: #1, #4, #5, #6 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final synchronized c2.d0 a() {
        /*
            java.lang.Class<c2.f> r0 = c2.f.class
            monitor-enter(r0)
            k2.g r1 = k2.g.f16918a     // Catch: java.lang.Throwable -> Lac
            k2.g.b()     // Catch: java.lang.Throwable -> Lac
            b2.f0 r1 = b2.f0.f5388a     // Catch: java.lang.Throwable -> Lac
            android.content.Context r1 = b2.f0.l()     // Catch: java.lang.Throwable -> Lac
            r2 = 0
            java.lang.String r3 = "AppEventsLogger.persistedevents"
            java.io.FileInputStream r3 = r1.openFileInput(r3)     // Catch: java.lang.Throwable -> L4f java.lang.Exception -> L53 java.io.FileNotFoundException -> L8d
            java.lang.String r4 = "context.openFileInput(PERSISTED_EVENTS_FILENAME)"
            kotlin.jvm.internal.m.f(r3, r4)     // Catch: java.lang.Throwable -> L4f java.lang.Exception -> L53 java.io.FileNotFoundException -> L8d
            c2.f$a r4 = new c2.f$a     // Catch: java.lang.Throwable -> L4f java.lang.Exception -> L53 java.io.FileNotFoundException -> L8d
            java.io.BufferedInputStream r5 = new java.io.BufferedInputStream     // Catch: java.lang.Throwable -> L4f java.lang.Exception -> L53 java.io.FileNotFoundException -> L8d
            r5.<init>(r3)     // Catch: java.lang.Throwable -> L4f java.lang.Exception -> L53 java.io.FileNotFoundException -> L8d
            r4.<init>(r5)     // Catch: java.lang.Throwable -> L4f java.lang.Exception -> L53 java.io.FileNotFoundException -> L8d
            java.lang.Object r3 = r4.readObject()     // Catch: java.lang.Exception -> L4d java.lang.Throwable -> L74 java.io.FileNotFoundException -> L8e
            if (r3 == 0) goto L45
            c2.d0 r3 = (c2.d0) r3     // Catch: java.lang.Exception -> L4d java.lang.Throwable -> L74 java.io.FileNotFoundException -> L8e
            r2.l0 r2 = r2.l0.f20174a     // Catch: java.lang.Throwable -> Lac
            r2.l0.j(r4)     // Catch: java.lang.Throwable -> Lac
            java.lang.String r2 = "AppEventsLogger.persistedevents"
            java.io.File r1 = r1.getFileStreamPath(r2)     // Catch: java.lang.Exception -> L3b java.lang.Throwable -> Lac
            r1.delete()     // Catch: java.lang.Exception -> L3b java.lang.Throwable -> Lac
            goto L43
        L3b:
            r1 = move-exception
            java.lang.String r2 = c2.f.f6195b     // Catch: java.lang.Throwable -> Lac
            java.lang.String r4 = "Got unexpected exception when removing events file: "
            android.util.Log.w(r2, r4, r1)     // Catch: java.lang.Throwable -> Lac
        L43:
            r2 = r3
            goto La3
        L45:
            java.lang.NullPointerException r3 = new java.lang.NullPointerException     // Catch: java.lang.Exception -> L4d java.lang.Throwable -> L74 java.io.FileNotFoundException -> L8e
            java.lang.String r5 = "null cannot be cast to non-null type com.facebook.appevents.PersistedEvents"
            r3.<init>(r5)     // Catch: java.lang.Exception -> L4d java.lang.Throwable -> L74 java.io.FileNotFoundException -> L8e
            throw r3     // Catch: java.lang.Exception -> L4d java.lang.Throwable -> L74 java.io.FileNotFoundException -> L8e
        L4d:
            r3 = move-exception
            goto L55
        L4f:
            r3 = move-exception
            r4 = r2
            r2 = r3
            goto L75
        L53:
            r3 = move-exception
            r4 = r2
        L55:
            java.lang.String r5 = c2.f.f6195b     // Catch: java.lang.Throwable -> L74
            java.lang.String r6 = "Got unexpected exception while reading events: "
            android.util.Log.w(r5, r6, r3)     // Catch: java.lang.Throwable -> L74
            r2.l0 r3 = r2.l0.f20174a     // Catch: java.lang.Throwable -> Lac
            r2.l0.j(r4)     // Catch: java.lang.Throwable -> Lac
            java.lang.String r3 = "AppEventsLogger.persistedevents"
            java.io.File r1 = r1.getFileStreamPath(r3)     // Catch: java.lang.Exception -> L6b java.lang.Throwable -> Lac
            r1.delete()     // Catch: java.lang.Exception -> L6b java.lang.Throwable -> Lac
            goto La3
        L6b:
            r1 = move-exception
            java.lang.String r3 = c2.f.f6195b     // Catch: java.lang.Throwable -> Lac
            java.lang.String r4 = "Got unexpected exception when removing events file: "
        L70:
            android.util.Log.w(r3, r4, r1)     // Catch: java.lang.Throwable -> Lac
            goto La3
        L74:
            r2 = move-exception
        L75:
            r2.l0 r3 = r2.l0.f20174a     // Catch: java.lang.Throwable -> Lac
            r2.l0.j(r4)     // Catch: java.lang.Throwable -> Lac
            java.lang.String r3 = "AppEventsLogger.persistedevents"
            java.io.File r1 = r1.getFileStreamPath(r3)     // Catch: java.lang.Exception -> L84 java.lang.Throwable -> Lac
            r1.delete()     // Catch: java.lang.Exception -> L84 java.lang.Throwable -> Lac
            goto L8c
        L84:
            r1 = move-exception
            java.lang.String r3 = c2.f.f6195b     // Catch: java.lang.Throwable -> Lac
            java.lang.String r4 = "Got unexpected exception when removing events file: "
            android.util.Log.w(r3, r4, r1)     // Catch: java.lang.Throwable -> Lac
        L8c:
            throw r2     // Catch: java.lang.Throwable -> Lac
        L8d:
            r4 = r2
        L8e:
            r2.l0 r3 = r2.l0.f20174a     // Catch: java.lang.Throwable -> Lac
            r2.l0.j(r4)     // Catch: java.lang.Throwable -> Lac
            java.lang.String r3 = "AppEventsLogger.persistedevents"
            java.io.File r1 = r1.getFileStreamPath(r3)     // Catch: java.lang.Exception -> L9d java.lang.Throwable -> Lac
            r1.delete()     // Catch: java.lang.Exception -> L9d java.lang.Throwable -> Lac
            goto La3
        L9d:
            r1 = move-exception
            java.lang.String r3 = c2.f.f6195b     // Catch: java.lang.Throwable -> Lac
            java.lang.String r4 = "Got unexpected exception when removing events file: "
            goto L70
        La3:
            if (r2 != 0) goto Laa
            c2.d0 r2 = new c2.d0     // Catch: java.lang.Throwable -> Lac
            r2.<init>()     // Catch: java.lang.Throwable -> Lac
        Laa:
            monitor-exit(r0)
            return r2
        Lac:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: c2.f.a():c2.d0");
    }

    public static final void b(d0 d0Var) throws IOException {
        ObjectOutputStream objectOutputStream;
        b2.f0 f0Var = b2.f0.f5388a;
        Context contextL = b2.f0.l();
        ObjectOutputStream objectOutputStream2 = null;
        try {
            objectOutputStream = new ObjectOutputStream(new BufferedOutputStream(contextL.openFileOutput("AppEventsLogger.persistedevents", 0)));
        } catch (Throwable th) {
            th = th;
        }
        try {
            objectOutputStream.writeObject(d0Var);
            l0 l0Var = l0.f20174a;
            l0.j(objectOutputStream);
        } catch (Throwable th2) {
            th = th2;
            objectOutputStream2 = objectOutputStream;
            try {
                Log.w(f6195b, "Got unexpected exception while persisting events: ", th);
                try {
                    contextL.getFileStreamPath("AppEventsLogger.persistedevents").delete();
                } catch (Exception unused) {
                }
            } finally {
                l0 l0Var2 = l0.f20174a;
                l0.j(objectOutputStream2);
            }
        }
    }
}
