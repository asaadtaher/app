package c2;

import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import java.util.Arrays;

/* loaded from: classes.dex */
public final class o {

    /* renamed from: b, reason: collision with root package name */
    public static final a f6225b = new a(null);

    /* renamed from: c, reason: collision with root package name */
    private static final String f6226c = o.class.getCanonicalName();

    /* renamed from: a, reason: collision with root package name */
    private final r f6227a;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final void a(Application application, String str) {
            kotlin.jvm.internal.m.g(application, "application");
            r.f6234c.f(application, str);
        }

        public final String b(Context context) {
            kotlin.jvm.internal.m.g(context, "context");
            return r.f6234c.i(context);
        }

        public final b c() {
            return r.f6234c.j();
        }

        public final String d() {
            c cVar = c.f6162a;
            return c.b();
        }

        public final void e(Context context, String str) {
            kotlin.jvm.internal.m.g(context, "context");
            r.f6234c.m(context, str);
        }

        public final o f(Context context) {
            kotlin.jvm.internal.m.g(context, "context");
            return new o(context, null, 0 == true ? 1 : 0, 0 == true ? 1 : 0);
        }

        public final void g() {
            r.f6234c.s();
        }
    }

    public enum b {
        AUTO,
        EXPLICIT_ONLY;

        /* renamed from: values, reason: to resolve conflict with enum method */
        public static b[] valuesCustom() {
            b[] bVarArrValuesCustom = values();
            return (b[]) Arrays.copyOf(bVarArrValuesCustom, bVarArrValuesCustom.length);
        }
    }

    private o(Context context, String str, b2.a aVar) {
        this.f6227a = new r(context, str, aVar);
    }

    public /* synthetic */ o(Context context, String str, b2.a aVar, kotlin.jvm.internal.g gVar) {
        this(context, str, aVar);
    }

    public final void a() {
        this.f6227a.j();
    }

    public final void b(String str, Bundle bundle) {
        this.f6227a.l(str, bundle);
    }
}
