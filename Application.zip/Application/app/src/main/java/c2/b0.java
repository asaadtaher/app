package c2;

/* loaded from: classes.dex */
public final class b0 {

    /* renamed from: a, reason: collision with root package name */
    private int f6160a;

    /* renamed from: b, reason: collision with root package name */
    private a0 f6161b = a0.SUCCESS;

    public final int a() {
        return this.f6160a;
    }

    public final a0 b() {
        return this.f6161b;
    }

    public final void c(int i10) {
        this.f6160a = i10;
    }

    public final void d(a0 a0Var) {
        kotlin.jvm.internal.m.g(a0Var, "<set-?>");
        this.f6161b = a0Var;
    }
}
