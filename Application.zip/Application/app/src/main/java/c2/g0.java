package c2;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.Patterns;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import r2.l0;
import uc.m0;

/* loaded from: classes.dex */
public final class g0 {

    /* renamed from: c, reason: collision with root package name */
    private static SharedPreferences f6205c;

    /* renamed from: a, reason: collision with root package name */
    public static final g0 f6203a = new g0();

    /* renamed from: b, reason: collision with root package name */
    private static final String f6204b = g0.class.getSimpleName();

    /* renamed from: d, reason: collision with root package name */
    private static final AtomicBoolean f6206d = new AtomicBoolean(false);

    /* renamed from: e, reason: collision with root package name */
    private static final ConcurrentHashMap<String, String> f6207e = new ConcurrentHashMap<>();

    /* renamed from: f, reason: collision with root package name */
    private static final ConcurrentHashMap<String, String> f6208f = new ConcurrentHashMap<>();

    private g0() {
    }

    public static final String b() {
        if (w2.a.d(g0.class)) {
            return null;
        }
        try {
            if (!f6206d.get()) {
                f6203a.d();
            }
            HashMap map = new HashMap();
            map.putAll(f6207e);
            map.putAll(f6203a.c());
            l0 l0Var = l0.f20174a;
            return l0.g0(map);
        } catch (Throwable th) {
            w2.a.b(th, g0.class);
            return null;
        }
    }

    private final Map<String, String> c() {
        if (w2.a.d(this)) {
            return null;
        }
        try {
            HashMap map = new HashMap();
            Set<String> setB = d2.d.f11250d.b();
            for (String str : f6208f.keySet()) {
                if (setB.contains(str)) {
                    map.put(str, f6208f.get(str));
                }
            }
            return map;
        } catch (Throwable th) {
            w2.a.b(th, this);
            return null;
        }
    }

    private final synchronized void d() {
        if (w2.a.d(this)) {
            return;
        }
        try {
            AtomicBoolean atomicBoolean = f6206d;
            if (atomicBoolean.get()) {
                return;
            }
            b2.f0 f0Var = b2.f0.f5388a;
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(b2.f0.l());
            kotlin.jvm.internal.m.f(defaultSharedPreferences, "getDefaultSharedPreferences(FacebookSdk.getApplicationContext())");
            f6205c = defaultSharedPreferences;
            if (defaultSharedPreferences == null) {
                kotlin.jvm.internal.m.u("sharedPreferences");
                throw null;
            }
            String string = defaultSharedPreferences.getString("com.facebook.appevents.UserDataStore.userData", "");
            if (string == null) {
                string = "";
            }
            SharedPreferences sharedPreferences = f6205c;
            if (sharedPreferences == null) {
                kotlin.jvm.internal.m.u("sharedPreferences");
                throw null;
            }
            String string2 = sharedPreferences.getString("com.facebook.appevents.UserDataStore.internalUserData", "");
            if (string2 == null) {
                string2 = "";
            }
            ConcurrentHashMap<String, String> concurrentHashMap = f6207e;
            l0 l0Var = l0.f20174a;
            concurrentHashMap.putAll(l0.c0(string));
            f6208f.putAll(l0.c0(string2));
            atomicBoolean.set(true);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public static final void e() {
        if (w2.a.d(g0.class)) {
            return;
        }
        try {
            if (f6206d.get()) {
                return;
            }
            f6203a.d();
        } catch (Throwable th) {
            w2.a.b(th, g0.class);
        }
    }

    private final String f(String str, String str2) {
        String strSubstring;
        if (w2.a.d(this)) {
            return null;
        }
        try {
            int length = str2.length() - 1;
            int i10 = 0;
            boolean z10 = false;
            while (i10 <= length) {
                boolean z11 = kotlin.jvm.internal.m.i(str2.charAt(!z10 ? i10 : length), 32) <= 0;
                if (z10) {
                    if (!z11) {
                        break;
                    }
                    length--;
                } else if (z11) {
                    i10++;
                } else {
                    z10 = true;
                }
            }
            String string = str2.subSequence(i10, length + 1).toString();
            if (string == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            String lowerCase = string.toLowerCase();
            kotlin.jvm.internal.m.f(lowerCase, "(this as java.lang.String).toLowerCase()");
            if (kotlin.jvm.internal.m.b("em", str)) {
                if (Patterns.EMAIL_ADDRESS.matcher(lowerCase).matches()) {
                    return lowerCase;
                }
                Log.e(f6204b, "Setting email failure: this is not a valid email address");
                return "";
            }
            if (kotlin.jvm.internal.m.b("ph", str)) {
                return new md.f("[^0-9]").b(lowerCase, "");
            }
            if (!kotlin.jvm.internal.m.b("ge", str)) {
                return lowerCase;
            }
            if (!(lowerCase.length() > 0)) {
                strSubstring = "";
            } else {
                if (lowerCase == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                strSubstring = lowerCase.substring(0, 1);
                kotlin.jvm.internal.m.f(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            }
            if (!kotlin.jvm.internal.m.b("f", strSubstring) && !kotlin.jvm.internal.m.b("m", strSubstring)) {
                Log.e(f6204b, "Setting gender failure: the supported value for gender is f or m");
                return "";
            }
            return strSubstring;
        } catch (Throwable th) {
            w2.a.b(th, this);
            return null;
        }
    }

    public static final void g(Map<String, String> ud2) {
        List<String> listC;
        if (w2.a.d(g0.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(ud2, "ud");
            if (!f6206d.get()) {
                f6203a.d();
            }
            for (Map.Entry<String, String> entry : ud2.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                l0 l0Var = l0.f20174a;
                g0 g0Var = f6203a;
                int i10 = 1;
                int length = value.length() - 1;
                int i11 = 0;
                boolean z10 = false;
                while (i11 <= length) {
                    boolean z11 = kotlin.jvm.internal.m.i(value.charAt(!z10 ? i11 : length), 32) <= 0;
                    if (z10) {
                        if (!z11) {
                            break;
                        } else {
                            length--;
                        }
                    } else if (z11) {
                        i11++;
                    } else {
                        z10 = true;
                    }
                }
                String strA0 = l0.A0(g0Var.f(key, value.subSequence(i11, length + 1).toString()));
                ConcurrentHashMap<String, String> concurrentHashMap = f6208f;
                if (concurrentHashMap.containsKey(key)) {
                    String str = concurrentHashMap.get(key);
                    String[] strArr = null;
                    if (str != null && (listC = new md.f(",").c(str, 0)) != null) {
                        Object[] array = listC.toArray(new String[0]);
                        if (array == null) {
                            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
                        }
                        strArr = (String[]) array;
                    }
                    if (strArr == null) {
                        strArr = new String[0];
                    }
                    Set setD = m0.d(Arrays.copyOf(strArr, strArr.length));
                    if (setD.contains(strA0)) {
                        return;
                    }
                    StringBuilder sb2 = new StringBuilder();
                    if (strArr.length == 0) {
                        sb2.append(strA0);
                        f6208f.put(key, sb2.toString());
                    } else if (strArr.length < 5) {
                        sb2.append(str);
                        sb2.append(",");
                        sb2.append(strA0);
                        f6208f.put(key, sb2.toString());
                    } else {
                        while (true) {
                            int i12 = i10 + 1;
                            sb2.append(strArr[i10]);
                            sb2.append(",");
                            if (i12 >= 5) {
                                break;
                            } else {
                                i10 = i12;
                            }
                        }
                        sb2.append(strA0);
                        setD.remove(strArr[0]);
                        f6208f.put(key, sb2.toString());
                    }
                } else {
                    concurrentHashMap.put(key, strA0);
                }
            }
            g0 g0Var2 = f6203a;
            l0 l0Var2 = l0.f20174a;
            g0Var2.h("com.facebook.appevents.UserDataStore.internalUserData", l0.g0(f6208f));
        } catch (Throwable th) {
            w2.a.b(th, g0.class);
        }
    }

    private final void h(final String str, final String str2) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            b2.f0 f0Var = b2.f0.f5388a;
            b2.f0.t().execute(new Runnable() { // from class: c2.f0
                @Override // java.lang.Runnable
                public final void run() {
                    g0.i(str, str2);
                }
            });
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void i(String key, String value) {
        if (w2.a.d(g0.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(key, "$key");
            kotlin.jvm.internal.m.g(value, "$value");
            if (!f6206d.get()) {
                f6203a.d();
            }
            SharedPreferences sharedPreferences = f6205c;
            if (sharedPreferences != null) {
                sharedPreferences.edit().putString(key, value).apply();
            } else {
                kotlin.jvm.internal.m.u("sharedPreferences");
                throw null;
            }
        } catch (Throwable th) {
            w2.a.b(th, g0.class);
        }
    }
}
