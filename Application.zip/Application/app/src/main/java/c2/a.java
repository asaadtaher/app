package c2;

import java.io.Serializable;
import r2.l0;

/* loaded from: classes.dex */
public final class a implements Serializable {

    /* renamed from: c, reason: collision with root package name */
    public static final C0101a f6148c = new C0101a(null);

    /* renamed from: a, reason: collision with root package name */
    private final String f6149a;

    /* renamed from: b, reason: collision with root package name */
    private final String f6150b;

    /* renamed from: c2.a$a, reason: collision with other inner class name */
    public static final class C0101a {
        private C0101a() {
        }

        public /* synthetic */ C0101a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public static final class b implements Serializable {

        /* renamed from: c, reason: collision with root package name */
        public static final C0102a f6151c = new C0102a(null);

        /* renamed from: a, reason: collision with root package name */
        private final String f6152a;

        /* renamed from: b, reason: collision with root package name */
        private final String f6153b;

        /* renamed from: c2.a$b$a, reason: collision with other inner class name */
        public static final class C0102a {
            private C0102a() {
            }

            public /* synthetic */ C0102a(kotlin.jvm.internal.g gVar) {
                this();
            }
        }

        public b(String str, String appId) {
            kotlin.jvm.internal.m.g(appId, "appId");
            this.f6152a = str;
            this.f6153b = appId;
        }

        private final Object readResolve() {
            return new a(this.f6152a, this.f6153b);
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public a(b2.a accessToken) {
        kotlin.jvm.internal.m.g(accessToken, "accessToken");
        String strW = accessToken.w();
        b2.f0 f0Var = b2.f0.f5388a;
        this(strW, b2.f0.m());
    }

    public a(String str, String applicationId) {
        kotlin.jvm.internal.m.g(applicationId, "applicationId");
        this.f6149a = applicationId;
        l0 l0Var = l0.f20174a;
        this.f6150b = l0.X(str) ? null : str;
    }

    private final Object writeReplace() {
        return new b(this.f6150b, this.f6149a);
    }

    public final String a() {
        return this.f6150b;
    }

    public final String b() {
        return this.f6149a;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof a)) {
            return false;
        }
        l0 l0Var = l0.f20174a;
        a aVar = (a) obj;
        return l0.e(aVar.f6150b, this.f6150b) && l0.e(aVar.f6149a, this.f6149a);
    }

    public int hashCode() {
        String str = this.f6150b;
        return (str == null ? 0 : str.hashCode()) ^ this.f6149a.hashCode();
    }
}
