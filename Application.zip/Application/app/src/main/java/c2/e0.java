package c2;

import android.content.Context;
import android.os.Bundle;
import b2.j0;
import java.util.ArrayList;
import java.util.List;
import k2.h;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import r2.l0;

/* loaded from: classes.dex */
public final class e0 {

    /* renamed from: f, reason: collision with root package name */
    public static final a f6186f = new a(null);

    /* renamed from: g, reason: collision with root package name */
    private static final String f6187g = e0.class.getSimpleName();

    /* renamed from: h, reason: collision with root package name */
    private static final int f6188h = 1000;

    /* renamed from: a, reason: collision with root package name */
    private final r2.a f6189a;

    /* renamed from: b, reason: collision with root package name */
    private final String f6190b;

    /* renamed from: c, reason: collision with root package name */
    private List<d> f6191c;

    /* renamed from: d, reason: collision with root package name */
    private final List<d> f6192d;

    /* renamed from: e, reason: collision with root package name */
    private int f6193e;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public e0(r2.a attributionIdentifiers, String anonymousAppDeviceGUID) {
        kotlin.jvm.internal.m.g(attributionIdentifiers, "attributionIdentifiers");
        kotlin.jvm.internal.m.g(anonymousAppDeviceGUID, "anonymousAppDeviceGUID");
        this.f6189a = attributionIdentifiers;
        this.f6190b = anonymousAppDeviceGUID;
        this.f6191c = new ArrayList();
        this.f6192d = new ArrayList();
    }

    private final void f(j0 j0Var, Context context, int i10, JSONArray jSONArray, boolean z10) {
        JSONObject jSONObject;
        try {
            if (w2.a.d(this)) {
                return;
            }
            try {
                k2.h hVar = k2.h.f16919a;
                jSONObject = k2.h.a(h.a.CUSTOM_APP_EVENTS, this.f6189a, this.f6190b, z10, context);
                if (this.f6193e > 0) {
                    jSONObject.put("num_skipped_events", i10);
                }
            } catch (JSONException unused) {
                jSONObject = new JSONObject();
            }
            j0Var.F(jSONObject);
            Bundle bundleU = j0Var.u();
            String string = jSONArray.toString();
            kotlin.jvm.internal.m.f(string, "events.toString()");
            bundleU.putString("custom_events", string);
            j0Var.I(string);
            j0Var.H(bundleU);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final synchronized void a(d event) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(event, "event");
            if (this.f6191c.size() + this.f6192d.size() >= f6188h) {
                this.f6193e++;
            } else {
                this.f6191c.add(event);
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final synchronized void b(boolean z10) {
        if (w2.a.d(this)) {
            return;
        }
        if (!z10) {
            this.f6192d.clear();
            this.f6193e = 0;
            return;
        }
        try {
            this.f6191c.addAll(this.f6192d);
            this.f6192d.clear();
            this.f6193e = 0;
            return;
        } catch (Throwable th) {
            w2.a.b(th, this);
            return;
        }
    }

    public final synchronized int c() {
        if (w2.a.d(this)) {
            return 0;
        }
        try {
            return this.f6191c.size();
        } catch (Throwable th) {
            w2.a.b(th, this);
            return 0;
        }
    }

    public final synchronized List<d> d() {
        if (w2.a.d(this)) {
            return null;
        }
        try {
            List<d> list = this.f6191c;
            this.f6191c = new ArrayList();
            return list;
        } catch (Throwable th) {
            w2.a.b(th, this);
            return null;
        }
    }

    public final int e(j0 request, Context applicationContext, boolean z10, boolean z11) {
        if (w2.a.d(this)) {
            return 0;
        }
        try {
            kotlin.jvm.internal.m.g(request, "request");
            kotlin.jvm.internal.m.g(applicationContext, "applicationContext");
            synchronized (this) {
                int i10 = this.f6193e;
                h2.a aVar = h2.a.f13031a;
                h2.a.d(this.f6191c);
                this.f6192d.addAll(this.f6191c);
                this.f6191c.clear();
                JSONArray jSONArray = new JSONArray();
                for (d dVar : this.f6192d) {
                    if (!dVar.g()) {
                        l0 l0Var = l0.f20174a;
                        l0.e0(f6187g, kotlin.jvm.internal.m.n("Event with invalid checksum: ", dVar));
                    } else if (z10 || !dVar.h()) {
                        jSONArray.put(dVar.e());
                    }
                }
                if (jSONArray.length() == 0) {
                    return 0;
                }
                tc.x xVar = tc.x.f21992a;
                f(request, applicationContext, i10, jSONArray, z11);
                return jSONArray.length();
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
            return 0;
        }
    }
}
