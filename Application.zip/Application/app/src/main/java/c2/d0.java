package c2;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public final class d0 implements Serializable {

    /* renamed from: b, reason: collision with root package name */
    public static final a f6181b = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private final HashMap<c2.a, List<d>> f6182a;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public static final class b implements Serializable {

        /* renamed from: b, reason: collision with root package name */
        public static final a f6183b = new a(null);

        /* renamed from: a, reason: collision with root package name */
        private final HashMap<c2.a, List<d>> f6184a;

        public static final class a {
            private a() {
            }

            public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
                this();
            }
        }

        public b(HashMap<c2.a, List<d>> proxyEvents) {
            kotlin.jvm.internal.m.g(proxyEvents, "proxyEvents");
            this.f6184a = proxyEvents;
        }

        private final Object readResolve() {
            return new d0(this.f6184a);
        }
    }

    public d0() {
        this.f6182a = new HashMap<>();
    }

    public d0(HashMap<c2.a, List<d>> appEventMap) {
        kotlin.jvm.internal.m.g(appEventMap, "appEventMap");
        HashMap<c2.a, List<d>> map = new HashMap<>();
        this.f6182a = map;
        map.putAll(appEventMap);
    }

    private final Object writeReplace() {
        if (w2.a.d(this)) {
            return null;
        }
        try {
            return new b(this.f6182a);
        } catch (Throwable th) {
            w2.a.b(th, this);
            return null;
        }
    }

    public final void a(c2.a accessTokenAppIdPair, List<d> appEvents) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(accessTokenAppIdPair, "accessTokenAppIdPair");
            kotlin.jvm.internal.m.g(appEvents, "appEvents");
            if (!this.f6182a.containsKey(accessTokenAppIdPair)) {
                this.f6182a.put(accessTokenAppIdPair, uc.x.j0(appEvents));
                return;
            }
            List<d> list = this.f6182a.get(accessTokenAppIdPair);
            if (list == null) {
                return;
            }
            list.addAll(appEvents);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final Set<Map.Entry<c2.a, List<d>>> b() {
        if (w2.a.d(this)) {
            return null;
        }
        try {
            Set<Map.Entry<c2.a, List<d>>> setEntrySet = this.f6182a.entrySet();
            kotlin.jvm.internal.m.f(setEntrySet, "events.entries");
            return setEntrySet;
        } catch (Throwable th) {
            w2.a.b(th, this);
            return null;
        }
    }
}
