package c2;

import android.content.Context;
import android.os.Bundle;
import c2.o;
import java.math.BigDecimal;
import java.util.Currency;
import java.util.Map;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class c0 {

    /* renamed from: b, reason: collision with root package name */
    public static final a f6167b = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private final r f6168a;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final c0 a(String activityName, String str, b2.a aVar) {
            kotlin.jvm.internal.m.g(activityName, "activityName");
            return new c0(activityName, str, aVar);
        }

        public final Executor b() {
            return r.f6234c.h();
        }

        public final o.b c() {
            return r.f6234c.j();
        }

        public final String d() {
            return r.f6234c.l();
        }

        public final void e(Map<String, String> ud2) {
            kotlin.jvm.internal.m.g(ud2, "ud");
            g0 g0Var = g0.f6203a;
            g0.g(ud2);
        }
    }

    public c0(Context context) {
        this(new r(context, (String) null, (b2.a) null));
    }

    public c0(Context context, String str) {
        this(new r(context, str, (b2.a) null));
    }

    public c0(r loggerImpl) {
        kotlin.jvm.internal.m.g(loggerImpl, "loggerImpl");
        this.f6168a = loggerImpl;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public c0(String activityName, String str, b2.a aVar) {
        this(new r(activityName, str, aVar));
        kotlin.jvm.internal.m.g(activityName, "activityName");
    }

    public final void a() {
        this.f6168a.j();
    }

    public final void b(Bundle parameters) {
        kotlin.jvm.internal.m.g(parameters, "parameters");
        if (!((parameters.getInt("previous") & 2) != 0)) {
            b2.f0 f0Var = b2.f0.f5388a;
            if (!b2.f0.p()) {
                return;
            }
        }
        this.f6168a.o("fb_sdk_settings_changed", null, parameters);
    }

    public final void c(String str, double d10, Bundle bundle) {
        b2.f0 f0Var = b2.f0.f5388a;
        if (b2.f0.p()) {
            this.f6168a.k(str, d10, bundle);
        }
    }

    public final void d(String str, Bundle bundle) {
        b2.f0 f0Var = b2.f0.f5388a;
        if (b2.f0.p()) {
            this.f6168a.l(str, bundle);
        }
    }

    public final void e(String str, String str2) {
        this.f6168a.n(str, str2);
    }

    public final void f(String str) {
        b2.f0 f0Var = b2.f0.f5388a;
        if (b2.f0.p()) {
            this.f6168a.o(str, null, null);
        }
    }

    public final void g(String str, Bundle bundle) {
        b2.f0 f0Var = b2.f0.f5388a;
        if (b2.f0.p()) {
            this.f6168a.o(str, null, bundle);
        }
    }

    public final void h(String str, Double d10, Bundle bundle) {
        b2.f0 f0Var = b2.f0.f5388a;
        if (b2.f0.p()) {
            this.f6168a.o(str, d10, bundle);
        }
    }

    public final void i(String str, BigDecimal bigDecimal, Currency currency, Bundle bundle) {
        b2.f0 f0Var = b2.f0.f5388a;
        if (b2.f0.p()) {
            this.f6168a.p(str, bigDecimal, currency, bundle);
        }
    }

    public final void j(BigDecimal bigDecimal, Currency currency, Bundle bundle) {
        b2.f0 f0Var = b2.f0.f5388a;
        if (b2.f0.p()) {
            this.f6168a.r(bigDecimal, currency, bundle);
        }
    }
}
