package c2;

import android.preference.PreferenceManager;
import android.util.Log;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public static final c f6162a = new c();

    /* renamed from: b, reason: collision with root package name */
    private static final String f6163b = c.class.getSimpleName();

    /* renamed from: c, reason: collision with root package name */
    private static final ReentrantReadWriteLock f6164c = new ReentrantReadWriteLock();

    /* renamed from: d, reason: collision with root package name */
    private static String f6165d;

    /* renamed from: e, reason: collision with root package name */
    private static volatile boolean f6166e;

    private c() {
    }

    public static final String b() {
        if (!f6166e) {
            Log.w(f6163b, "initStore should have been called before calling setUserID");
            f6162a.c();
        }
        ReentrantReadWriteLock reentrantReadWriteLock = f6164c;
        reentrantReadWriteLock.readLock().lock();
        try {
            String str = f6165d;
            reentrantReadWriteLock.readLock().unlock();
            return str;
        } catch (Throwable th) {
            f6164c.readLock().unlock();
            throw th;
        }
    }

    private final void c() {
        if (f6166e) {
            return;
        }
        ReentrantReadWriteLock reentrantReadWriteLock = f6164c;
        reentrantReadWriteLock.writeLock().lock();
        try {
            if (f6166e) {
                reentrantReadWriteLock.writeLock().unlock();
                return;
            }
            b2.f0 f0Var = b2.f0.f5388a;
            f6165d = PreferenceManager.getDefaultSharedPreferences(b2.f0.l()).getString("com.facebook.appevents.AnalyticsUserIDStore.userID", null);
            f6166e = true;
            reentrantReadWriteLock.writeLock().unlock();
        } catch (Throwable th) {
            f6164c.writeLock().unlock();
            throw th;
        }
    }

    public static final void d() {
        if (f6166e) {
            return;
        }
        c0.f6167b.b().execute(new Runnable() { // from class: c2.b
            @Override // java.lang.Runnable
            public final void run() {
                c.e();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void e() {
        f6162a.c();
    }
}
