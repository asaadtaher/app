package c2;

import android.os.Build;
import android.os.Bundle;
import b2.r0;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;
import r2.c0;
import r2.l0;

/* loaded from: classes.dex */
public final class d implements Serializable {

    /* renamed from: f, reason: collision with root package name */
    public static final a f6169f = new a(null);

    /* renamed from: g, reason: collision with root package name */
    private static final HashSet<String> f6170g = new HashSet<>();

    /* renamed from: a, reason: collision with root package name */
    private final JSONObject f6171a;

    /* renamed from: b, reason: collision with root package name */
    private final boolean f6172b;

    /* renamed from: c, reason: collision with root package name */
    private final boolean f6173c;

    /* renamed from: d, reason: collision with root package name */
    private final String f6174d;

    /* renamed from: e, reason: collision with root package name */
    private final String f6175e;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final String c(String str) throws NoSuchAlgorithmException {
            try {
                MessageDigest messageDigest = MessageDigest.getInstance("MD5");
                Charset charsetForName = Charset.forName("UTF-8");
                kotlin.jvm.internal.m.f(charsetForName, "Charset.forName(charsetName)");
                if (str == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                byte[] bytes = str.getBytes(charsetForName);
                kotlin.jvm.internal.m.f(bytes, "(this as java.lang.String).getBytes(charset)");
                messageDigest.update(bytes, 0, bytes.length);
                byte[] bArrDigest = messageDigest.digest();
                kotlin.jvm.internal.m.f(bArrDigest, "digest.digest()");
                k2.g gVar = k2.g.f16918a;
                return k2.g.c(bArrDigest);
            } catch (UnsupportedEncodingException e10) {
                l0 l0Var = l0.f20174a;
                l0.d0("Failed to generate checksum: ", e10);
                return "1";
            } catch (NoSuchAlgorithmException e11) {
                l0 l0Var2 = l0.f20174a;
                l0.d0("Failed to generate checksum: ", e11);
                return "0";
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final void d(String str) {
            boolean zContains;
            if (str != null) {
                if (!(str.length() == 0) && str.length() <= 40) {
                    synchronized (d.f6170g) {
                        zContains = d.f6170g.contains(str);
                        tc.x xVar = tc.x.f21992a;
                    }
                    if (zContains) {
                        return;
                    }
                    if (new md.f("^[0-9a-zA-Z_]+[0-9a-zA-Z _-]*$").a(str)) {
                        synchronized (d.f6170g) {
                            d.f6170g.add(str);
                        }
                        return;
                    } else {
                        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
                        String str2 = String.format("Skipping event named '%s' due to illegal name - must be under 40 chars and alphanumeric, _, - or space, and not start with a space or hyphen.", Arrays.copyOf(new Object[]{str}, 1));
                        kotlin.jvm.internal.m.f(str2, "java.lang.String.format(format, *args)");
                        throw new b2.s(str2);
                    }
                }
            }
            if (str == null) {
                str = "<None Provided>";
            }
            kotlin.jvm.internal.w wVar2 = kotlin.jvm.internal.w.f17306a;
            String str3 = String.format(Locale.ROOT, "Identifier '%s' must be less than %d characters", Arrays.copyOf(new Object[]{str, 40}, 2));
            kotlin.jvm.internal.m.f(str3, "java.lang.String.format(locale, format, *args)");
            throw new b2.s(str3);
        }
    }

    public static final class b implements Serializable {

        /* renamed from: e, reason: collision with root package name */
        public static final a f6176e = new a(null);

        /* renamed from: a, reason: collision with root package name */
        private final String f6177a;

        /* renamed from: b, reason: collision with root package name */
        private final boolean f6178b;

        /* renamed from: c, reason: collision with root package name */
        private final boolean f6179c;

        /* renamed from: d, reason: collision with root package name */
        private final String f6180d;

        public static final class a {
            private a() {
            }

            public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
                this();
            }
        }

        public b(String jsonString, boolean z10, boolean z11, String str) {
            kotlin.jvm.internal.m.g(jsonString, "jsonString");
            this.f6177a = jsonString;
            this.f6178b = z10;
            this.f6179c = z11;
            this.f6180d = str;
        }

        private final Object readResolve() {
            return new d(this.f6177a, this.f6178b, this.f6179c, this.f6180d, null);
        }
    }

    public d(String contextName, String eventName, Double d10, Bundle bundle, boolean z10, boolean z11, UUID uuid) {
        kotlin.jvm.internal.m.g(contextName, "contextName");
        kotlin.jvm.internal.m.g(eventName, "eventName");
        this.f6172b = z10;
        this.f6173c = z11;
        this.f6174d = eventName;
        this.f6171a = d(contextName, eventName, d10, bundle, uuid);
        this.f6175e = b();
    }

    private d(String str, boolean z10, boolean z11, String str2) {
        JSONObject jSONObject = new JSONObject(str);
        this.f6171a = jSONObject;
        this.f6172b = z10;
        String strOptString = jSONObject.optString("_eventName");
        kotlin.jvm.internal.m.f(strOptString, "jsonObject.optString(Constants.EVENT_NAME_EVENT_KEY)");
        this.f6174d = strOptString;
        this.f6175e = str2;
        this.f6173c = z11;
    }

    public /* synthetic */ d(String str, boolean z10, boolean z11, String str2, kotlin.jvm.internal.g gVar) {
        this(str, z10, z11, str2);
    }

    private final String b() {
        a aVar;
        String string;
        String str;
        if (Build.VERSION.SDK_INT > 19) {
            aVar = f6169f;
            string = this.f6171a.toString();
            str = "jsonObject.toString()";
        } else {
            ArrayList arrayList = new ArrayList();
            Iterator<String> itKeys = this.f6171a.keys();
            while (itKeys.hasNext()) {
                arrayList.add(itKeys.next());
            }
            uc.t.s(arrayList);
            StringBuilder sb2 = new StringBuilder();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                String str2 = (String) it.next();
                sb2.append(str2);
                sb2.append(" = ");
                sb2.append(this.f6171a.optString(str2));
                sb2.append('\n');
            }
            aVar = f6169f;
            string = sb2.toString();
            str = "sb.toString()";
        }
        kotlin.jvm.internal.m.f(string, str);
        return aVar.c(string);
    }

    private final JSONObject d(String str, String str2, Double d10, Bundle bundle, UUID uuid) throws JSONException {
        a aVar = f6169f;
        aVar.d(str2);
        JSONObject jSONObject = new JSONObject();
        n2.a aVar2 = n2.a.f18082a;
        String strE = n2.a.e(str2);
        jSONObject.put("_eventName", strE);
        jSONObject.put("_eventName_md5", aVar.c(strE));
        jSONObject.put("_logTime", System.currentTimeMillis() / 1000);
        jSONObject.put("_ui", str);
        if (uuid != null) {
            jSONObject.put("_session_id", uuid);
        }
        if (bundle != null) {
            Map<String, String> mapI = i(bundle);
            for (String str3 : mapI.keySet()) {
                jSONObject.put(str3, mapI.get(str3));
            }
        }
        if (d10 != null) {
            jSONObject.put("_valueToSum", d10.doubleValue());
        }
        if (this.f6173c) {
            jSONObject.put("_inBackground", "1");
        }
        if (this.f6172b) {
            jSONObject.put("_implicitlyLogged", "1");
        } else {
            c0.a aVar3 = r2.c0.f20089e;
            r0 r0Var = r0.APP_EVENTS;
            String string = jSONObject.toString();
            kotlin.jvm.internal.m.f(string, "eventObject.toString()");
            aVar3.c(r0Var, "AppEvents", "Created app event '%s'", string);
        }
        return jSONObject;
    }

    private final Map<String, String> i(Bundle bundle) {
        HashMap map = new HashMap();
        for (String key : bundle.keySet()) {
            a aVar = f6169f;
            kotlin.jvm.internal.m.f(key, "key");
            aVar.d(key);
            Object obj = bundle.get(key);
            if (!(obj instanceof String) && !(obj instanceof Number)) {
                kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
                String str = String.format("Parameter value '%s' for key '%s' should be a string or a numeric type.", Arrays.copyOf(new Object[]{obj, key}, 2));
                kotlin.jvm.internal.m.f(str, "java.lang.String.format(format, *args)");
                throw new b2.s(str);
            }
            map.put(key, obj.toString());
        }
        j2.a aVar2 = j2.a.f16602a;
        j2.a.c(map);
        n2.a aVar3 = n2.a.f18082a;
        n2.a.f(map, this.f6174d);
        h2.a aVar4 = h2.a.f13031a;
        h2.a.c(map, this.f6174d);
        return map;
    }

    private final Object writeReplace() {
        String string = this.f6171a.toString();
        kotlin.jvm.internal.m.f(string, "jsonObject.toString()");
        return new b(string, this.f6172b, this.f6173c, this.f6175e);
    }

    public final boolean c() {
        return this.f6172b;
    }

    public final JSONObject e() {
        return this.f6171a;
    }

    public final String f() {
        return this.f6174d;
    }

    public final boolean g() {
        if (this.f6175e == null) {
            return true;
        }
        return kotlin.jvm.internal.m.b(b(), this.f6175e);
    }

    public final boolean h() {
        return this.f6172b;
    }

    public String toString() {
        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
        String str = String.format("\"%s\", implicit: %b, json: %s", Arrays.copyOf(new Object[]{this.f6171a.optString("_eventName"), Boolean.valueOf(this.f6172b), this.f6171a.toString()}, 3));
        kotlin.jvm.internal.m.f(str, "java.lang.String.format(format, *args)");
        return str;
    }
}
