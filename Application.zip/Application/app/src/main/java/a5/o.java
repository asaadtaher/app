package a5;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class o extends b5.a {
    public static final Parcelable.Creator<o> CREATOR = new n0();

    /* renamed from: a, reason: collision with root package name */
    private final int f303a;

    /* renamed from: b, reason: collision with root package name */
    private final int f304b;

    /* renamed from: c, reason: collision with root package name */
    private final int f305c;

    /* renamed from: d, reason: collision with root package name */
    private final long f306d;

    /* renamed from: e, reason: collision with root package name */
    private final long f307e;

    /* renamed from: f, reason: collision with root package name */
    private final String f308f;

    /* renamed from: g, reason: collision with root package name */
    private final String f309g;

    /* renamed from: h, reason: collision with root package name */
    private final int f310h;

    /* renamed from: i, reason: collision with root package name */
    private final int f311i;

    public o(int i10, int i11, int i12, long j10, long j11, String str, String str2, int i13, int i14) {
        this.f303a = i10;
        this.f304b = i11;
        this.f305c = i12;
        this.f306d = j10;
        this.f307e = j11;
        this.f308f = str;
        this.f309g = str2;
        this.f310h = i13;
        this.f311i = i14;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.k(parcel, 1, this.f303a);
        b5.c.k(parcel, 2, this.f304b);
        b5.c.k(parcel, 3, this.f305c);
        b5.c.o(parcel, 4, this.f306d);
        b5.c.o(parcel, 5, this.f307e);
        b5.c.r(parcel, 6, this.f308f, false);
        b5.c.r(parcel, 7, this.f309g, false);
        b5.c.k(parcel, 8, this.f310h);
        b5.c.k(parcel, 9, this.f311i);
        b5.c.b(parcel, iA);
    }
}
