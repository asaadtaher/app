package a5;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;
import y4.f;

/* loaded from: classes.dex */
public final class l0 implements Handler.Callback {

    /* renamed from: a, reason: collision with root package name */
    private final k0 f286a;

    /* renamed from: h, reason: collision with root package name */
    private final Handler f293h;

    /* renamed from: b, reason: collision with root package name */
    private final ArrayList f287b = new ArrayList();

    /* renamed from: c, reason: collision with root package name */
    final ArrayList f288c = new ArrayList();

    /* renamed from: d, reason: collision with root package name */
    private final ArrayList f289d = new ArrayList();

    /* renamed from: e, reason: collision with root package name */
    private volatile boolean f290e = false;

    /* renamed from: f, reason: collision with root package name */
    private final AtomicInteger f291f = new AtomicInteger(0);

    /* renamed from: g, reason: collision with root package name */
    private boolean f292g = false;

    /* renamed from: i, reason: collision with root package name */
    private final Object f294i = new Object();

    public l0(Looper looper, k0 k0Var) {
        this.f286a = k0Var;
        this.f293h = new m5.n(looper, this);
    }

    public final void a() {
        this.f290e = false;
        this.f291f.incrementAndGet();
    }

    public final void b() {
        this.f290e = true;
    }

    public final void c(x4.b bVar) {
        r.e(this.f293h, "onConnectionFailure must only be called on the Handler thread");
        this.f293h.removeMessages(1);
        synchronized (this.f294i) {
            ArrayList arrayList = new ArrayList(this.f289d);
            int i10 = this.f291f.get();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                f.c cVar = (f.c) it.next();
                if (this.f290e && this.f291f.get() == i10) {
                    if (this.f289d.contains(cVar)) {
                        cVar.r(bVar);
                    }
                }
                return;
            }
        }
    }

    public final void d(Bundle bundle) {
        r.e(this.f293h, "onConnectionSuccess must only be called on the Handler thread");
        synchronized (this.f294i) {
            r.m(!this.f292g);
            this.f293h.removeMessages(1);
            this.f292g = true;
            r.m(this.f288c.isEmpty());
            ArrayList arrayList = new ArrayList(this.f287b);
            int i10 = this.f291f.get();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                f.b bVar = (f.b) it.next();
                if (!this.f290e || !this.f286a.a() || this.f291f.get() != i10) {
                    break;
                } else if (!this.f288c.contains(bVar)) {
                    bVar.R(bundle);
                }
            }
            this.f288c.clear();
            this.f292g = false;
        }
    }

    public final void e(int i10) {
        r.e(this.f293h, "onUnintentionalDisconnection must only be called on the Handler thread");
        this.f293h.removeMessages(1);
        synchronized (this.f294i) {
            this.f292g = true;
            ArrayList arrayList = new ArrayList(this.f287b);
            int i11 = this.f291f.get();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                f.b bVar = (f.b) it.next();
                if (!this.f290e || this.f291f.get() != i11) {
                    break;
                } else if (this.f287b.contains(bVar)) {
                    bVar.y(i10);
                }
            }
            this.f288c.clear();
            this.f292g = false;
        }
    }

    public final void f(f.b bVar) {
        r.k(bVar);
        synchronized (this.f294i) {
            if (this.f287b.contains(bVar)) {
                Log.w("GmsClientEvents", "registerConnectionCallbacks(): listener " + String.valueOf(bVar) + " is already registered");
            } else {
                this.f287b.add(bVar);
            }
        }
        if (this.f286a.a()) {
            Handler handler = this.f293h;
            handler.sendMessage(handler.obtainMessage(1, bVar));
        }
    }

    public final void g(f.c cVar) {
        r.k(cVar);
        synchronized (this.f294i) {
            if (this.f289d.contains(cVar)) {
                Log.w("GmsClientEvents", "registerConnectionFailedListener(): listener " + String.valueOf(cVar) + " is already registered");
            } else {
                this.f289d.add(cVar);
            }
        }
    }

    public final void h(f.c cVar) {
        r.k(cVar);
        synchronized (this.f294i) {
            if (!this.f289d.remove(cVar)) {
                Log.w("GmsClientEvents", "unregisterConnectionFailedListener(): listener " + String.valueOf(cVar) + " not found");
            }
        }
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        int i10 = message.what;
        if (i10 != 1) {
            Log.wtf("GmsClientEvents", "Don't know how to handle message: " + i10, new Exception());
            return false;
        }
        f.b bVar = (f.b) message.obj;
        synchronized (this.f294i) {
            if (this.f290e && this.f286a.a() && this.f287b.contains(bVar)) {
                bVar.R(null);
            }
        }
        return true;
    }
}
