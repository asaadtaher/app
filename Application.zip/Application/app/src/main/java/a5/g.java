package a5;

import a5.k;
import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;

/* loaded from: classes.dex */
public class g extends b5.a {
    public static final Parcelable.Creator<g> CREATOR = new m1();

    /* renamed from: t, reason: collision with root package name */
    static final Scope[] f250t = new Scope[0];

    /* renamed from: u, reason: collision with root package name */
    static final x4.d[] f251u = new x4.d[0];

    /* renamed from: a, reason: collision with root package name */
    final int f252a;

    /* renamed from: b, reason: collision with root package name */
    final int f253b;

    /* renamed from: c, reason: collision with root package name */
    final int f254c;

    /* renamed from: d, reason: collision with root package name */
    String f255d;

    /* renamed from: e, reason: collision with root package name */
    IBinder f256e;

    /* renamed from: f, reason: collision with root package name */
    Scope[] f257f;

    /* renamed from: g, reason: collision with root package name */
    Bundle f258g;

    /* renamed from: h, reason: collision with root package name */
    Account f259h;

    /* renamed from: i, reason: collision with root package name */
    x4.d[] f260i;

    /* renamed from: j, reason: collision with root package name */
    x4.d[] f261j;

    /* renamed from: k, reason: collision with root package name */
    final boolean f262k;

    /* renamed from: l, reason: collision with root package name */
    final int f263l;

    /* renamed from: r, reason: collision with root package name */
    boolean f264r;

    /* renamed from: s, reason: collision with root package name */
    private final String f265s;

    g(int i10, int i11, int i12, String str, IBinder iBinder, Scope[] scopeArr, Bundle bundle, Account account, x4.d[] dVarArr, x4.d[] dVarArr2, boolean z10, int i13, boolean z11, String str2) {
        scopeArr = scopeArr == null ? f250t : scopeArr;
        bundle = bundle == null ? new Bundle() : bundle;
        dVarArr = dVarArr == null ? f251u : dVarArr;
        dVarArr2 = dVarArr2 == null ? f251u : dVarArr2;
        this.f252a = i10;
        this.f253b = i11;
        this.f254c = i12;
        if ("com.google.android.gms".equals(str)) {
            this.f255d = "com.google.android.gms";
        } else {
            this.f255d = str;
        }
        if (i10 < 2) {
            this.f259h = iBinder != null ? a.R(k.a.y(iBinder)) : null;
        } else {
            this.f256e = iBinder;
            this.f259h = account;
        }
        this.f257f = scopeArr;
        this.f258g = bundle;
        this.f260i = dVarArr;
        this.f261j = dVarArr2;
        this.f262k = z10;
        this.f263l = i13;
        this.f264r = z11;
        this.f265s = str2;
    }

    public final String j() {
        return this.f265s;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        m1.a(this, parcel, i10);
    }
}
