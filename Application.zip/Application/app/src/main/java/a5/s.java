package a5;

/* loaded from: classes.dex */
public final class s {

    /* renamed from: b, reason: collision with root package name */
    private static s f335b;

    /* renamed from: c, reason: collision with root package name */
    private static final t f336c = new t(0, false, false, 0, 0);

    /* renamed from: a, reason: collision with root package name */
    private t f337a;

    private s() {
    }

    public static synchronized s b() {
        if (f335b == null) {
            f335b = new s();
        }
        return f335b;
    }

    public t a() {
        return this.f337a;
    }

    public final synchronized void c(t tVar) {
        if (tVar == null) {
            this.f337a = f336c;
            return;
        }
        t tVar2 = this.f337a;
        if (tVar2 == null || tVar2.n() < tVar.n()) {
            this.f337a = tVar;
        }
    }
}
