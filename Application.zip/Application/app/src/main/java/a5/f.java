package a5;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class f extends b5.a {
    public static final Parcelable.Creator<f> CREATOR = new l1();

    /* renamed from: a, reason: collision with root package name */
    private final t f239a;

    /* renamed from: b, reason: collision with root package name */
    private final boolean f240b;

    /* renamed from: c, reason: collision with root package name */
    private final boolean f241c;

    /* renamed from: d, reason: collision with root package name */
    private final int[] f242d;

    /* renamed from: e, reason: collision with root package name */
    private final int f243e;

    /* renamed from: f, reason: collision with root package name */
    private final int[] f244f;

    public f(t tVar, boolean z10, boolean z11, int[] iArr, int i10, int[] iArr2) {
        this.f239a = tVar;
        this.f240b = z10;
        this.f241c = z11;
        this.f242d = iArr;
        this.f243e = i10;
        this.f244f = iArr2;
    }

    public int j() {
        return this.f243e;
    }

    public int[] k() {
        return this.f242d;
    }

    public int[] l() {
        return this.f244f;
    }

    public boolean m() {
        return this.f240b;
    }

    public boolean n() {
        return this.f241c;
    }

    public final t o() {
        return this.f239a;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.q(parcel, 1, this.f239a, i10, false);
        b5.c.c(parcel, 2, m());
        b5.c.c(parcel, 3, n());
        b5.c.l(parcel, 4, k(), false);
        b5.c.k(parcel, 5, j());
        b5.c.l(parcel, 6, l(), false);
        b5.c.b(parcel, iA);
    }
}
