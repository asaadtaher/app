package a5;

/* loaded from: classes.dex */
public interface r0 {
}
