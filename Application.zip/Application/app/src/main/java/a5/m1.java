package a5;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;

/* loaded from: classes.dex */
public final class m1 implements Parcelable.Creator {
    static void a(g gVar, Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.k(parcel, 1, gVar.f252a);
        b5.c.k(parcel, 2, gVar.f253b);
        b5.c.k(parcel, 3, gVar.f254c);
        b5.c.r(parcel, 4, gVar.f255d, false);
        b5.c.j(parcel, 5, gVar.f256e, false);
        b5.c.u(parcel, 6, gVar.f257f, i10, false);
        b5.c.d(parcel, 7, gVar.f258g, false);
        b5.c.q(parcel, 8, gVar.f259h, i10, false);
        b5.c.u(parcel, 10, gVar.f260i, i10, false);
        b5.c.u(parcel, 11, gVar.f261j, i10, false);
        b5.c.c(parcel, 12, gVar.f262k);
        b5.c.k(parcel, 13, gVar.f263l);
        b5.c.c(parcel, 14, gVar.f264r);
        b5.c.r(parcel, 15, gVar.j(), false);
        b5.c.b(parcel, iA);
    }

    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b5.b.z(parcel);
        Scope[] scopeArr = g.f250t;
        Bundle bundle = new Bundle();
        x4.d[] dVarArr = g.f251u;
        x4.d[] dVarArr2 = dVarArr;
        String strE = null;
        IBinder iBinderR = null;
        Account account = null;
        String strE2 = null;
        int iS = 0;
        int iS2 = 0;
        int iS3 = 0;
        boolean zL = false;
        int iS4 = 0;
        boolean zL2 = false;
        while (parcel.dataPosition() < iZ) {
            int iQ = b5.b.q(parcel);
            switch (b5.b.k(iQ)) {
                case 1:
                    iS = b5.b.s(parcel, iQ);
                    break;
                case 2:
                    iS2 = b5.b.s(parcel, iQ);
                    break;
                case 3:
                    iS3 = b5.b.s(parcel, iQ);
                    break;
                case 4:
                    strE = b5.b.e(parcel, iQ);
                    break;
                case 5:
                    iBinderR = b5.b.r(parcel, iQ);
                    break;
                case 6:
                    scopeArr = (Scope[]) b5.b.h(parcel, iQ, Scope.CREATOR);
                    break;
                case 7:
                    bundle = b5.b.a(parcel, iQ);
                    break;
                case 8:
                    account = (Account) b5.b.d(parcel, iQ, Account.CREATOR);
                    break;
                case 9:
                default:
                    b5.b.y(parcel, iQ);
                    break;
                case 10:
                    dVarArr = (x4.d[]) b5.b.h(parcel, iQ, x4.d.CREATOR);
                    break;
                case 11:
                    dVarArr2 = (x4.d[]) b5.b.h(parcel, iQ, x4.d.CREATOR);
                    break;
                case 12:
                    zL = b5.b.l(parcel, iQ);
                    break;
                case 13:
                    iS4 = b5.b.s(parcel, iQ);
                    break;
                case 14:
                    zL2 = b5.b.l(parcel, iQ);
                    break;
                case 15:
                    strE2 = b5.b.e(parcel, iQ);
                    break;
            }
        }
        b5.b.j(parcel, iZ);
        return new g(iS, iS2, iS3, strE, iBinderR, scopeArr, bundle, account, dVarArr, dVarArr2, zL, iS4, zL2, strE2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new g[i10];
    }
}
