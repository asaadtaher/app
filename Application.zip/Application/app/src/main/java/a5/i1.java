package a5;

import android.os.Bundle;

/* loaded from: classes.dex */
public final class i1 extends w0 {

    /* renamed from: g, reason: collision with root package name */
    final /* synthetic */ c f278g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i1(c cVar, int i10, Bundle bundle) {
        super(cVar, i10, null);
        this.f278g = cVar;
    }

    @Override // a5.w0
    protected final void f(x4.b bVar) {
        if (this.f278g.x() && c.k0(this.f278g)) {
            c.g0(this.f278g, 16);
        } else {
            this.f278g.f203p.c(bVar);
            this.f278g.P(bVar);
        }
    }

    @Override // a5.w0
    protected final boolean g() {
        this.f278g.f203p.c(x4.b.f23623e);
        return true;
    }
}
