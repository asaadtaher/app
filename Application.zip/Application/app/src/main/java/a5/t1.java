package a5;

/* loaded from: classes.dex */
public final class t1 {

    /* renamed from: a, reason: collision with root package name */
    private final String f347a;

    /* renamed from: b, reason: collision with root package name */
    private final String f348b;

    /* renamed from: c, reason: collision with root package name */
    private final boolean f349c;

    public t1(String str, String str2, boolean z10, int i10, boolean z11) {
        this.f348b = str;
        this.f347a = str2;
        this.f349c = z11;
    }

    final String a() {
        return this.f348b;
    }

    final String b() {
        return this.f347a;
    }

    final boolean c() {
        return this.f349c;
    }
}
