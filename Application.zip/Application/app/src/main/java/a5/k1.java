package a5;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class k1 implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b5.b.z(parcel);
        Bundle bundleA = null;
        x4.d[] dVarArr = null;
        f fVar = null;
        int iS = 0;
        while (parcel.dataPosition() < iZ) {
            int iQ = b5.b.q(parcel);
            int iK = b5.b.k(iQ);
            if (iK == 1) {
                bundleA = b5.b.a(parcel, iQ);
            } else if (iK == 2) {
                dVarArr = (x4.d[]) b5.b.h(parcel, iQ, x4.d.CREATOR);
            } else if (iK == 3) {
                iS = b5.b.s(parcel, iQ);
            } else if (iK != 4) {
                b5.b.y(parcel, iQ);
            } else {
                fVar = (f) b5.b.d(parcel, iQ, f.CREATOR);
            }
        }
        b5.b.j(parcel, iZ);
        return new j1(bundleA, dVarArr, iS, fVar);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new j1[i10];
    }
}
