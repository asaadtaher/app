package a5;

import android.content.Context;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.Looper;
import java.util.HashMap;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class r1 extends i {

    /* renamed from: f, reason: collision with root package name */
    private final HashMap f327f = new HashMap();

    /* renamed from: g, reason: collision with root package name */
    private final Context f328g;

    /* renamed from: h, reason: collision with root package name */
    private volatile Handler f329h;

    /* renamed from: i, reason: collision with root package name */
    private final q1 f330i;

    /* renamed from: j, reason: collision with root package name */
    private final e5.a f331j;

    /* renamed from: k, reason: collision with root package name */
    private final long f332k;

    /* renamed from: l, reason: collision with root package name */
    private final long f333l;

    /* renamed from: m, reason: collision with root package name */
    private volatile Executor f334m;

    r1(Context context, Looper looper, Executor executor) {
        q1 q1Var = new q1(this, null);
        this.f330i = q1Var;
        this.f328g = context.getApplicationContext();
        this.f329h = new o5.e(looper, q1Var);
        this.f331j = e5.a.b();
        this.f332k = 5000L;
        this.f333l = 300000L;
        this.f334m = executor;
    }

    @Override // a5.i
    protected final void f(n1 n1Var, ServiceConnection serviceConnection, String str) {
        r.l(serviceConnection, "ServiceConnection must not be null");
        synchronized (this.f327f) {
            o1 o1Var = (o1) this.f327f.get(n1Var);
            if (o1Var == null) {
                throw new IllegalStateException("Nonexistent connection status for service config: " + n1Var.toString());
            }
            if (!o1Var.h(serviceConnection)) {
                throw new IllegalStateException("Trying to unbind a GmsServiceConnection  that was not bound before.  config=" + n1Var.toString());
            }
            o1Var.f(serviceConnection, str);
            if (o1Var.i()) {
                this.f329h.sendMessageDelayed(this.f329h.obtainMessage(0, n1Var), this.f332k);
            }
        }
    }

    @Override // a5.i
    protected final boolean h(n1 n1Var, ServiceConnection serviceConnection, String str, Executor executor) {
        boolean zJ;
        r.l(serviceConnection, "ServiceConnection must not be null");
        synchronized (this.f327f) {
            o1 o1Var = (o1) this.f327f.get(n1Var);
            if (executor == null) {
                executor = this.f334m;
            }
            if (o1Var == null) {
                o1Var = new o1(this, n1Var);
                o1Var.d(serviceConnection, serviceConnection, str);
                o1Var.e(str, executor);
                this.f327f.put(n1Var, o1Var);
            } else {
                this.f329h.removeMessages(0, n1Var);
                if (o1Var.h(serviceConnection)) {
                    throw new IllegalStateException("Trying to bind a GmsServiceConnection that was already connected before.  config=" + n1Var.toString());
                }
                o1Var.d(serviceConnection, serviceConnection, str);
                int iA = o1Var.a();
                if (iA == 1) {
                    serviceConnection.onServiceConnected(o1Var.b(), o1Var.c());
                } else if (iA == 2) {
                    o1Var.e(str, executor);
                }
            }
            zJ = o1Var.j();
        }
        return zJ;
    }
}
