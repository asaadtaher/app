package a5;

import android.app.PendingIntent;
import android.os.Bundle;

/* loaded from: classes.dex */
abstract class w0 extends e1 {

    /* renamed from: d, reason: collision with root package name */
    public final int f359d;

    /* renamed from: e, reason: collision with root package name */
    public final Bundle f360e;

    /* renamed from: f, reason: collision with root package name */
    final /* synthetic */ c f361f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    protected w0(c cVar, int i10, Bundle bundle) {
        super(cVar, Boolean.TRUE);
        this.f361f = cVar;
        this.f359d = i10;
        this.f360e = bundle;
    }

    @Override // a5.e1
    protected final /* bridge */ /* synthetic */ void a(Object obj) {
        x4.b bVar;
        if (this.f359d != 0) {
            this.f361f.l0(1, null);
            Bundle bundle = this.f360e;
            bVar = new x4.b(this.f359d, bundle != null ? (PendingIntent) bundle.getParcelable("pendingIntent") : null);
        } else {
            if (g()) {
                return;
            }
            this.f361f.l0(1, null);
            bVar = new x4.b(8, null);
        }
        f(bVar);
    }

    @Override // a5.e1
    protected final void b() {
    }

    protected abstract void f(x4.b bVar);

    protected abstract boolean g();
}
