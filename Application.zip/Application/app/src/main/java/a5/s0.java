package a5;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

/* loaded from: classes.dex */
public final class s0 extends b5.a {
    public static final Parcelable.Creator<s0> CREATOR = new t0();

    /* renamed from: a, reason: collision with root package name */
    final int f338a;

    /* renamed from: b, reason: collision with root package name */
    private final Account f339b;

    /* renamed from: c, reason: collision with root package name */
    private final int f340c;

    /* renamed from: d, reason: collision with root package name */
    private final GoogleSignInAccount f341d;

    s0(int i10, Account account, int i11, GoogleSignInAccount googleSignInAccount) {
        this.f338a = i10;
        this.f339b = account;
        this.f340c = i11;
        this.f341d = googleSignInAccount;
    }

    public s0(Account account, int i10, GoogleSignInAccount googleSignInAccount) {
        this(2, account, i10, googleSignInAccount);
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.k(parcel, 1, this.f338a);
        b5.c.q(parcel, 2, this.f339b, i10, false);
        b5.c.k(parcel, 3, this.f340c);
        b5.c.q(parcel, 4, this.f341d, i10, false);
        b5.c.b(parcel, iA);
    }
}
