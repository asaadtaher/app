package a5;

import android.accounts.Account;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.api.Scope;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.dex */
public abstract class c<T extends IInterface> {

    /* renamed from: a, reason: collision with root package name */
    private int f188a;

    /* renamed from: b, reason: collision with root package name */
    private long f189b;

    /* renamed from: c, reason: collision with root package name */
    private long f190c;

    /* renamed from: d, reason: collision with root package name */
    private int f191d;

    /* renamed from: e, reason: collision with root package name */
    private long f192e;

    /* renamed from: g, reason: collision with root package name */
    t1 f194g;

    /* renamed from: h, reason: collision with root package name */
    private final Context f195h;

    /* renamed from: i, reason: collision with root package name */
    private final Looper f196i;

    /* renamed from: j, reason: collision with root package name */
    private final i f197j;

    /* renamed from: k, reason: collision with root package name */
    private final x4.f f198k;

    /* renamed from: l, reason: collision with root package name */
    final Handler f199l;

    /* renamed from: o, reason: collision with root package name */
    private n f202o;

    /* renamed from: p, reason: collision with root package name */
    protected InterfaceC0003c f203p;

    /* renamed from: q, reason: collision with root package name */
    private IInterface f204q;

    /* renamed from: s, reason: collision with root package name */
    private g1 f206s;

    /* renamed from: u, reason: collision with root package name */
    private final a f208u;

    /* renamed from: v, reason: collision with root package name */
    private final b f209v;

    /* renamed from: w, reason: collision with root package name */
    private final int f210w;

    /* renamed from: x, reason: collision with root package name */
    private final String f211x;

    /* renamed from: y, reason: collision with root package name */
    private volatile String f212y;
    private static final x4.d[] E = new x4.d[0];
    public static final String[] D = {"service_esmobile", "service_googleme"};

    /* renamed from: f, reason: collision with root package name */
    private volatile String f193f = null;

    /* renamed from: m, reason: collision with root package name */
    private final Object f200m = new Object();

    /* renamed from: n, reason: collision with root package name */
    private final Object f201n = new Object();

    /* renamed from: r, reason: collision with root package name */
    private final ArrayList f205r = new ArrayList();

    /* renamed from: t, reason: collision with root package name */
    private int f207t = 1;

    /* renamed from: z, reason: collision with root package name */
    private x4.b f213z = null;
    private boolean A = false;
    private volatile j1 B = null;
    protected AtomicInteger C = new AtomicInteger(0);

    public interface a {
        void R(Bundle bundle);

        void y(int i10);
    }

    public interface b {
        void r(x4.b bVar);
    }

    /* renamed from: a5.c$c, reason: collision with other inner class name */
    public interface InterfaceC0003c {
        void c(x4.b bVar);
    }

    protected class d implements InterfaceC0003c {
        public d() {
        }

        @Override // a5.c.InterfaceC0003c
        public final void c(x4.b bVar) {
            if (bVar.n()) {
                c cVar = c.this;
                cVar.d(null, cVar.G());
            } else if (c.this.f209v != null) {
                c.this.f209v.r(bVar);
            }
        }
    }

    public interface e {
        void a();
    }

    protected c(Context context, Looper looper, i iVar, x4.f fVar, int i10, a aVar, b bVar, String str) {
        r.l(context, "Context must not be null");
        this.f195h = context;
        r.l(looper, "Looper must not be null");
        this.f196i = looper;
        r.l(iVar, "Supervisor must not be null");
        this.f197j = iVar;
        r.l(fVar, "API availability must not be null");
        this.f198k = fVar;
        this.f199l = new d1(this, looper);
        this.f210w = i10;
        this.f208u = aVar;
        this.f209v = bVar;
        this.f211x = str;
    }

    static /* bridge */ /* synthetic */ void f0(c cVar, j1 j1Var) {
        cVar.B = j1Var;
        if (cVar.V()) {
            f fVar = j1Var.f285d;
            s.b().c(fVar == null ? null : fVar.o());
        }
    }

    static /* bridge */ /* synthetic */ void g0(c cVar, int i10) {
        int i11;
        int i12;
        synchronized (cVar.f200m) {
            i11 = cVar.f207t;
        }
        if (i11 == 3) {
            cVar.A = true;
            i12 = 5;
        } else {
            i12 = 4;
        }
        Handler handler = cVar.f199l;
        handler.sendMessage(handler.obtainMessage(i12, cVar.C.get(), 16));
    }

    static /* bridge */ /* synthetic */ boolean j0(c cVar, int i10, int i11, IInterface iInterface) {
        synchronized (cVar.f200m) {
            if (cVar.f207t != i10) {
                return false;
            }
            cVar.l0(i11, iInterface);
            return true;
        }
    }

    static /* bridge */ /* synthetic */ boolean k0(c cVar) throws ClassNotFoundException {
        if (cVar.A || TextUtils.isEmpty(cVar.I()) || TextUtils.isEmpty(cVar.F())) {
            return false;
        }
        try {
            Class.forName(cVar.I());
            return true;
        } catch (ClassNotFoundException unused) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void l0(int i10, IInterface iInterface) {
        t1 t1Var;
        r.a((i10 == 4) == (iInterface != null));
        synchronized (this.f200m) {
            this.f207t = i10;
            this.f204q = iInterface;
            if (i10 == 1) {
                g1 g1Var = this.f206s;
                if (g1Var != null) {
                    i iVar = this.f197j;
                    String strB = this.f194g.b();
                    r.k(strB);
                    iVar.g(strB, this.f194g.a(), 4225, g1Var, a0(), this.f194g.c());
                    this.f206s = null;
                }
            } else if (i10 == 2 || i10 == 3) {
                g1 g1Var2 = this.f206s;
                if (g1Var2 != null && (t1Var = this.f194g) != null) {
                    Log.e("GmsClient", "Calling connect() while still connected, missing disconnect() for " + t1Var.b() + " on " + t1Var.a());
                    i iVar2 = this.f197j;
                    String strB2 = this.f194g.b();
                    r.k(strB2);
                    iVar2.g(strB2, this.f194g.a(), 4225, g1Var2, a0(), this.f194g.c());
                    this.C.incrementAndGet();
                }
                g1 g1Var3 = new g1(this, this.C.get());
                this.f206s = g1Var3;
                t1 t1Var2 = (this.f207t != 3 || F() == null) ? new t1(K(), J(), false, 4225, M()) : new t1(C().getPackageName(), F(), true, 4225, false);
                this.f194g = t1Var2;
                if (t1Var2.c() && m() < 17895000) {
                    throw new IllegalStateException("Internal Error, the minimum apk version of this BaseGmsClient is too low to support dynamic lookup. Start service action: ".concat(String.valueOf(this.f194g.b())));
                }
                i iVar3 = this.f197j;
                String strB3 = this.f194g.b();
                r.k(strB3);
                if (!iVar3.h(new n1(strB3, this.f194g.a(), 4225, this.f194g.c()), g1Var3, a0(), A())) {
                    Log.w("GmsClient", "unable to connect to service: " + this.f194g.b() + " on " + this.f194g.a());
                    h0(16, null, this.C.get());
                }
            } else if (i10 == 4) {
                r.k(iInterface);
                O(iInterface);
            }
        }
    }

    protected Executor A() {
        return null;
    }

    public Bundle B() {
        return null;
    }

    public final Context C() {
        return this.f195h;
    }

    public int D() {
        return this.f210w;
    }

    protected Bundle E() {
        return new Bundle();
    }

    protected String F() {
        return null;
    }

    protected Set<Scope> G() {
        return Collections.emptySet();
    }

    public final T H() {
        T t10;
        synchronized (this.f200m) {
            if (this.f207t == 5) {
                throw new DeadObjectException();
            }
            v();
            t10 = (T) this.f204q;
            r.l(t10, "Client is connected but service is null");
        }
        return t10;
    }

    protected abstract String I();

    protected abstract String J();

    protected String K() {
        return "com.google.android.gms";
    }

    public f L() {
        j1 j1Var = this.B;
        if (j1Var == null) {
            return null;
        }
        return j1Var.f285d;
    }

    protected boolean M() {
        return m() >= 211700000;
    }

    public boolean N() {
        return this.B != null;
    }

    protected void O(T t10) {
        this.f190c = System.currentTimeMillis();
    }

    protected void P(x4.b bVar) {
        this.f191d = bVar.j();
        this.f192e = System.currentTimeMillis();
    }

    protected void Q(int i10) {
        this.f188a = i10;
        this.f189b = System.currentTimeMillis();
    }

    protected void R(int i10, IBinder iBinder, Bundle bundle, int i11) {
        Handler handler = this.f199l;
        handler.sendMessage(handler.obtainMessage(1, i11, -1, new h1(this, i10, iBinder, bundle)));
    }

    public boolean S() {
        return false;
    }

    public void T(String str) {
        this.f212y = str;
    }

    public void U(int i10) {
        Handler handler = this.f199l;
        handler.sendMessage(handler.obtainMessage(6, this.C.get(), i10));
    }

    public boolean V() {
        return false;
    }

    public boolean a() {
        boolean z10;
        synchronized (this.f200m) {
            z10 = this.f207t == 4;
        }
        return z10;
    }

    protected final String a0() {
        String str = this.f211x;
        return str == null ? this.f195h.getClass().getName() : str;
    }

    public void d(k kVar, Set<Scope> set) {
        Bundle bundleE = E();
        int i10 = this.f210w;
        String str = this.f212y;
        int i11 = x4.f.f23638a;
        Scope[] scopeArr = g.f250t;
        Bundle bundle = new Bundle();
        x4.d[] dVarArr = g.f251u;
        g gVar = new g(6, i10, i11, null, null, scopeArr, bundle, null, dVarArr, dVarArr, true, 0, false, str);
        gVar.f255d = this.f195h.getPackageName();
        gVar.f258g = bundleE;
        if (set != null) {
            gVar.f257f = (Scope[]) set.toArray(new Scope[0]);
        }
        if (t()) {
            Account accountY = y();
            if (accountY == null) {
                accountY = new Account("<<default account>>", "com.google");
            }
            gVar.f259h = accountY;
            if (kVar != null) {
                gVar.f256e = kVar.asBinder();
            }
        } else if (S()) {
            gVar.f259h = y();
        }
        gVar.f260i = E;
        gVar.f261j = z();
        if (V()) {
            gVar.f264r = true;
        }
        try {
            synchronized (this.f201n) {
                n nVar = this.f202o;
                if (nVar != null) {
                    nVar.P0(new f1(this, this.C.get()), gVar);
                } else {
                    Log.w("GmsClient", "mServiceBroker is null, client disconnected");
                }
            }
        } catch (DeadObjectException e10) {
            Log.w("GmsClient", "IGmsServiceBroker.getService failed", e10);
            U(3);
        } catch (RemoteException e11) {
            e = e11;
            Log.w("GmsClient", "IGmsServiceBroker.getService failed", e);
            R(8, null, null, this.C.get());
        } catch (SecurityException e12) {
            throw e12;
        } catch (RuntimeException e13) {
            e = e13;
            Log.w("GmsClient", "IGmsServiceBroker.getService failed", e);
            R(8, null, null, this.C.get());
        }
    }

    public void e(InterfaceC0003c interfaceC0003c) {
        r.l(interfaceC0003c, "Connection progress callbacks cannot be null.");
        this.f203p = interfaceC0003c;
        l0(2, null);
    }

    public boolean f() {
        return false;
    }

    public void h(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int i10;
        IInterface iInterface;
        n nVar;
        synchronized (this.f200m) {
            i10 = this.f207t;
            iInterface = this.f204q;
        }
        synchronized (this.f201n) {
            nVar = this.f202o;
        }
        printWriter.append((CharSequence) str).append("mConnectState=");
        printWriter.print(i10 != 1 ? i10 != 2 ? i10 != 3 ? i10 != 4 ? i10 != 5 ? "UNKNOWN" : "DISCONNECTING" : "CONNECTED" : "LOCAL_CONNECTING" : "REMOTE_CONNECTING" : "DISCONNECTED");
        printWriter.append(" mService=");
        if (iInterface == null) {
            printWriter.append("null");
        } else {
            printWriter.append((CharSequence) I()).append("@").append((CharSequence) Integer.toHexString(System.identityHashCode(iInterface.asBinder())));
        }
        printWriter.append(" mServiceBroker=");
        if (nVar == null) {
            printWriter.println("null");
        } else {
            printWriter.append("IGmsServiceBroker@").println(Integer.toHexString(System.identityHashCode(nVar.asBinder())));
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);
        if (this.f190c > 0) {
            PrintWriter printWriterAppend = printWriter.append((CharSequence) str).append("lastConnectedTime=");
            long j10 = this.f190c;
            printWriterAppend.println(j10 + " " + simpleDateFormat.format(new Date(j10)));
        }
        if (this.f189b > 0) {
            printWriter.append((CharSequence) str).append("lastSuspendedCause=");
            int i11 = this.f188a;
            printWriter.append((CharSequence) (i11 != 1 ? i11 != 2 ? i11 != 3 ? String.valueOf(i11) : "CAUSE_DEAD_OBJECT_EXCEPTION" : "CAUSE_NETWORK_LOST" : "CAUSE_SERVICE_DISCONNECTED"));
            PrintWriter printWriterAppend2 = printWriter.append(" lastSuspendedTime=");
            long j11 = this.f189b;
            printWriterAppend2.println(j11 + " " + simpleDateFormat.format(new Date(j11)));
        }
        if (this.f192e > 0) {
            printWriter.append((CharSequence) str).append("lastFailedStatus=").append((CharSequence) y4.d.a(this.f191d));
            PrintWriter printWriterAppend3 = printWriter.append(" lastFailedTime=");
            long j12 = this.f192e;
            printWriterAppend3.println(j12 + " " + simpleDateFormat.format(new Date(j12)));
        }
    }

    protected final void h0(int i10, Bundle bundle, int i11) {
        Handler handler = this.f199l;
        handler.sendMessage(handler.obtainMessage(7, i11, -1, new i1(this, i10, null)));
    }

    public void i(String str) {
        this.f193f = str;
        r();
    }

    public void j(e eVar) {
        eVar.a();
    }

    public boolean l() {
        return true;
    }

    public int m() {
        return x4.f.f23638a;
    }

    public boolean n() {
        boolean z10;
        synchronized (this.f200m) {
            int i10 = this.f207t;
            z10 = true;
            if (i10 != 2 && i10 != 3) {
                z10 = false;
            }
        }
        return z10;
    }

    public final x4.d[] o() {
        j1 j1Var = this.B;
        if (j1Var == null) {
            return null;
        }
        return j1Var.f283b;
    }

    public String p() {
        t1 t1Var;
        if (!a() || (t1Var = this.f194g) == null) {
            throw new RuntimeException("Failed to connect when checking package");
        }
        return t1Var.a();
    }

    public String q() {
        return this.f193f;
    }

    public void r() {
        this.C.incrementAndGet();
        synchronized (this.f205r) {
            int size = this.f205r.size();
            for (int i10 = 0; i10 < size; i10++) {
                ((e1) this.f205r.get(i10)).d();
            }
            this.f205r.clear();
        }
        synchronized (this.f201n) {
            this.f202o = null;
        }
        l0(1, null);
    }

    public Intent s() {
        throw new UnsupportedOperationException("Not a sign in API");
    }

    public boolean t() {
        return false;
    }

    protected final void v() {
        if (!a()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    protected abstract T w(IBinder iBinder);

    protected boolean x() {
        return false;
    }

    public Account y() {
        return null;
    }

    public x4.d[] z() {
        return E;
    }
}
