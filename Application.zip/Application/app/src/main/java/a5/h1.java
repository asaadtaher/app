package a5;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.util.Log;

/* loaded from: classes.dex */
public final class h1 extends w0 {

    /* renamed from: g, reason: collision with root package name */
    public final IBinder f270g;

    /* renamed from: h, reason: collision with root package name */
    final /* synthetic */ c f271h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h1(c cVar, int i10, IBinder iBinder, Bundle bundle) {
        super(cVar, i10, bundle);
        this.f271h = cVar;
        this.f270g = iBinder;
    }

    @Override // a5.w0
    protected final void f(x4.b bVar) {
        if (this.f271h.f209v != null) {
            this.f271h.f209v.r(bVar);
        }
        this.f271h.P(bVar);
    }

    @Override // a5.w0
    protected final boolean g() throws RemoteException {
        String str;
        String interfaceDescriptor;
        try {
            IBinder iBinder = this.f270g;
            r.k(iBinder);
            interfaceDescriptor = iBinder.getInterfaceDescriptor();
        } catch (RemoteException unused) {
            str = "service probably died";
        }
        if (!this.f271h.I().equals(interfaceDescriptor)) {
            str = "service descriptor mismatch: " + this.f271h.I() + " vs. " + interfaceDescriptor;
            Log.w("GmsClient", str);
            return false;
        }
        IInterface iInterfaceW = this.f271h.w(this.f270g);
        if (iInterfaceW == null || !(c.j0(this.f271h, 2, 4, iInterfaceW) || c.j0(this.f271h, 3, 4, iInterfaceW))) {
            return false;
        }
        this.f271h.f213z = null;
        Bundle bundleB = this.f271h.B();
        c cVar = this.f271h;
        if (cVar.f208u == null) {
            return true;
        }
        cVar.f208u.R(bundleB);
        return true;
    }
}
