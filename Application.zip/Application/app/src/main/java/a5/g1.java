package a5;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;

/* loaded from: classes.dex */
public final class g1 implements ServiceConnection {

    /* renamed from: a, reason: collision with root package name */
    private final int f268a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ c f269b;

    public g1(c cVar, int i10) {
        this.f269b = cVar;
        this.f268a = i10;
    }

    @Override // android.content.ServiceConnection
    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        c cVar = this.f269b;
        if (iBinder == null) {
            c.g0(cVar, 16);
            return;
        }
        synchronized (cVar.f201n) {
            c cVar2 = this.f269b;
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.IGmsServiceBroker");
            cVar2.f202o = (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof n)) ? new z0(iBinder) : (n) iInterfaceQueryLocalInterface;
        }
        this.f269b.h0(0, null, this.f268a);
    }

    @Override // android.content.ServiceConnection
    public final void onServiceDisconnected(ComponentName componentName) {
        synchronized (this.f269b.f201n) {
            this.f269b.f202o = null;
        }
        Handler handler = this.f269b.f199l;
        handler.sendMessage(handler.obtainMessage(6, this.f268a, 1));
    }
}
