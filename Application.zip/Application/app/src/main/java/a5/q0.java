package a5;

import a5.q;

/* loaded from: classes.dex */
final class q0 implements q.a {
    q0() {
    }

    @Override // a5.q.a
    public final /* bridge */ /* synthetic */ Object a(y4.m mVar) {
        return null;
    }
}
