package a5;

import android.os.Parcel;

/* loaded from: classes.dex */
public abstract class v1 extends o5.b implements x0 {
    public v1() {
        super("com.google.android.gms.common.internal.ICertData");
    }

    @Override // o5.b
    protected final boolean r(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (i10 == 1) {
            i5.b bVarA = a();
            parcel2.writeNoException();
            o5.c.c(parcel2, bVarA);
        } else {
            if (i10 != 2) {
                return false;
            }
            int iJ = j();
            parcel2.writeNoException();
            parcel2.writeInt(iJ);
        }
        return true;
    }
}
