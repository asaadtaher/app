package a5;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class n0 implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b5.b.z(parcel);
        String strE = null;
        String strE2 = null;
        long jV = 0;
        long jV2 = 0;
        int iS = 0;
        int iS2 = 0;
        int iS3 = 0;
        int iS4 = 0;
        int iS5 = -1;
        while (parcel.dataPosition() < iZ) {
            int iQ = b5.b.q(parcel);
            switch (b5.b.k(iQ)) {
                case 1:
                    iS = b5.b.s(parcel, iQ);
                    break;
                case 2:
                    iS2 = b5.b.s(parcel, iQ);
                    break;
                case 3:
                    iS3 = b5.b.s(parcel, iQ);
                    break;
                case 4:
                    jV = b5.b.v(parcel, iQ);
                    break;
                case 5:
                    jV2 = b5.b.v(parcel, iQ);
                    break;
                case 6:
                    strE = b5.b.e(parcel, iQ);
                    break;
                case 7:
                    strE2 = b5.b.e(parcel, iQ);
                    break;
                case 8:
                    iS4 = b5.b.s(parcel, iQ);
                    break;
                case 9:
                    iS5 = b5.b.s(parcel, iQ);
                    break;
                default:
                    b5.b.y(parcel, iQ);
                    break;
            }
        }
        b5.b.j(parcel, iZ);
        return new o(iS, iS2, iS3, jV, jV2, strE, strE2, iS4, iS5);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new o[i10];
    }
}
