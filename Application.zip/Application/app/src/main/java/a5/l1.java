package a5;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class l1 implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b5.b.z(parcel);
        t tVar = null;
        int[] iArrC = null;
        int[] iArrC2 = null;
        boolean zL = false;
        boolean zL2 = false;
        int iS = 0;
        while (parcel.dataPosition() < iZ) {
            int iQ = b5.b.q(parcel);
            switch (b5.b.k(iQ)) {
                case 1:
                    tVar = (t) b5.b.d(parcel, iQ, t.CREATOR);
                    break;
                case 2:
                    zL = b5.b.l(parcel, iQ);
                    break;
                case 3:
                    zL2 = b5.b.l(parcel, iQ);
                    break;
                case 4:
                    iArrC = b5.b.c(parcel, iQ);
                    break;
                case 5:
                    iS = b5.b.s(parcel, iQ);
                    break;
                case 6:
                    iArrC2 = b5.b.c(parcel, iQ);
                    break;
                default:
                    b5.b.y(parcel, iQ);
                    break;
            }
        }
        b5.b.j(parcel, iZ);
        return new f(tVar, zL, zL2, iArrC, iS, iArrC2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new f[i10];
    }
}
