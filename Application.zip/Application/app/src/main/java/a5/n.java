package a5;

import android.os.IInterface;

/* loaded from: classes.dex */
public interface n extends IInterface {
    void P0(m mVar, g gVar);
}
