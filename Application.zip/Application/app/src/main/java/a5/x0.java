package a5;

import android.os.IInterface;

/* loaded from: classes.dex */
public interface x0 extends IInterface {
    i5.b a();

    int j();
}
