package a5;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;

/* loaded from: classes.dex */
public interface m extends IInterface {
    void Q0(int i10, IBinder iBinder, j1 j1Var);

    void R1(int i10, Bundle bundle);

    void b3(int i10, IBinder iBinder, Bundle bundle);
}
