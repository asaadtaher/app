package a5;

import a5.c;

/* loaded from: classes.dex */
final class j0 implements c.b {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ z4.h f281a;

    j0(z4.h hVar) {
        this.f281a = hVar;
    }

    @Override // a5.c.b
    public final void r(x4.b bVar) {
        this.f281a.r(bVar);
    }
}
