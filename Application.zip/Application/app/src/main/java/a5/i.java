package a5;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.HandlerThread;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public abstract class i {

    /* renamed from: a, reason: collision with root package name */
    private static final Object f272a = new Object();

    /* renamed from: b, reason: collision with root package name */
    private static r1 f273b = null;

    /* renamed from: c, reason: collision with root package name */
    static HandlerThread f274c = null;

    /* renamed from: d, reason: collision with root package name */
    private static Executor f275d = null;

    /* renamed from: e, reason: collision with root package name */
    private static boolean f276e = false;

    public static int b() {
        return 4225;
    }

    public static i c(Context context) {
        synchronized (f272a) {
            if (f273b == null) {
                f273b = new r1(context.getApplicationContext(), f276e ? d().getLooper() : context.getMainLooper(), f275d);
            }
        }
        return f273b;
    }

    public static HandlerThread d() {
        synchronized (f272a) {
            HandlerThread handlerThread = f274c;
            if (handlerThread != null) {
                return handlerThread;
            }
            HandlerThread handlerThread2 = new HandlerThread("GoogleApiHandler", 9);
            f274c = handlerThread2;
            handlerThread2.start();
            return f274c;
        }
    }

    public boolean a(ComponentName componentName, ServiceConnection serviceConnection, String str) {
        return h(new n1(componentName, 4225), serviceConnection, str, null);
    }

    public void e(ComponentName componentName, ServiceConnection serviceConnection, String str) {
        f(new n1(componentName, 4225), serviceConnection, str);
    }

    protected abstract void f(n1 n1Var, ServiceConnection serviceConnection, String str);

    public final void g(String str, String str2, int i10, ServiceConnection serviceConnection, String str3, boolean z10) {
        f(new n1(str, str2, 4225, z10), serviceConnection, str3);
    }

    protected abstract boolean h(n1 n1Var, ServiceConnection serviceConnection, String str, Executor executor);
}
