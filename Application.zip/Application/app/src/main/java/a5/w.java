package a5;

import android.content.Context;

/* loaded from: classes.dex */
public class w {
    public static x a(Context context) {
        return b(context, y.f362b);
    }

    public static x b(Context context, y yVar) {
        return new c5.d(context, yVar);
    }
}
