package a5;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.StrictMode;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class o1 implements ServiceConnection, s1 {

    /* renamed from: a, reason: collision with root package name */
    private final Map f312a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    private int f313b = 2;

    /* renamed from: c, reason: collision with root package name */
    private boolean f314c;

    /* renamed from: d, reason: collision with root package name */
    private IBinder f315d;

    /* renamed from: e, reason: collision with root package name */
    private final n1 f316e;

    /* renamed from: f, reason: collision with root package name */
    private ComponentName f317f;

    /* renamed from: g, reason: collision with root package name */
    final /* synthetic */ r1 f318g;

    public o1(r1 r1Var, n1 n1Var) {
        this.f318g = r1Var;
        this.f316e = n1Var;
    }

    public final int a() {
        return this.f313b;
    }

    public final ComponentName b() {
        return this.f317f;
    }

    public final IBinder c() {
        return this.f315d;
    }

    public final void d(ServiceConnection serviceConnection, ServiceConnection serviceConnection2, String str) {
        this.f312a.put(serviceConnection, serviceConnection2);
    }

    public final void e(String str, Executor executor) {
        this.f313b = 3;
        StrictMode.VmPolicy vmPolicy = StrictMode.getVmPolicy();
        if (f5.k.l()) {
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder(vmPolicy).permitUnsafeIntentLaunch().build());
        }
        try {
            r1 r1Var = this.f318g;
            boolean zD = r1Var.f331j.d(r1Var.f328g, str, this.f316e.b(r1Var.f328g), this, 4225, executor);
            this.f314c = zD;
            if (zD) {
                this.f318g.f329h.sendMessageDelayed(this.f318g.f329h.obtainMessage(1, this.f316e), this.f318g.f333l);
            } else {
                this.f313b = 2;
                try {
                    r1 r1Var2 = this.f318g;
                    r1Var2.f331j.c(r1Var2.f328g, this);
                } catch (IllegalArgumentException unused) {
                }
            }
        } finally {
            StrictMode.setVmPolicy(vmPolicy);
        }
    }

    public final void f(ServiceConnection serviceConnection, String str) {
        this.f312a.remove(serviceConnection);
    }

    public final void g(String str) {
        this.f318g.f329h.removeMessages(1, this.f316e);
        r1 r1Var = this.f318g;
        r1Var.f331j.c(r1Var.f328g, this);
        this.f314c = false;
        this.f313b = 2;
    }

    public final boolean h(ServiceConnection serviceConnection) {
        return this.f312a.containsKey(serviceConnection);
    }

    public final boolean i() {
        return this.f312a.isEmpty();
    }

    public final boolean j() {
        return this.f314c;
    }

    @Override // android.content.ServiceConnection
    public final void onBindingDied(ComponentName componentName) {
        onServiceDisconnected(componentName);
    }

    @Override // android.content.ServiceConnection
    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        synchronized (this.f318g.f327f) {
            this.f318g.f329h.removeMessages(1, this.f316e);
            this.f315d = iBinder;
            this.f317f = componentName;
            Iterator it = this.f312a.values().iterator();
            while (it.hasNext()) {
                ((ServiceConnection) it.next()).onServiceConnected(componentName, iBinder);
            }
            this.f313b = 1;
        }
    }

    @Override // android.content.ServiceConnection
    public final void onServiceDisconnected(ComponentName componentName) {
        synchronized (this.f318g.f327f) {
            this.f318g.f329h.removeMessages(1, this.f316e);
            this.f315d = null;
            this.f317f = componentName;
            Iterator it = this.f312a.values().iterator();
            while (it.hasNext()) {
                ((ServiceConnection) it.next()).onServiceDisconnected(componentName);
            }
            this.f313b = 2;
        }
    }
}
