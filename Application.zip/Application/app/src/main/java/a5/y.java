package a5;

import android.os.Bundle;
import y4.a;

/* loaded from: classes.dex */
public class y implements a.d {

    /* renamed from: b, reason: collision with root package name */
    public static final y f362b = a().a();

    /* renamed from: a, reason: collision with root package name */
    private final String f363a;

    public static class a {

        /* renamed from: a, reason: collision with root package name */
        private String f364a;

        /* synthetic */ a(b0 b0Var) {
        }

        public y a() {
            return new y(this.f364a, null);
        }
    }

    /* synthetic */ y(String str, c0 c0Var) {
        this.f363a = str;
    }

    public static a a() {
        return new a(null);
    }

    public final Bundle c() {
        Bundle bundle = new Bundle();
        String str = this.f363a;
        if (str != null) {
            bundle.putString("api", str);
        }
        return bundle;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof y) {
            return p.b(this.f363a, ((y) obj).f363a);
        }
        return false;
    }

    public final int hashCode() {
        return p.c(this.f363a);
    }
}
