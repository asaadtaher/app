package a5;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

/* loaded from: classes.dex */
public final class n1 {

    /* renamed from: f, reason: collision with root package name */
    private static final Uri f297f = new Uri.Builder().scheme("content").authority("com.google.android.gms.chimera").build();

    /* renamed from: a, reason: collision with root package name */
    private final String f298a;

    /* renamed from: b, reason: collision with root package name */
    private final String f299b;

    /* renamed from: c, reason: collision with root package name */
    private final ComponentName f300c;

    /* renamed from: d, reason: collision with root package name */
    private final int f301d;

    /* renamed from: e, reason: collision with root package name */
    private final boolean f302e;

    public n1(ComponentName componentName, int i10) {
        this.f298a = null;
        this.f299b = null;
        r.k(componentName);
        this.f300c = componentName;
        this.f301d = 4225;
        this.f302e = false;
    }

    public n1(String str, String str2, int i10, boolean z10) {
        r.g(str);
        this.f298a = str;
        r.g(str2);
        this.f299b = str2;
        this.f300c = null;
        this.f301d = 4225;
        this.f302e = z10;
    }

    public final ComponentName a() {
        return this.f300c;
    }

    public final Intent b(Context context) {
        Bundle bundleCall;
        if (this.f298a == null) {
            return new Intent().setComponent(this.f300c);
        }
        if (this.f302e) {
            Bundle bundle = new Bundle();
            bundle.putString("serviceActionBundleKey", this.f298a);
            try {
                bundleCall = context.getContentResolver().call(f297f, "serviceIntentCall", (String) null, bundle);
            } catch (IllegalArgumentException e10) {
                Log.w("ConnectionStatusConfig", "Dynamic intent resolution failed: ".concat(e10.toString()));
                bundleCall = null;
            }
            intent = bundleCall != null ? (Intent) bundleCall.getParcelable("serviceResponseIntentKey") : null;
            if (intent == null) {
                Log.w("ConnectionStatusConfig", "Dynamic lookup for intent failed for action: ".concat(String.valueOf(this.f298a)));
            }
        }
        return intent == null ? new Intent(this.f298a).setPackage(this.f299b) : intent;
    }

    public final String c() {
        return this.f299b;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof n1)) {
            return false;
        }
        n1 n1Var = (n1) obj;
        return p.b(this.f298a, n1Var.f298a) && p.b(this.f299b, n1Var.f299b) && p.b(this.f300c, n1Var.f300c) && this.f302e == n1Var.f302e;
    }

    public final int hashCode() {
        return p.c(this.f298a, this.f299b, this.f300c, 4225, Boolean.valueOf(this.f302e));
    }

    public final String toString() {
        String str = this.f298a;
        if (str != null) {
            return str;
        }
        r.k(this.f300c);
        return this.f300c.flattenToString();
    }
}
