package a5;

/* loaded from: classes.dex */
public class q {

    /* renamed from: a, reason: collision with root package name */
    private static final r0 f325a = new o0();

    public interface a<R extends y4.m, T> {
        T a(R r10);
    }

    public static <R extends y4.m, T> b6.i<T> a(y4.h<R> hVar, a<R, T> aVar) {
        r0 r0Var = f325a;
        b6.j jVar = new b6.j();
        hVar.a(new p0(hVar, jVar, aVar, r0Var));
        return jVar.a();
    }

    public static <R extends y4.m> b6.i<Void> b(y4.h<R> hVar) {
        return a(hVar, new q0());
    }
}
