package a5;

import android.util.Log;

/* loaded from: classes.dex */
public abstract class e1 {

    /* renamed from: a, reason: collision with root package name */
    private Object f236a;

    /* renamed from: b, reason: collision with root package name */
    private boolean f237b = false;

    /* renamed from: c, reason: collision with root package name */
    final /* synthetic */ c f238c;

    public e1(c cVar, Object obj) {
        this.f238c = cVar;
        this.f236a = obj;
    }

    protected abstract void a(Object obj);

    protected abstract void b();

    public final void c() {
        Object obj;
        synchronized (this) {
            obj = this.f236a;
            if (this.f237b) {
                Log.w("GmsClient", "Callback proxy " + toString() + " being reused. This is not safe.");
            }
        }
        if (obj != null) {
            try {
                a(obj);
            } catch (RuntimeException e10) {
                throw e10;
            }
        }
        synchronized (this) {
            this.f237b = true;
        }
        e();
    }

    public final void d() {
        synchronized (this) {
            this.f236a = null;
        }
    }

    public final void e() {
        d();
        synchronized (this.f238c.f205r) {
            this.f238c.f205r.remove(this);
        }
    }
}
