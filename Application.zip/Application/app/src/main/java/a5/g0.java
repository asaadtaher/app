package a5;

import android.content.Intent;

/* loaded from: classes.dex */
final class g0 extends h0 {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ Intent f266a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ z4.f f267b;

    g0(Intent intent, z4.f fVar, int i10) {
        this.f266a = intent;
        this.f267b = fVar;
    }

    @Override // a5.h0
    public final void a() {
        Intent intent = this.f266a;
        if (intent != null) {
            this.f267b.startActivityForResult(intent, 2);
        }
    }
}
