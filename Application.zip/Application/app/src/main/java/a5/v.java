package a5;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class v extends b5.a {
    public static final Parcelable.Creator<v> CREATOR = new a0();

    /* renamed from: a, reason: collision with root package name */
    private final int f357a;

    /* renamed from: b, reason: collision with root package name */
    private List f358b;

    public v(int i10, List list) {
        this.f357a = i10;
        this.f358b = list;
    }

    public final int j() {
        return this.f357a;
    }

    public final List k() {
        return this.f358b;
    }

    public final void l(o oVar) {
        if (this.f358b == null) {
            this.f358b = new ArrayList();
        }
        this.f358b.add(oVar);
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.k(parcel, 1, this.f357a);
        b5.c.v(parcel, 2, this.f358b, false);
        b5.c.b(parcel, iA);
    }
}
