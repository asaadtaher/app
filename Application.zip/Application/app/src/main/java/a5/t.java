package a5;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class t extends b5.a {
    public static final Parcelable.Creator<t> CREATOR = new c1();

    /* renamed from: a, reason: collision with root package name */
    private final int f342a;

    /* renamed from: b, reason: collision with root package name */
    private final boolean f343b;

    /* renamed from: c, reason: collision with root package name */
    private final boolean f344c;

    /* renamed from: d, reason: collision with root package name */
    private final int f345d;

    /* renamed from: e, reason: collision with root package name */
    private final int f346e;

    public t(int i10, boolean z10, boolean z11, int i11, int i12) {
        this.f342a = i10;
        this.f343b = z10;
        this.f344c = z11;
        this.f345d = i11;
        this.f346e = i12;
    }

    public int j() {
        return this.f345d;
    }

    public int k() {
        return this.f346e;
    }

    public boolean l() {
        return this.f343b;
    }

    public boolean m() {
        return this.f344c;
    }

    public int n() {
        return this.f342a;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.k(parcel, 1, n());
        b5.c.c(parcel, 2, l());
        b5.c.c(parcel, 3, m());
        b5.c.k(parcel, 4, j());
        b5.c.k(parcel, 5, k());
        b5.c.b(parcel, iA);
    }
}
