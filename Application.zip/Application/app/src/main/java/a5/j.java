package a5;

/* loaded from: classes.dex */
public final class j {

    /* renamed from: a, reason: collision with root package name */
    private final String f279a;

    /* renamed from: b, reason: collision with root package name */
    private final String f280b;

    public j(String str) {
        this(str, null);
    }

    public j(String str, String str2) {
        r.l(str, "log tag cannot be null");
        r.c(str.length() <= 23, "tag \"%s\" is longer than the %d character maximum", str, 23);
        this.f279a = str;
        if (str2 == null || str2.length() <= 0) {
            this.f280b = null;
        } else {
            this.f280b = str2;
        }
    }
}
