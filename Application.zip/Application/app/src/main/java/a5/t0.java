package a5;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

/* loaded from: classes.dex */
public final class t0 implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b5.b.z(parcel);
        Account account = null;
        GoogleSignInAccount googleSignInAccount = null;
        int iS = 0;
        int iS2 = 0;
        while (parcel.dataPosition() < iZ) {
            int iQ = b5.b.q(parcel);
            int iK = b5.b.k(iQ);
            if (iK == 1) {
                iS = b5.b.s(parcel, iQ);
            } else if (iK == 2) {
                account = (Account) b5.b.d(parcel, iQ, Account.CREATOR);
            } else if (iK == 3) {
                iS2 = b5.b.s(parcel, iQ);
            } else if (iK != 4) {
                b5.b.y(parcel, iQ);
            } else {
                googleSignInAccount = (GoogleSignInAccount) b5.b.d(parcel, iQ, GoogleSignInAccount.CREATOR);
            }
        }
        b5.b.j(parcel, iZ);
        return new s0(iS, account, iS2, googleSignInAccount);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new s0[i10];
    }
}
