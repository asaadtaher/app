package a5;

import android.accounts.Account;
import android.os.IBinder;
import android.os.Parcel;

/* loaded from: classes.dex */
public final class u1 extends o5.a implements k {
    u1(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.common.internal.IAccountAccessor");
    }

    @Override // a5.k
    public final Account i() {
        Parcel parcelR = r(2, y());
        Account account = (Account) o5.c.a(parcelR, Account.CREATOR);
        parcelR.recycle();
        return account;
    }
}
