package a5;

import android.content.ComponentName;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

/* loaded from: classes.dex */
final class q1 implements Handler.Callback {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ r1 f326a;

    /* synthetic */ q1(r1 r1Var, p1 p1Var) {
        this.f326a = r1Var;
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        int i10 = message.what;
        if (i10 == 0) {
            synchronized (this.f326a.f327f) {
                n1 n1Var = (n1) message.obj;
                o1 o1Var = (o1) this.f326a.f327f.get(n1Var);
                if (o1Var != null && o1Var.i()) {
                    if (o1Var.j()) {
                        o1Var.g("GmsClientSupervisor");
                    }
                    this.f326a.f327f.remove(n1Var);
                }
            }
            return true;
        }
        if (i10 != 1) {
            return false;
        }
        synchronized (this.f326a.f327f) {
            n1 n1Var2 = (n1) message.obj;
            o1 o1Var2 = (o1) this.f326a.f327f.get(n1Var2);
            if (o1Var2 != null && o1Var2.a() == 3) {
                Log.e("GmsClientSupervisor", "Timeout waiting for ServiceConnection callback " + String.valueOf(n1Var2), new Exception());
                ComponentName componentNameB = o1Var2.b();
                if (componentNameB == null) {
                    componentNameB = n1Var2.a();
                }
                if (componentNameB == null) {
                    String strC = n1Var2.c();
                    r.k(strC);
                    componentNameB = new ComponentName(strC, "unknown");
                }
                o1Var2.onServiceDisconnected(componentNameB);
            }
        }
        return true;
    }
}
