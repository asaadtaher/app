package a5;

import android.app.Activity;
import android.content.Intent;

/* loaded from: classes.dex */
final class f0 extends h0 {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ Intent f245a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ Activity f246b;

    /* renamed from: c, reason: collision with root package name */
    final /* synthetic */ int f247c;

    f0(Intent intent, Activity activity, int i10) {
        this.f245a = intent;
        this.f246b = activity;
        this.f247c = i10;
    }

    @Override // a5.h0
    public final void a() {
        Intent intent = this.f245a;
        if (intent != null) {
            this.f246b.startActivityForResult(intent, this.f247c);
        }
    }
}
