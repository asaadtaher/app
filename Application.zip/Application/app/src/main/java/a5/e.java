package a5;

import android.accounts.Account;
import android.view.View;
import com.google.android.gms.common.api.Scope;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    private final Account f219a;

    /* renamed from: b, reason: collision with root package name */
    private final Set f220b;

    /* renamed from: c, reason: collision with root package name */
    private final Set f221c;

    /* renamed from: d, reason: collision with root package name */
    private final Map f222d;

    /* renamed from: e, reason: collision with root package name */
    private final int f223e;

    /* renamed from: f, reason: collision with root package name */
    private final View f224f;

    /* renamed from: g, reason: collision with root package name */
    private final String f225g;

    /* renamed from: h, reason: collision with root package name */
    private final String f226h;

    /* renamed from: i, reason: collision with root package name */
    private final y5.a f227i;

    /* renamed from: j, reason: collision with root package name */
    private Integer f228j;

    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        private Account f229a;

        /* renamed from: b, reason: collision with root package name */
        private f0.b f230b;

        /* renamed from: c, reason: collision with root package name */
        private String f231c;

        /* renamed from: d, reason: collision with root package name */
        private String f232d;

        /* renamed from: e, reason: collision with root package name */
        private y5.a f233e = y5.a.f24284j;

        public e a() {
            return new e(this.f229a, this.f230b, null, 0, null, this.f231c, this.f232d, this.f233e, false);
        }

        public a b(String str) {
            this.f231c = str;
            return this;
        }

        public final a c(Collection collection) {
            if (this.f230b == null) {
                this.f230b = new f0.b();
            }
            this.f230b.addAll(collection);
            return this;
        }

        public final a d(Account account) {
            this.f229a = account;
            return this;
        }

        public final a e(String str) {
            this.f232d = str;
            return this;
        }
    }

    public e(Account account, Set set, Map map, int i10, View view, String str, String str2, y5.a aVar, boolean z10) {
        this.f219a = account;
        Set setEmptySet = set == null ? Collections.emptySet() : Collections.unmodifiableSet(set);
        this.f220b = setEmptySet;
        map = map == null ? Collections.emptyMap() : map;
        this.f222d = map;
        this.f224f = view;
        this.f223e = i10;
        this.f225g = str;
        this.f226h = str2;
        this.f227i = aVar == null ? y5.a.f24284j : aVar;
        HashSet hashSet = new HashSet(setEmptySet);
        Iterator it = map.values().iterator();
        while (it.hasNext()) {
            hashSet.addAll(((d0) it.next()).f217a);
        }
        this.f221c = Collections.unmodifiableSet(hashSet);
    }

    public Account a() {
        return this.f219a;
    }

    @Deprecated
    public String b() {
        Account account = this.f219a;
        if (account != null) {
            return account.name;
        }
        return null;
    }

    public Account c() {
        Account account = this.f219a;
        return account != null ? account : new Account("<<default account>>", "com.google");
    }

    public Set<Scope> d() {
        return this.f221c;
    }

    public Set<Scope> e(y4.a<?> aVar) {
        d0 d0Var = (d0) this.f222d.get(aVar);
        if (d0Var == null || d0Var.f217a.isEmpty()) {
            return this.f220b;
        }
        HashSet hashSet = new HashSet(this.f220b);
        hashSet.addAll(d0Var.f217a);
        return hashSet;
    }

    public String f() {
        return this.f225g;
    }

    public Set<Scope> g() {
        return this.f220b;
    }

    public final y5.a h() {
        return this.f227i;
    }

    public final Integer i() {
        return this.f228j;
    }

    public final String j() {
        return this.f226h;
    }

    public final Map k() {
        return this.f222d;
    }

    public final void l(Integer num) {
        this.f228j = num;
    }
}
