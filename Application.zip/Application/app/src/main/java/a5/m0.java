package a5;

import android.content.Context;
import android.util.SparseIntArray;
import y4.a;

/* loaded from: classes.dex */
public final class m0 {

    /* renamed from: a, reason: collision with root package name */
    private final SparseIntArray f295a = new SparseIntArray();

    /* renamed from: b, reason: collision with root package name */
    private x4.f f296b;

    public m0(x4.f fVar) {
        r.k(fVar);
        this.f296b = fVar;
    }

    public final int a(Context context, int i10) {
        return this.f295a.get(i10, -1);
    }

    public final int b(Context context, a.f fVar) {
        r.k(context);
        r.k(fVar);
        int i10 = 0;
        if (!fVar.l()) {
            return 0;
        }
        int iM = fVar.m();
        int iA = a(context, iM);
        if (iA == -1) {
            int i11 = 0;
            while (true) {
                if (i11 >= this.f295a.size()) {
                    i10 = -1;
                    break;
                }
                int iKeyAt = this.f295a.keyAt(i11);
                if (iKeyAt > iM && this.f295a.get(iKeyAt) == 0) {
                    break;
                }
                i11++;
            }
            iA = i10 == -1 ? this.f296b.i(context, iM) : i10;
            this.f295a.put(iM, iA);
        }
        return iA;
    }

    public final void c() {
        this.f295a.clear();
    }
}
