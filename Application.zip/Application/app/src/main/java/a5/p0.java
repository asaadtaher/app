package a5;

import a5.q;
import com.google.android.gms.common.api.Status;
import java.util.concurrent.TimeUnit;
import y4.h;

/* loaded from: classes.dex */
final class p0 implements h.a {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ y4.h f321a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ b6.j f322b;

    /* renamed from: c, reason: collision with root package name */
    final /* synthetic */ q.a f323c;

    /* renamed from: d, reason: collision with root package name */
    final /* synthetic */ r0 f324d;

    p0(y4.h hVar, b6.j jVar, q.a aVar, r0 r0Var) {
        this.f321a = hVar;
        this.f322b = jVar;
        this.f323c = aVar;
        this.f324d = r0Var;
    }

    @Override // y4.h.a
    public final void a(Status status) {
        if (!status.n()) {
            this.f322b.b(b.a(status));
        } else {
            this.f322b.c(this.f323c.a(this.f321a.b(0L, TimeUnit.MILLISECONDS)));
        }
    }
}
