package a5;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

/* loaded from: classes.dex */
public final class a1 {

    /* renamed from: a, reason: collision with root package name */
    private static final Object f184a = new Object();

    /* renamed from: b, reason: collision with root package name */
    private static boolean f185b;

    /* renamed from: c, reason: collision with root package name */
    private static String f186c;

    /* renamed from: d, reason: collision with root package name */
    private static int f187d;

    public static int a(Context context) {
        b(context);
        return f187d;
    }

    private static void b(Context context) {
        Bundle bundle;
        synchronized (f184a) {
            if (f185b) {
                return;
            }
            f185b = true;
            try {
                bundle = h5.c.a(context).b(context.getPackageName(), 128).metaData;
            } catch (PackageManager.NameNotFoundException e10) {
                Log.wtf("MetadataValueReader", "This should never happen.", e10);
            }
            if (bundle == null) {
                return;
            }
            f186c = bundle.getString("com.google.app.id");
            f187d = bundle.getInt("com.google.android.gms.version");
        }
    }
}
