package a5;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class v0 implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b5.b.z(parcel);
        IBinder iBinderR = null;
        x4.b bVar = null;
        int iS = 0;
        boolean zL = false;
        boolean zL2 = false;
        while (parcel.dataPosition() < iZ) {
            int iQ = b5.b.q(parcel);
            int iK = b5.b.k(iQ);
            if (iK == 1) {
                iS = b5.b.s(parcel, iQ);
            } else if (iK == 2) {
                iBinderR = b5.b.r(parcel, iQ);
            } else if (iK == 3) {
                bVar = (x4.b) b5.b.d(parcel, iQ, x4.b.CREATOR);
            } else if (iK == 4) {
                zL = b5.b.l(parcel, iQ);
            } else if (iK != 5) {
                b5.b.y(parcel, iQ);
            } else {
                zL2 = b5.b.l(parcel, iQ);
            }
        }
        b5.b.j(parcel, iZ);
        return new u0(iS, iBinderR, bVar, zL, zL2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new u0[i10];
    }
}
