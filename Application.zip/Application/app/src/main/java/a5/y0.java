package a5;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;

/* loaded from: classes.dex */
public abstract class y0 extends o5.b implements m {
    public y0() {
        super("com.google.android.gms.common.internal.IGmsCallbacks");
    }

    @Override // o5.b
    protected final boolean r(int i10, Parcel parcel, Parcel parcel2, int i11) {
        if (i10 == 1) {
            int i12 = parcel.readInt();
            IBinder strongBinder = parcel.readStrongBinder();
            Bundle bundle = (Bundle) o5.c.a(parcel, Bundle.CREATOR);
            o5.c.b(parcel);
            b3(i12, strongBinder, bundle);
        } else if (i10 == 2) {
            int i13 = parcel.readInt();
            Bundle bundle2 = (Bundle) o5.c.a(parcel, Bundle.CREATOR);
            o5.c.b(parcel);
            R1(i13, bundle2);
        } else {
            if (i10 != 3) {
                return false;
            }
            int i14 = parcel.readInt();
            IBinder strongBinder2 = parcel.readStrongBinder();
            j1 j1Var = (j1) o5.c.a(parcel, j1.CREATOR);
            o5.c.b(parcel);
            Q0(i14, strongBinder2, j1Var);
        }
        parcel2.writeNoException();
        return true;
    }
}
