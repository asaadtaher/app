package a5;

import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

/* loaded from: classes.dex */
public final class f1 extends y0 {

    /* renamed from: c, reason: collision with root package name */
    private c f248c;

    /* renamed from: d, reason: collision with root package name */
    private final int f249d;

    public f1(c cVar, int i10) {
        this.f248c = cVar;
        this.f249d = i10;
    }

    @Override // a5.m
    public final void Q0(int i10, IBinder iBinder, j1 j1Var) {
        c cVar = this.f248c;
        r.l(cVar, "onPostInitCompleteWithConnectionInfo can be called only once per call togetRemoteService");
        r.k(j1Var);
        c.f0(cVar, j1Var);
        b3(i10, iBinder, j1Var.f282a);
    }

    @Override // a5.m
    public final void R1(int i10, Bundle bundle) {
        Log.wtf("GmsClient", "received deprecated onAccountValidationComplete callback, ignoring", new Exception());
    }

    @Override // a5.m
    public final void b3(int i10, IBinder iBinder, Bundle bundle) {
        r.l(this.f248c, "onPostInitComplete can be called only once per call to getRemoteService");
        this.f248c.R(i10, iBinder, bundle, this.f249d);
        this.f248c = null;
    }
}
