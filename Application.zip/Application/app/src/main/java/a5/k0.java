package a5;

/* loaded from: classes.dex */
public interface k0 {
    boolean a();
}
