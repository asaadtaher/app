package a5;

import a5.k;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class u0 extends b5.a {
    public static final Parcelable.Creator<u0> CREATOR = new v0();

    /* renamed from: a, reason: collision with root package name */
    final int f352a;

    /* renamed from: b, reason: collision with root package name */
    final IBinder f353b;

    /* renamed from: c, reason: collision with root package name */
    private final x4.b f354c;

    /* renamed from: d, reason: collision with root package name */
    private final boolean f355d;

    /* renamed from: e, reason: collision with root package name */
    private final boolean f356e;

    u0(int i10, IBinder iBinder, x4.b bVar, boolean z10, boolean z11) {
        this.f352a = i10;
        this.f353b = iBinder;
        this.f354c = bVar;
        this.f355d = z10;
        this.f356e = z11;
    }

    public final boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof u0)) {
            return false;
        }
        u0 u0Var = (u0) obj;
        return this.f354c.equals(u0Var.f354c) && p.b(k(), u0Var.k());
    }

    public final x4.b j() {
        return this.f354c;
    }

    public final k k() {
        IBinder iBinder = this.f353b;
        if (iBinder == null) {
            return null;
        }
        return k.a.y(iBinder);
    }

    public final boolean l() {
        return this.f355d;
    }

    public final boolean m() {
        return this.f356e;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.k(parcel, 1, this.f352a);
        b5.c.j(parcel, 2, this.f353b, false);
        b5.c.q(parcel, 3, this.f354c, i10, false);
        b5.c.c(parcel, 4, this.f355d);
        b5.c.c(parcel, 5, this.f356e);
        b5.c.b(parcel, iA);
    }
}
