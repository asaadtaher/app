package a5;

import com.google.android.gms.common.api.Status;

/* loaded from: classes.dex */
public class b {
    public static y4.b a(Status status) {
        return status.m() ? new y4.k(status) : new y4.b(status);
    }
}
