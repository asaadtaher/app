package a5;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class j1 extends b5.a {
    public static final Parcelable.Creator<j1> CREATOR = new k1();

    /* renamed from: a, reason: collision with root package name */
    Bundle f282a;

    /* renamed from: b, reason: collision with root package name */
    x4.d[] f283b;

    /* renamed from: c, reason: collision with root package name */
    int f284c;

    /* renamed from: d, reason: collision with root package name */
    f f285d;

    public j1() {
    }

    j1(Bundle bundle, x4.d[] dVarArr, int i10, f fVar) {
        this.f282a = bundle;
        this.f283b = dVarArr;
        this.f284c = i10;
        this.f285d = fVar;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.d(parcel, 1, this.f282a, false);
        b5.c.u(parcel, 2, this.f283b, i10, false);
        b5.c.k(parcel, 3, this.f284c);
        b5.c.q(parcel, 4, this.f285d, i10, false);
        b5.c.b(parcel, iA);
    }
}
