package a5;

import a5.c;
import android.os.Bundle;

/* loaded from: classes.dex */
final class i0 implements c.a {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ z4.c f277a;

    i0(z4.c cVar) {
        this.f277a = cVar;
    }

    @Override // a5.c.a
    public final void R(Bundle bundle) {
        this.f277a.R(bundle);
    }

    @Override // a5.c.a
    public final void y(int i10) {
        this.f277a.y(i10);
    }
}
