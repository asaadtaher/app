package a5;

import android.app.PendingIntent;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

/* loaded from: classes.dex */
final class d1 extends o5.e {

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ c f218b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d1(c cVar, Looper looper) {
        super(looper);
        this.f218b = cVar;
    }

    private static final void a(Message message) {
        e1 e1Var = (e1) message.obj;
        e1Var.b();
        e1Var.e();
    }

    private static final boolean b(Message message) {
        int i10 = message.what;
        return i10 == 2 || i10 == 1 || i10 == 7;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        if (this.f218b.C.get() != message.arg1) {
            if (b(message)) {
                a(message);
                return;
            }
            return;
        }
        int i10 = message.what;
        if ((i10 == 1 || i10 == 7 || ((i10 == 4 && !this.f218b.x()) || message.what == 5)) && !this.f218b.n()) {
            a(message);
            return;
        }
        int i11 = message.what;
        if (i11 == 4) {
            this.f218b.f213z = new x4.b(message.arg2);
            if (c.k0(this.f218b)) {
                c cVar = this.f218b;
                if (!cVar.A) {
                    cVar.l0(3, null);
                    return;
                }
            }
            c cVar2 = this.f218b;
            x4.b bVar = cVar2.f213z != null ? cVar2.f213z : new x4.b(8);
            this.f218b.f203p.c(bVar);
            this.f218b.P(bVar);
            return;
        }
        if (i11 == 5) {
            c cVar3 = this.f218b;
            x4.b bVar2 = cVar3.f213z != null ? cVar3.f213z : new x4.b(8);
            this.f218b.f203p.c(bVar2);
            this.f218b.P(bVar2);
            return;
        }
        if (i11 == 3) {
            Object obj = message.obj;
            x4.b bVar3 = new x4.b(message.arg2, obj instanceof PendingIntent ? (PendingIntent) obj : null);
            this.f218b.f203p.c(bVar3);
            this.f218b.P(bVar3);
            return;
        }
        if (i11 == 6) {
            this.f218b.l0(5, null);
            c cVar4 = this.f218b;
            if (cVar4.f208u != null) {
                cVar4.f208u.y(message.arg2);
            }
            this.f218b.Q(message.arg2);
            c.j0(this.f218b, 5, 1, null);
            return;
        }
        if (i11 == 2 && !this.f218b.a()) {
            a(message);
            return;
        }
        if (b(message)) {
            ((e1) message.obj).c();
            return;
        }
        Log.wtf("GmsClient", "Don't know how to handle message: " + message.what, new Exception());
    }
}
