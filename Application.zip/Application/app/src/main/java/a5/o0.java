package a5;

/* loaded from: classes.dex */
final class o0 implements r0 {
    o0() {
    }
}
