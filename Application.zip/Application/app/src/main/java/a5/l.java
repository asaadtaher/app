package a5;

import android.os.IInterface;

/* loaded from: classes.dex */
public interface l extends IInterface {
    void cancel();
}
