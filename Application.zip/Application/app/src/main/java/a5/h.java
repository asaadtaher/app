package a5;

import android.accounts.Account;
import android.content.Context;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.api.Scope;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.Executor;
import y4.a;
import y4.f;

/* loaded from: classes.dex */
public abstract class h<T extends IInterface> extends c<T> implements a.f, k0 {
    private final e F;
    private final Set G;
    private final Account H;

    @Deprecated
    protected h(Context context, Looper looper, int i10, e eVar, f.b bVar, f.c cVar) {
        this(context, looper, i10, eVar, (z4.c) bVar, (z4.h) cVar);
    }

    protected h(Context context, Looper looper, int i10, e eVar, z4.c cVar, z4.h hVar) {
        this(context, looper, i.c(context), x4.e.p(), i10, eVar, (z4.c) r.k(cVar), (z4.h) r.k(hVar));
    }

    protected h(Context context, Looper looper, i iVar, x4.e eVar, int i10, e eVar2, z4.c cVar, z4.h hVar) {
        super(context, looper, iVar, eVar, i10, cVar == null ? null : new i0(cVar), hVar == null ? null : new j0(hVar), eVar2.j());
        this.F = eVar2;
        this.H = eVar2.a();
        this.G = o0(eVar2.d());
    }

    private final Set o0(Set set) {
        Set<Scope> setN0 = n0(set);
        Iterator<Scope> it = setN0.iterator();
        while (it.hasNext()) {
            if (!set.contains(it.next())) {
                throw new IllegalStateException("Expanding scopes is not permitted, use implied scopes instead");
            }
        }
        return setN0;
    }

    @Override // a5.c
    protected final Executor A() {
        return null;
    }

    @Override // a5.c
    protected final Set<Scope> G() {
        return this.G;
    }

    @Override // y4.a.f
    public Set<Scope> g() {
        return t() ? this.G : Collections.emptySet();
    }

    protected final e m0() {
        return this.F;
    }

    protected Set<Scope> n0(Set<Scope> set) {
        return set;
    }

    @Override // a5.c
    public final Account y() {
        return this.H;
    }
}
