package a5;

import android.os.IBinder;
import android.os.Parcel;

/* loaded from: classes.dex */
final class z0 implements n {

    /* renamed from: c, reason: collision with root package name */
    private final IBinder f365c;

    z0(IBinder iBinder) {
        this.f365c = iBinder;
    }

    @Override // a5.n
    public final void P0(m mVar, g gVar) {
        Parcel parcelObtain = Parcel.obtain();
        Parcel parcelObtain2 = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
            parcelObtain.writeStrongBinder(mVar != null ? mVar.asBinder() : null);
            if (gVar != null) {
                parcelObtain.writeInt(1);
                m1.a(gVar, parcelObtain, 0);
            } else {
                parcelObtain.writeInt(0);
            }
            this.f365c.transact(46, parcelObtain, parcelObtain2, 0);
            parcelObtain2.readException();
        } finally {
            parcelObtain2.recycle();
            parcelObtain.recycle();
        }
    }

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f365c;
    }
}
