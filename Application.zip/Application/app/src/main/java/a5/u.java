package a5;

import android.content.Context;
import android.content.res.Resources;

/* loaded from: classes.dex */
public class u {

    /* renamed from: a, reason: collision with root package name */
    private final Resources f350a;

    /* renamed from: b, reason: collision with root package name */
    private final String f351b;

    public u(Context context) {
        r.k(context);
        Resources resources = context.getResources();
        this.f350a = resources;
        this.f351b = resources.getResourcePackageName(x4.l.f23650a);
    }

    public String a(String str) {
        int identifier = this.f350a.getIdentifier(str, "string", this.f351b);
        if (identifier == 0) {
            return null;
        }
        return this.f350a.getString(identifier);
    }
}
