package a4;

import a4.c;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a4.a$a, reason: collision with other inner class name */
    public static abstract class AbstractC0001a {
        public abstract a a();

        public abstract AbstractC0001a b(String str);

        public abstract AbstractC0001a c(String str);

        public abstract AbstractC0001a d(String str);

        public abstract AbstractC0001a e(String str);

        public abstract AbstractC0001a f(String str);

        public abstract AbstractC0001a g(String str);

        public abstract AbstractC0001a h(String str);

        public abstract AbstractC0001a i(String str);

        public abstract AbstractC0001a j(String str);

        public abstract AbstractC0001a k(String str);

        public abstract AbstractC0001a l(String str);

        public abstract AbstractC0001a m(Integer num);
    }

    public static AbstractC0001a a() {
        return new c.b();
    }

    public abstract String b();

    public abstract String c();

    public abstract String d();

    public abstract String e();

    public abstract String f();

    public abstract String g();

    public abstract String h();

    public abstract String i();

    public abstract String j();

    public abstract String k();

    public abstract String l();

    public abstract Integer m();
}
