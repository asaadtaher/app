package a4;

import a4.l;
import java.util.Arrays;

/* loaded from: classes.dex */
final class f extends l {

    /* renamed from: a, reason: collision with root package name */
    private final long f96a;

    /* renamed from: b, reason: collision with root package name */
    private final Integer f97b;

    /* renamed from: c, reason: collision with root package name */
    private final long f98c;

    /* renamed from: d, reason: collision with root package name */
    private final byte[] f99d;

    /* renamed from: e, reason: collision with root package name */
    private final String f100e;

    /* renamed from: f, reason: collision with root package name */
    private final long f101f;

    /* renamed from: g, reason: collision with root package name */
    private final o f102g;

    static final class b extends l.a {

        /* renamed from: a, reason: collision with root package name */
        private Long f103a;

        /* renamed from: b, reason: collision with root package name */
        private Integer f104b;

        /* renamed from: c, reason: collision with root package name */
        private Long f105c;

        /* renamed from: d, reason: collision with root package name */
        private byte[] f106d;

        /* renamed from: e, reason: collision with root package name */
        private String f107e;

        /* renamed from: f, reason: collision with root package name */
        private Long f108f;

        /* renamed from: g, reason: collision with root package name */
        private o f109g;

        b() {
        }

        @Override // a4.l.a
        public l a() {
            String str = "";
            if (this.f103a == null) {
                str = " eventTimeMs";
            }
            if (this.f105c == null) {
                str = str + " eventUptimeMs";
            }
            if (this.f108f == null) {
                str = str + " timezoneOffsetSeconds";
            }
            if (str.isEmpty()) {
                return new f(this.f103a.longValue(), this.f104b, this.f105c.longValue(), this.f106d, this.f107e, this.f108f.longValue(), this.f109g);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // a4.l.a
        public l.a b(Integer num) {
            this.f104b = num;
            return this;
        }

        @Override // a4.l.a
        public l.a c(long j10) {
            this.f103a = Long.valueOf(j10);
            return this;
        }

        @Override // a4.l.a
        public l.a d(long j10) {
            this.f105c = Long.valueOf(j10);
            return this;
        }

        @Override // a4.l.a
        public l.a e(o oVar) {
            this.f109g = oVar;
            return this;
        }

        @Override // a4.l.a
        l.a f(byte[] bArr) {
            this.f106d = bArr;
            return this;
        }

        @Override // a4.l.a
        l.a g(String str) {
            this.f107e = str;
            return this;
        }

        @Override // a4.l.a
        public l.a h(long j10) {
            this.f108f = Long.valueOf(j10);
            return this;
        }
    }

    private f(long j10, Integer num, long j11, byte[] bArr, String str, long j12, o oVar) {
        this.f96a = j10;
        this.f97b = num;
        this.f98c = j11;
        this.f99d = bArr;
        this.f100e = str;
        this.f101f = j12;
        this.f102g = oVar;
    }

    @Override // a4.l
    public Integer b() {
        return this.f97b;
    }

    @Override // a4.l
    public long c() {
        return this.f96a;
    }

    @Override // a4.l
    public long d() {
        return this.f98c;
    }

    @Override // a4.l
    public o e() {
        return this.f102g;
    }

    public boolean equals(Object obj) {
        Integer num;
        String str;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof l)) {
            return false;
        }
        l lVar = (l) obj;
        if (this.f96a == lVar.c() && ((num = this.f97b) != null ? num.equals(lVar.b()) : lVar.b() == null) && this.f98c == lVar.d()) {
            if (Arrays.equals(this.f99d, lVar instanceof f ? ((f) lVar).f99d : lVar.f()) && ((str = this.f100e) != null ? str.equals(lVar.g()) : lVar.g() == null) && this.f101f == lVar.h()) {
                o oVar = this.f102g;
                o oVarE = lVar.e();
                if (oVar == null) {
                    if (oVarE == null) {
                        return true;
                    }
                } else if (oVar.equals(oVarE)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // a4.l
    public byte[] f() {
        return this.f99d;
    }

    @Override // a4.l
    public String g() {
        return this.f100e;
    }

    @Override // a4.l
    public long h() {
        return this.f101f;
    }

    public int hashCode() {
        long j10 = this.f96a;
        int i10 = (((int) (j10 ^ (j10 >>> 32))) ^ 1000003) * 1000003;
        Integer num = this.f97b;
        int iHashCode = num == null ? 0 : num.hashCode();
        long j11 = this.f98c;
        int iHashCode2 = (((((i10 ^ iHashCode) * 1000003) ^ ((int) (j11 ^ (j11 >>> 32)))) * 1000003) ^ Arrays.hashCode(this.f99d)) * 1000003;
        String str = this.f100e;
        int iHashCode3 = str == null ? 0 : str.hashCode();
        long j12 = this.f101f;
        int i11 = (((iHashCode2 ^ iHashCode3) * 1000003) ^ ((int) ((j12 >>> 32) ^ j12))) * 1000003;
        o oVar = this.f102g;
        return i11 ^ (oVar != null ? oVar.hashCode() : 0);
    }

    public String toString() {
        return "LogEvent{eventTimeMs=" + this.f96a + ", eventCode=" + this.f97b + ", eventUptimeMs=" + this.f98c + ", sourceExtension=" + Arrays.toString(this.f99d) + ", sourceExtensionJsonProto3=" + this.f100e + ", timezoneOffsetSeconds=" + this.f101f + ", networkConnectionInfo=" + this.f102g + "}";
    }
}
