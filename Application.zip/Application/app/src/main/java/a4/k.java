package a4;

import a4.e;

/* loaded from: classes.dex */
public abstract class k {

    public static abstract class a {
        public abstract k a();

        public abstract a b(a4.a aVar);

        public abstract a c(b bVar);
    }

    public enum b {
        UNKNOWN(0),
        ANDROID_FIREBASE(23);


        /* renamed from: a, reason: collision with root package name */
        private final int f132a;

        b(int i10) {
            this.f132a = i10;
        }
    }

    public static a a() {
        return new e.b();
    }

    public abstract a4.a b();

    public abstract b c();
}
