package a4;

import a4.m;
import java.util.List;

/* loaded from: classes.dex */
final class g extends m {

    /* renamed from: a, reason: collision with root package name */
    private final long f110a;

    /* renamed from: b, reason: collision with root package name */
    private final long f111b;

    /* renamed from: c, reason: collision with root package name */
    private final k f112c;

    /* renamed from: d, reason: collision with root package name */
    private final Integer f113d;

    /* renamed from: e, reason: collision with root package name */
    private final String f114e;

    /* renamed from: f, reason: collision with root package name */
    private final List<l> f115f;

    /* renamed from: g, reason: collision with root package name */
    private final p f116g;

    static final class b extends m.a {

        /* renamed from: a, reason: collision with root package name */
        private Long f117a;

        /* renamed from: b, reason: collision with root package name */
        private Long f118b;

        /* renamed from: c, reason: collision with root package name */
        private k f119c;

        /* renamed from: d, reason: collision with root package name */
        private Integer f120d;

        /* renamed from: e, reason: collision with root package name */
        private String f121e;

        /* renamed from: f, reason: collision with root package name */
        private List<l> f122f;

        /* renamed from: g, reason: collision with root package name */
        private p f123g;

        b() {
        }

        @Override // a4.m.a
        public m a() {
            String str = "";
            if (this.f117a == null) {
                str = " requestTimeMs";
            }
            if (this.f118b == null) {
                str = str + " requestUptimeMs";
            }
            if (str.isEmpty()) {
                return new g(this.f117a.longValue(), this.f118b.longValue(), this.f119c, this.f120d, this.f121e, this.f122f, this.f123g);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // a4.m.a
        public m.a b(k kVar) {
            this.f119c = kVar;
            return this;
        }

        @Override // a4.m.a
        public m.a c(List<l> list) {
            this.f122f = list;
            return this;
        }

        @Override // a4.m.a
        m.a d(Integer num) {
            this.f120d = num;
            return this;
        }

        @Override // a4.m.a
        m.a e(String str) {
            this.f121e = str;
            return this;
        }

        @Override // a4.m.a
        public m.a f(p pVar) {
            this.f123g = pVar;
            return this;
        }

        @Override // a4.m.a
        public m.a g(long j10) {
            this.f117a = Long.valueOf(j10);
            return this;
        }

        @Override // a4.m.a
        public m.a h(long j10) {
            this.f118b = Long.valueOf(j10);
            return this;
        }
    }

    private g(long j10, long j11, k kVar, Integer num, String str, List<l> list, p pVar) {
        this.f110a = j10;
        this.f111b = j11;
        this.f112c = kVar;
        this.f113d = num;
        this.f114e = str;
        this.f115f = list;
        this.f116g = pVar;
    }

    @Override // a4.m
    public k b() {
        return this.f112c;
    }

    @Override // a4.m
    public List<l> c() {
        return this.f115f;
    }

    @Override // a4.m
    public Integer d() {
        return this.f113d;
    }

    @Override // a4.m
    public String e() {
        return this.f114e;
    }

    public boolean equals(Object obj) {
        k kVar;
        Integer num;
        String str;
        List<l> list;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof m)) {
            return false;
        }
        m mVar = (m) obj;
        if (this.f110a == mVar.g() && this.f111b == mVar.h() && ((kVar = this.f112c) != null ? kVar.equals(mVar.b()) : mVar.b() == null) && ((num = this.f113d) != null ? num.equals(mVar.d()) : mVar.d() == null) && ((str = this.f114e) != null ? str.equals(mVar.e()) : mVar.e() == null) && ((list = this.f115f) != null ? list.equals(mVar.c()) : mVar.c() == null)) {
            p pVar = this.f116g;
            p pVarF = mVar.f();
            if (pVar == null) {
                if (pVarF == null) {
                    return true;
                }
            } else if (pVar.equals(pVarF)) {
                return true;
            }
        }
        return false;
    }

    @Override // a4.m
    public p f() {
        return this.f116g;
    }

    @Override // a4.m
    public long g() {
        return this.f110a;
    }

    @Override // a4.m
    public long h() {
        return this.f111b;
    }

    public int hashCode() {
        long j10 = this.f110a;
        long j11 = this.f111b;
        int i10 = (((((int) (j10 ^ (j10 >>> 32))) ^ 1000003) * 1000003) ^ ((int) ((j11 >>> 32) ^ j11))) * 1000003;
        k kVar = this.f112c;
        int iHashCode = (i10 ^ (kVar == null ? 0 : kVar.hashCode())) * 1000003;
        Integer num = this.f113d;
        int iHashCode2 = (iHashCode ^ (num == null ? 0 : num.hashCode())) * 1000003;
        String str = this.f114e;
        int iHashCode3 = (iHashCode2 ^ (str == null ? 0 : str.hashCode())) * 1000003;
        List<l> list = this.f115f;
        int iHashCode4 = (iHashCode3 ^ (list == null ? 0 : list.hashCode())) * 1000003;
        p pVar = this.f116g;
        return iHashCode4 ^ (pVar != null ? pVar.hashCode() : 0);
    }

    public String toString() {
        return "LogRequest{requestTimeMs=" + this.f110a + ", requestUptimeMs=" + this.f111b + ", clientInfo=" + this.f112c + ", logSource=" + this.f113d + ", logSourceName=" + this.f114e + ", logEvents=" + this.f115f + ", qosTier=" + this.f116g + "}";
    }
}
