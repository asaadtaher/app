package a4;

import java.util.List;
import java.util.Objects;

/* loaded from: classes.dex */
final class d extends j {

    /* renamed from: a, reason: collision with root package name */
    private final List<m> f91a;

    d(List<m> list) {
        Objects.requireNonNull(list, "Null logRequests");
        this.f91a = list;
    }

    @Override // a4.j
    public List<m> c() {
        return this.f91a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof j) {
            return this.f91a.equals(((j) obj).c());
        }
        return false;
    }

    public int hashCode() {
        return this.f91a.hashCode() ^ 1000003;
    }

    public String toString() {
        return "BatchedLogRequest{logRequests=" + this.f91a + "}";
    }
}
