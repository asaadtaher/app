package a4;

import a4.k;

/* loaded from: classes.dex */
final class e extends k {

    /* renamed from: a, reason: collision with root package name */
    private final k.b f92a;

    /* renamed from: b, reason: collision with root package name */
    private final a4.a f93b;

    static final class b extends k.a {

        /* renamed from: a, reason: collision with root package name */
        private k.b f94a;

        /* renamed from: b, reason: collision with root package name */
        private a4.a f95b;

        b() {
        }

        @Override // a4.k.a
        public k a() {
            return new e(this.f94a, this.f95b);
        }

        @Override // a4.k.a
        public k.a b(a4.a aVar) {
            this.f95b = aVar;
            return this;
        }

        @Override // a4.k.a
        public k.a c(k.b bVar) {
            this.f94a = bVar;
            return this;
        }
    }

    private e(k.b bVar, a4.a aVar) {
        this.f92a = bVar;
        this.f93b = aVar;
    }

    @Override // a4.k
    public a4.a b() {
        return this.f93b;
    }

    @Override // a4.k
    public k.b c() {
        return this.f92a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof k)) {
            return false;
        }
        k kVar = (k) obj;
        k.b bVar = this.f92a;
        if (bVar != null ? bVar.equals(kVar.c()) : kVar.c() == null) {
            a4.a aVar = this.f93b;
            a4.a aVarB = kVar.b();
            if (aVar == null) {
                if (aVarB == null) {
                    return true;
                }
            } else if (aVar.equals(aVarB)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        k.b bVar = this.f92a;
        int iHashCode = ((bVar == null ? 0 : bVar.hashCode()) ^ 1000003) * 1000003;
        a4.a aVar = this.f93b;
        return iHashCode ^ (aVar != null ? aVar.hashCode() : 0);
    }

    public String toString() {
        return "ClientInfo{clientType=" + this.f92a + ", androidClientInfo=" + this.f93b + "}";
    }
}
