package a4;

import a4.o;

/* loaded from: classes.dex */
final class i extends o {

    /* renamed from: a, reason: collision with root package name */
    private final o.c f125a;

    /* renamed from: b, reason: collision with root package name */
    private final o.b f126b;

    static final class b extends o.a {

        /* renamed from: a, reason: collision with root package name */
        private o.c f127a;

        /* renamed from: b, reason: collision with root package name */
        private o.b f128b;

        b() {
        }

        @Override // a4.o.a
        public o a() {
            return new i(this.f127a, this.f128b);
        }

        @Override // a4.o.a
        public o.a b(o.b bVar) {
            this.f128b = bVar;
            return this;
        }

        @Override // a4.o.a
        public o.a c(o.c cVar) {
            this.f127a = cVar;
            return this;
        }
    }

    private i(o.c cVar, o.b bVar) {
        this.f125a = cVar;
        this.f126b = bVar;
    }

    @Override // a4.o
    public o.b b() {
        return this.f126b;
    }

    @Override // a4.o
    public o.c c() {
        return this.f125a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof o)) {
            return false;
        }
        o oVar = (o) obj;
        o.c cVar = this.f125a;
        if (cVar != null ? cVar.equals(oVar.c()) : oVar.c() == null) {
            o.b bVar = this.f126b;
            o.b bVarB = oVar.b();
            if (bVar == null) {
                if (bVarB == null) {
                    return true;
                }
            } else if (bVar.equals(bVarB)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        o.c cVar = this.f125a;
        int iHashCode = ((cVar == null ? 0 : cVar.hashCode()) ^ 1000003) * 1000003;
        o.b bVar = this.f126b;
        return iHashCode ^ (bVar != null ? bVar.hashCode() : 0);
    }

    public String toString() {
        return "NetworkConnectionInfo{networkType=" + this.f125a + ", mobileSubtype=" + this.f126b + "}";
    }
}
