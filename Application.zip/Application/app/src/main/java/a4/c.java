package a4;

import a4.a;

/* loaded from: classes.dex */
final class c extends a4.a {

    /* renamed from: a, reason: collision with root package name */
    private final Integer f67a;

    /* renamed from: b, reason: collision with root package name */
    private final String f68b;

    /* renamed from: c, reason: collision with root package name */
    private final String f69c;

    /* renamed from: d, reason: collision with root package name */
    private final String f70d;

    /* renamed from: e, reason: collision with root package name */
    private final String f71e;

    /* renamed from: f, reason: collision with root package name */
    private final String f72f;

    /* renamed from: g, reason: collision with root package name */
    private final String f73g;

    /* renamed from: h, reason: collision with root package name */
    private final String f74h;

    /* renamed from: i, reason: collision with root package name */
    private final String f75i;

    /* renamed from: j, reason: collision with root package name */
    private final String f76j;

    /* renamed from: k, reason: collision with root package name */
    private final String f77k;

    /* renamed from: l, reason: collision with root package name */
    private final String f78l;

    static final class b extends a.AbstractC0001a {

        /* renamed from: a, reason: collision with root package name */
        private Integer f79a;

        /* renamed from: b, reason: collision with root package name */
        private String f80b;

        /* renamed from: c, reason: collision with root package name */
        private String f81c;

        /* renamed from: d, reason: collision with root package name */
        private String f82d;

        /* renamed from: e, reason: collision with root package name */
        private String f83e;

        /* renamed from: f, reason: collision with root package name */
        private String f84f;

        /* renamed from: g, reason: collision with root package name */
        private String f85g;

        /* renamed from: h, reason: collision with root package name */
        private String f86h;

        /* renamed from: i, reason: collision with root package name */
        private String f87i;

        /* renamed from: j, reason: collision with root package name */
        private String f88j;

        /* renamed from: k, reason: collision with root package name */
        private String f89k;

        /* renamed from: l, reason: collision with root package name */
        private String f90l;

        b() {
        }

        @Override // a4.a.AbstractC0001a
        public a4.a a() {
            return new c(this.f79a, this.f80b, this.f81c, this.f82d, this.f83e, this.f84f, this.f85g, this.f86h, this.f87i, this.f88j, this.f89k, this.f90l);
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a b(String str) {
            this.f90l = str;
            return this;
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a c(String str) {
            this.f88j = str;
            return this;
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a d(String str) {
            this.f82d = str;
            return this;
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a e(String str) {
            this.f86h = str;
            return this;
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a f(String str) {
            this.f81c = str;
            return this;
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a g(String str) {
            this.f87i = str;
            return this;
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a h(String str) {
            this.f85g = str;
            return this;
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a i(String str) {
            this.f89k = str;
            return this;
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a j(String str) {
            this.f80b = str;
            return this;
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a k(String str) {
            this.f84f = str;
            return this;
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a l(String str) {
            this.f83e = str;
            return this;
        }

        @Override // a4.a.AbstractC0001a
        public a.AbstractC0001a m(Integer num) {
            this.f79a = num;
            return this;
        }
    }

    private c(Integer num, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11) {
        this.f67a = num;
        this.f68b = str;
        this.f69c = str2;
        this.f70d = str3;
        this.f71e = str4;
        this.f72f = str5;
        this.f73g = str6;
        this.f74h = str7;
        this.f75i = str8;
        this.f76j = str9;
        this.f77k = str10;
        this.f78l = str11;
    }

    @Override // a4.a
    public String b() {
        return this.f78l;
    }

    @Override // a4.a
    public String c() {
        return this.f76j;
    }

    @Override // a4.a
    public String d() {
        return this.f70d;
    }

    @Override // a4.a
    public String e() {
        return this.f74h;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof a4.a)) {
            return false;
        }
        a4.a aVar = (a4.a) obj;
        Integer num = this.f67a;
        if (num != null ? num.equals(aVar.m()) : aVar.m() == null) {
            String str = this.f68b;
            if (str != null ? str.equals(aVar.j()) : aVar.j() == null) {
                String str2 = this.f69c;
                if (str2 != null ? str2.equals(aVar.f()) : aVar.f() == null) {
                    String str3 = this.f70d;
                    if (str3 != null ? str3.equals(aVar.d()) : aVar.d() == null) {
                        String str4 = this.f71e;
                        if (str4 != null ? str4.equals(aVar.l()) : aVar.l() == null) {
                            String str5 = this.f72f;
                            if (str5 != null ? str5.equals(aVar.k()) : aVar.k() == null) {
                                String str6 = this.f73g;
                                if (str6 != null ? str6.equals(aVar.h()) : aVar.h() == null) {
                                    String str7 = this.f74h;
                                    if (str7 != null ? str7.equals(aVar.e()) : aVar.e() == null) {
                                        String str8 = this.f75i;
                                        if (str8 != null ? str8.equals(aVar.g()) : aVar.g() == null) {
                                            String str9 = this.f76j;
                                            if (str9 != null ? str9.equals(aVar.c()) : aVar.c() == null) {
                                                String str10 = this.f77k;
                                                if (str10 != null ? str10.equals(aVar.i()) : aVar.i() == null) {
                                                    String str11 = this.f78l;
                                                    String strB = aVar.b();
                                                    if (str11 == null) {
                                                        if (strB == null) {
                                                            return true;
                                                        }
                                                    } else if (str11.equals(strB)) {
                                                        return true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    @Override // a4.a
    public String f() {
        return this.f69c;
    }

    @Override // a4.a
    public String g() {
        return this.f75i;
    }

    @Override // a4.a
    public String h() {
        return this.f73g;
    }

    public int hashCode() {
        Integer num = this.f67a;
        int iHashCode = ((num == null ? 0 : num.hashCode()) ^ 1000003) * 1000003;
        String str = this.f68b;
        int iHashCode2 = (iHashCode ^ (str == null ? 0 : str.hashCode())) * 1000003;
        String str2 = this.f69c;
        int iHashCode3 = (iHashCode2 ^ (str2 == null ? 0 : str2.hashCode())) * 1000003;
        String str3 = this.f70d;
        int iHashCode4 = (iHashCode3 ^ (str3 == null ? 0 : str3.hashCode())) * 1000003;
        String str4 = this.f71e;
        int iHashCode5 = (iHashCode4 ^ (str4 == null ? 0 : str4.hashCode())) * 1000003;
        String str5 = this.f72f;
        int iHashCode6 = (iHashCode5 ^ (str5 == null ? 0 : str5.hashCode())) * 1000003;
        String str6 = this.f73g;
        int iHashCode7 = (iHashCode6 ^ (str6 == null ? 0 : str6.hashCode())) * 1000003;
        String str7 = this.f74h;
        int iHashCode8 = (iHashCode7 ^ (str7 == null ? 0 : str7.hashCode())) * 1000003;
        String str8 = this.f75i;
        int iHashCode9 = (iHashCode8 ^ (str8 == null ? 0 : str8.hashCode())) * 1000003;
        String str9 = this.f76j;
        int iHashCode10 = (iHashCode9 ^ (str9 == null ? 0 : str9.hashCode())) * 1000003;
        String str10 = this.f77k;
        int iHashCode11 = (iHashCode10 ^ (str10 == null ? 0 : str10.hashCode())) * 1000003;
        String str11 = this.f78l;
        return iHashCode11 ^ (str11 != null ? str11.hashCode() : 0);
    }

    @Override // a4.a
    public String i() {
        return this.f77k;
    }

    @Override // a4.a
    public String j() {
        return this.f68b;
    }

    @Override // a4.a
    public String k() {
        return this.f72f;
    }

    @Override // a4.a
    public String l() {
        return this.f71e;
    }

    @Override // a4.a
    public Integer m() {
        return this.f67a;
    }

    public String toString() {
        return "AndroidClientInfo{sdkVersion=" + this.f67a + ", model=" + this.f68b + ", hardware=" + this.f69c + ", device=" + this.f70d + ", product=" + this.f71e + ", osBuild=" + this.f72f + ", manufacturer=" + this.f73g + ", fingerprint=" + this.f74h + ", locale=" + this.f75i + ", country=" + this.f76j + ", mccMnc=" + this.f77k + ", applicationBuild=" + this.f78l + "}";
    }
}
