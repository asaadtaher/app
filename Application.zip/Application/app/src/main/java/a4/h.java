package a4;

/* loaded from: classes.dex */
final class h extends n {

    /* renamed from: a, reason: collision with root package name */
    private final long f124a;

    h(long j10) {
        this.f124a = j10;
    }

    @Override // a4.n
    public long c() {
        return this.f124a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        return (obj instanceof n) && this.f124a == ((n) obj).c();
    }

    public int hashCode() {
        long j10 = this.f124a;
        return 1000003 ^ ((int) (j10 ^ (j10 >>> 32)));
    }

    public String toString() {
        return "LogResponse{nextRequestWaitMillis=" + this.f124a + "}";
    }
}
