package a4;

import java.util.List;

/* loaded from: classes.dex */
public abstract class j {
    public static j a(List<m> list) {
        return new d(list);
    }

    public static k8.a b() {
        return new m8.d().j(b.f29a).k(true).i();
    }

    public abstract List<m> c();
}
