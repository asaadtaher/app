package a4;

/* loaded from: classes.dex */
public final class b implements l8.a {

    /* renamed from: a, reason: collision with root package name */
    public static final l8.a f29a = new b();

    private static final class a implements k8.d<a4.a> {

        /* renamed from: a, reason: collision with root package name */
        static final a f30a = new a();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f31b = k8.c.d("sdkVersion");

        /* renamed from: c, reason: collision with root package name */
        private static final k8.c f32c = k8.c.d("model");

        /* renamed from: d, reason: collision with root package name */
        private static final k8.c f33d = k8.c.d("hardware");

        /* renamed from: e, reason: collision with root package name */
        private static final k8.c f34e = k8.c.d("device");

        /* renamed from: f, reason: collision with root package name */
        private static final k8.c f35f = k8.c.d("product");

        /* renamed from: g, reason: collision with root package name */
        private static final k8.c f36g = k8.c.d("osBuild");

        /* renamed from: h, reason: collision with root package name */
        private static final k8.c f37h = k8.c.d("manufacturer");

        /* renamed from: i, reason: collision with root package name */
        private static final k8.c f38i = k8.c.d("fingerprint");

        /* renamed from: j, reason: collision with root package name */
        private static final k8.c f39j = k8.c.d("locale");

        /* renamed from: k, reason: collision with root package name */
        private static final k8.c f40k = k8.c.d("country");

        /* renamed from: l, reason: collision with root package name */
        private static final k8.c f41l = k8.c.d("mccMnc");

        /* renamed from: m, reason: collision with root package name */
        private static final k8.c f42m = k8.c.d("applicationBuild");

        private a() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(a4.a aVar, k8.e eVar) {
            eVar.a(f31b, aVar.m());
            eVar.a(f32c, aVar.j());
            eVar.a(f33d, aVar.f());
            eVar.a(f34e, aVar.d());
            eVar.a(f35f, aVar.l());
            eVar.a(f36g, aVar.k());
            eVar.a(f37h, aVar.h());
            eVar.a(f38i, aVar.e());
            eVar.a(f39j, aVar.g());
            eVar.a(f40k, aVar.c());
            eVar.a(f41l, aVar.i());
            eVar.a(f42m, aVar.b());
        }
    }

    /* renamed from: a4.b$b, reason: collision with other inner class name */
    private static final class C0002b implements k8.d<j> {

        /* renamed from: a, reason: collision with root package name */
        static final C0002b f43a = new C0002b();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f44b = k8.c.d("logRequest");

        private C0002b() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(j jVar, k8.e eVar) {
            eVar.a(f44b, jVar.c());
        }
    }

    private static final class c implements k8.d<k> {

        /* renamed from: a, reason: collision with root package name */
        static final c f45a = new c();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f46b = k8.c.d("clientType");

        /* renamed from: c, reason: collision with root package name */
        private static final k8.c f47c = k8.c.d("androidClientInfo");

        private c() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(k kVar, k8.e eVar) {
            eVar.a(f46b, kVar.c());
            eVar.a(f47c, kVar.b());
        }
    }

    private static final class d implements k8.d<l> {

        /* renamed from: a, reason: collision with root package name */
        static final d f48a = new d();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f49b = k8.c.d("eventTimeMs");

        /* renamed from: c, reason: collision with root package name */
        private static final k8.c f50c = k8.c.d("eventCode");

        /* renamed from: d, reason: collision with root package name */
        private static final k8.c f51d = k8.c.d("eventUptimeMs");

        /* renamed from: e, reason: collision with root package name */
        private static final k8.c f52e = k8.c.d("sourceExtension");

        /* renamed from: f, reason: collision with root package name */
        private static final k8.c f53f = k8.c.d("sourceExtensionJsonProto3");

        /* renamed from: g, reason: collision with root package name */
        private static final k8.c f54g = k8.c.d("timezoneOffsetSeconds");

        /* renamed from: h, reason: collision with root package name */
        private static final k8.c f55h = k8.c.d("networkConnectionInfo");

        private d() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(l lVar, k8.e eVar) {
            eVar.d(f49b, lVar.c());
            eVar.a(f50c, lVar.b());
            eVar.d(f51d, lVar.d());
            eVar.a(f52e, lVar.f());
            eVar.a(f53f, lVar.g());
            eVar.d(f54g, lVar.h());
            eVar.a(f55h, lVar.e());
        }
    }

    private static final class e implements k8.d<m> {

        /* renamed from: a, reason: collision with root package name */
        static final e f56a = new e();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f57b = k8.c.d("requestTimeMs");

        /* renamed from: c, reason: collision with root package name */
        private static final k8.c f58c = k8.c.d("requestUptimeMs");

        /* renamed from: d, reason: collision with root package name */
        private static final k8.c f59d = k8.c.d("clientInfo");

        /* renamed from: e, reason: collision with root package name */
        private static final k8.c f60e = k8.c.d("logSource");

        /* renamed from: f, reason: collision with root package name */
        private static final k8.c f61f = k8.c.d("logSourceName");

        /* renamed from: g, reason: collision with root package name */
        private static final k8.c f62g = k8.c.d("logEvent");

        /* renamed from: h, reason: collision with root package name */
        private static final k8.c f63h = k8.c.d("qosTier");

        private e() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(m mVar, k8.e eVar) {
            eVar.d(f57b, mVar.g());
            eVar.d(f58c, mVar.h());
            eVar.a(f59d, mVar.b());
            eVar.a(f60e, mVar.d());
            eVar.a(f61f, mVar.e());
            eVar.a(f62g, mVar.c());
            eVar.a(f63h, mVar.f());
        }
    }

    private static final class f implements k8.d<o> {

        /* renamed from: a, reason: collision with root package name */
        static final f f64a = new f();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f65b = k8.c.d("networkType");

        /* renamed from: c, reason: collision with root package name */
        private static final k8.c f66c = k8.c.d("mobileSubtype");

        private f() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(o oVar, k8.e eVar) {
            eVar.a(f65b, oVar.c());
            eVar.a(f66c, oVar.b());
        }
    }

    private b() {
    }

    @Override // l8.a
    public void a(l8.b<?> bVar) {
        C0002b c0002b = C0002b.f43a;
        bVar.a(j.class, c0002b);
        bVar.a(a4.d.class, c0002b);
        e eVar = e.f56a;
        bVar.a(m.class, eVar);
        bVar.a(g.class, eVar);
        c cVar = c.f45a;
        bVar.a(k.class, cVar);
        bVar.a(a4.e.class, cVar);
        a aVar = a.f30a;
        bVar.a(a4.a.class, aVar);
        bVar.a(a4.c.class, aVar);
        d dVar = d.f48a;
        bVar.a(l.class, dVar);
        bVar.a(a4.f.class, dVar);
        f fVar = f.f64a;
        bVar.a(o.class, fVar);
        bVar.a(i.class, fVar);
    }
}
