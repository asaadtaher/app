package c5;

import a5.y;
import android.content.Context;
import android.os.Looper;
import y4.a;
import z4.h;

/* loaded from: classes.dex */
final class c extends a.AbstractC0429a {
    c() {
    }

    @Override // y4.a.AbstractC0429a
    public final /* synthetic */ a.f d(Context context, Looper looper, a5.e eVar, Object obj, z4.c cVar, h hVar) {
        return new e(context, looper, eVar, (y) obj, cVar, hVar);
    }
}
