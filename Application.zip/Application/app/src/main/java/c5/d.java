package c5;

import a5.v;
import a5.x;
import a5.y;
import android.content.Context;
import b6.i;
import com.google.android.gms.common.api.internal.h;
import m5.f;
import y4.a;
import y4.e;
import z4.j;

/* loaded from: classes.dex */
public final class d extends y4.e implements x {

    /* renamed from: k, reason: collision with root package name */
    private static final a.g f6289k;

    /* renamed from: l, reason: collision with root package name */
    private static final a.AbstractC0429a f6290l;

    /* renamed from: m, reason: collision with root package name */
    private static final y4.a f6291m;

    /* renamed from: n, reason: collision with root package name */
    public static final /* synthetic */ int f6292n = 0;

    static {
        a.g gVar = new a.g();
        f6289k = gVar;
        c cVar = new c();
        f6290l = cVar;
        f6291m = new y4.a("ClientTelemetry.API", cVar, gVar);
    }

    public d(Context context, y yVar) {
        super(context, (y4.a<y>) f6291m, yVar, e.a.f24257c);
    }

    @Override // a5.x
    public final i<Void> g(final v vVar) {
        h.a aVarA = h.a();
        aVarA.d(f.f17719a);
        aVarA.c(false);
        aVarA.b(new j() { // from class: c5.b
            /* JADX WARN: Multi-variable type inference failed */
            @Override // z4.j
            public final void b(Object obj, Object obj2) {
                v vVar2 = vVar;
                int i10 = d.f6292n;
                ((a) ((e) obj).H()).m1(vVar2);
                ((b6.j) obj2).c(null);
            }
        });
        return j(aVarA.a());
    }
}
