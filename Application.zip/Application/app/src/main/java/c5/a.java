package c5;

import a5.v;
import android.os.IBinder;
import android.os.Parcel;

/* loaded from: classes.dex */
public final class a extends m5.a {
    a(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.common.internal.service.IClientTelemetryService");
    }

    public final void m1(v vVar) {
        Parcel parcelR = r();
        m5.c.d(parcelR, vVar);
        R(1, parcelR);
    }
}
