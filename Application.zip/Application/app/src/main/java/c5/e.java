package c5;

import a5.h;
import a5.y;
import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import m5.f;

/* loaded from: classes.dex */
public final class e extends h {
    private final y I;

    public e(Context context, Looper looper, a5.e eVar, y yVar, z4.c cVar, z4.h hVar) {
        super(context, looper, 270, eVar, cVar, hVar);
        this.I = yVar;
    }

    @Override // a5.c
    protected final Bundle E() {
        return this.I.c();
    }

    @Override // a5.c
    protected final String I() {
        return "com.google.android.gms.common.internal.service.IClientTelemetryService";
    }

    @Override // a5.c
    protected final String J() {
        return "com.google.android.gms.common.telemetry.service.START";
    }

    @Override // a5.c
    protected final boolean M() {
        return true;
    }

    @Override // a5.c, y4.a.f
    public final int m() {
        return 203400000;
    }

    @Override // a5.c
    protected final /* synthetic */ IInterface w(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.service.IClientTelemetryService");
        return iInterfaceQueryLocalInterface instanceof a ? (a) iInterfaceQueryLocalInterface : new a(iBinder);
    }

    @Override // a5.c
    public final x4.d[] z() {
        return f.f17720b;
    }
}
