package cb;

import android.app.Activity;
import android.os.Build;
import com.payment.paymentsdk.PaymentSdkActivity;
import com.payment.paymentsdk.PaymentSdkConfigBuilder;
import com.payment.paymentsdk.PaymentSdkParams;
import com.payment.paymentsdk.QuerySdkActivity;
import com.payment.paymentsdk.integrationmodels.PaymentSDKQueryConfiguration;
import com.payment.paymentsdk.integrationmodels.PaymentSdkApms;
import com.payment.paymentsdk.integrationmodels.PaymentSdkApmsKt;
import com.payment.paymentsdk.integrationmodels.PaymentSdkBillingDetails;
import com.payment.paymentsdk.integrationmodels.PaymentSdkConfigurationDetails;
import com.payment.paymentsdk.integrationmodels.PaymentSdkError;
import com.payment.paymentsdk.integrationmodels.PaymentSdkLanguageCode;
import com.payment.paymentsdk.integrationmodels.PaymentSdkLanguageCodeKt;
import com.payment.paymentsdk.integrationmodels.PaymentSdkShippingDetails;
import com.payment.paymentsdk.integrationmodels.PaymentSdkTokenFormat;
import com.payment.paymentsdk.integrationmodels.PaymentSdkTokenFormatKt;
import com.payment.paymentsdk.integrationmodels.PaymentSdkTokenise;
import com.payment.paymentsdk.integrationmodels.PaymentSdkTokeniseKt;
import com.payment.paymentsdk.integrationmodels.PaymentSdkTransactionClassKt;
import com.payment.paymentsdk.integrationmodels.PaymentSdkTransactionDetails;
import com.payment.paymentsdk.integrationmodels.PaymentSdkTransactionType;
import com.payment.paymentsdk.integrationmodels.PaymentSdkTransactionTypeKt;
import com.payment.paymentsdk.save_cards.entities.PaymentSDKSavedCardInfo;
import com.payment.paymentsdk.sharedclasses.interfaces.CallbackPaymentInterface;
import com.payment.paymentsdk.sharedclasses.interfaces.CallbackQueryInterface;
import com.payment.paymentsdk.sharedclasses.model.response.TransactionResponseBody;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import kb.a;
import org.json.JSONException;
import org.json.JSONObject;
import tb.d;
import tb.j;
import tb.k;

/* loaded from: classes.dex */
public class a implements kb.a, k.c, lb.a {

    /* renamed from: a, reason: collision with root package name */
    private k f6743a;

    /* renamed from: b, reason: collision with root package name */
    private Activity f6744b;

    /* renamed from: c, reason: collision with root package name */
    private d.b f6745c;

    /* renamed from: cb.a$a, reason: collision with other inner class name */
    class C0110a implements d.InterfaceC0377d {
        C0110a() {
        }

        @Override // tb.d.InterfaceC0377d
        public void a(Object obj, d.b bVar) {
            a.this.f6745c = bVar;
        }

        @Override // tb.d.InterfaceC0377d
        public void b(Object obj) {
        }
    }

    class b implements CallbackPaymentInterface {
        b() {
        }

        @Override // com.payment.paymentsdk.sharedclasses.interfaces.CallbackPaymentInterface
        public void onError(PaymentSdkError paymentSdkError) {
            if (paymentSdkError.getCode() != null) {
                a.this.x(paymentSdkError.getCode().intValue(), paymentSdkError.getMsg(), "error", paymentSdkError.getTrace(), null);
            } else {
                a.this.x(0, paymentSdkError.getMsg(), "error", paymentSdkError.getTrace(), null);
            }
        }

        @Override // com.payment.paymentsdk.sharedclasses.interfaces.CallbackPaymentInterface
        public void onPaymentCancel() {
            a.this.x(0, "Cancelled", "event", null, null);
        }

        @Override // com.payment.paymentsdk.sharedclasses.interfaces.CallbackPaymentInterface
        public void onPaymentFinish(PaymentSdkTransactionDetails paymentSdkTransactionDetails) {
            a.this.x(200, "success", "success", null, paymentSdkTransactionDetails);
        }
    }

    class c implements CallbackQueryInterface {
        c() {
        }

        @Override // com.payment.paymentsdk.sharedclasses.interfaces.CallbackQueryInterface
        public void onCancel() {
            a.this.x(0, "Cancelled", "event", null, null);
        }

        @Override // com.payment.paymentsdk.sharedclasses.interfaces.CallbackQueryInterface
        public void onError(PaymentSdkError paymentSdkError) {
            if (paymentSdkError.getCode() != null) {
                a.this.x(paymentSdkError.getCode().intValue(), paymentSdkError.getMsg(), "error", paymentSdkError.getTrace(), null);
            } else {
                a.this.x(0, paymentSdkError.getMsg(), "error", paymentSdkError.getTrace(), null);
            }
        }

        @Override // com.payment.paymentsdk.sharedclasses.interfaces.CallbackQueryInterface
        public void onResult(TransactionResponseBody transactionResponseBody) {
            a.this.w(200, "success", "success", transactionResponseBody);
        }
    }

    class d extends com.google.gson.reflect.a<HashMap<String, Object>> {
        d() {
        }
    }

    class e extends com.google.gson.reflect.a<HashMap<String, Object>> {
        e() {
        }
    }

    private void d() {
        try {
            PaymentSdkActivity.cancelPayment();
        } catch (Exception e10) {
            this.f6745c.b("0", e10.getMessage(), "{}");
        }
    }

    private void e(k.d dVar) {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                PaymentSdkActivity.clearSavedCards(this.f6744b);
                dVar.a(null);
            } else {
                dVar.b("0", "Unsupported Android Version. Min supported SDK is 23", "{}");
            }
        } catch (Exception e10) {
            dVar.b("0", e10.getMessage(), "{}");
        }
    }

    private ArrayList<PaymentSdkApms> f(String str) {
        PaymentSdkApms paymentSdkApmsCreatePaymentSdkApms;
        ArrayList<PaymentSdkApms> arrayList = new ArrayList<>();
        if (str != null && !str.isEmpty()) {
            for (String str2 : str.split(",")) {
                if (str2.length() > 0 && (paymentSdkApmsCreatePaymentSdkApms = PaymentSdkApmsKt.createPaymentSdkApms(str2)) != null) {
                    arrayList.add(paymentSdkApmsCreatePaymentSdkApms);
                }
            }
        }
        return arrayList;
    }

    private CallbackPaymentInterface g() {
        return new b();
    }

    private Boolean h(JSONObject jSONObject) {
        return Boolean.valueOf(jSONObject.optBoolean("support3DS"));
    }

    private PaymentSdkConfigurationDetails i(JSONObject jSONObject) {
        PaymentSdkTokenise paymentSdkTokenise;
        PaymentSdkTransactionType paymentSdkTransactionType;
        String string;
        PaymentSdkBillingDetails paymentSdkBillingDetails;
        PaymentSdkShippingDetails paymentSdkShippingDetails;
        String strOptString = jSONObject.optString("pt_profile_id");
        String strOptString2 = jSONObject.optString("pt_server_key");
        String strOptString3 = jSONObject.optString("pt_client_key");
        PaymentSdkLanguageCode paymentSdkLanguageCodeCreatePaymentSdkLanguageCode = PaymentSdkLanguageCodeKt.createPaymentSdkLanguageCode(jSONObject.optString("pt_language"));
        String strOptString4 = jSONObject.optString("pt_screen_title");
        String strOptString5 = jSONObject.optString("pt_cart_id");
        String strOptString6 = jSONObject.optString("pt_cart_description");
        long jOptInt = jSONObject.optInt("pt_expiry_time", 0);
        String str = strOptString6.equals("null") ? null : strOptString6;
        String strOptString7 = jSONObject.optString("pt_currency_code");
        String strOptString8 = jSONObject.optString("pt_token");
        String str2 = (strOptString8 == "null" || strOptString8 == null) ? "" : strOptString8;
        String strOptString9 = jSONObject.optString("pt_transaction_reference");
        String str3 = (strOptString9 == "null" || strOptString9 == null) ? "" : strOptString9;
        double dOptDouble = jSONObject.optDouble("pt_amount");
        PaymentSdkTokenise paymentSdkTokeniseCreatePaymentSdkTokenise = PaymentSdkTokeniseKt.createPaymentSdkTokenise(jSONObject.optString("pt_tokenise_type"));
        PaymentSdkTokenFormat paymentSdkTokenFormatCreatePaymentSdkTokenFormat = PaymentSdkTokenFormatKt.createPaymentSdkTokenFormat(jSONObject.optString("pt_token_format"));
        PaymentSdkTransactionType paymentSdkTransactionTypeCreatePaymentSdkTransactionType = PaymentSdkTransactionTypeKt.createPaymentSdkTransactionType(jSONObject.optString("pt_transaction_type"));
        ArrayList<PaymentSdkApms> arrayListF = f(jSONObject.optString("pt_apms"));
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("pt_billing_details");
        String str4 = str3;
        if (jSONObject.isNull("pt_ios_theme")) {
            paymentSdkTokenise = paymentSdkTokeniseCreatePaymentSdkTokenise;
            paymentSdkTransactionType = paymentSdkTransactionTypeCreatePaymentSdkTransactionType;
            string = null;
        } else {
            paymentSdkTokenise = paymentSdkTokeniseCreatePaymentSdkTokenise;
            StringBuilder sb2 = new StringBuilder();
            paymentSdkTransactionType = paymentSdkTransactionTypeCreatePaymentSdkTransactionType;
            sb2.append("file://");
            sb2.append(u(jSONObject.optJSONObject("pt_ios_theme"), "pt_ios_logo"));
            string = sb2.toString();
        }
        PaymentSdkBillingDetails paymentSdkBillingDetails2 = jSONObjectOptJSONObject != null ? new PaymentSdkBillingDetails(jSONObjectOptJSONObject.optString("pt_city_billing"), jSONObjectOptJSONObject.optString("pt_country_billing"), jSONObjectOptJSONObject.optString("pt_email_billing"), jSONObjectOptJSONObject.optString("pt_name_billing"), jSONObjectOptJSONObject.optString("pt_phone_billing"), jSONObjectOptJSONObject.optString("pt_state_billing"), jSONObjectOptJSONObject.optString("pt_address_billing"), jSONObjectOptJSONObject.optString("pt_zip_billing")) : null;
        JSONObject jSONObjectOptJSONObject2 = jSONObject.optJSONObject("pt_shipping_details");
        if (jSONObjectOptJSONObject2 != null) {
            paymentSdkBillingDetails = paymentSdkBillingDetails2;
            paymentSdkShippingDetails = new PaymentSdkShippingDetails(jSONObjectOptJSONObject2.optString("pt_city_shipping"), jSONObjectOptJSONObject2.optString("pt_country_shipping"), jSONObjectOptJSONObject2.optString("pt_email_shipping"), jSONObjectOptJSONObject2.optString("pt_name_shipping"), jSONObjectOptJSONObject2.optString("pt_phone_shipping"), jSONObjectOptJSONObject2.optString("pt_state_shipping"), jSONObjectOptJSONObject2.optString("pt_address_shipping"), jSONObjectOptJSONObject2.optString("pt_zip_shipping"));
        } else {
            paymentSdkBillingDetails = paymentSdkBillingDetails2;
            paymentSdkShippingDetails = null;
        }
        return new PaymentSdkConfigBuilder(strOptString, strOptString2, strOptString3, dOptDouble, strOptString7).setCartDescription(str).setLanguageCode(paymentSdkLanguageCodeCreatePaymentSdkLanguageCode).setBillingData(paymentSdkBillingDetails).setMerchantCountryCode(jSONObject.optString("pt_merchant_country_code")).setShippingData(paymentSdkShippingDetails).setCartId(strOptString5).setTransactionClass(PaymentSdkTransactionClassKt.createPaymentSdkTransactionClass(jSONObject.optString("pt_transaction_class"))).setTransactionType(paymentSdkTransactionType).setTokenise(paymentSdkTokenise, paymentSdkTokenFormatCreatePaymentSdkTokenFormat).setTokenisationData(str2, str4).setAlternativePaymentMethods(arrayListF).showBillingInfo(jSONObject.optBoolean("pt_show_billing_info")).showShippingInfo(jSONObject.optBoolean("pt_show_shipping_info")).forceShippingInfo(jSONObject.optBoolean("pt_force_validate_shipping")).setMerchantIcon(string).setScreenTitle(strOptString4).linkBillingNameWithCard(jSONObject.optBoolean("pt_link_billing_name")).hideCardScanner(jSONObject.optBoolean("pt_hide_card_scanner")).enableZeroContacts(Boolean.valueOf(jSONObject.optBoolean("pt_enable_zero_contacts"))).isDigitalProduct(Boolean.valueOf(jSONObject.optBoolean("pt_is_digital_product"))).setPaymentExpiry(jOptInt).build();
    }

    private CallbackQueryInterface j() {
        return new c();
    }

    private PaymentSDKQueryConfiguration k(JSONObject jSONObject) {
        return new PaymentSDKQueryConfiguration(jSONObject.optString("pt_server_key"), jSONObject.optString("pt_client_key"), jSONObject.optString("pt_merchant_country_code"), jSONObject.optString("pt_profile_id"), jSONObject.optString("pt_transaction_reference"));
    }

    private PaymentSDKSavedCardInfo l(JSONObject jSONObject) {
        return new PaymentSDKSavedCardInfo(jSONObject.optString("pt_masked_card"), jSONObject.optString("pt_card_type"));
    }

    private String m(JSONObject jSONObject) {
        return jSONObject.optString(PaymentSdkParams.TOKEN);
    }

    private String n(JSONObject jSONObject) {
        return jSONObject.optString("transactionRef");
    }

    private void o(j jVar) {
        try {
            JSONObject jSONObject = new JSONObject((HashMap) jVar.b());
            PaymentSdkActivity.start3DSecureTokenizedCardPayment(this.f6744b, i(jSONObject), l(jSONObject.optJSONObject("paymentSDKSavedCardInfo")), m(jSONObject), g());
        } catch (Exception e10) {
            this.f6745c.b("0", e10.getMessage(), "{}");
        }
    }

    private void p(j jVar) {
        try {
            PaymentSdkActivity.startAlternativePaymentMethods(this.f6744b, i(new JSONObject((HashMap) jVar.b())), g());
        } catch (Exception e10) {
            this.f6745c.b("0", e10.getMessage(), "{}");
        }
    }

    private void q(j jVar) {
        try {
            PaymentSdkActivity.startCardPayment(this.f6744b, i(new JSONObject((HashMap) jVar.b())), g());
        } catch (Exception e10) {
            this.f6745c.b("0", e10.getMessage(), "{}");
        }
    }

    private void r(j jVar) {
        try {
            JSONObject jSONObject = new JSONObject((HashMap) jVar.b());
            PaymentSdkActivity.startPaymentWithSavedCards(this.f6744b, i(jSONObject), h(jSONObject).booleanValue(), g());
        } catch (Exception e10) {
            this.f6745c.b("0", e10.getMessage(), "{}");
        }
    }

    private void s(j jVar) throws JSONException {
        try {
            JSONObject jSONObject = new JSONObject((HashMap) jVar.b());
            PaymentSdkActivity.startSamsungPayment(this.f6744b, i(jSONObject), jSONObject.getString("pt_samsung_pay_token"), g());
        } catch (Exception e10) {
            this.f6745c.b("0", e10.getMessage(), "{}");
        }
    }

    private void t(j jVar) {
        try {
            JSONObject jSONObject = new JSONObject((HashMap) jVar.b());
            PaymentSdkActivity.startTokenizedCardPayment(this.f6744b, i(jSONObject), m(jSONObject), n(jSONObject), g());
        } catch (Exception e10) {
            this.f6745c.b("0", e10.getMessage(), "{}");
        }
    }

    public static String u(JSONObject jSONObject, String str) {
        return jSONObject.isNull(str) ? "" : jSONObject.optString(str, null);
    }

    private void v(j jVar) {
        try {
            QuerySdkActivity.queryTransaction(this.f6744b, k(new JSONObject((HashMap) jVar.b()).optJSONObject("paymentSDKQueryConfiguration")), j());
        } catch (Exception e10) {
            this.f6745c.b("0", e10.getMessage(), "{}");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void w(int i10, String str, String str2, TransactionResponseBody transactionResponseBody) {
        HashMap map = new HashMap();
        if (transactionResponseBody != null) {
            map.put("data", (Map) new p9.e().j(new p9.e().r(transactionResponseBody), new e().getType()));
        }
        map.put("code", Integer.valueOf(i10));
        map.put("message", str);
        map.put("status", str2);
        this.f6745c.a(map);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void x(int i10, String str, String str2, String str3, PaymentSdkTransactionDetails paymentSdkTransactionDetails) {
        HashMap map = new HashMap();
        if (paymentSdkTransactionDetails != null) {
            map.put("data", (Map) new p9.e().j(new p9.e().r(paymentSdkTransactionDetails), new d().getType()));
        }
        map.put("code", Integer.valueOf(i10));
        map.put("message", str);
        map.put("status", str2);
        map.put("trace", str3);
        this.f6745c.a(map);
    }

    @Override // lb.a
    public void onAttachedToActivity(lb.c cVar) {
        this.f6744b = cVar.c();
    }

    @Override // kb.a
    public void onAttachedToEngine(a.b bVar) {
        k kVar = new k(bVar.b(), "flutter_paytabs_bridge");
        this.f6743a = kVar;
        kVar.e(this);
        new tb.d(bVar.b(), "flutter_paytabs_bridge_stream").d(new C0110a());
    }

    @Override // lb.a
    public void onDetachedFromActivity() {
    }

    @Override // lb.a
    public void onDetachedFromActivityForConfigChanges() {
    }

    @Override // kb.a
    public void onDetachedFromEngine(a.b bVar) {
        this.f6743a.e(null);
    }

    @Override // tb.k.c
    public void onMethodCall(j jVar, k.d dVar) throws JSONException {
        String str = jVar.f21944a;
        str.hashCode();
        switch (str) {
            case "startPaymentWithSavedCards":
                r(jVar);
                break;
            case "startCardPayment":
                q(jVar);
                break;
            case "startSamsungPayPayment":
                s(jVar);
                break;
            case "startApmsPayment":
                p(jVar);
                break;
            case "cancelPayment":
                d();
                break;
            case "clearSavedCards":
                e(dVar);
                break;
            case "startTokenizedCardPayment":
                t(jVar);
                break;
            case "start3DSecureTokenizedCardPayment":
                o(jVar);
                break;
            case "queryTransaction":
                v(jVar);
                break;
        }
    }

    @Override // lb.a
    public void onReattachedToActivityForConfigChanges(lb.c cVar) {
    }
}
