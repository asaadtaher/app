package b3;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import b3.u;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class a0 {

    /* renamed from: d, reason: collision with root package name */
    public static final a f5620d = new a(null);

    /* renamed from: e, reason: collision with root package name */
    private static final ScheduledExecutorService f5621e = Executors.newSingleThreadScheduledExecutor();

    /* renamed from: a, reason: collision with root package name */
    private final String f5622a;

    /* renamed from: b, reason: collision with root package name */
    private final c2.c0 f5623b;

    /* renamed from: c, reason: collision with root package name */
    private String f5624c;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final Bundle b(String str) {
            Bundle bundle = new Bundle();
            bundle.putLong("1_timestamp_ms", System.currentTimeMillis());
            bundle.putString("0_auth_logger_id", str);
            bundle.putString("3_method", "");
            bundle.putString("2_result", "");
            bundle.putString("5_error_message", "");
            bundle.putString("4_error_code", "");
            bundle.putString("6_extras", "");
            return bundle;
        }
    }

    public a0(Context context, String applicationId) {
        PackageInfo packageInfo;
        kotlin.jvm.internal.m.g(context, "context");
        kotlin.jvm.internal.m.g(applicationId, "applicationId");
        this.f5622a = applicationId;
        this.f5623b = new c2.c0(context, applicationId);
        try {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager == null || (packageInfo = packageManager.getPackageInfo("com.facebook.katana", 0)) == null) {
                return;
            }
            this.f5624c = packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException unused) {
        }
    }

    private final void g(String str) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            final Bundle bundleB = f5620d.b(str);
            f5621e.schedule(new Runnable() { // from class: b3.z
                @Override // java.lang.Runnable
                public final void run() {
                    a0.h(this.f5837a, bundleB);
                }
            }, 5L, TimeUnit.SECONDS);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void h(a0 this$0, Bundle bundle) {
        if (w2.a.d(a0.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(this$0, "this$0");
            kotlin.jvm.internal.m.g(bundle, "$bundle");
            this$0.f5623b.g("fb_mobile_login_heartbeat", bundle);
        } catch (Throwable th) {
            w2.a.b(th, a0.class);
        }
    }

    public static /* synthetic */ void o(a0 a0Var, String str, String str2, String str3, int i10, Object obj) {
        if (w2.a.d(a0.class)) {
            return;
        }
        if ((i10 & 4) != 0) {
            str3 = "";
        }
        try {
            a0Var.n(str, str2, str3);
        } catch (Throwable th) {
            w2.a.b(th, a0.class);
        }
    }

    public final String b() {
        if (w2.a.d(this)) {
            return null;
        }
        try {
            return this.f5622a;
        } catch (Throwable th) {
            w2.a.b(th, this);
            return null;
        }
    }

    public final void c(String str, String str2, String str3, String str4, String str5, Map<String, String> map, String str6) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            Bundle bundleB = f5620d.b(str);
            if (str3 != null) {
                bundleB.putString("2_result", str3);
            }
            if (str4 != null) {
                bundleB.putString("5_error_message", str4);
            }
            if (str5 != null) {
                bundleB.putString("4_error_code", str5);
            }
            if (map != null && (!map.isEmpty())) {
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                for (Map.Entry<String, String> entry : map.entrySet()) {
                    if (entry.getKey() != null) {
                        linkedHashMap.put(entry.getKey(), entry.getValue());
                    }
                }
                bundleB.putString("6_extras", new JSONObject(linkedHashMap).toString());
            }
            bundleB.putString("3_method", str2);
            this.f5623b.g(str6, bundleB);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void d(String str, String str2, String str3) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            Bundle bundleB = f5620d.b(str);
            bundleB.putString("3_method", str2);
            this.f5623b.g(str3, bundleB);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void e(String str, String str2, String str3) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            Bundle bundleB = f5620d.b(str);
            bundleB.putString("3_method", str2);
            this.f5623b.g(str3, bundleB);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void f(String str, Map<String, String> loggingExtras, u.f.a aVar, Map<String, String> map, Exception exc, String str2) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(loggingExtras, "loggingExtras");
            Bundle bundleB = f5620d.b(str);
            if (aVar != null) {
                bundleB.putString("2_result", aVar.b());
            }
            if ((exc == null ? null : exc.getMessage()) != null) {
                bundleB.putString("5_error_message", exc.getMessage());
            }
            JSONObject jSONObject = loggingExtras.isEmpty() ^ true ? new JSONObject(loggingExtras) : null;
            if (map != null) {
                if (jSONObject == null) {
                    jSONObject = new JSONObject();
                }
                try {
                    for (Map.Entry<String, String> entry : map.entrySet()) {
                        String key = entry.getKey();
                        String value = entry.getValue();
                        if (key != null) {
                            jSONObject.put(key, value);
                        }
                    }
                } catch (JSONException unused) {
                }
            }
            if (jSONObject != null) {
                bundleB.putString("6_extras", jSONObject.toString());
            }
            this.f5623b.g(str2, bundleB);
            if (aVar == u.f.a.SUCCESS) {
                g(str);
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void i(String str, Exception exception) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(exception, "exception");
            Bundle bundleB = f5620d.b(str);
            bundleB.putString("2_result", u.f.a.ERROR.b());
            bundleB.putString("5_error_message", exception.toString());
            this.f5623b.g("fb_mobile_login_status_complete", bundleB);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void j(String str) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            Bundle bundleB = f5620d.b(str);
            bundleB.putString("2_result", "failure");
            this.f5623b.g("fb_mobile_login_status_complete", bundleB);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void k(String str) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            this.f5623b.g("fb_mobile_login_status_start", f5620d.b(str));
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void l(String str) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            Bundle bundleB = f5620d.b(str);
            bundleB.putString("2_result", u.f.a.SUCCESS.b());
            this.f5623b.g("fb_mobile_login_status_complete", bundleB);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void m(u.e pendingLoginRequest, String str) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(pendingLoginRequest, "pendingLoginRequest");
            Bundle bundleB = f5620d.b(pendingLoginRequest.h());
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("login_behavior", pendingLoginRequest.q().toString());
                jSONObject.put("request_code", u.f5776r.b());
                jSONObject.put("permissions", TextUtils.join(",", pendingLoginRequest.x()));
                jSONObject.put("default_audience", pendingLoginRequest.m().toString());
                jSONObject.put("isReauthorize", pendingLoginRequest.C());
                String str2 = this.f5624c;
                if (str2 != null) {
                    jSONObject.put("facebookVersion", str2);
                }
                if (pendingLoginRequest.s() != null) {
                    jSONObject.put("target_app", pendingLoginRequest.s().toString());
                }
                bundleB.putString("6_extras", jSONObject.toString());
            } catch (JSONException unused) {
            }
            this.f5623b.g(str, bundleB);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public final void n(String str, String str2, String str3) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            Bundle bundleB = f5620d.b("");
            bundleB.putString("2_result", u.f.a.ERROR.b());
            bundleB.putString("5_error_message", str2);
            bundleB.putString("3_method", str3);
            this.f5623b.g(str, bundleB);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }
}
