package b3;

import android.content.Context;
import android.os.Bundle;
import b3.u;

/* loaded from: classes.dex */
public final class o extends r2.f0 {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o(Context context, u.e request) {
        super(context, 65536, 65537, 20121101, request.b(), request.w());
        kotlin.jvm.internal.m.g(context, "context");
        kotlin.jvm.internal.m.g(request, "request");
    }

    @Override // r2.f0
    protected void e(Bundle data) {
        kotlin.jvm.internal.m.g(data, "data");
    }
}
