package b3;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import b3.f0;
import b3.u;
import org.json.JSONException;
import org.json.JSONObject;
import r2.f0;
import r2.l0;

/* loaded from: classes.dex */
public final class q extends f0 {

    /* renamed from: d, reason: collision with root package name */
    private o f5752d;

    /* renamed from: e, reason: collision with root package name */
    private final String f5753e;

    /* renamed from: f, reason: collision with root package name */
    public static final b f5751f = new b(null);
    public static final Parcelable.Creator<q> CREATOR = new a();

    public static final class a implements Parcelable.Creator<q> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public q createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new q(source);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public q[] newArray(int i10) {
            return new q[i10];
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public static final class c implements l0.a {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ Bundle f5754a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ q f5755b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ u.e f5756c;

        c(Bundle bundle, q qVar, u.e eVar) {
            this.f5754a = bundle;
            this.f5755b = qVar;
            this.f5756c = eVar;
        }

        @Override // r2.l0.a
        public void a(JSONObject jSONObject) throws NumberFormatException {
            try {
                this.f5754a.putString("com.facebook.platform.extra.USER_ID", jSONObject == null ? null : jSONObject.getString("id"));
                this.f5755b.C(this.f5756c, this.f5754a);
            } catch (JSONException e10) {
                this.f5755b.j().l(u.f.c.d(u.f.f5808i, this.f5755b.j().y(), "Caught exception", e10.getMessage(), null, 8, null));
            }
        }

        @Override // r2.l0.a
        public void b(b2.s sVar) {
            this.f5755b.j().l(u.f.c.d(u.f.f5808i, this.f5755b.j().y(), "Caught exception", sVar == null ? null : sVar.getMessage(), null, 8, null));
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public q(Parcel source) {
        super(source);
        kotlin.jvm.internal.m.g(source, "source");
        this.f5753e = "get_token";
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public q(u loginClient) {
        super(loginClient);
        kotlin.jvm.internal.m.g(loginClient, "loginClient");
        this.f5753e = "get_token";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void D(q this$0, u.e request, Bundle bundle) throws NumberFormatException {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        kotlin.jvm.internal.m.g(request, "$request");
        this$0.B(request, bundle);
    }

    public final void A(u.e request, Bundle result) throws NumberFormatException {
        kotlin.jvm.internal.m.g(request, "request");
        kotlin.jvm.internal.m.g(result, "result");
        String string = result.getString("com.facebook.platform.extra.USER_ID");
        if (!(string == null || string.length() == 0)) {
            C(request, result);
            return;
        }
        j().B();
        String string2 = result.getString("com.facebook.platform.extra.ACCESS_TOKEN");
        if (string2 == null) {
            throw new IllegalStateException("Required value was null.".toString());
        }
        r2.l0 l0Var = r2.l0.f20174a;
        r2.l0.D(string2, new c(result, this, request));
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x0054  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void B(b3.u.e r6, android.os.Bundle r7) throws java.lang.NumberFormatException {
        /*
            r5 = this;
            java.lang.String r0 = "request"
            kotlin.jvm.internal.m.g(r6, r0)
            b3.o r0 = r5.f5752d
            r1 = 0
            if (r0 != 0) goto Lb
            goto Le
        Lb:
            r0.g(r1)
        Le:
            r5.f5752d = r1
            b3.u r0 = r5.j()
            r0.C()
            if (r7 == 0) goto L4c
            java.lang.String r0 = "com.facebook.platform.extra.PERMISSIONS"
            java.util.ArrayList r0 = r7.getStringArrayList(r0)
            if (r0 != 0) goto L25
            java.util.List r0 = uc.n.g()
        L25:
            java.util.Set r1 = r6.x()
            if (r1 != 0) goto L2f
            java.util.Set r1 = uc.k0.b()
        L2f:
            java.lang.String r2 = "com.facebook.platform.extra.ID_TOKEN"
            java.lang.String r2 = r7.getString(r2)
            java.lang.String r3 = "openid"
            boolean r3 = r1.contains(r3)
            r4 = 1
            if (r3 == 0) goto L54
            if (r2 == 0) goto L49
            int r2 = r2.length()
            if (r2 != 0) goto L47
            goto L49
        L47:
            r2 = 0
            goto L4a
        L49:
            r2 = 1
        L4a:
            if (r2 == 0) goto L54
        L4c:
            b3.u r6 = r5.j()
            r6.K()
            return
        L54:
            boolean r2 = r0.containsAll(r1)
            if (r2 == 0) goto L5e
            r5.A(r6, r7)
            return
        L5e:
            java.util.HashSet r7 = new java.util.HashSet
            r7.<init>()
            java.util.Iterator r1 = r1.iterator()
        L67:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L7d
            java.lang.Object r2 = r1.next()
            java.lang.String r2 = (java.lang.String) r2
            boolean r3 = r0.contains(r2)
            if (r3 != 0) goto L67
            r7.add(r2)
            goto L67
        L7d:
            boolean r0 = r7.isEmpty()
            r0 = r0 ^ r4
            if (r0 == 0) goto L8f
            java.lang.String r0 = ","
            java.lang.String r0 = android.text.TextUtils.join(r0, r7)
            java.lang.String r1 = "new_permissions"
            r5.b(r1, r0)
        L8f:
            r6.F(r7)
            goto L4c
        */
        throw new UnsupportedOperationException("Method not decompiled: b3.q.B(b3.u$e, android.os.Bundle):void");
    }

    public final void C(u.e request, Bundle result) throws NumberFormatException {
        u.f fVarD;
        kotlin.jvm.internal.m.g(request, "request");
        kotlin.jvm.internal.m.g(result, "result");
        try {
            f0.a aVar = f0.f5669c;
            fVarD = u.f.f5808i.b(request, aVar.a(result, b2.h.FACEBOOK_APPLICATION_SERVICE, request.b()), aVar.c(result, request.w()));
        } catch (b2.s e10) {
            fVarD = u.f.c.d(u.f.f5808i, j().y(), null, e10.getMessage(), null, 8, null);
        }
        j().m(fVarD);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // b3.f0
    public void h() {
        o oVar = this.f5752d;
        if (oVar == null) {
            return;
        }
        oVar.b();
        oVar.g(null);
        this.f5752d = null;
    }

    @Override // b3.f0
    public String l() {
        return this.f5753e;
    }

    @Override // b3.f0
    public int y(final u.e request) {
        kotlin.jvm.internal.m.g(request, "request");
        Context contextO = j().o();
        if (contextO == null) {
            b2.f0 f0Var = b2.f0.f5388a;
            contextO = b2.f0.l();
        }
        o oVar = new o(contextO, request);
        this.f5752d = oVar;
        if (kotlin.jvm.internal.m.b(Boolean.valueOf(oVar.h()), Boolean.FALSE)) {
            return 0;
        }
        j().B();
        f0.b bVar = new f0.b() { // from class: b3.p
            @Override // r2.f0.b
            public final void a(Bundle bundle) throws NumberFormatException {
                q.D(this.f5734a, request, bundle);
            }
        };
        o oVar2 = this.f5752d;
        if (oVar2 == null) {
            return 1;
        }
        oVar2.g(bVar);
        return 1;
    }
}
