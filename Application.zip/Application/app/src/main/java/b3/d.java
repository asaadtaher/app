package b3;

import android.content.ComponentName;
import android.net.Uri;
import java.util.concurrent.locks.ReentrantLock;

/* loaded from: classes.dex */
public final class d extends androidx.browser.customtabs.e {

    /* renamed from: c, reason: collision with root package name */
    private static androidx.browser.customtabs.c f5639c;

    /* renamed from: d, reason: collision with root package name */
    private static androidx.browser.customtabs.f f5640d;

    /* renamed from: b, reason: collision with root package name */
    public static final a f5638b = new a(null);

    /* renamed from: e, reason: collision with root package name */
    private static final ReentrantLock f5641e = new ReentrantLock();

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final void d() {
            androidx.browser.customtabs.c cVar;
            d.f5641e.lock();
            if (d.f5640d == null && (cVar = d.f5639c) != null) {
                a aVar = d.f5638b;
                d.f5640d = cVar.f(null);
            }
            d.f5641e.unlock();
        }

        public final androidx.browser.customtabs.f b() {
            d.f5641e.lock();
            androidx.browser.customtabs.f fVar = d.f5640d;
            d.f5640d = null;
            d.f5641e.unlock();
            return fVar;
        }

        public final void c(Uri url) {
            kotlin.jvm.internal.m.g(url, "url");
            d();
            d.f5641e.lock();
            androidx.browser.customtabs.f fVar = d.f5640d;
            if (fVar != null) {
                fVar.f(url, null, null);
            }
            d.f5641e.unlock();
        }
    }

    @Override // androidx.browser.customtabs.e
    public void a(ComponentName name, androidx.browser.customtabs.c newClient) {
        kotlin.jvm.internal.m.g(name, "name");
        kotlin.jvm.internal.m.g(newClient, "newClient");
        newClient.h(0L);
        a aVar = f5638b;
        f5639c = newClient;
        aVar.d();
    }

    @Override // android.content.ServiceConnection
    public void onServiceDisconnected(ComponentName componentName) {
        kotlin.jvm.internal.m.g(componentName, "componentName");
    }
}
