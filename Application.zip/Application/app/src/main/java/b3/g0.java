package b3;

import java.util.Set;

/* loaded from: classes.dex */
public final class g0 {

    /* renamed from: a, reason: collision with root package name */
    private final b2.a f5678a;

    /* renamed from: b, reason: collision with root package name */
    private final b2.i f5679b;

    /* renamed from: c, reason: collision with root package name */
    private final Set<String> f5680c;

    /* renamed from: d, reason: collision with root package name */
    private final Set<String> f5681d;

    public g0(b2.a accessToken, b2.i iVar, Set<String> recentlyGrantedPermissions, Set<String> recentlyDeniedPermissions) {
        kotlin.jvm.internal.m.g(accessToken, "accessToken");
        kotlin.jvm.internal.m.g(recentlyGrantedPermissions, "recentlyGrantedPermissions");
        kotlin.jvm.internal.m.g(recentlyDeniedPermissions, "recentlyDeniedPermissions");
        this.f5678a = accessToken;
        this.f5679b = iVar;
        this.f5680c = recentlyGrantedPermissions;
        this.f5681d = recentlyDeniedPermissions;
    }

    public final b2.a a() {
        return this.f5678a;
    }

    public final Set<String> b() {
        return this.f5680c;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof g0)) {
            return false;
        }
        g0 g0Var = (g0) obj;
        return kotlin.jvm.internal.m.b(this.f5678a, g0Var.f5678a) && kotlin.jvm.internal.m.b(this.f5679b, g0Var.f5679b) && kotlin.jvm.internal.m.b(this.f5680c, g0Var.f5680c) && kotlin.jvm.internal.m.b(this.f5681d, g0Var.f5681d);
    }

    public int hashCode() {
        int iHashCode = this.f5678a.hashCode() * 31;
        b2.i iVar = this.f5679b;
        return ((((iHashCode + (iVar == null ? 0 : iVar.hashCode())) * 31) + this.f5680c.hashCode()) * 31) + this.f5681d.hashCode();
    }

    public String toString() {
        return "LoginResult(accessToken=" + this.f5678a + ", authenticationToken=" + this.f5679b + ", recentlyGrantedPermissions=" + this.f5680c + ", recentlyDeniedPermissions=" + this.f5681d + ')';
    }
}
