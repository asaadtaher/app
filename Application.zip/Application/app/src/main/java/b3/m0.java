package b3;

import android.os.Bundle;
import android.util.Base64;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public final class m0 {

    /* renamed from: a, reason: collision with root package name */
    public static final m0 f5728a = new m0();

    private m0() {
    }

    public static final b2.j0 a(String authorizationCode, String redirectUri, String codeVerifier) {
        kotlin.jvm.internal.m.g(authorizationCode, "authorizationCode");
        kotlin.jvm.internal.m.g(redirectUri, "redirectUri");
        kotlin.jvm.internal.m.g(codeVerifier, "codeVerifier");
        Bundle bundle = new Bundle();
        bundle.putString("code", authorizationCode);
        b2.f0 f0Var = b2.f0.f5388a;
        bundle.putString("client_id", b2.f0.m());
        bundle.putString("redirect_uri", redirectUri);
        bundle.putString("code_verifier", codeVerifier);
        b2.j0 j0VarX = b2.j0.f5454n.x(null, "oauth/access_token", null);
        j0VarX.G(b2.p0.GET);
        j0VarX.H(bundle);
        return j0VarX;
    }

    public static final String b(String codeVerifier, a codeChallengeMethod) throws NoSuchAlgorithmException {
        kotlin.jvm.internal.m.g(codeVerifier, "codeVerifier");
        kotlin.jvm.internal.m.g(codeChallengeMethod, "codeChallengeMethod");
        if (!d(codeVerifier)) {
            throw new b2.s("Invalid Code Verifier.");
        }
        if (codeChallengeMethod == a.PLAIN) {
            return codeVerifier;
        }
        try {
            byte[] bytes = codeVerifier.getBytes(md.d.f17900f);
            kotlin.jvm.internal.m.f(bytes, "(this as java.lang.String).getBytes(charset)");
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.update(bytes, 0, bytes.length);
            String strEncodeToString = Base64.encodeToString(messageDigest.digest(), 11);
            kotlin.jvm.internal.m.f(strEncodeToString, "{\n      // try to generate challenge with S256\n      val bytes: ByteArray = codeVerifier.toByteArray(Charsets.US_ASCII)\n      val messageDigest = MessageDigest.getInstance(\"SHA-256\")\n      messageDigest.update(bytes, 0, bytes.size)\n      val digest = messageDigest.digest()\n\n      Base64.encodeToString(digest, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)\n    }");
            return strEncodeToString;
        } catch (Exception e10) {
            throw new b2.s(e10);
        }
    }

    public static final String c() {
        int iH = jd.i.h(new jd.f(43, 128), hd.c.f13179a);
        List listV = uc.x.V(uc.x.V(uc.x.V(uc.x.V(uc.x.U(uc.x.T(new jd.c('a', 'z'), new jd.c('A', 'Z')), new jd.c('0', '9')), '-'), '.'), '_'), '~');
        ArrayList arrayList = new ArrayList(iH);
        for (int i10 = 0; i10 < iH; i10++) {
            arrayList.add(Character.valueOf(((Character) uc.x.W(listV, hd.c.f13179a)).charValue()));
        }
        return uc.x.O(arrayList, "", null, null, 0, null, null, 62, null);
    }

    public static final boolean d(String str) {
        if ((str == null || str.length() == 0) || str.length() < 43 || str.length() > 128) {
            return false;
        }
        return new md.f("^[-._~A-Za-z0-9]+$").a(str);
    }
}
