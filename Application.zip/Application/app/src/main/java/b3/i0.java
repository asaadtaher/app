package b3;

import java.util.Arrays;

/* loaded from: classes.dex */
public enum i0 {
    FACEBOOK("facebook"),
    INSTAGRAM("instagram");


    /* renamed from: b, reason: collision with root package name */
    public static final a f5688b = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private final String f5692a;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final i0 a(String str) {
            i0[] i0VarArrValuesCustom = i0.valuesCustom();
            int length = i0VarArrValuesCustom.length;
            int i10 = 0;
            while (i10 < length) {
                i0 i0Var = i0VarArrValuesCustom[i10];
                i10++;
                if (kotlin.jvm.internal.m.b(i0Var.toString(), str)) {
                    return i0Var;
                }
            }
            return i0.FACEBOOK;
        }
    }

    i0(String str) {
        this.f5692a = str;
    }

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static i0[] valuesCustom() {
        i0[] i0VarArrValuesCustom = values();
        return (i0[]) Arrays.copyOf(i0VarArrValuesCustom, i0VarArrValuesCustom.length);
    }

    @Override // java.lang.Enum
    public String toString() {
        return this.f5692a;
    }
}
