package b3;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.text.TextUtils;
import android.webkit.CookieSyncManager;
import b3.f0;
import b3.u;

/* loaded from: classes.dex */
public abstract class o0 extends f0 {

    /* renamed from: e, reason: collision with root package name */
    public static final a f5732e = new a(null);

    /* renamed from: d, reason: collision with root package name */
    private String f5733d;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o0(Parcel source) {
        super(source);
        kotlin.jvm.internal.m.g(source, "source");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o0(u loginClient) {
        super(loginClient);
        kotlin.jvm.internal.m.g(loginClient, "loginClient");
    }

    private final String D() {
        Context contextO = j().o();
        if (contextO == null) {
            b2.f0 f0Var = b2.f0.f5388a;
            contextO = b2.f0.l();
        }
        return contextO.getSharedPreferences("com.facebook.login.AuthorizationClient.WebViewAuthHandler.TOKEN_STORE_KEY", 0).getString("TOKEN", "");
    }

    private final void F(String str) {
        Context contextO = j().o();
        if (contextO == null) {
            b2.f0 f0Var = b2.f0.f5388a;
            contextO = b2.f0.l();
        }
        contextO.getSharedPreferences("com.facebook.login.AuthorizationClient.WebViewAuthHandler.TOKEN_STORE_KEY", 0).edit().putString("TOKEN", str).apply();
    }

    protected Bundle A(u.e request) {
        kotlin.jvm.internal.m.g(request, "request");
        Bundle bundle = new Bundle();
        r2.l0 l0Var = r2.l0.f20174a;
        if (!r2.l0.Y(request.x())) {
            String strJoin = TextUtils.join(",", request.x());
            bundle.putString("scope", strJoin);
            b("scope", strJoin);
        }
        e eVarM = request.m();
        if (eVarM == null) {
            eVarM = e.NONE;
        }
        bundle.putString("default_audience", eVarM.b());
        bundle.putString("state", i(request.h()));
        b2.a aVarE = b2.a.f5323l.e();
        String strW = aVarE == null ? null : aVarE.w();
        if (strW == null || !kotlin.jvm.internal.m.b(strW, D())) {
            androidx.fragment.app.s sVarO = j().o();
            if (sVarO != null) {
                r2.l0.i(sVarO);
            }
            b("access_token", "0");
        } else {
            bundle.putString("access_token", strW);
            b("access_token", "1");
        }
        bundle.putString("cbt", String.valueOf(System.currentTimeMillis()));
        b2.f0 f0Var = b2.f0.f5388a;
        bundle.putString("ies", b2.f0.p() ? "1" : "0");
        return bundle;
    }

    protected String B() {
        return null;
    }

    public abstract b2.h C();

    public void E(u.e request, Bundle bundle, b2.s sVar) {
        String strValueOf;
        u.f fVarC;
        kotlin.jvm.internal.m.g(request, "request");
        u uVarJ = j();
        this.f5733d = null;
        if (bundle != null) {
            if (bundle.containsKey("e2e")) {
                this.f5733d = bundle.getString("e2e");
            }
            try {
                f0.a aVar = f0.f5669c;
                b2.a aVarB = aVar.b(request.x(), bundle, C(), request.b());
                fVarC = u.f.f5808i.b(uVarJ.y(), aVarB, aVar.d(bundle, request.w()));
                if (uVarJ.o() != null) {
                    try {
                        CookieSyncManager.createInstance(uVarJ.o()).sync();
                    } catch (Exception unused) {
                    }
                    if (aVarB != null) {
                        F(aVarB.w());
                    }
                }
            } catch (b2.s e10) {
                fVarC = u.f.c.d(u.f.f5808i, uVarJ.y(), null, e10.getMessage(), null, 8, null);
            }
        } else if (sVar instanceof b2.u) {
            fVarC = u.f.f5808i.a(uVarJ.y(), "User canceled log in.");
        } else {
            this.f5733d = null;
            String message = sVar == null ? null : sVar.getMessage();
            if (sVar instanceof b2.h0) {
                b2.v vVarC = ((b2.h0) sVar).c();
                strValueOf = String.valueOf(vVarC.h());
                message = vVarC.toString();
            } else {
                strValueOf = null;
            }
            fVarC = u.f.f5808i.c(uVarJ.y(), null, message, strValueOf);
        }
        r2.l0 l0Var = r2.l0.f20174a;
        if (!r2.l0.X(this.f5733d)) {
            n(this.f5733d);
        }
        uVarJ.m(fVarC);
    }

    protected Bundle z(Bundle parameters, u.e request) {
        String strB;
        String str;
        String str2;
        kotlin.jvm.internal.m.g(parameters, "parameters");
        kotlin.jvm.internal.m.g(request, "request");
        parameters.putString("redirect_uri", m());
        if (request.B()) {
            strB = request.b();
            str = "app_id";
        } else {
            strB = request.b();
            str = "client_id";
        }
        parameters.putString(str, strB);
        parameters.putString("e2e", u.f5776r.a());
        if (request.B()) {
            str2 = "token,signed_request,graph_domain,granted_scopes";
        } else {
            if (request.x().contains("openid")) {
                parameters.putString("nonce", request.w());
            }
            str2 = "id_token,token,signed_request,graph_domain";
        }
        parameters.putString("response_type", str2);
        parameters.putString("code_challenge", request.j());
        b3.a aVarK = request.k();
        parameters.putString("code_challenge_method", aVarK == null ? null : aVarK.name());
        parameters.putString("return_scopes", "true");
        parameters.putString("auth_type", request.i());
        parameters.putString("login_behavior", request.q().name());
        b2.f0 f0Var = b2.f0.f5388a;
        parameters.putString("sdk", kotlin.jvm.internal.m.n("android-", b2.f0.B()));
        if (B() != null) {
            parameters.putString("sso", B());
        }
        parameters.putString("cct_prefetching", b2.f0.f5404q ? "1" : "0");
        if (request.A()) {
            parameters.putString("fx_app", request.s().toString());
        }
        if (request.J()) {
            parameters.putString("skip_dedupe", "true");
        }
        if (request.v() != null) {
            parameters.putString("messenger_page_id", request.v());
            parameters.putString("reset_messenger_state", request.y() ? "1" : "0");
        }
        return parameters;
    }
}
