package b3;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import android.util.Log;
import b3.u;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class f0 implements Parcelable {

    /* renamed from: c, reason: collision with root package name */
    public static final a f5669c = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private Map<String, String> f5670a;

    /* renamed from: b, reason: collision with root package name */
    public u f5671b;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final b2.a a(Bundle bundle, b2.h hVar, String applicationId) throws NumberFormatException {
            String string;
            kotlin.jvm.internal.m.g(bundle, "bundle");
            kotlin.jvm.internal.m.g(applicationId, "applicationId");
            r2.l0 l0Var = r2.l0.f20174a;
            Date dateW = r2.l0.w(bundle, "com.facebook.platform.extra.EXPIRES_SECONDS_SINCE_EPOCH", new Date(0L));
            ArrayList<String> stringArrayList = bundle.getStringArrayList("com.facebook.platform.extra.PERMISSIONS");
            String string2 = bundle.getString("com.facebook.platform.extra.ACCESS_TOKEN");
            Date dateW2 = r2.l0.w(bundle, "com.facebook.platform.extra.EXTRA_DATA_ACCESS_EXPIRATION_TIME", new Date(0L));
            if (string2 != null) {
                if (!(string2.length() == 0) && (string = bundle.getString("com.facebook.platform.extra.USER_ID")) != null) {
                    if (!(string.length() == 0)) {
                        return new b2.a(string2, applicationId, string, stringArrayList, null, null, hVar, dateW, new Date(), dateW2, bundle.getString("graph_domain"));
                    }
                }
            }
            return null;
        }

        /* JADX WARN: Removed duplicated region for block: B:13:0x006f  */
        /* JADX WARN: Removed duplicated region for block: B:22:0x00a8  */
        /* JADX WARN: Removed duplicated region for block: B:31:0x00e0  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final b2.a b(java.util.Collection<java.lang.String> r20, android.os.Bundle r21, b2.h r22, java.lang.String r23) throws java.lang.NumberFormatException {
            /*
                Method dump skipped, instructions count: 270
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: b3.f0.a.b(java.util.Collection, android.os.Bundle, b2.h, java.lang.String):b2.a");
        }

        public final b2.i c(Bundle bundle, String str) {
            kotlin.jvm.internal.m.g(bundle, "bundle");
            String string = bundle.getString("com.facebook.platform.extra.ID_TOKEN");
            if (string != null) {
                if (!(string.length() == 0) && str != null) {
                    if (!(str.length() == 0)) {
                        try {
                            return new b2.i(string, str);
                        } catch (Exception e10) {
                            throw new b2.s(e10.getMessage());
                        }
                    }
                }
            }
            return null;
        }

        public final b2.i d(Bundle bundle, String str) {
            kotlin.jvm.internal.m.g(bundle, "bundle");
            String string = bundle.getString("id_token");
            if (string != null) {
                if (!(string.length() == 0) && str != null) {
                    if (!(str.length() == 0)) {
                        try {
                            return new b2.i(string, str);
                        } catch (Exception e10) {
                            throw new b2.s(e10.getMessage(), e10);
                        }
                    }
                }
            }
            return null;
        }

        public final String e(String str) throws JSONException {
            Object[] array;
            if (str != null) {
                if (!(str.length() == 0)) {
                    try {
                        array = md.q.r0(str, new String[]{"."}, false, 0, 6, null).toArray(new String[0]);
                    } catch (UnsupportedEncodingException | JSONException unused) {
                    }
                    if (array == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
                    }
                    String[] strArr = (String[]) array;
                    if (strArr.length == 2) {
                        byte[] data = Base64.decode(strArr[1], 0);
                        kotlin.jvm.internal.m.f(data, "data");
                        String string = new JSONObject(new String(data, md.d.f17896b)).getString("user_id");
                        kotlin.jvm.internal.m.f(string, "jsonObject.getString(\"user_id\")");
                        return string;
                    }
                    throw new b2.s("Failed to retrieve user_id from signed_request");
                }
            }
            throw new b2.s("Authorization response does not contain the signed_request");
        }
    }

    protected f0(Parcel source) {
        kotlin.jvm.internal.m.g(source, "source");
        r2.l0 l0Var = r2.l0.f20174a;
        Map<String, String> mapO0 = r2.l0.o0(source);
        this.f5670a = mapO0 == null ? null : uc.g0.n(mapO0);
    }

    public f0(u loginClient) {
        kotlin.jvm.internal.m.g(loginClient, "loginClient");
        w(loginClient);
    }

    protected void b(String str, Object obj) {
        if (this.f5670a == null) {
            this.f5670a = new HashMap();
        }
        Map<String, String> map = this.f5670a;
        if (map == null) {
            return;
        }
        map.put(str, obj == null ? null : obj.toString());
    }

    public void h() {
    }

    protected String i(String authId) throws JSONException {
        kotlin.jvm.internal.m.g(authId, "authId");
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("0_auth_logger_id", authId);
            jSONObject.put("3_method", l());
            v(jSONObject);
        } catch (JSONException e10) {
            Log.w("LoginMethodHandler", kotlin.jvm.internal.m.n("Error creating client state json: ", e10.getMessage()));
        }
        String string = jSONObject.toString();
        kotlin.jvm.internal.m.f(string, "param.toString()");
        return string;
    }

    public final u j() {
        u uVar = this.f5671b;
        if (uVar != null) {
            return uVar;
        }
        kotlin.jvm.internal.m.u("loginClient");
        throw null;
    }

    public final Map<String, String> k() {
        return this.f5670a;
    }

    public abstract String l();

    protected String m() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append("fb");
        b2.f0 f0Var = b2.f0.f5388a;
        sb2.append(b2.f0.m());
        sb2.append("://authorize/");
        return sb2.toString();
    }

    protected void n(String str) {
        u.e eVarY = j().y();
        String strB = eVarY == null ? null : eVarY.b();
        if (strB == null) {
            b2.f0 f0Var = b2.f0.f5388a;
            strB = b2.f0.m();
        }
        c2.c0 c0Var = new c2.c0(j().o(), strB);
        Bundle bundle = new Bundle();
        bundle.putString("fb_web_login_e2e", str);
        bundle.putLong("fb_web_login_switchback_time", System.currentTimeMillis());
        bundle.putString("app_id", strB);
        c0Var.h("fb_dialogs_web_login_dialog_complete", null, bundle);
    }

    public boolean o() {
        return false;
    }

    public boolean q(int i10, int i11, Intent intent) {
        return false;
    }

    protected Bundle s(u.e request, Bundle values) {
        b2.j0 j0VarA;
        kotlin.jvm.internal.m.g(request, "request");
        kotlin.jvm.internal.m.g(values, "values");
        String string = values.getString("code");
        r2.l0 l0Var = r2.l0.f20174a;
        if (r2.l0.X(string)) {
            throw new b2.s("No code param found from the request");
        }
        if (string == null) {
            j0VarA = null;
        } else {
            m0 m0Var = m0.f5728a;
            String strM = m();
            String strL = request.l();
            if (strL == null) {
                strL = "";
            }
            j0VarA = m0.a(string, strM, strL);
        }
        if (j0VarA == null) {
            throw new b2.s("Failed to create code exchange request");
        }
        b2.o0 o0VarK = j0VarA.k();
        b2.v vVarB = o0VarK.b();
        if (vVarB != null) {
            throw new b2.h0(vVarB, vVarB.i());
        }
        try {
            JSONObject jSONObjectC = o0VarK.c();
            String string2 = jSONObjectC != null ? jSONObjectC.getString("access_token") : null;
            if (jSONObjectC == null || r2.l0.X(string2)) {
                throw new b2.s("No access token found from result");
            }
            values.putString("access_token", string2);
            if (jSONObjectC.has("id_token")) {
                values.putString("id_token", jSONObjectC.getString("id_token"));
            }
            return values;
        } catch (JSONException e10) {
            throw new b2.s(kotlin.jvm.internal.m.n("Fail to process code exchange response: ", e10.getMessage()));
        }
    }

    public void v(JSONObject param) {
        kotlin.jvm.internal.m.g(param, "param");
    }

    public final void w(u uVar) {
        kotlin.jvm.internal.m.g(uVar, "<set-?>");
        this.f5671b = uVar;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int i10) {
        kotlin.jvm.internal.m.g(dest, "dest");
        r2.l0 l0Var = r2.l0.f20174a;
        r2.l0.C0(dest, this.f5670a);
    }

    public boolean x() {
        return false;
    }

    public abstract int y(u.e eVar);
}
