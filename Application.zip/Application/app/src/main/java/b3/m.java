package b3;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import b2.j0;
import b3.u;
import com.facebook.FacebookActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class m extends androidx.fragment.app.m {

    /* renamed from: m0, reason: collision with root package name */
    private View f5707m0;

    /* renamed from: n0, reason: collision with root package name */
    private TextView f5708n0;

    /* renamed from: o0, reason: collision with root package name */
    private TextView f5709o0;

    /* renamed from: p0, reason: collision with root package name */
    private n f5710p0;

    /* renamed from: q0, reason: collision with root package name */
    private final AtomicBoolean f5711q0 = new AtomicBoolean();

    /* renamed from: r0, reason: collision with root package name */
    private volatile b2.m0 f5712r0;

    /* renamed from: s0, reason: collision with root package name */
    private volatile ScheduledFuture<?> f5713s0;

    /* renamed from: t0, reason: collision with root package name */
    private volatile c f5714t0;

    /* renamed from: u0, reason: collision with root package name */
    private boolean f5715u0;

    /* renamed from: v0, reason: collision with root package name */
    private boolean f5716v0;

    /* renamed from: w0, reason: collision with root package name */
    private u.e f5717w0;

    /* renamed from: x0, reason: collision with root package name */
    public static final a f5704x0 = new a(null);

    /* renamed from: y0, reason: collision with root package name */
    private static final String f5705y0 = "device/login";

    /* renamed from: z0, reason: collision with root package name */
    private static final String f5706z0 = "device/login_status";
    private static final int A0 = 1349174;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final b b(JSONObject jSONObject) throws JSONException {
            String strOptString;
            JSONArray jSONArray = jSONObject.getJSONObject("permissions").getJSONArray("data");
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            ArrayList arrayList3 = new ArrayList();
            int length = jSONArray.length();
            if (length > 0) {
                int i10 = 0;
                while (true) {
                    int i11 = i10 + 1;
                    JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i10);
                    String permission = jSONObjectOptJSONObject.optString("permission");
                    kotlin.jvm.internal.m.f(permission, "permission");
                    if (!(permission.length() == 0) && !kotlin.jvm.internal.m.b(permission, "installed") && (strOptString = jSONObjectOptJSONObject.optString("status")) != null) {
                        int iHashCode = strOptString.hashCode();
                        if (iHashCode != -1309235419) {
                            if (iHashCode != 280295099) {
                                if (iHashCode == 568196142 && strOptString.equals("declined")) {
                                    arrayList2.add(permission);
                                }
                            } else if (strOptString.equals("granted")) {
                                arrayList.add(permission);
                            }
                        } else if (strOptString.equals("expired")) {
                            arrayList3.add(permission);
                        }
                    }
                    if (i11 >= length) {
                        break;
                    }
                    i10 = i11;
                }
            }
            return new b(arrayList, arrayList2, arrayList3);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    static final class b {

        /* renamed from: a, reason: collision with root package name */
        private List<String> f5718a;

        /* renamed from: b, reason: collision with root package name */
        private List<String> f5719b;

        /* renamed from: c, reason: collision with root package name */
        private List<String> f5720c;

        public b(List<String> grantedPermissions, List<String> declinedPermissions, List<String> expiredPermissions) {
            kotlin.jvm.internal.m.g(grantedPermissions, "grantedPermissions");
            kotlin.jvm.internal.m.g(declinedPermissions, "declinedPermissions");
            kotlin.jvm.internal.m.g(expiredPermissions, "expiredPermissions");
            this.f5718a = grantedPermissions;
            this.f5719b = declinedPermissions;
            this.f5720c = expiredPermissions;
        }

        public final List<String> a() {
            return this.f5719b;
        }

        public final List<String> b() {
            return this.f5720c;
        }

        public final List<String> c() {
            return this.f5718a;
        }
    }

    private static final class c implements Parcelable {

        /* renamed from: a, reason: collision with root package name */
        private String f5722a;

        /* renamed from: b, reason: collision with root package name */
        private String f5723b;

        /* renamed from: c, reason: collision with root package name */
        private String f5724c;

        /* renamed from: d, reason: collision with root package name */
        private long f5725d;

        /* renamed from: e, reason: collision with root package name */
        private long f5726e;

        /* renamed from: f, reason: collision with root package name */
        public static final b f5721f = new b(null);
        public static final Parcelable.Creator<c> CREATOR = new a();

        public static final class a implements Parcelable.Creator<c> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public c createFromParcel(Parcel parcel) {
                kotlin.jvm.internal.m.g(parcel, "parcel");
                return new c(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public c[] newArray(int i10) {
                return new c[i10];
            }
        }

        public static final class b {
            private b() {
            }

            public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
                this();
            }
        }

        public c() {
        }

        protected c(Parcel parcel) {
            kotlin.jvm.internal.m.g(parcel, "parcel");
            this.f5722a = parcel.readString();
            this.f5723b = parcel.readString();
            this.f5724c = parcel.readString();
            this.f5725d = parcel.readLong();
            this.f5726e = parcel.readLong();
        }

        public final String b() {
            return this.f5722a;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public final long h() {
            return this.f5725d;
        }

        public final String i() {
            return this.f5724c;
        }

        public final String j() {
            return this.f5723b;
        }

        public final void k(long j10) {
            this.f5725d = j10;
        }

        public final void l(long j10) {
            this.f5726e = j10;
        }

        public final void m(String str) {
            this.f5724c = str;
        }

        public final void n(String str) {
            this.f5723b = str;
            kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
            String str2 = String.format(Locale.ENGLISH, "https://facebook.com/device?user_code=%1$s&qr=1", Arrays.copyOf(new Object[]{str}, 1));
            kotlin.jvm.internal.m.f(str2, "java.lang.String.format(locale, format, *args)");
            this.f5722a = str2;
        }

        public final boolean o() {
            return this.f5726e != 0 && (new Date().getTime() - this.f5726e) - (this.f5725d * 1000) < 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel dest, int i10) {
            kotlin.jvm.internal.m.g(dest, "dest");
            dest.writeString(this.f5722a);
            dest.writeString(this.f5723b);
            dest.writeString(this.f5724c);
            dest.writeLong(this.f5725d);
            dest.writeLong(this.f5726e);
        }
    }

    public static final class d extends Dialog {
        d(androidx.fragment.app.s sVar, int i10) {
            super(sVar, i10);
        }

        @Override // android.app.Dialog
        public void onBackPressed() {
            if (m.this.Q0()) {
                super.onBackPressed();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void I0(m this$0, b2.o0 response) throws JSONException {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        kotlin.jvm.internal.m.g(response, "response");
        if (this$0.f5711q0.get()) {
            return;
        }
        b2.v vVarB = response.b();
        if (vVarB == null) {
            try {
                JSONObject jSONObjectC = response.c();
                if (jSONObjectC == null) {
                    jSONObjectC = new JSONObject();
                }
                String string = jSONObjectC.getString("access_token");
                kotlin.jvm.internal.m.f(string, "resultObject.getString(\"access_token\")");
                this$0.S0(string, jSONObjectC.getLong("expires_in"), Long.valueOf(jSONObjectC.optLong("data_access_expiration_time")));
                return;
            } catch (JSONException e10) {
                this$0.R0(new b2.s(e10));
                return;
            }
        }
        int iM = vVarB.m();
        boolean z10 = true;
        if (iM != A0 && iM != 1349172) {
            z10 = false;
        }
        if (z10) {
            this$0.Y0();
            return;
        }
        if (iM == 1349152) {
            c cVar = this$0.f5714t0;
            if (cVar != null) {
                q2.a aVar = q2.a.f19577a;
                q2.a.a(cVar.j());
            }
            u.e eVar = this$0.f5717w0;
            if (eVar != null) {
                this$0.b1(eVar);
                return;
            }
        } else if (iM != 1349173) {
            b2.v vVarB2 = response.b();
            b2.s sVarK = vVarB2 == null ? null : vVarB2.k();
            if (sVarK == null) {
                sVarK = new b2.s();
            }
            this$0.R0(sVarK);
            return;
        }
        this$0.onCancel();
    }

    private final void K0(String str, b bVar, String str2, Date date, Date date2) {
        n nVar = this.f5710p0;
        if (nVar != null) {
            b2.f0 f0Var = b2.f0.f5388a;
            nVar.E(str2, b2.f0.m(), str, bVar.c(), bVar.a(), bVar.b(), b2.h.DEVICE_AUTH, date, null, date2);
        }
        Dialog dialog = getDialog();
        if (dialog == null) {
            return;
        }
        dialog.dismiss();
    }

    private final b2.j0 N0() {
        Bundle bundle = new Bundle();
        c cVar = this.f5714t0;
        bundle.putString("code", cVar == null ? null : cVar.i());
        bundle.putString("access_token", L0());
        return b2.j0.f5454n.B(null, f5706z0, bundle, new j0.b() { // from class: b3.j
            @Override // b2.j0.b
            public final void b(b2.o0 o0Var) throws JSONException {
                m.I0(this.f5693a, o0Var);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void P0(m this$0, View view) {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        this$0.onCancel();
    }

    private final void S0(final String str, long j10, Long l10) {
        Bundle bundle = new Bundle();
        bundle.putString("fields", "id,permissions,name");
        final Date date = null;
        final Date date2 = j10 != 0 ? new Date(new Date().getTime() + (j10 * 1000)) : null;
        if ((l10 == null || l10.longValue() != 0) && l10 != null) {
            date = new Date(l10.longValue() * 1000);
        }
        b2.f0 f0Var = b2.f0.f5388a;
        b2.j0 j0VarX = b2.j0.f5454n.x(new b2.a(str, b2.f0.m(), "0", null, null, null, null, date2, null, date, null, 1024, null), "me", new j0.b() { // from class: b3.k
            @Override // b2.j0.b
            public final void b(b2.o0 o0Var) throws JSONException, Resources.NotFoundException {
                m.T0(this.f5697a, str, date2, date, o0Var);
            }
        });
        j0VarX.G(b2.p0.GET);
        j0VarX.H(bundle);
        j0VarX.l();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void T0(m this$0, String accessToken, Date date, Date date2, b2.o0 response) throws JSONException, Resources.NotFoundException {
        EnumSet<r2.i0> enumSetJ;
        kotlin.jvm.internal.m.g(this$0, "this$0");
        kotlin.jvm.internal.m.g(accessToken, "$accessToken");
        kotlin.jvm.internal.m.g(response, "response");
        if (this$0.f5711q0.get()) {
            return;
        }
        b2.v vVarB = response.b();
        if (vVarB != null) {
            b2.s sVarK = vVarB.k();
            if (sVarK == null) {
                sVarK = new b2.s();
            }
            this$0.R0(sVarK);
            return;
        }
        try {
            JSONObject jSONObjectC = response.c();
            if (jSONObjectC == null) {
                jSONObjectC = new JSONObject();
            }
            String string = jSONObjectC.getString("id");
            kotlin.jvm.internal.m.f(string, "jsonObject.getString(\"id\")");
            b bVarB = f5704x0.b(jSONObjectC);
            String string2 = jSONObjectC.getString("name");
            kotlin.jvm.internal.m.f(string2, "jsonObject.getString(\"name\")");
            c cVar = this$0.f5714t0;
            if (cVar != null) {
                q2.a aVar = q2.a.f19577a;
                q2.a.a(cVar.j());
            }
            r2.v vVar = r2.v.f20292a;
            b2.f0 f0Var = b2.f0.f5388a;
            r2.r rVarF = r2.v.f(b2.f0.m());
            Boolean boolValueOf = null;
            if (rVarF != null && (enumSetJ = rVarF.j()) != null) {
                boolValueOf = Boolean.valueOf(enumSetJ.contains(r2.i0.RequireConfirm));
            }
            if (!kotlin.jvm.internal.m.b(boolValueOf, Boolean.TRUE) || this$0.f5716v0) {
                this$0.K0(string, bVarB, accessToken, date, date2);
            } else {
                this$0.f5716v0 = true;
                this$0.V0(string, bVarB, accessToken, string2, date, date2);
            }
        } catch (JSONException e10) {
            this$0.R0(new b2.s(e10));
        }
    }

    private final void U0() {
        c cVar = this.f5714t0;
        if (cVar != null) {
            cVar.l(new Date().getTime());
        }
        this.f5712r0 = N0().l();
    }

    private final void V0(final String str, final b bVar, final String str2, String str3, final Date date, final Date date2) throws Resources.NotFoundException {
        String string = getResources().getString(p2.d.f18842g);
        kotlin.jvm.internal.m.f(string, "resources.getString(R.string.com_facebook_smart_login_confirmation_title)");
        String string2 = getResources().getString(p2.d.f18841f);
        kotlin.jvm.internal.m.f(string2, "resources.getString(R.string.com_facebook_smart_login_confirmation_continue_as)");
        String string3 = getResources().getString(p2.d.f18840e);
        kotlin.jvm.internal.m.f(string3, "resources.getString(R.string.com_facebook_smart_login_confirmation_cancel)");
        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
        String str4 = String.format(string2, Arrays.copyOf(new Object[]{str3}, 1));
        kotlin.jvm.internal.m.f(str4, "java.lang.String.format(format, *args)");
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setMessage(string).setCancelable(true).setNegativeButton(str4, new DialogInterface.OnClickListener() { // from class: b3.g
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i10) {
                m.W0(this.f5672a, str, bVar, str2, date, date2, dialogInterface, i10);
            }
        }).setPositiveButton(string3, new DialogInterface.OnClickListener() { // from class: b3.f
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i10) {
                m.X0(this.f5668a, dialogInterface, i10);
            }
        });
        builder.create().show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void W0(m this$0, String userId, b permissions, String accessToken, Date date, Date date2, DialogInterface dialogInterface, int i10) {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        kotlin.jvm.internal.m.g(userId, "$userId");
        kotlin.jvm.internal.m.g(permissions, "$permissions");
        kotlin.jvm.internal.m.g(accessToken, "$accessToken");
        this$0.K0(userId, permissions, accessToken, date, date2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void X0(m this$0, DialogInterface dialogInterface, int i10) {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        View viewO0 = this$0.O0(false);
        Dialog dialog = this$0.getDialog();
        if (dialog != null) {
            dialog.setContentView(viewO0);
        }
        u.e eVar = this$0.f5717w0;
        if (eVar == null) {
            return;
        }
        this$0.b1(eVar);
    }

    private final void Y0() {
        c cVar = this.f5714t0;
        Long lValueOf = cVar == null ? null : Long.valueOf(cVar.h());
        if (lValueOf != null) {
            this.f5713s0 = n.f5729e.a().schedule(new Runnable() { // from class: b3.l
                @Override // java.lang.Runnable
                public final void run() {
                    m.Z0(this.f5702a);
                }
            }, lValueOf.longValue(), TimeUnit.SECONDS);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void Z0(m this$0) {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        this$0.U0();
    }

    private final void a1(c cVar) {
        this.f5714t0 = cVar;
        TextView textView = this.f5708n0;
        if (textView == null) {
            kotlin.jvm.internal.m.u("confirmationCode");
            throw null;
        }
        textView.setText(cVar.j());
        q2.a aVar = q2.a.f19577a;
        BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), q2.a.c(cVar.b()));
        TextView textView2 = this.f5709o0;
        if (textView2 == null) {
            kotlin.jvm.internal.m.u("instructions");
            throw null;
        }
        textView2.setCompoundDrawablesWithIntrinsicBounds((Drawable) null, bitmapDrawable, (Drawable) null, (Drawable) null);
        TextView textView3 = this.f5708n0;
        if (textView3 == null) {
            kotlin.jvm.internal.m.u("confirmationCode");
            throw null;
        }
        textView3.setVisibility(0);
        View view = this.f5707m0;
        if (view == null) {
            kotlin.jvm.internal.m.u("progressBar");
            throw null;
        }
        view.setVisibility(8);
        if (!this.f5716v0 && q2.a.f(cVar.j())) {
            new c2.c0(getContext()).f("fb_smart_login_service");
        }
        if (cVar.o()) {
            Y0();
        } else {
            U0();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void c1(m this$0, b2.o0 response) {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        kotlin.jvm.internal.m.g(response, "response");
        if (this$0.f5715u0) {
            return;
        }
        if (response.b() != null) {
            b2.v vVarB = response.b();
            b2.s sVarK = vVarB == null ? null : vVarB.k();
            if (sVarK == null) {
                sVarK = new b2.s();
            }
            this$0.R0(sVarK);
            return;
        }
        JSONObject jSONObjectC = response.c();
        if (jSONObjectC == null) {
            jSONObjectC = new JSONObject();
        }
        c cVar = new c();
        try {
            cVar.n(jSONObjectC.getString("user_code"));
            cVar.m(jSONObjectC.getString("code"));
            cVar.k(jSONObjectC.getLong("interval"));
            this$0.a1(cVar);
        } catch (JSONException e10) {
            this$0.R0(new b2.s(e10));
        }
    }

    public Map<String, String> J0() {
        return null;
    }

    public String L0() {
        StringBuilder sb2 = new StringBuilder();
        r2.m0 m0Var = r2.m0.f20185a;
        sb2.append(r2.m0.b());
        sb2.append('|');
        sb2.append(r2.m0.c());
        return sb2.toString();
    }

    protected int M0(boolean z10) {
        return z10 ? p2.c.f18835d : p2.c.f18833b;
    }

    protected View O0(boolean z10) {
        LayoutInflater layoutInflater = requireActivity().getLayoutInflater();
        kotlin.jvm.internal.m.f(layoutInflater, "requireActivity().layoutInflater");
        View viewInflate = layoutInflater.inflate(M0(z10), (ViewGroup) null);
        kotlin.jvm.internal.m.f(viewInflate, "inflater.inflate(getLayoutResId(isSmartLogin), null)");
        View viewFindViewById = viewInflate.findViewById(p2.b.f18831f);
        kotlin.jvm.internal.m.f(viewFindViewById, "view.findViewById(R.id.progress_bar)");
        this.f5707m0 = viewFindViewById;
        View viewFindViewById2 = viewInflate.findViewById(p2.b.f18830e);
        Objects.requireNonNull(viewFindViewById2, "null cannot be cast to non-null type android.widget.TextView");
        this.f5708n0 = (TextView) viewFindViewById2;
        View viewFindViewById3 = viewInflate.findViewById(p2.b.f18826a);
        Objects.requireNonNull(viewFindViewById3, "null cannot be cast to non-null type android.widget.Button");
        ((Button) viewFindViewById3).setOnClickListener(new View.OnClickListener() { // from class: b3.h
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                m.P0(this.f5682a, view);
            }
        });
        View viewFindViewById4 = viewInflate.findViewById(p2.b.f18827b);
        Objects.requireNonNull(viewFindViewById4, "null cannot be cast to non-null type android.widget.TextView");
        TextView textView = (TextView) viewFindViewById4;
        this.f5709o0 = textView;
        textView.setText(Html.fromHtml(getString(p2.d.f18836a)));
        return viewInflate;
    }

    protected boolean Q0() {
        return true;
    }

    protected void R0(b2.s ex) {
        kotlin.jvm.internal.m.g(ex, "ex");
        if (this.f5711q0.compareAndSet(false, true)) {
            c cVar = this.f5714t0;
            if (cVar != null) {
                q2.a aVar = q2.a.f19577a;
                q2.a.a(cVar.j());
            }
            n nVar = this.f5710p0;
            if (nVar != null) {
                nVar.D(ex);
            }
            Dialog dialog = getDialog();
            if (dialog == null) {
                return;
            }
            dialog.dismiss();
        }
    }

    public void b1(u.e request) {
        kotlin.jvm.internal.m.g(request, "request");
        this.f5717w0 = request;
        Bundle bundle = new Bundle();
        bundle.putString("scope", TextUtils.join(",", request.x()));
        r2.l0 l0Var = r2.l0.f20174a;
        r2.l0.l0(bundle, "redirect_uri", request.o());
        r2.l0.l0(bundle, "target_user_id", request.n());
        bundle.putString("access_token", L0());
        q2.a aVar = q2.a.f19577a;
        Map<String, String> mapJ0 = J0();
        bundle.putString("device_info", q2.a.d(mapJ0 == null ? null : uc.g0.n(mapJ0)));
        b2.j0.f5454n.B(null, f5705y0, bundle, new j0.b() { // from class: b3.i
            @Override // b2.j0.b
            public final void b(b2.o0 o0Var) {
                m.c1(this.f5687a, o0Var);
            }
        }).l();
    }

    protected void onCancel() {
        if (this.f5711q0.compareAndSet(false, true)) {
            c cVar = this.f5714t0;
            if (cVar != null) {
                q2.a aVar = q2.a.f19577a;
                q2.a.a(cVar.j());
            }
            n nVar = this.f5710p0;
            if (nVar != null) {
                nVar.C();
            }
            Dialog dialog = getDialog();
            if (dialog == null) {
                return;
            }
            dialog.dismiss();
        }
    }

    @Override // androidx.fragment.app.m
    public Dialog onCreateDialog(Bundle bundle) {
        d dVar = new d(requireActivity(), p2.e.f18844b);
        q2.a aVar = q2.a.f19577a;
        dVar.setContentView(O0(q2.a.e() && !this.f5716v0));
        return dVar;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup viewGroup, Bundle bundle) {
        c cVar;
        u uVarD0;
        kotlin.jvm.internal.m.g(inflater, "inflater");
        View viewOnCreateView = super.onCreateView(inflater, viewGroup, bundle);
        y yVar = (y) ((FacebookActivity) requireActivity()).u();
        f0 f0VarQ = null;
        if (yVar != null && (uVarD0 = yVar.D0()) != null) {
            f0VarQ = uVarD0.q();
        }
        this.f5710p0 = (n) f0VarQ;
        if (bundle != null && (cVar = (c) bundle.getParcelable("request_state")) != null) {
            a1(cVar);
        }
        return viewOnCreateView;
    }

    @Override // androidx.fragment.app.m, androidx.fragment.app.Fragment
    public void onDestroyView() {
        this.f5715u0 = true;
        this.f5711q0.set(true);
        super.onDestroyView();
        b2.m0 m0Var = this.f5712r0;
        if (m0Var != null) {
            m0Var.cancel(true);
        }
        ScheduledFuture<?> scheduledFuture = this.f5713s0;
        if (scheduledFuture == null) {
            return;
        }
        scheduledFuture.cancel(true);
    }

    @Override // androidx.fragment.app.m, android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialog) {
        kotlin.jvm.internal.m.g(dialog, "dialog");
        super.onDismiss(dialog);
        if (this.f5715u0) {
            return;
        }
        onCancel();
    }

    @Override // androidx.fragment.app.m, androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle outState) {
        kotlin.jvm.internal.m.g(outState, "outState");
        super.onSaveInstanceState(outState);
        if (this.f5714t0 != null) {
            outState.putParcelable("request_state", this.f5714t0);
        }
    }
}
