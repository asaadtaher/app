package b3;

/* loaded from: classes.dex */
public final class l0 {

    /* renamed from: a, reason: collision with root package name */
    public static final l0 f5703a = new l0();

    private l0() {
    }

    public static final boolean a(String str) {
        if (str == null || str.length() == 0) {
            return false;
        }
        return !(md.q.R(str, ' ', 0, false, 6, null) >= 0);
    }
}
