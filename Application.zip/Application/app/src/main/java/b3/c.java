package b3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.fragment.app.Fragment;
import b3.d;
import b3.u;
import com.facebook.CustomTabMainActivity;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class c extends o0 {

    /* renamed from: l, reason: collision with root package name */
    public static boolean f5630l;

    /* renamed from: f, reason: collision with root package name */
    private String f5631f;

    /* renamed from: g, reason: collision with root package name */
    private String f5632g;

    /* renamed from: h, reason: collision with root package name */
    private String f5633h;

    /* renamed from: i, reason: collision with root package name */
    private final String f5634i;

    /* renamed from: j, reason: collision with root package name */
    private final b2.h f5635j;

    /* renamed from: k, reason: collision with root package name */
    public static final b f5629k = new b(null);
    public static final Parcelable.Creator<c> CREATOR = new a();

    public static final class a implements Parcelable.Creator<c> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public c createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new c(source);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public c[] newArray(int i10) {
            return new c[i10];
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(Parcel source) {
        super(source);
        kotlin.jvm.internal.m.g(source, "source");
        this.f5634i = "custom_tab";
        this.f5635j = b2.h.CHROME_CUSTOM_TAB;
        this.f5632g = source.readString();
        r2.f fVar = r2.f.f20131a;
        this.f5633h = r2.f.c(I());
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(u loginClient) {
        super(loginClient);
        kotlin.jvm.internal.m.g(loginClient, "loginClient");
        this.f5634i = "custom_tab";
        this.f5635j = b2.h.CHROME_CUSTOM_TAB;
        r2.l0 l0Var = r2.l0.f20174a;
        this.f5632g = r2.l0.s(20);
        f5630l = false;
        r2.f fVar = r2.f.f20131a;
        this.f5633h = r2.f.c(I());
    }

    private final String H() {
        String str = this.f5631f;
        if (str != null) {
            return str;
        }
        r2.f fVar = r2.f.f20131a;
        String strA = r2.f.a();
        this.f5631f = strA;
        return strA;
    }

    private final String I() {
        return super.m();
    }

    private final void J(String str, final u.e eVar) throws NumberFormatException {
        int i10;
        if (str != null) {
            if (md.p.C(str, "fbconnect://cct.", false, 2, null) || md.p.C(str, super.m(), false, 2, null)) {
                Uri uri = Uri.parse(str);
                r2.l0 l0Var = r2.l0.f20174a;
                final Bundle bundleJ0 = r2.l0.j0(uri.getQuery());
                bundleJ0.putAll(r2.l0.j0(uri.getFragment()));
                if (!L(bundleJ0)) {
                    super.E(eVar, null, new b2.s("Invalid state parameter"));
                    return;
                }
                String string = bundleJ0.getString("error");
                if (string == null) {
                    string = bundleJ0.getString("error_type");
                }
                String string2 = bundleJ0.getString("error_msg");
                if (string2 == null) {
                    string2 = bundleJ0.getString("error_message");
                }
                if (string2 == null) {
                    string2 = bundleJ0.getString("error_description");
                }
                String string3 = bundleJ0.getString("error_code");
                if (string3 == null) {
                    i10 = -1;
                } else {
                    try {
                        i10 = Integer.parseInt(string3);
                    } catch (NumberFormatException unused) {
                    }
                }
                r2.l0 l0Var2 = r2.l0.f20174a;
                if (!r2.l0.X(string) || !r2.l0.X(string2) || i10 != -1) {
                    b2.s h0Var = ((string == null || !(kotlin.jvm.internal.m.b(string, "access_denied") || kotlin.jvm.internal.m.b(string, "OAuthAccessDeniedException"))) && i10 != 4201) ? new b2.h0(new b2.v(i10, string, string2), string2) : new b2.u();
                    super.E(eVar, null, h0Var);
                } else if (bundleJ0.containsKey("access_token")) {
                    super.E(eVar, bundleJ0, null);
                } else {
                    b2.f0 f0Var = b2.f0.f5388a;
                    b2.f0.t().execute(new Runnable() { // from class: b3.b
                        @Override // java.lang.Runnable
                        public final void run() {
                            c.K(this.f5625a, eVar, bundleJ0);
                        }
                    });
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void K(c this$0, u.e request, Bundle values) {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        kotlin.jvm.internal.m.g(request, "$request");
        kotlin.jvm.internal.m.g(values, "$values");
        try {
            this$0.E(request, this$0.s(request, values), null);
        } catch (b2.s e10) {
            this$0.E(request, null, e10);
        }
    }

    private final boolean L(Bundle bundle) {
        try {
            String string = bundle.getString("state");
            if (string == null) {
                return false;
            }
            return kotlin.jvm.internal.m.b(new JSONObject(string).getString("7_challenge"), this.f5632g);
        } catch (JSONException unused) {
            return false;
        }
    }

    @Override // b3.o0
    protected String B() {
        return "chrome_custom_tab";
    }

    @Override // b3.o0
    public b2.h C() {
        return this.f5635j;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // b3.f0
    public String l() {
        return this.f5634i;
    }

    @Override // b3.f0
    protected String m() {
        return this.f5633h;
    }

    @Override // b3.f0
    public boolean q(int i10, int i11, Intent intent) throws NumberFormatException {
        if ((intent == null || !intent.getBooleanExtra(CustomTabMainActivity.f6913j, false)) && i10 == 1) {
            u.e eVarY = j().y();
            if (eVarY == null) {
                return false;
            }
            if (i11 == -1) {
                J(intent != null ? intent.getStringExtra(CustomTabMainActivity.f6910g) : null, eVarY);
                return true;
            }
            super.E(eVarY, null, new b2.u());
            return false;
        }
        return super.q(i10, i11, intent);
    }

    @Override // b3.f0
    public void v(JSONObject param) throws JSONException {
        kotlin.jvm.internal.m.g(param, "param");
        param.put("7_challenge", this.f5632g);
    }

    @Override // b3.f0, android.os.Parcelable
    public void writeToParcel(Parcel dest, int i10) {
        kotlin.jvm.internal.m.g(dest, "dest");
        super.writeToParcel(dest, i10);
        dest.writeString(this.f5632g);
    }

    @Override // b3.f0
    public int y(u.e request) {
        d.a aVar;
        Uri uriA;
        kotlin.jvm.internal.m.g(request, "request");
        u uVarJ = j();
        if (m().length() == 0) {
            return 0;
        }
        Bundle bundleZ = z(A(request), request);
        if (f5630l) {
            bundleZ.putString("cct_over_app_switch", "1");
        }
        if (b2.f0.f5404q) {
            if (request.B()) {
                aVar = d.f5638b;
                uriA = r2.x.f20309c.a("oauth", bundleZ);
            } else {
                aVar = d.f5638b;
                uriA = r2.e.f20118b.a("oauth", bundleZ);
            }
            aVar.c(uriA);
        }
        androidx.fragment.app.s sVarO = uVarJ.o();
        if (sVarO == null) {
            return 0;
        }
        Intent intent = new Intent(sVarO, (Class<?>) CustomTabMainActivity.class);
        intent.putExtra(CustomTabMainActivity.f6907d, "oauth");
        intent.putExtra(CustomTabMainActivity.f6908e, bundleZ);
        intent.putExtra(CustomTabMainActivity.f6909f, H());
        intent.putExtra(CustomTabMainActivity.f6911h, request.s().toString());
        Fragment fragmentS = uVarJ.s();
        if (fragmentS != null) {
            fragmentS.startActivityForResult(intent, 1);
        }
        return 1;
    }
}
