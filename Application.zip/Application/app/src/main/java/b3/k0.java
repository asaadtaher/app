package b3;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import androidx.fragment.app.Fragment;
import b3.c;
import b3.f0;
import b3.u;

/* loaded from: classes.dex */
public abstract class k0 extends f0 {

    /* renamed from: d, reason: collision with root package name */
    private final b2.h f5701d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k0(Parcel source) {
        super(source);
        kotlin.jvm.internal.m.g(source, "source");
        this.f5701d = b2.h.FACEBOOK_APPLICATION_WEB;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k0(u loginClient) {
        super(loginClient);
        kotlin.jvm.internal.m.g(loginClient, "loginClient");
        this.f5701d = b2.h.FACEBOOK_APPLICATION_WEB;
    }

    private final void A(u.f fVar) {
        if (fVar != null) {
            j().m(fVar);
        } else {
            j().K();
        }
    }

    private final boolean H(Intent intent) {
        b2.f0 f0Var = b2.f0.f5388a;
        kotlin.jvm.internal.m.f(b2.f0.l().getPackageManager().queryIntentActivities(intent, 65536), "FacebookSdk.getApplicationContext()\n            .packageManager\n            .queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)");
        return !r3.isEmpty();
    }

    private final void I(final u.e eVar, final Bundle bundle) throws NumberFormatException {
        if (bundle.containsKey("code")) {
            r2.l0 l0Var = r2.l0.f20174a;
            if (!r2.l0.X(bundle.getString("code"))) {
                b2.f0 f0Var = b2.f0.f5388a;
                b2.f0.t().execute(new Runnable() { // from class: b3.j0
                    @Override // java.lang.Runnable
                    public final void run() throws NumberFormatException {
                        k0.J(this.f5694a, eVar, bundle);
                    }
                });
                return;
            }
        }
        G(eVar, bundle);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void J(k0 this$0, u.e request, Bundle extras) throws NumberFormatException {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        kotlin.jvm.internal.m.g(request, "$request");
        kotlin.jvm.internal.m.g(extras, "$extras");
        try {
            this$0.G(request, this$0.s(request, extras));
        } catch (b2.h0 e10) {
            b2.v vVarC = e10.c();
            this$0.F(request, vVarC.j(), vVarC.i(), String.valueOf(vVarC.h()));
        } catch (b2.s e11) {
            this$0.F(request, null, e11.getMessage(), null);
        }
    }

    protected String B(Bundle bundle) {
        String string = bundle == null ? null : bundle.getString("error");
        if (string != null) {
            return string;
        }
        if (bundle == null) {
            return null;
        }
        return bundle.getString("error_type");
    }

    protected String C(Bundle bundle) {
        String string = bundle == null ? null : bundle.getString("error_message");
        if (string != null) {
            return string;
        }
        if (bundle == null) {
            return null;
        }
        return bundle.getString("error_description");
    }

    public b2.h D() {
        return this.f5701d;
    }

    protected void E(u.e eVar, Intent data) {
        Object obj;
        kotlin.jvm.internal.m.g(data, "data");
        Bundle extras = data.getExtras();
        String strB = B(extras);
        String string = null;
        if (extras != null && (obj = extras.get("error_code")) != null) {
            string = obj.toString();
        }
        r2.h0 h0Var = r2.h0.f20148a;
        A(kotlin.jvm.internal.m.b(r2.h0.c(), string) ? u.f.f5808i.c(eVar, strB, C(extras), string) : u.f.f5808i.a(eVar, strB));
    }

    protected void F(u.e eVar, String str, String str2, String str3) {
        if (str == null || !kotlin.jvm.internal.m.b(str, "logged_out")) {
            r2.h0 h0Var = r2.h0.f20148a;
            if (!uc.x.A(r2.h0.d(), str)) {
                A(uc.x.A(r2.h0.e(), str) ? u.f.f5808i.a(eVar, null) : u.f.f5808i.c(eVar, str, str2, str3));
                return;
            }
        } else {
            c.b bVar = c.f5629k;
            c.f5630l = true;
        }
        A(null);
    }

    protected void G(u.e request, Bundle extras) throws NumberFormatException {
        kotlin.jvm.internal.m.g(request, "request");
        kotlin.jvm.internal.m.g(extras, "extras");
        try {
            f0.a aVar = f0.f5669c;
            A(u.f.f5808i.b(request, aVar.b(request.x(), extras, D(), request.b()), aVar.d(extras, request.w())));
        } catch (b2.s e10) {
            A(u.f.c.d(u.f.f5808i, request, null, e10.getMessage(), null, 8, null));
        }
    }

    protected boolean K(Intent intent, int i10) {
        androidx.activity.result.c<Intent> cVarB0;
        if (intent == null || !H(intent)) {
            return false;
        }
        Fragment fragmentS = j().s();
        tc.x xVar = null;
        y yVar = fragmentS instanceof y ? (y) fragmentS : null;
        if (yVar != null && (cVarB0 = yVar.B0()) != null) {
            cVarB0.a(intent);
            xVar = tc.x.f21992a;
        }
        return xVar != null;
    }

    @Override // b3.f0
    public boolean q(int i10, int i11, Intent intent) throws NumberFormatException {
        u.f fVarD;
        u.e eVarY = j().y();
        if (intent != null) {
            if (i11 == 0) {
                E(eVarY, intent);
            } else if (i11 != -1) {
                fVarD = u.f.c.d(u.f.f5808i, eVarY, "Unexpected resultCode from authorization.", null, null, 8, null);
            } else {
                Bundle extras = intent.getExtras();
                if (extras == null) {
                    A(u.f.c.d(u.f.f5808i, eVarY, "Unexpected null from returned authorization data.", null, null, 8, null));
                    return true;
                }
                String strB = B(extras);
                Object obj = extras.get("error_code");
                String string = obj == null ? null : obj.toString();
                String strC = C(extras);
                String string2 = extras.getString("e2e");
                r2.l0 l0Var = r2.l0.f20174a;
                if (!r2.l0.X(string2)) {
                    n(string2);
                }
                if (strB == null && string == null && strC == null && eVarY != null) {
                    I(eVarY, extras);
                } else {
                    F(eVarY, strB, strC, string);
                }
            }
            return true;
        }
        fVarD = u.f.f5808i.a(eVarY, "Operation canceled");
        A(fVarD);
        return true;
    }
}
