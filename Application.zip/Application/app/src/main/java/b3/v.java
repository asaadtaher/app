package b3;

import java.util.Collection;
import java.util.Set;
import java.util.UUID;

/* loaded from: classes.dex */
public final class v {

    /* renamed from: d, reason: collision with root package name */
    public static final a f5822d = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private final Set<String> f5823a;

    /* renamed from: b, reason: collision with root package name */
    private final String f5824b;

    /* renamed from: c, reason: collision with root package name */
    private final String f5825c;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public v(Collection<String> collection, String nonce) {
        this(collection, nonce, m0.c());
        kotlin.jvm.internal.m.g(nonce, "nonce");
        m0 m0Var = m0.f5728a;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public /* synthetic */ v(Collection collection, String str, int i10, kotlin.jvm.internal.g gVar) {
        if ((i10 & 2) != 0) {
            str = UUID.randomUUID().toString();
            kotlin.jvm.internal.m.f(str, "randomUUID().toString()");
        }
        this(collection, str);
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x001f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public v(java.util.Collection<java.lang.String> r2, java.lang.String r3, java.lang.String r4) {
        /*
            r1 = this;
            java.lang.String r0 = "nonce"
            kotlin.jvm.internal.m.g(r3, r0)
            java.lang.String r0 = "codeVerifier"
            kotlin.jvm.internal.m.g(r4, r0)
            r1.<init>()
            b3.l0 r0 = b3.l0.f5703a
            boolean r0 = b3.l0.a(r3)
            if (r0 == 0) goto L1f
            b3.m0 r0 = b3.m0.f5728a
            boolean r0 = b3.m0.d(r4)
            if (r0 == 0) goto L1f
            r0 = 1
            goto L20
        L1f:
            r0 = 0
        L20:
            if (r0 == 0) goto L42
            java.util.HashSet r0 = new java.util.HashSet
            if (r2 == 0) goto L2a
            r0.<init>(r2)
            goto L2d
        L2a:
            r0.<init>()
        L2d:
            java.lang.String r2 = "openid"
            r0.add(r2)
            java.util.Set r2 = java.util.Collections.unmodifiableSet(r0)
            java.lang.String r0 = "unmodifiableSet(permissions)"
            kotlin.jvm.internal.m.f(r2, r0)
            r1.f5823a = r2
            r1.f5824b = r3
            r1.f5825c = r4
            return
        L42:
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.String r3 = "Failed requirement."
            java.lang.String r3 = r3.toString()
            r2.<init>(r3)
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: b3.v.<init>(java.util.Collection, java.lang.String, java.lang.String):void");
    }

    public final String a() {
        return this.f5825c;
    }

    public final String b() {
        return this.f5824b;
    }

    public final Set<String> c() {
        return this.f5823a;
    }
}
