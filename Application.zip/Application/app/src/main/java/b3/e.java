package b3;

import java.util.Arrays;

/* loaded from: classes.dex */
public enum e {
    NONE(null),
    ONLY_ME("only_me"),
    FRIENDS("friends"),
    EVERYONE("everyone");


    /* renamed from: a, reason: collision with root package name */
    private final String f5651a;

    e(String str) {
        this.f5651a = str;
    }

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static e[] valuesCustom() {
        e[] eVarArrValuesCustom = values();
        return (e[]) Arrays.copyOf(eVarArrValuesCustom, eVarArrValuesCustom.length);
    }

    public final String b() {
        return this.f5651a;
    }
}
