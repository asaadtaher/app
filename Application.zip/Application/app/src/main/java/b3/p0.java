package b3;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import b3.u;
import java.util.Objects;
import r2.q0;

/* loaded from: classes.dex */
public class p0 extends o0 {

    /* renamed from: f, reason: collision with root package name */
    private q0 f5737f;

    /* renamed from: g, reason: collision with root package name */
    private String f5738g;

    /* renamed from: h, reason: collision with root package name */
    private final String f5739h;

    /* renamed from: i, reason: collision with root package name */
    private final b2.h f5740i;

    /* renamed from: j, reason: collision with root package name */
    public static final c f5736j = new c(null);
    public static final Parcelable.Creator<p0> CREATOR = new b();

    public final class a extends q0.a {

        /* renamed from: h, reason: collision with root package name */
        private String f5741h;

        /* renamed from: i, reason: collision with root package name */
        private t f5742i;

        /* renamed from: j, reason: collision with root package name */
        private i0 f5743j;

        /* renamed from: k, reason: collision with root package name */
        private boolean f5744k;

        /* renamed from: l, reason: collision with root package name */
        private boolean f5745l;

        /* renamed from: m, reason: collision with root package name */
        public String f5746m;

        /* renamed from: n, reason: collision with root package name */
        public String f5747n;

        /* renamed from: o, reason: collision with root package name */
        final /* synthetic */ p0 f5748o;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(p0 this$0, Context context, String applicationId, Bundle parameters) {
            super(context, applicationId, "oauth", parameters);
            kotlin.jvm.internal.m.g(this$0, "this$0");
            kotlin.jvm.internal.m.g(context, "context");
            kotlin.jvm.internal.m.g(applicationId, "applicationId");
            kotlin.jvm.internal.m.g(parameters, "parameters");
            this.f5748o = this$0;
            this.f5741h = "fbconnect://success";
            this.f5742i = t.NATIVE_WITH_FALLBACK;
            this.f5743j = i0.FACEBOOK;
        }

        @Override // r2.q0.a
        public q0 a() {
            Bundle bundleF = f();
            Objects.requireNonNull(bundleF, "null cannot be cast to non-null type android.os.Bundle");
            bundleF.putString("redirect_uri", this.f5741h);
            bundleF.putString("client_id", c());
            bundleF.putString("e2e", j());
            bundleF.putString("response_type", this.f5743j == i0.INSTAGRAM ? "token,signed_request,graph_domain,granted_scopes" : "token,signed_request,graph_domain");
            bundleF.putString("return_scopes", "true");
            bundleF.putString("auth_type", i());
            bundleF.putString("login_behavior", this.f5742i.name());
            if (this.f5744k) {
                bundleF.putString("fx_app", this.f5743j.toString());
            }
            if (this.f5745l) {
                bundleF.putString("skip_dedupe", "true");
            }
            q0.b bVar = q0.f20228r;
            Context contextD = d();
            Objects.requireNonNull(contextD, "null cannot be cast to non-null type android.content.Context");
            return bVar.c(contextD, "oauth", bundleF, g(), this.f5743j, e());
        }

        public final String i() {
            String str = this.f5747n;
            if (str != null) {
                return str;
            }
            kotlin.jvm.internal.m.u("authType");
            throw null;
        }

        public final String j() {
            String str = this.f5746m;
            if (str != null) {
                return str;
            }
            kotlin.jvm.internal.m.u("e2e");
            throw null;
        }

        public final a k(String authType) {
            kotlin.jvm.internal.m.g(authType, "authType");
            l(authType);
            return this;
        }

        public final void l(String str) {
            kotlin.jvm.internal.m.g(str, "<set-?>");
            this.f5747n = str;
        }

        public final a m(String e2e) {
            kotlin.jvm.internal.m.g(e2e, "e2e");
            n(e2e);
            return this;
        }

        public final void n(String str) {
            kotlin.jvm.internal.m.g(str, "<set-?>");
            this.f5746m = str;
        }

        public final a o(boolean z10) {
            this.f5744k = z10;
            return this;
        }

        public final a p(boolean z10) {
            this.f5741h = z10 ? "fbconnect://chrome_os_success" : "fbconnect://success";
            return this;
        }

        public final a q(t loginBehavior) {
            kotlin.jvm.internal.m.g(loginBehavior, "loginBehavior");
            this.f5742i = loginBehavior;
            return this;
        }

        public final a r(i0 targetApp) {
            kotlin.jvm.internal.m.g(targetApp, "targetApp");
            this.f5743j = targetApp;
            return this;
        }

        public final a s(boolean z10) {
            this.f5745l = z10;
            return this;
        }
    }

    public static final class b implements Parcelable.Creator<p0> {
        b() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public p0 createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new p0(source);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public p0[] newArray(int i10) {
            return new p0[i10];
        }
    }

    public static final class c {
        private c() {
        }

        public /* synthetic */ c(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public static final class d implements q0.e {

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ u.e f5750b;

        d(u.e eVar) {
            this.f5750b = eVar;
        }

        @Override // r2.q0.e
        public void a(Bundle bundle, b2.s sVar) {
            p0.this.G(this.f5750b, bundle, sVar);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p0(Parcel source) {
        super(source);
        kotlin.jvm.internal.m.g(source, "source");
        this.f5739h = "web_view";
        this.f5740i = b2.h.WEB_VIEW;
        this.f5738g = source.readString();
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p0(u loginClient) {
        super(loginClient);
        kotlin.jvm.internal.m.g(loginClient, "loginClient");
        this.f5739h = "web_view";
        this.f5740i = b2.h.WEB_VIEW;
    }

    @Override // b3.o0
    public b2.h C() {
        return this.f5740i;
    }

    public final void G(u.e request, Bundle bundle, b2.s sVar) {
        kotlin.jvm.internal.m.g(request, "request");
        super.E(request, bundle, sVar);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // b3.f0
    public void h() {
        q0 q0Var = this.f5737f;
        if (q0Var != null) {
            if (q0Var != null) {
                q0Var.cancel();
            }
            this.f5737f = null;
        }
    }

    @Override // b3.f0
    public String l() {
        return this.f5739h;
    }

    @Override // b3.f0
    public boolean o() {
        return true;
    }

    @Override // b3.f0, android.os.Parcelable
    public void writeToParcel(Parcel dest, int i10) {
        kotlin.jvm.internal.m.g(dest, "dest");
        super.writeToParcel(dest, i10);
        dest.writeString(this.f5738g);
    }

    @Override // b3.f0
    public int y(u.e request) {
        kotlin.jvm.internal.m.g(request, "request");
        Bundle bundleA = A(request);
        d dVar = new d(request);
        String strA = u.f5776r.a();
        this.f5738g = strA;
        b("e2e", strA);
        androidx.fragment.app.s sVarO = j().o();
        if (sVarO == null) {
            return 0;
        }
        r2.l0 l0Var = r2.l0.f20174a;
        boolean zR = r2.l0.R(sVarO);
        a aVar = new a(this, sVarO, request.b(), bundleA);
        String str = this.f5738g;
        Objects.requireNonNull(str, "null cannot be cast to non-null type kotlin.String");
        this.f5737f = aVar.m(str).p(zR).k(request.i()).q(request.q()).r(request.s()).o(request.A()).s(request.J()).h(dVar).a();
        r2.i iVar = new r2.i();
        iVar.setRetainInstance(true);
        iVar.I0(this.f5737f);
        iVar.show(sVarO.getSupportFragmentManager(), "FacebookDialogFragment");
        return 1;
    }
}
