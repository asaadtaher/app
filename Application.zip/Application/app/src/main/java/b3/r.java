package b3;

import android.content.Context;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import b3.u;
import java.util.Set;

/* loaded from: classes.dex */
public final class r extends k0 {

    /* renamed from: e, reason: collision with root package name */
    private final String f5758e;

    /* renamed from: f, reason: collision with root package name */
    private final b2.h f5759f;

    /* renamed from: g, reason: collision with root package name */
    public static final b f5757g = new b(null);
    public static final Parcelable.Creator<r> CREATOR = new a();

    public static final class a implements Parcelable.Creator<r> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public r createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new r(source);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public r[] newArray(int i10) {
            return new r[i10];
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public r(Parcel source) {
        super(source);
        kotlin.jvm.internal.m.g(source, "source");
        this.f5758e = "instagram_login";
        this.f5759f = b2.h.INSTAGRAM_APPLICATION_WEB;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public r(u loginClient) {
        super(loginClient);
        kotlin.jvm.internal.m.g(loginClient, "loginClient");
        this.f5758e = "instagram_login";
        this.f5759f = b2.h.INSTAGRAM_APPLICATION_WEB;
    }

    @Override // b3.k0
    public b2.h D() {
        return this.f5759f;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // b3.f0
    public String l() {
        return this.f5758e;
    }

    @Override // b3.f0, android.os.Parcelable
    public void writeToParcel(Parcel dest, int i10) {
        kotlin.jvm.internal.m.g(dest, "dest");
        super.writeToParcel(dest, i10);
    }

    @Override // b3.f0
    public int y(u.e request) {
        kotlin.jvm.internal.m.g(request, "request");
        u.c cVar = u.f5776r;
        String strA = cVar.a();
        r2.e0 e0Var = r2.e0.f20120a;
        Context contextO = j().o();
        if (contextO == null) {
            b2.f0 f0Var = b2.f0.f5388a;
            contextO = b2.f0.l();
        }
        String strB = request.b();
        Set<String> setX = request.x();
        boolean zC = request.C();
        boolean z10 = request.z();
        e eVarM = request.m();
        if (eVarM == null) {
            eVarM = e.NONE;
        }
        Intent intentJ = r2.e0.j(contextO, strB, setX, strA, zC, z10, eVarM, i(request.h()), request.i(), request.v(), request.y(), request.A(), request.J());
        b("e2e", strA);
        return K(intentJ, cVar.b()) ? 1 : 0;
    }
}
