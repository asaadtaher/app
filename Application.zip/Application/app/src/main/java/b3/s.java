package b3;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class s extends k0 {

    /* renamed from: e, reason: collision with root package name */
    private final String f5761e;

    /* renamed from: f, reason: collision with root package name */
    public static final b f5760f = new b(null);
    public static final Parcelable.Creator<s> CREATOR = new a();

    public static final class a implements Parcelable.Creator<s> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public s createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new s(source);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public s[] newArray(int i10) {
            return new s[i10];
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public s(Parcel source) {
        super(source);
        kotlin.jvm.internal.m.g(source, "source");
        this.f5761e = "katana_proxy_auth";
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public s(u loginClient) {
        super(loginClient);
        kotlin.jvm.internal.m.g(loginClient, "loginClient");
        this.f5761e = "katana_proxy_auth";
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // b3.f0
    public String l() {
        return this.f5761e;
    }

    @Override // b3.f0
    public boolean x() {
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x0023  */
    @Override // b3.f0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public int y(b3.u.e r24) throws org.json.JSONException {
        /*
            r23 = this;
            r0 = r23
            java.lang.String r1 = "request"
            r2 = r24
            kotlin.jvm.internal.m.g(r2, r1)
            b3.t r1 = r24.q()
            boolean r3 = b2.f0.f5405r
            r4 = 1
            r5 = 0
            if (r3 == 0) goto L23
            r2.f r3 = r2.f.f20131a
            java.lang.String r3 = r2.f.a()
            if (r3 == 0) goto L23
            boolean r1 = r1.b()
            if (r1 == 0) goto L23
            r15 = 1
            goto L24
        L23:
            r15 = 0
        L24:
            b3.u$c r1 = b3.u.f5776r
            java.lang.String r1 = r1.a()
            r2.e0 r3 = r2.e0.f20120a
            b3.u r3 = r23.j()
            androidx.fragment.app.s r6 = r3.o()
            java.lang.String r7 = r24.b()
            java.util.Set r8 = r24.x()
            boolean r10 = r24.C()
            boolean r11 = r24.z()
            b3.e r3 = r24.m()
            if (r3 != 0) goto L4c
            b3.e r3 = b3.e.NONE
        L4c:
            r12 = r3
            java.lang.String r3 = r24.h()
            java.lang.String r13 = r0.i(r3)
            java.lang.String r14 = r24.i()
            java.lang.String r16 = r24.v()
            boolean r17 = r24.y()
            boolean r18 = r24.A()
            boolean r19 = r24.J()
            java.lang.String r20 = r24.w()
            java.lang.String r21 = r24.j()
            b3.a r2 = r24.k()
            if (r2 != 0) goto L79
            r2 = 0
            goto L7d
        L79:
            java.lang.String r2 = r2.name()
        L7d:
            r22 = r2
            r9 = r1
            java.util.List r2 = r2.e0.n(r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22)
            java.lang.String r3 = "e2e"
            r0.b(r3, r1)
            java.util.Iterator r1 = r2.iterator()
            r2 = 0
        L8e:
            boolean r3 = r1.hasNext()
            if (r3 == 0) goto La8
            int r2 = r2 + r4
            java.lang.Object r3 = r1.next()
            android.content.Intent r3 = (android.content.Intent) r3
            b3.u$c r6 = b3.u.f5776r
            int r6 = r6.b()
            boolean r3 = r0.K(r3, r6)
            if (r3 == 0) goto L8e
            return r2
        La8:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: b3.s.y(b3.u$e):int");
    }
}
