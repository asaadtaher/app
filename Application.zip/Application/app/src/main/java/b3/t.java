package b3;

import java.util.Arrays;

/* loaded from: classes.dex */
public enum t {
    NATIVE_WITH_FALLBACK(true, true, true, false, true, true, true),
    NATIVE_ONLY(true, true, false, false, false, true, true),
    KATANA_ONLY(false, true, false, false, false, false, false),
    WEB_ONLY(false, false, true, false, true, false, false),
    DIALOG_ONLY(false, true, true, false, true, true, true),
    DEVICE_AUTH(false, false, false, true, false, false, false);


    /* renamed from: a, reason: collision with root package name */
    private final boolean f5769a;

    /* renamed from: b, reason: collision with root package name */
    private final boolean f5770b;

    /* renamed from: c, reason: collision with root package name */
    private final boolean f5771c;

    /* renamed from: d, reason: collision with root package name */
    private final boolean f5772d;

    /* renamed from: e, reason: collision with root package name */
    private final boolean f5773e;

    /* renamed from: f, reason: collision with root package name */
    private final boolean f5774f;

    /* renamed from: g, reason: collision with root package name */
    private final boolean f5775g;

    t(boolean z10, boolean z11, boolean z12, boolean z13, boolean z14, boolean z15, boolean z16) {
        this.f5769a = z10;
        this.f5770b = z11;
        this.f5771c = z12;
        this.f5772d = z13;
        this.f5773e = z14;
        this.f5774f = z15;
        this.f5775g = z16;
    }

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static t[] valuesCustom() {
        t[] tVarArrValuesCustom = values();
        return (t[]) Arrays.copyOf(tVarArrValuesCustom, tVarArrValuesCustom.length);
    }

    public final boolean b() {
        return this.f5773e;
    }

    public final boolean c() {
        return this.f5772d;
    }

    public final boolean d() {
        return this.f5769a;
    }

    public final boolean e() {
        return this.f5775g;
    }

    public final boolean f() {
        return this.f5770b;
    }

    public final boolean g() {
        return this.f5771c;
    }
}
