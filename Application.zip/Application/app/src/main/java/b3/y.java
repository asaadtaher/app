package b3;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import b3.u;

/* loaded from: classes.dex */
public class y extends Fragment {

    /* renamed from: r0, reason: collision with root package name */
    public static final a f5828r0 = new a(null);

    /* renamed from: m0, reason: collision with root package name */
    private String f5829m0;

    /* renamed from: n0, reason: collision with root package name */
    private u.e f5830n0;

    /* renamed from: o0, reason: collision with root package name */
    private u f5831o0;

    /* renamed from: p0, reason: collision with root package name */
    private androidx.activity.result.c<Intent> f5832p0;

    /* renamed from: q0, reason: collision with root package name */
    private View f5833q0;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    static final class b extends kotlin.jvm.internal.n implements ed.l<androidx.activity.result.a, tc.x> {

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ androidx.fragment.app.s f5835b;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        b(androidx.fragment.app.s sVar) {
            super(1);
            this.f5835b = sVar;
        }

        public final void a(androidx.activity.result.a result) {
            kotlin.jvm.internal.m.g(result, "result");
            if (result.h() == -1) {
                y.this.D0().E(u.f5776r.b(), result.h(), result.b());
            } else {
                this.f5835b.finish();
            }
        }

        @Override // ed.l
        public /* bridge */ /* synthetic */ tc.x invoke(androidx.activity.result.a aVar) {
            a(aVar);
            return tc.x.f21992a;
        }
    }

    public static final class c implements u.a {
        c() {
        }

        @Override // b3.u.a
        public void a() {
            y.this.M0();
        }

        @Override // b3.u.a
        public void b() {
            y.this.F0();
        }
    }

    private final ed.l<androidx.activity.result.a, tc.x> E0(androidx.fragment.app.s sVar) {
        return new b(sVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void F0() {
        View view = this.f5833q0;
        if (view == null) {
            kotlin.jvm.internal.m.u("progressBar");
            throw null;
        }
        view.setVisibility(8);
        K0();
    }

    private final void G0(Activity activity) {
        ComponentName callingActivity = activity.getCallingActivity();
        if (callingActivity == null) {
            return;
        }
        this.f5829m0 = callingActivity.getPackageName();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void H0(y this$0, u.f outcome) {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        kotlin.jvm.internal.m.g(outcome, "outcome");
        this$0.J0(outcome);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void I0(ed.l tmp0, androidx.activity.result.a aVar) {
        kotlin.jvm.internal.m.g(tmp0, "$tmp0");
        tmp0.invoke(aVar);
    }

    private final void J0(u.f fVar) {
        this.f5830n0 = null;
        int i10 = fVar.f5809a == u.f.a.CANCEL ? 0 : -1;
        Bundle bundle = new Bundle();
        bundle.putParcelable("com.facebook.LoginFragment:Result", fVar);
        Intent intent = new Intent();
        intent.putExtras(bundle);
        androidx.fragment.app.s activity = getActivity();
        if (!isAdded() || activity == null) {
            return;
        }
        activity.setResult(i10, intent);
        activity.finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void M0() {
        View view = this.f5833q0;
        if (view == null) {
            kotlin.jvm.internal.m.u("progressBar");
            throw null;
        }
        view.setVisibility(0);
        L0();
    }

    protected u A0() {
        return new u(this);
    }

    public final androidx.activity.result.c<Intent> B0() {
        androidx.activity.result.c<Intent> cVar = this.f5832p0;
        if (cVar != null) {
            return cVar;
        }
        kotlin.jvm.internal.m.u("launcher");
        throw null;
    }

    protected int C0() {
        return p2.c.f18834c;
    }

    public final u D0() {
        u uVar = this.f5831o0;
        if (uVar != null) {
            return uVar;
        }
        kotlin.jvm.internal.m.u("loginClient");
        throw null;
    }

    protected void K0() {
    }

    protected void L0() {
    }

    @Override // androidx.fragment.app.Fragment
    public void onActivityResult(int i10, int i11, Intent intent) {
        super.onActivityResult(i10, i11, intent);
        D0().E(i10, i11, intent);
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        Bundle bundleExtra;
        super.onCreate(bundle);
        u uVarA0 = bundle == null ? null : (u) bundle.getParcelable("loginClient");
        if (uVarA0 != null) {
            uVarA0.G(this);
        } else {
            uVarA0 = A0();
        }
        this.f5831o0 = uVarA0;
        D0().H(new u.d() { // from class: b3.x
            @Override // b3.u.d
            public final void a(u.f fVar) {
                y.H0(this.f5827a, fVar);
            }
        });
        androidx.fragment.app.s activity = getActivity();
        if (activity == null) {
            return;
        }
        G0(activity);
        Intent intent = activity.getIntent();
        if (intent != null && (bundleExtra = intent.getBundleExtra("com.facebook.LoginFragment:Request")) != null) {
            this.f5830n0 = (u.e) bundleExtra.getParcelable("request");
        }
        f.g gVar = new f.g();
        final ed.l<androidx.activity.result.a, tc.x> lVarE0 = E0(activity);
        androidx.activity.result.c<Intent> cVarRegisterForActivityResult = registerForActivityResult(gVar, new androidx.activity.result.b() { // from class: b3.w
            @Override // androidx.activity.result.b
            public final void b(Object obj) {
                y.I0(lVarE0, (androidx.activity.result.a) obj);
            }
        });
        kotlin.jvm.internal.m.f(cVarRegisterForActivityResult, "registerForActivityResult(\n            ActivityResultContracts.StartActivityForResult(),\n            getLoginMethodHandlerCallback(activity))");
        this.f5832p0 = cVarRegisterForActivityResult;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup viewGroup, Bundle bundle) {
        kotlin.jvm.internal.m.g(inflater, "inflater");
        View viewInflate = inflater.inflate(C0(), viewGroup, false);
        View viewFindViewById = viewInflate.findViewById(p2.b.f18829d);
        kotlin.jvm.internal.m.f(viewFindViewById, "view.findViewById<View>(R.id.com_facebook_login_fragment_progress_bar)");
        this.f5833q0 = viewFindViewById;
        D0().F(new c());
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        D0().i();
        super.onDestroy();
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        super.onPause();
        View view = getView();
        View viewFindViewById = view == null ? null : view.findViewById(p2.b.f18829d);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility(8);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        if (this.f5829m0 != null) {
            D0().I(this.f5830n0);
            return;
        }
        Log.e("LoginFragment", "Cannot call LoginFragment with a null calling package. This can occur if the launchMode of the caller is singleInstance.");
        androidx.fragment.app.s activity = getActivity();
        if (activity == null) {
            return;
        }
        activity.finish();
    }

    @Override // androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle outState) {
        kotlin.jvm.internal.m.g(outState, "outState");
        super.onSaveInstanceState(outState);
        outState.putParcelable("loginClient", D0());
    }
}
