package b3;

import android.os.Parcel;
import android.os.Parcelable;
import b3.u;
import java.util.Collection;
import java.util.Date;
import java.util.concurrent.ScheduledThreadPoolExecutor;

/* loaded from: classes.dex */
public class n extends f0 {

    /* renamed from: f, reason: collision with root package name */
    private static ScheduledThreadPoolExecutor f5730f;

    /* renamed from: d, reason: collision with root package name */
    private final String f5731d;

    /* renamed from: e, reason: collision with root package name */
    public static final b f5729e = new b(null);
    public static final Parcelable.Creator<n> CREATOR = new a();

    public static final class a implements Parcelable.Creator<n> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public n createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new n(source);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public n[] newArray(int i10) {
            return new n[i10];
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final synchronized ScheduledThreadPoolExecutor a() {
            ScheduledThreadPoolExecutor scheduledThreadPoolExecutor;
            if (n.f5730f == null) {
                n.f5730f = new ScheduledThreadPoolExecutor(1);
            }
            scheduledThreadPoolExecutor = n.f5730f;
            if (scheduledThreadPoolExecutor == null) {
                kotlin.jvm.internal.m.u("backgroundExecutor");
                throw null;
            }
            return scheduledThreadPoolExecutor;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    protected n(Parcel parcel) {
        super(parcel);
        kotlin.jvm.internal.m.g(parcel, "parcel");
        this.f5731d = "device_auth";
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n(u loginClient) {
        super(loginClient);
        kotlin.jvm.internal.m.g(loginClient, "loginClient");
        this.f5731d = "device_auth";
    }

    private final void F(u.e eVar) {
        androidx.fragment.app.s sVarO = j().o();
        if (sVarO == null || sVarO.isFinishing()) {
            return;
        }
        m mVarB = B();
        mVarB.show(sVarO.getSupportFragmentManager(), "login_with_facebook");
        mVarB.b1(eVar);
    }

    protected m B() {
        return new m();
    }

    public void C() {
        j().m(u.f.f5808i.a(j().y(), "User canceled log in."));
    }

    public void D(Exception ex) {
        kotlin.jvm.internal.m.g(ex, "ex");
        j().m(u.f.c.d(u.f.f5808i, j().y(), null, ex.getMessage(), null, 8, null));
    }

    public void E(String accessToken, String applicationId, String userId, Collection<String> collection, Collection<String> collection2, Collection<String> collection3, b2.h hVar, Date date, Date date2, Date date3) {
        kotlin.jvm.internal.m.g(accessToken, "accessToken");
        kotlin.jvm.internal.m.g(applicationId, "applicationId");
        kotlin.jvm.internal.m.g(userId, "userId");
        j().m(u.f.f5808i.e(j().y(), new b2.a(accessToken, applicationId, userId, collection, collection2, collection3, hVar, date, date2, date3, null, 1024, null)));
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // b3.f0
    public String l() {
        return this.f5731d;
    }

    @Override // b3.f0
    public int y(u.e request) {
        kotlin.jvm.internal.m.g(request, "request");
        F(request);
        return 1;
    }
}
