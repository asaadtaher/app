package b3;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import b2.s0;
import b2.t0;
import b3.u;
import com.facebook.FacebookActivity;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import r2.d;
import r2.f0;

/* loaded from: classes.dex */
public class e0 {

    /* renamed from: j, reason: collision with root package name */
    public static final b f5652j;

    /* renamed from: k, reason: collision with root package name */
    private static final Set<String> f5653k;

    /* renamed from: l, reason: collision with root package name */
    private static final String f5654l;

    /* renamed from: m, reason: collision with root package name */
    private static volatile e0 f5655m;

    /* renamed from: c, reason: collision with root package name */
    private final SharedPreferences f5658c;

    /* renamed from: e, reason: collision with root package name */
    private String f5660e;

    /* renamed from: f, reason: collision with root package name */
    private boolean f5661f;

    /* renamed from: h, reason: collision with root package name */
    private boolean f5663h;

    /* renamed from: i, reason: collision with root package name */
    private boolean f5664i;

    /* renamed from: a, reason: collision with root package name */
    private t f5656a = t.NATIVE_WITH_FALLBACK;

    /* renamed from: b, reason: collision with root package name */
    private e f5657b = e.FRIENDS;

    /* renamed from: d, reason: collision with root package name */
    private String f5659d = "rerequest";

    /* renamed from: g, reason: collision with root package name */
    private i0 f5662g = i0.FACEBOOK;

    private static final class a implements n0 {

        /* renamed from: a, reason: collision with root package name */
        private final Activity f5665a;

        public a(Activity activity) {
            kotlin.jvm.internal.m.g(activity, "activity");
            this.f5665a = activity;
        }

        @Override // b3.n0
        public Activity a() {
            return this.f5665a;
        }

        @Override // b3.n0
        public void startActivityForResult(Intent intent, int i10) {
            kotlin.jvm.internal.m.g(intent, "intent");
            a().startActivityForResult(intent, i10);
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final Set<String> e() {
            return uc.m0.f("ads_management", "create_event", "rsvp_event");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final void f(String str, String str2, String str3, a0 a0Var, s0 s0Var) {
            b2.s sVar = new b2.s(str + ": " + ((Object) str2));
            a0Var.i(str3, sVar);
            s0Var.c(sVar);
        }

        public final g0 c(u.e request, b2.a newToken, b2.i iVar) {
            kotlin.jvm.internal.m.g(request, "request");
            kotlin.jvm.internal.m.g(newToken, "newToken");
            Set<String> setX = request.x();
            Set setK0 = uc.x.k0(uc.x.F(newToken.s()));
            if (request.C()) {
                setK0.retainAll(setX);
            }
            Set setK02 = uc.x.k0(uc.x.F(setX));
            setK02.removeAll(setK0);
            return new g0(newToken, iVar, setK0, setK02);
        }

        public e0 d() {
            if (e0.f5655m == null) {
                synchronized (this) {
                    b bVar = e0.f5652j;
                    e0.f5655m = new e0();
                    tc.x xVar = tc.x.f21992a;
                }
            }
            e0 e0Var = e0.f5655m;
            if (e0Var != null) {
                return e0Var;
            }
            kotlin.jvm.internal.m.u("instance");
            throw null;
        }

        public final boolean g(String str) {
            if (str != null) {
                return md.p.C(str, "publish", false, 2, null) || md.p.C(str, "manage", false, 2, null) || e0.f5653k.contains(str);
            }
            return false;
        }
    }

    private static final class c {

        /* renamed from: a, reason: collision with root package name */
        public static final c f5666a = new c();

        /* renamed from: b, reason: collision with root package name */
        private static a0 f5667b;

        private c() {
        }

        /* JADX WARN: Removed duplicated region for block: B:12:0x0011 A[Catch: all -> 0x000a, TRY_ENTER, TryCatch #0 {, blocks: (B:4:0x0003, B:12:0x0011, B:14:0x0015, B:15:0x0022), top: B:20:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:9:0x000e  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final synchronized b3.a0 a(android.content.Context r3) {
            /*
                r2 = this;
                monitor-enter(r2)
                if (r3 != 0) goto Lc
                b2.f0 r3 = b2.f0.f5388a     // Catch: java.lang.Throwable -> La
                android.content.Context r3 = b2.f0.l()     // Catch: java.lang.Throwable -> La
                goto Lc
            La:
                r3 = move-exception
                goto L26
            Lc:
                if (r3 != 0) goto L11
                r3 = 0
                monitor-exit(r2)
                return r3
            L11:
                b3.a0 r0 = b3.e0.c.f5667b     // Catch: java.lang.Throwable -> La
                if (r0 != 0) goto L22
                b3.a0 r0 = new b3.a0     // Catch: java.lang.Throwable -> La
                b2.f0 r1 = b2.f0.f5388a     // Catch: java.lang.Throwable -> La
                java.lang.String r1 = b2.f0.m()     // Catch: java.lang.Throwable -> La
                r0.<init>(r3, r1)     // Catch: java.lang.Throwable -> La
                b3.e0.c.f5667b = r0     // Catch: java.lang.Throwable -> La
            L22:
                b3.a0 r3 = b3.e0.c.f5667b     // Catch: java.lang.Throwable -> La
                monitor-exit(r2)
                return r3
            L26:
                monitor-exit(r2)
                throw r3
            */
            throw new UnsupportedOperationException("Method not decompiled: b3.e0.c.a(android.content.Context):b3.a0");
        }
    }

    static {
        b bVar = new b(null);
        f5652j = bVar;
        f5653k = bVar.e();
        String string = e0.class.toString();
        kotlin.jvm.internal.m.f(string, "LoginManager::class.java.toString()");
        f5654l = string;
    }

    public e0() {
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.l();
        b2.f0 f0Var = b2.f0.f5388a;
        SharedPreferences sharedPreferences = b2.f0.l().getSharedPreferences("com.facebook.loginManager", 0);
        kotlin.jvm.internal.m.f(sharedPreferences, "getApplicationContext().getSharedPreferences(PREFERENCE_LOGIN_MANAGER, Context.MODE_PRIVATE)");
        this.f5658c = sharedPreferences;
        if (b2.f0.f5404q) {
            r2.f fVar = r2.f.f20131a;
            if (r2.f.a() != null) {
                androidx.browser.customtabs.c.a(b2.f0.l(), "com.android.chrome", new d());
                androidx.browser.customtabs.c.b(b2.f0.l(), b2.f0.l().getPackageName());
            }
        }
    }

    private final void B(n0 n0Var, u.e eVar) {
        p(n0Var.a(), eVar);
        r2.d.f20095b.c(d.c.Login.b(), new d.a() { // from class: b3.b0
            @Override // r2.d.a
            public final boolean a(int i10, Intent intent) {
                return e0.C(this.f5628a, i10, intent);
            }
        });
        if (D(n0Var, eVar)) {
            return;
        }
        b2.s sVar = new b2.s("Log in attempt failed: FacebookActivity could not be started. Please make sure you added FacebookActivity to the AndroidManifest.");
        l(n0Var.a(), u.f.a.ERROR, null, sVar, false, eVar);
        throw sVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean C(e0 this$0, int i10, Intent intent) {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        return r(this$0, i10, intent, null, 4, null);
    }

    private final boolean D(n0 n0Var, u.e eVar) {
        Intent intentI = i(eVar);
        if (!u(intentI)) {
            return false;
        }
        try {
            n0Var.startActivityForResult(intentI, u.f5776r.b());
            return true;
        } catch (ActivityNotFoundException unused) {
            return false;
        }
    }

    private final void h(b2.a aVar, b2.i iVar, u.e eVar, b2.s sVar, boolean z10, b2.p<g0> pVar) {
        if (aVar != null) {
            b2.a.f5323l.h(aVar);
            t0.f5559h.a();
        }
        if (iVar != null) {
            b2.i.f5445f.a(iVar);
        }
        if (pVar != null) {
            g0 g0VarC = (aVar == null || eVar == null) ? null : f5652j.c(eVar, aVar, iVar);
            if (z10 || (g0VarC != null && g0VarC.b().isEmpty())) {
                pVar.onCancel();
                return;
            }
            if (sVar != null) {
                pVar.b(sVar);
            } else {
                if (aVar == null || g0VarC == null) {
                    return;
                }
                z(true);
                pVar.a(g0VarC);
            }
        }
    }

    public static e0 j() {
        return f5652j.d();
    }

    private final boolean k() {
        return this.f5658c.getBoolean("express_login_allowed", true);
    }

    private final void l(Context context, u.f.a aVar, Map<String, String> map, Exception exc, boolean z10, u.e eVar) {
        a0 a0VarA = c.f5666a.a(context);
        if (a0VarA == null) {
            return;
        }
        if (eVar == null) {
            a0.o(a0VarA, "fb_mobile_login_complete", "Unexpected call to logCompleteLogin with null pendingAuthorizationRequest.", null, 4, null);
            return;
        }
        HashMap map2 = new HashMap();
        map2.put("try_login_activity", z10 ? "1" : "0");
        a0VarA.f(eVar.h(), map2, aVar, map, exc, eVar.A() ? "foa_mobile_login_complete" : "fb_mobile_login_complete");
    }

    private final void p(Context context, u.e eVar) {
        a0 a0VarA = c.f5666a.a(context);
        if (a0VarA == null || eVar == null) {
            return;
        }
        a0VarA.m(eVar, eVar.A() ? "foa_mobile_login_start" : "fb_mobile_login_start");
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ boolean r(e0 e0Var, int i10, Intent intent, b2.p pVar, int i11, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: onActivityResult");
        }
        if ((i11 & 4) != 0) {
            pVar = null;
        }
        return e0Var.q(i10, intent, pVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean t(e0 this$0, b2.p pVar, int i10, Intent intent) {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        return this$0.q(i10, intent, pVar);
    }

    private final boolean u(Intent intent) {
        b2.f0 f0Var = b2.f0.f5388a;
        return b2.f0.l().getPackageManager().resolveActivity(intent, 0) != null;
    }

    private final void x(Context context, final s0 s0Var, long j10) {
        b2.f0 f0Var = b2.f0.f5388a;
        final String strM = b2.f0.m();
        final String string = UUID.randomUUID().toString();
        kotlin.jvm.internal.m.f(string, "randomUUID().toString()");
        final a0 a0Var = new a0(context == null ? b2.f0.l() : context, strM);
        if (!k()) {
            a0Var.j(string);
            s0Var.b();
            return;
        }
        h0 h0VarA = h0.f5683n.a(context, strM, string, b2.f0.w(), j10, null);
        h0VarA.g(new f0.b() { // from class: b3.d0
            @Override // r2.f0.b
            public final void a(Bundle bundle) throws NumberFormatException {
                e0.y(string, a0Var, s0Var, strM, bundle);
            }
        });
        a0Var.k(string);
        if (h0VarA.h()) {
            return;
        }
        a0Var.j(string);
        s0Var.b();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void y(String loggerRef, a0 logger, s0 responseCallback, String applicationId, Bundle bundle) throws NumberFormatException {
        kotlin.jvm.internal.m.g(loggerRef, "$loggerRef");
        kotlin.jvm.internal.m.g(logger, "$logger");
        kotlin.jvm.internal.m.g(responseCallback, "$responseCallback");
        kotlin.jvm.internal.m.g(applicationId, "$applicationId");
        if (bundle != null) {
            String string = bundle.getString("com.facebook.platform.status.ERROR_TYPE");
            String string2 = bundle.getString("com.facebook.platform.status.ERROR_DESCRIPTION");
            if (string != null) {
                f5652j.f(string, string2, loggerRef, logger, responseCallback);
                return;
            }
            String string3 = bundle.getString("com.facebook.platform.extra.ACCESS_TOKEN");
            r2.l0 l0Var = r2.l0.f20174a;
            Date dateW = r2.l0.w(bundle, "com.facebook.platform.extra.EXPIRES_SECONDS_SINCE_EPOCH", new Date(0L));
            ArrayList<String> stringArrayList = bundle.getStringArrayList("com.facebook.platform.extra.PERMISSIONS");
            String string4 = bundle.getString("signed request");
            String string5 = bundle.getString("graph_domain");
            Date dateW2 = r2.l0.w(bundle, "com.facebook.platform.extra.EXTRA_DATA_ACCESS_EXPIRATION_TIME", new Date(0L));
            String strE = string4 == null || string4.length() == 0 ? null : f0.f5669c.e(string4);
            if (!(string3 == null || string3.length() == 0)) {
                if (!(stringArrayList == null || stringArrayList.isEmpty())) {
                    if (!(strE == null || strE.length() == 0)) {
                        b2.a aVar = new b2.a(string3, applicationId, strE, stringArrayList, null, null, null, dateW, null, dateW2, string5);
                        b2.a.f5323l.h(aVar);
                        t0.f5559h.a();
                        logger.l(loggerRef);
                        responseCallback.a(aVar);
                        return;
                    }
                }
            }
        }
        logger.j(loggerRef);
        responseCallback.b();
    }

    private final void z(boolean z10) {
        SharedPreferences.Editor editorEdit = this.f5658c.edit();
        editorEdit.putBoolean("express_login_allowed", z10);
        editorEdit.apply();
    }

    public final e0 A(t loginBehavior) {
        kotlin.jvm.internal.m.g(loginBehavior, "loginBehavior");
        this.f5656a = loginBehavior;
        return this;
    }

    protected u.e g(v loginConfig) throws NoSuchAlgorithmException {
        String strA;
        kotlin.jvm.internal.m.g(loginConfig, "loginConfig");
        b3.a aVar = b3.a.S256;
        try {
            m0 m0Var = m0.f5728a;
            strA = m0.b(loginConfig.a(), aVar);
        } catch (b2.s unused) {
            aVar = b3.a.PLAIN;
            strA = loginConfig.a();
        }
        String str = strA;
        t tVar = this.f5656a;
        Set setL0 = uc.x.l0(loginConfig.c());
        e eVar = this.f5657b;
        String str2 = this.f5659d;
        b2.f0 f0Var = b2.f0.f5388a;
        String strM = b2.f0.m();
        String string = UUID.randomUUID().toString();
        kotlin.jvm.internal.m.f(string, "randomUUID().toString()");
        u.e eVar2 = new u.e(tVar, setL0, eVar, str2, strM, string, this.f5662g, loginConfig.b(), loginConfig.a(), str, aVar);
        eVar2.G(b2.a.f5323l.g());
        eVar2.E(this.f5660e);
        eVar2.H(this.f5661f);
        eVar2.D(this.f5663h);
        eVar2.I(this.f5664i);
        return eVar2;
    }

    protected Intent i(u.e request) {
        kotlin.jvm.internal.m.g(request, "request");
        Intent intent = new Intent();
        b2.f0 f0Var = b2.f0.f5388a;
        intent.setClass(b2.f0.l(), FacebookActivity.class);
        intent.setAction(request.q().toString());
        Bundle bundle = new Bundle();
        bundle.putParcelable("request", request);
        intent.putExtra("com.facebook.LoginFragment:Request", bundle);
        return intent;
    }

    public final void m(Activity activity, v loginConfig) throws NoSuchAlgorithmException {
        kotlin.jvm.internal.m.g(activity, "activity");
        kotlin.jvm.internal.m.g(loginConfig, "loginConfig");
        if (activity instanceof androidx.activity.result.d) {
            Log.w(f5654l, "You're calling logging in Facebook with an activity supports androidx activity result APIs. Please follow our document to upgrade to new APIs to avoid overriding onActivityResult().");
        }
        B(new a(activity), g(loginConfig));
    }

    public final void n(Activity activity, Collection<String> collection) throws NoSuchAlgorithmException {
        kotlin.jvm.internal.m.g(activity, "activity");
        m(activity, new v(collection, null, 2, null));
    }

    public void o() {
        b2.a.f5323l.h(null);
        b2.i.f5445f.a(null);
        t0.f5559h.c(null);
        z(false);
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x0053  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean q(int r16, android.content.Intent r17, b2.p<b3.g0> r18) {
        /*
            r15 = this;
            r0 = r16
            r1 = r17
            b3.u$f$a r2 = b3.u.f.a.ERROR
            r3 = 1
            r4 = 0
            r5 = 0
            if (r1 == 0) goto L48
            java.lang.Class<b3.u$f> r6 = b3.u.f.class
            java.lang.ClassLoader r6 = r6.getClassLoader()
            r1.setExtrasClassLoader(r6)
            java.lang.String r6 = "com.facebook.LoginFragment:Result"
            android.os.Parcelable r1 = r1.getParcelableExtra(r6)
            b3.u$f r1 = (b3.u.f) r1
            if (r1 == 0) goto L53
            b3.u$e r2 = r1.f5814f
            b3.u$f$a r6 = r1.f5809a
            r7 = -1
            if (r0 == r7) goto L2e
            if (r0 == 0) goto L2a
            r0 = r4
            r7 = r0
            goto L41
        L2a:
            r0 = r4
            r7 = r0
            r5 = 1
            goto L41
        L2e:
            b3.u$f$a r0 = b3.u.f.a.SUCCESS
            if (r6 != r0) goto L37
            b2.a r0 = r1.f5810b
            b2.i r7 = r1.f5811c
            goto L41
        L37:
            b2.o r0 = new b2.o
            java.lang.String r7 = r1.f5812d
            r0.<init>(r7)
            r7 = r4
            r4 = r0
            r0 = r7
        L41:
            java.util.Map<java.lang.String, java.lang.String> r1 = r1.f5815g
            r8 = r1
            r13 = r5
            r1 = r7
            r7 = r6
            goto L59
        L48:
            if (r0 != 0) goto L53
            b3.u$f$a r2 = b3.u.f.a.CANCEL
            r7 = r2
            r0 = r4
            r1 = r0
            r2 = r1
            r8 = r2
            r13 = 1
            goto L59
        L53:
            r7 = r2
            r0 = r4
            r1 = r0
            r2 = r1
            r8 = r2
            r13 = 0
        L59:
            if (r4 != 0) goto L66
            if (r0 != 0) goto L66
            if (r13 != 0) goto L66
            b2.s r4 = new b2.s
            java.lang.String r5 = "Unexpected call to LoginManager.onActivityResult"
            r4.<init>(r5)
        L66:
            r12 = r4
            r10 = 1
            r6 = 0
            r5 = r15
            r9 = r12
            r11 = r2
            r5.l(r6, r7, r8, r9, r10, r11)
            r8 = r15
            r9 = r0
            r10 = r1
            r14 = r18
            r8.h(r9, r10, r11, r12, r13, r14)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: b3.e0.q(int, android.content.Intent, b2.p):boolean");
    }

    public final void s(b2.n nVar, final b2.p<g0> pVar) {
        if (!(nVar instanceof r2.d)) {
            throw new b2.s("Unexpected CallbackManager, please use the provided Factory.");
        }
        ((r2.d) nVar).b(d.c.Login.b(), new d.a() { // from class: b3.c0
            @Override // r2.d.a
            public final boolean a(int i10, Intent intent) {
                return e0.t(this.f5636a, pVar, i10, intent);
            }
        });
    }

    public final void v(Context context, long j10, s0 responseCallback) {
        kotlin.jvm.internal.m.g(context, "context");
        kotlin.jvm.internal.m.g(responseCallback, "responseCallback");
        x(context, responseCallback, j10);
    }

    public final void w(Context context, s0 responseCallback) {
        kotlin.jvm.internal.m.g(context, "context");
        kotlin.jvm.internal.m.g(responseCallback, "responseCallback");
        v(context, 5000L, responseCallback);
    }
}
