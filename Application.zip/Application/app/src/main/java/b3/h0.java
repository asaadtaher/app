package b3;

import android.content.Context;
import android.os.Bundle;

/* loaded from: classes.dex */
public final class h0 extends r2.f0 {

    /* renamed from: n, reason: collision with root package name */
    public static final a f5683n = new a(null);

    /* renamed from: k, reason: collision with root package name */
    private final String f5684k;

    /* renamed from: l, reason: collision with root package name */
    private final String f5685l;

    /* renamed from: m, reason: collision with root package name */
    private final long f5686m;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final h0 a(Context context, String applicationId, String loggerRef, String graphApiVersion, long j10, String str) {
            kotlin.jvm.internal.m.g(context, "context");
            kotlin.jvm.internal.m.g(applicationId, "applicationId");
            kotlin.jvm.internal.m.g(loggerRef, "loggerRef");
            kotlin.jvm.internal.m.g(graphApiVersion, "graphApiVersion");
            return new h0(context, applicationId, loggerRef, graphApiVersion, j10, str);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h0(Context context, String applicationId, String loggerRef, String graphApiVersion, long j10, String str) {
        super(context, 65546, 65547, 20170411, applicationId, str);
        kotlin.jvm.internal.m.g(context, "context");
        kotlin.jvm.internal.m.g(applicationId, "applicationId");
        kotlin.jvm.internal.m.g(loggerRef, "loggerRef");
        kotlin.jvm.internal.m.g(graphApiVersion, "graphApiVersion");
        this.f5684k = loggerRef;
        this.f5685l = graphApiVersion;
        this.f5686m = j10;
    }

    @Override // r2.f0
    protected void e(Bundle data) {
        kotlin.jvm.internal.m.g(data, "data");
        data.putString("com.facebook.platform.extra.LOGGER_REF", this.f5684k);
        data.putString("com.facebook.platform.extra.GRAPH_API_VERSION", this.f5685l);
        data.putLong("com.facebook.platform.extra.EXTRA_TOAST_DURATION_MS", this.f5686m);
    }
}
