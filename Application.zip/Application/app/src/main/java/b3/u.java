package b3;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.fragment.app.Fragment;
import com.facebook.CustomTabMainActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;
import r2.d;

/* loaded from: classes.dex */
public class u implements Parcelable {

    /* renamed from: a, reason: collision with root package name */
    private f0[] f5777a;

    /* renamed from: b, reason: collision with root package name */
    private int f5778b;

    /* renamed from: c, reason: collision with root package name */
    private Fragment f5779c;

    /* renamed from: d, reason: collision with root package name */
    private d f5780d;

    /* renamed from: e, reason: collision with root package name */
    private a f5781e;

    /* renamed from: f, reason: collision with root package name */
    private boolean f5782f;

    /* renamed from: g, reason: collision with root package name */
    private e f5783g;

    /* renamed from: h, reason: collision with root package name */
    private Map<String, String> f5784h;

    /* renamed from: i, reason: collision with root package name */
    private Map<String, String> f5785i;

    /* renamed from: j, reason: collision with root package name */
    private a0 f5786j;

    /* renamed from: k, reason: collision with root package name */
    private int f5787k;

    /* renamed from: l, reason: collision with root package name */
    private int f5788l;

    /* renamed from: r, reason: collision with root package name */
    public static final c f5776r = new c(null);
    public static final Parcelable.Creator<u> CREATOR = new b();

    public interface a {
        void a();

        void b();
    }

    public static final class b implements Parcelable.Creator<u> {
        b() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public u createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new u(source);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public u[] newArray(int i10) {
            return new u[i10];
        }
    }

    public static final class c {
        private c() {
        }

        public /* synthetic */ c(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final String a() {
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("init", System.currentTimeMillis());
            } catch (JSONException unused) {
            }
            String string = jSONObject.toString();
            kotlin.jvm.internal.m.f(string, "e2e.toString()");
            return string;
        }

        public final int b() {
            return d.c.Login.b();
        }
    }

    public interface d {
        void a(f fVar);
    }

    public static final class e implements Parcelable {

        /* renamed from: a, reason: collision with root package name */
        private final t f5790a;

        /* renamed from: b, reason: collision with root package name */
        private Set<String> f5791b;

        /* renamed from: c, reason: collision with root package name */
        private final b3.e f5792c;

        /* renamed from: d, reason: collision with root package name */
        private final String f5793d;

        /* renamed from: e, reason: collision with root package name */
        private String f5794e;

        /* renamed from: f, reason: collision with root package name */
        private boolean f5795f;

        /* renamed from: g, reason: collision with root package name */
        private String f5796g;

        /* renamed from: h, reason: collision with root package name */
        private String f5797h;

        /* renamed from: i, reason: collision with root package name */
        private String f5798i;

        /* renamed from: j, reason: collision with root package name */
        private String f5799j;

        /* renamed from: k, reason: collision with root package name */
        private boolean f5800k;

        /* renamed from: l, reason: collision with root package name */
        private final i0 f5801l;

        /* renamed from: r, reason: collision with root package name */
        private boolean f5802r;

        /* renamed from: s, reason: collision with root package name */
        private boolean f5803s;

        /* renamed from: t, reason: collision with root package name */
        private final String f5804t;

        /* renamed from: u, reason: collision with root package name */
        private final String f5805u;

        /* renamed from: v, reason: collision with root package name */
        private final String f5806v;

        /* renamed from: w, reason: collision with root package name */
        private final b3.a f5807w;

        /* renamed from: x, reason: collision with root package name */
        public static final b f5789x = new b(null);
        public static final Parcelable.Creator<e> CREATOR = new a();

        public static final class a implements Parcelable.Creator<e> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public e createFromParcel(Parcel source) {
                kotlin.jvm.internal.m.g(source, "source");
                return new e(source, null);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public e[] newArray(int i10) {
                return new e[i10];
            }
        }

        public static final class b {
            private b() {
            }

            public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
                this();
            }
        }

        private e(Parcel parcel) {
            r2.m0 m0Var = r2.m0.f20185a;
            this.f5790a = t.valueOf(r2.m0.k(parcel.readString(), "loginBehavior"));
            ArrayList arrayList = new ArrayList();
            parcel.readStringList(arrayList);
            this.f5791b = new HashSet(arrayList);
            String string = parcel.readString();
            this.f5792c = string != null ? b3.e.valueOf(string) : b3.e.NONE;
            this.f5793d = r2.m0.k(parcel.readString(), "applicationId");
            this.f5794e = r2.m0.k(parcel.readString(), "authId");
            this.f5795f = parcel.readByte() != 0;
            this.f5796g = parcel.readString();
            this.f5797h = r2.m0.k(parcel.readString(), "authType");
            this.f5798i = parcel.readString();
            this.f5799j = parcel.readString();
            this.f5800k = parcel.readByte() != 0;
            String string2 = parcel.readString();
            this.f5801l = string2 != null ? i0.valueOf(string2) : i0.FACEBOOK;
            this.f5802r = parcel.readByte() != 0;
            this.f5803s = parcel.readByte() != 0;
            this.f5804t = r2.m0.k(parcel.readString(), "nonce");
            this.f5805u = parcel.readString();
            this.f5806v = parcel.readString();
            String string3 = parcel.readString();
            this.f5807w = string3 == null ? null : b3.a.valueOf(string3);
        }

        public /* synthetic */ e(Parcel parcel, kotlin.jvm.internal.g gVar) {
            this(parcel);
        }

        /* JADX WARN: Removed duplicated region for block: B:17:0x0046  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public e(b3.t r2, java.util.Set<java.lang.String> r3, b3.e r4, java.lang.String r5, java.lang.String r6, java.lang.String r7, b3.i0 r8, java.lang.String r9, java.lang.String r10, java.lang.String r11, b3.a r12) {
            /*
                r1 = this;
                java.lang.String r0 = "loginBehavior"
                kotlin.jvm.internal.m.g(r2, r0)
                java.lang.String r0 = "defaultAudience"
                kotlin.jvm.internal.m.g(r4, r0)
                java.lang.String r0 = "authType"
                kotlin.jvm.internal.m.g(r5, r0)
                java.lang.String r0 = "applicationId"
                kotlin.jvm.internal.m.g(r6, r0)
                java.lang.String r0 = "authId"
                kotlin.jvm.internal.m.g(r7, r0)
                r1.<init>()
                r1.f5790a = r2
                if (r3 != 0) goto L25
                java.util.HashSet r3 = new java.util.HashSet
                r3.<init>()
            L25:
                r1.f5791b = r3
                r1.f5792c = r4
                r1.f5797h = r5
                r1.f5793d = r6
                r1.f5794e = r7
                if (r8 != 0) goto L33
                b3.i0 r8 = b3.i0.FACEBOOK
            L33:
                r1.f5801l = r8
                if (r9 == 0) goto L46
                int r2 = r9.length()
                if (r2 != 0) goto L3f
                r2 = 1
                goto L40
            L3f:
                r2 = 0
            L40:
                if (r2 == 0) goto L43
                goto L46
            L43:
                r1.f5804t = r9
                goto L55
            L46:
                java.util.UUID r2 = java.util.UUID.randomUUID()
                java.lang.String r2 = r2.toString()
                java.lang.String r3 = "randomUUID().toString()"
                kotlin.jvm.internal.m.f(r2, r3)
                r1.f5804t = r2
            L55:
                r1.f5805u = r10
                r1.f5806v = r11
                r1.f5807w = r12
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: b3.u.e.<init>(b3.t, java.util.Set, b3.e, java.lang.String, java.lang.String, java.lang.String, b3.i0, java.lang.String, java.lang.String, java.lang.String, b3.a):void");
        }

        public final boolean A() {
            return this.f5802r;
        }

        public final boolean B() {
            return this.f5801l == i0.INSTAGRAM;
        }

        public final boolean C() {
            return this.f5795f;
        }

        public final void D(boolean z10) {
            this.f5802r = z10;
        }

        public final void E(String str) {
            this.f5799j = str;
        }

        public final void F(Set<String> set) {
            kotlin.jvm.internal.m.g(set, "<set-?>");
            this.f5791b = set;
        }

        public final void G(boolean z10) {
            this.f5795f = z10;
        }

        public final void H(boolean z10) {
            this.f5800k = z10;
        }

        public final void I(boolean z10) {
            this.f5803s = z10;
        }

        public final boolean J() {
            return this.f5803s;
        }

        public final String b() {
            return this.f5793d;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public final String h() {
            return this.f5794e;
        }

        public final String i() {
            return this.f5797h;
        }

        public final String j() {
            return this.f5806v;
        }

        public final b3.a k() {
            return this.f5807w;
        }

        public final String l() {
            return this.f5805u;
        }

        public final b3.e m() {
            return this.f5792c;
        }

        public final String n() {
            return this.f5798i;
        }

        public final String o() {
            return this.f5796g;
        }

        public final t q() {
            return this.f5790a;
        }

        public final i0 s() {
            return this.f5801l;
        }

        public final String v() {
            return this.f5799j;
        }

        public final String w() {
            return this.f5804t;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel dest, int i10) {
            kotlin.jvm.internal.m.g(dest, "dest");
            dest.writeString(this.f5790a.name());
            dest.writeStringList(new ArrayList(this.f5791b));
            dest.writeString(this.f5792c.name());
            dest.writeString(this.f5793d);
            dest.writeString(this.f5794e);
            dest.writeByte(this.f5795f ? (byte) 1 : (byte) 0);
            dest.writeString(this.f5796g);
            dest.writeString(this.f5797h);
            dest.writeString(this.f5798i);
            dest.writeString(this.f5799j);
            dest.writeByte(this.f5800k ? (byte) 1 : (byte) 0);
            dest.writeString(this.f5801l.name());
            dest.writeByte(this.f5802r ? (byte) 1 : (byte) 0);
            dest.writeByte(this.f5803s ? (byte) 1 : (byte) 0);
            dest.writeString(this.f5804t);
            dest.writeString(this.f5805u);
            dest.writeString(this.f5806v);
            b3.a aVar = this.f5807w;
            dest.writeString(aVar == null ? null : aVar.name());
        }

        public final Set<String> x() {
            return this.f5791b;
        }

        public final boolean y() {
            return this.f5800k;
        }

        public final boolean z() {
            Iterator<String> it = this.f5791b.iterator();
            while (it.hasNext()) {
                if (e0.f5652j.g(it.next())) {
                    return true;
                }
            }
            return false;
        }
    }

    public static final class f implements Parcelable {

        /* renamed from: a, reason: collision with root package name */
        public final a f5809a;

        /* renamed from: b, reason: collision with root package name */
        public final b2.a f5810b;

        /* renamed from: c, reason: collision with root package name */
        public final b2.i f5811c;

        /* renamed from: d, reason: collision with root package name */
        public final String f5812d;

        /* renamed from: e, reason: collision with root package name */
        public final String f5813e;

        /* renamed from: f, reason: collision with root package name */
        public final e f5814f;

        /* renamed from: g, reason: collision with root package name */
        public Map<String, String> f5815g;

        /* renamed from: h, reason: collision with root package name */
        public Map<String, String> f5816h;

        /* renamed from: i, reason: collision with root package name */
        public static final c f5808i = new c(null);
        public static final Parcelable.Creator<f> CREATOR = new b();

        public enum a {
            SUCCESS("success"),
            CANCEL("cancel"),
            ERROR("error");


            /* renamed from: a, reason: collision with root package name */
            private final String f5821a;

            a(String str) {
                this.f5821a = str;
            }

            /* renamed from: values, reason: to resolve conflict with enum method */
            public static a[] valuesCustom() {
                a[] aVarArrValuesCustom = values();
                return (a[]) Arrays.copyOf(aVarArrValuesCustom, aVarArrValuesCustom.length);
            }

            public final String b() {
                return this.f5821a;
            }
        }

        public static final class b implements Parcelable.Creator<f> {
            b() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public f createFromParcel(Parcel source) {
                kotlin.jvm.internal.m.g(source, "source");
                return new f(source, null);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public f[] newArray(int i10) {
                return new f[i10];
            }
        }

        public static final class c {
            private c() {
            }

            public /* synthetic */ c(kotlin.jvm.internal.g gVar) {
                this();
            }

            public static /* synthetic */ f d(c cVar, e eVar, String str, String str2, String str3, int i10, Object obj) {
                if ((i10 & 8) != 0) {
                    str3 = null;
                }
                return cVar.c(eVar, str, str2, str3);
            }

            public final f a(e eVar, String str) {
                return new f(eVar, a.CANCEL, null, str, null);
            }

            public final f b(e eVar, b2.a aVar, b2.i iVar) {
                return new f(eVar, a.SUCCESS, aVar, iVar, null, null);
            }

            public final f c(e eVar, String str, String str2, String str3) {
                ArrayList arrayList = new ArrayList();
                if (str != null) {
                    arrayList.add(str);
                }
                if (str2 != null) {
                    arrayList.add(str2);
                }
                return new f(eVar, a.ERROR, null, TextUtils.join(": ", arrayList), str3);
            }

            public final f e(e eVar, b2.a token) {
                kotlin.jvm.internal.m.g(token, "token");
                return new f(eVar, a.SUCCESS, token, null, null);
            }
        }

        private f(Parcel parcel) {
            String string = parcel.readString();
            this.f5809a = a.valueOf(string == null ? "error" : string);
            this.f5810b = (b2.a) parcel.readParcelable(b2.a.class.getClassLoader());
            this.f5811c = (b2.i) parcel.readParcelable(b2.i.class.getClassLoader());
            this.f5812d = parcel.readString();
            this.f5813e = parcel.readString();
            this.f5814f = (e) parcel.readParcelable(e.class.getClassLoader());
            r2.l0 l0Var = r2.l0.f20174a;
            this.f5815g = r2.l0.m0(parcel);
            this.f5816h = r2.l0.m0(parcel);
        }

        public /* synthetic */ f(Parcel parcel, kotlin.jvm.internal.g gVar) {
            this(parcel);
        }

        public f(e eVar, a code, b2.a aVar, b2.i iVar, String str, String str2) {
            kotlin.jvm.internal.m.g(code, "code");
            this.f5814f = eVar;
            this.f5810b = aVar;
            this.f5811c = iVar;
            this.f5812d = str;
            this.f5809a = code;
            this.f5813e = str2;
        }

        /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
        public f(e eVar, a code, b2.a aVar, String str, String str2) {
            this(eVar, code, aVar, null, str, str2);
            kotlin.jvm.internal.m.g(code, "code");
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel dest, int i10) {
            kotlin.jvm.internal.m.g(dest, "dest");
            dest.writeString(this.f5809a.name());
            dest.writeParcelable(this.f5810b, i10);
            dest.writeParcelable(this.f5811c, i10);
            dest.writeString(this.f5812d);
            dest.writeString(this.f5813e);
            dest.writeParcelable(this.f5814f, i10);
            r2.l0 l0Var = r2.l0.f20174a;
            r2.l0.B0(dest, this.f5815g);
            r2.l0.B0(dest, this.f5816h);
        }
    }

    public u(Parcel source) {
        kotlin.jvm.internal.m.g(source, "source");
        this.f5778b = -1;
        Parcelable[] parcelableArray = source.readParcelableArray(f0.class.getClassLoader());
        parcelableArray = parcelableArray == null ? new Parcelable[0] : parcelableArray;
        ArrayList arrayList = new ArrayList();
        int length = parcelableArray.length;
        int i10 = 0;
        while (true) {
            if (i10 >= length) {
                break;
            }
            Parcelable parcelable = parcelableArray[i10];
            f0 f0Var = parcelable instanceof f0 ? (f0) parcelable : null;
            if (f0Var != null) {
                f0Var.w(this);
            }
            if (f0Var != null) {
                arrayList.add(f0Var);
            }
            i10++;
        }
        Object[] array = arrayList.toArray(new f0[0]);
        Objects.requireNonNull(array, "null cannot be cast to non-null type kotlin.Array<T>");
        this.f5777a = (f0[]) array;
        this.f5778b = source.readInt();
        this.f5783g = (e) source.readParcelable(e.class.getClassLoader());
        r2.l0 l0Var = r2.l0.f20174a;
        Map<String, String> mapM0 = r2.l0.m0(source);
        this.f5784h = mapM0 == null ? null : uc.g0.n(mapM0);
        Map<String, String> mapM02 = r2.l0.m0(source);
        this.f5785i = mapM02 != null ? uc.g0.n(mapM02) : null;
    }

    public u(Fragment fragment) {
        kotlin.jvm.internal.m.g(fragment, "fragment");
        this.f5778b = -1;
        G(fragment);
    }

    private final void A(String str, String str2, String str3, String str4, Map<String, String> map) {
        e eVar = this.f5783g;
        if (eVar == null) {
            x().n("fb_mobile_login_method_complete", "Unexpected call to logCompleteLogin with null pendingAuthorizationRequest.", str);
        } else {
            x().c(eVar.h(), str, str2, str3, str4, map, eVar.A() ? "foa_mobile_login_method_complete" : "fb_mobile_login_method_complete");
        }
    }

    private final void D(f fVar) {
        d dVar = this.f5780d;
        if (dVar == null) {
            return;
        }
        dVar.a(fVar);
    }

    private final void b(String str, String str2, boolean z10) {
        Map<String, String> map = this.f5784h;
        if (map == null) {
            map = new HashMap<>();
        }
        if (this.f5784h == null) {
            this.f5784h = map;
        }
        if (map.containsKey(str) && z10) {
            str2 = ((Object) map.get(str)) + ',' + str2;
        }
        map.put(str, str2);
    }

    private final void n() {
        l(f.c.d(f.f5808i, this.f5783g, "Login attempt failed.", null, null, 8, null));
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0018  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final b3.a0 x() {
        /*
            r3 = this;
            b3.a0 r0 = r3.f5786j
            if (r0 == 0) goto L18
            java.lang.String r1 = r0.b()
            b3.u$e r2 = r3.f5783g
            if (r2 != 0) goto Le
            r2 = 0
            goto L12
        Le:
            java.lang.String r2 = r2.b()
        L12:
            boolean r1 = kotlin.jvm.internal.m.b(r1, r2)
            if (r1 != 0) goto L3a
        L18:
            b3.a0 r0 = new b3.a0
            androidx.fragment.app.s r1 = r3.o()
            if (r1 != 0) goto L26
            b2.f0 r1 = b2.f0.f5388a
            android.content.Context r1 = b2.f0.l()
        L26:
            b3.u$e r2 = r3.f5783g
            if (r2 != 0) goto L31
            b2.f0 r2 = b2.f0.f5388a
            java.lang.String r2 = b2.f0.m()
            goto L35
        L31:
            java.lang.String r2 = r2.b()
        L35:
            r0.<init>(r1, r2)
            r3.f5786j = r0
        L3a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: b3.u.x():b3.a0");
    }

    private final void z(String str, f fVar, Map<String, String> map) {
        A(str, fVar.f5809a.b(), fVar.f5812d, fVar.f5813e, map);
    }

    public final void B() {
        a aVar = this.f5781e;
        if (aVar == null) {
            return;
        }
        aVar.a();
    }

    public final void C() {
        a aVar = this.f5781e;
        if (aVar == null) {
            return;
        }
        aVar.b();
    }

    public final boolean E(int i10, int i11, Intent intent) {
        this.f5787k++;
        if (this.f5783g != null) {
            if (intent != null && intent.getBooleanExtra(CustomTabMainActivity.f6913j, false)) {
                K();
                return false;
            }
            f0 f0VarQ = q();
            if (f0VarQ != null && (!f0VarQ.x() || intent != null || this.f5787k >= this.f5788l)) {
                return f0VarQ.q(i10, i11, intent);
            }
        }
        return false;
    }

    public final void F(a aVar) {
        this.f5781e = aVar;
    }

    public final void G(Fragment fragment) {
        if (this.f5779c != null) {
            throw new b2.s("Can't set fragment once it is already set.");
        }
        this.f5779c = fragment;
    }

    public final void H(d dVar) {
        this.f5780d = dVar;
    }

    public final void I(e eVar) {
        if (w()) {
            return;
        }
        h(eVar);
    }

    public final boolean J() {
        f0 f0VarQ = q();
        if (f0VarQ == null) {
            return false;
        }
        if (f0VarQ.o() && !j()) {
            b("no_internet_permission", "1", false);
            return false;
        }
        e eVar = this.f5783g;
        if (eVar == null) {
            return false;
        }
        int iY = f0VarQ.y(eVar);
        this.f5787k = 0;
        a0 a0VarX = x();
        String strH = eVar.h();
        if (iY > 0) {
            a0VarX.e(strH, f0VarQ.l(), eVar.A() ? "foa_mobile_login_method_start" : "fb_mobile_login_method_start");
            this.f5788l = iY;
        } else {
            a0VarX.d(strH, f0VarQ.l(), eVar.A() ? "foa_mobile_login_method_not_tried" : "fb_mobile_login_method_not_tried");
            b("not_tried", f0VarQ.l(), true);
        }
        return iY > 0;
    }

    public final void K() {
        f0 f0VarQ = q();
        if (f0VarQ != null) {
            A(f0VarQ.l(), "skipped", null, null, f0VarQ.k());
        }
        f0[] f0VarArr = this.f5777a;
        while (f0VarArr != null) {
            int i10 = this.f5778b;
            if (i10 >= f0VarArr.length - 1) {
                break;
            }
            this.f5778b = i10 + 1;
            if (J()) {
                return;
            }
        }
        if (this.f5783g != null) {
            n();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x002e A[Catch: Exception -> 0x0041, TryCatch #0 {Exception -> 0x0041, blocks: (B:6:0x0013, B:8:0x0021, B:10:0x003d, B:9:0x002e), top: B:17:0x0013 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void L(b3.u.f r8) {
        /*
            r7 = this;
            java.lang.String r0 = "pendingResult"
            kotlin.jvm.internal.m.g(r8, r0)
            b2.a r0 = r8.f5810b
            if (r0 == 0) goto L58
            b2.a$c r0 = b2.a.f5323l
            b2.a r0 = r0.e()
            b2.a r1 = r8.f5810b
            if (r0 == 0) goto L2e
            java.lang.String r0 = r0.x()     // Catch: java.lang.Exception -> L41
            java.lang.String r1 = r1.x()     // Catch: java.lang.Exception -> L41
            boolean r0 = kotlin.jvm.internal.m.b(r0, r1)     // Catch: java.lang.Exception -> L41
            if (r0 == 0) goto L2e
            b3.u$f$c r0 = b3.u.f.f5808i     // Catch: java.lang.Exception -> L41
            b3.u$e r1 = r7.f5783g     // Catch: java.lang.Exception -> L41
            b2.a r2 = r8.f5810b     // Catch: java.lang.Exception -> L41
            b2.i r8 = r8.f5811c     // Catch: java.lang.Exception -> L41
            b3.u$f r8 = r0.b(r1, r2, r8)     // Catch: java.lang.Exception -> L41
            goto L3d
        L2e:
            b3.u$f$c r0 = b3.u.f.f5808i     // Catch: java.lang.Exception -> L41
            b3.u$e r1 = r7.f5783g     // Catch: java.lang.Exception -> L41
            java.lang.String r2 = "User logged in as different Facebook user."
            r3 = 0
            r4 = 0
            r5 = 8
            r6 = 0
            b3.u$f r8 = b3.u.f.c.d(r0, r1, r2, r3, r4, r5, r6)     // Catch: java.lang.Exception -> L41
        L3d:
            r7.l(r8)     // Catch: java.lang.Exception -> L41
            goto L57
        L41:
            r8 = move-exception
            b3.u$f$c r0 = b3.u.f.f5808i
            b3.u$e r1 = r7.f5783g
            java.lang.String r3 = r8.getMessage()
            r4 = 0
            r5 = 8
            r6 = 0
            java.lang.String r2 = "Caught exception"
            b3.u$f r8 = b3.u.f.c.d(r0, r1, r2, r3, r4, r5, r6)
            r7.l(r8)
        L57:
            return
        L58:
            b2.s r8 = new b2.s
            java.lang.String r0 = "Can't validate without a token"
            r8.<init>(r0)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: b3.u.L(b3.u$f):void");
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public final void h(e eVar) {
        if (eVar == null) {
            return;
        }
        if (this.f5783g != null) {
            throw new b2.s("Attempted to authorize while a request is pending.");
        }
        if (!b2.a.f5323l.g() || j()) {
            this.f5783g = eVar;
            this.f5777a = v(eVar);
            K();
        }
    }

    public final void i() {
        f0 f0VarQ = q();
        if (f0VarQ == null) {
            return;
        }
        f0VarQ.h();
    }

    public final boolean j() {
        if (this.f5782f) {
            return true;
        }
        if (k("android.permission.INTERNET") == 0) {
            this.f5782f = true;
            return true;
        }
        androidx.fragment.app.s sVarO = o();
        l(f.c.d(f.f5808i, this.f5783g, sVarO == null ? null : sVarO.getString(p2.d.f18838c), sVarO != null ? sVarO.getString(p2.d.f18837b) : null, null, 8, null));
        return false;
    }

    public final int k(String permission) {
        kotlin.jvm.internal.m.g(permission, "permission");
        androidx.fragment.app.s sVarO = o();
        if (sVarO == null) {
            return -1;
        }
        return sVarO.checkCallingOrSelfPermission(permission);
    }

    public final void l(f outcome) {
        kotlin.jvm.internal.m.g(outcome, "outcome");
        f0 f0VarQ = q();
        if (f0VarQ != null) {
            z(f0VarQ.l(), outcome, f0VarQ.k());
        }
        Map<String, String> map = this.f5784h;
        if (map != null) {
            outcome.f5815g = map;
        }
        Map<String, String> map2 = this.f5785i;
        if (map2 != null) {
            outcome.f5816h = map2;
        }
        this.f5777a = null;
        this.f5778b = -1;
        this.f5783g = null;
        this.f5784h = null;
        this.f5787k = 0;
        this.f5788l = 0;
        D(outcome);
    }

    public final void m(f outcome) {
        kotlin.jvm.internal.m.g(outcome, "outcome");
        if (outcome.f5810b == null || !b2.a.f5323l.g()) {
            l(outcome);
        } else {
            L(outcome);
        }
    }

    public final androidx.fragment.app.s o() {
        Fragment fragment = this.f5779c;
        if (fragment == null) {
            return null;
        }
        return fragment.getActivity();
    }

    public final f0 q() {
        f0[] f0VarArr;
        int i10 = this.f5778b;
        if (i10 < 0 || (f0VarArr = this.f5777a) == null) {
            return null;
        }
        return f0VarArr[i10];
    }

    public final Fragment s() {
        return this.f5779c;
    }

    public f0[] v(e request) {
        Parcelable sVar;
        kotlin.jvm.internal.m.g(request, "request");
        ArrayList arrayList = new ArrayList();
        t tVarQ = request.q();
        if (!request.B()) {
            if (tVarQ.d()) {
                arrayList.add(new q(this));
            }
            if (!b2.f0.f5406s && tVarQ.f()) {
                sVar = new s(this);
                arrayList.add(sVar);
            }
        } else if (!b2.f0.f5406s && tVarQ.e()) {
            sVar = new r(this);
            arrayList.add(sVar);
        }
        if (tVarQ.b()) {
            arrayList.add(new b3.c(this));
        }
        if (tVarQ.g()) {
            arrayList.add(new p0(this));
        }
        if (!request.B() && tVarQ.c()) {
            arrayList.add(new n(this));
        }
        Object[] array = arrayList.toArray(new f0[0]);
        Objects.requireNonNull(array, "null cannot be cast to non-null type kotlin.Array<T>");
        return (f0[]) array;
    }

    public final boolean w() {
        return this.f5783g != null && this.f5778b >= 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int i10) {
        kotlin.jvm.internal.m.g(dest, "dest");
        dest.writeParcelableArray(this.f5777a, i10);
        dest.writeInt(this.f5778b);
        dest.writeParcelable(this.f5783g, i10);
        r2.l0 l0Var = r2.l0.f20174a;
        r2.l0.B0(dest, this.f5784h);
        r2.l0.B0(dest, this.f5785i);
    }

    public final e y() {
        return this.f5783g;
    }
}
