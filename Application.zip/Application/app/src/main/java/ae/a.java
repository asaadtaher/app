package ae;

import java.net.Authenticator;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.SocketAddress;
import java.util.List;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;
import md.p;
import uc.x;
import yd.b;
import yd.b0;
import yd.d0;
import yd.f0;
import yd.h;
import yd.o;
import yd.q;
import yd.v;

/* loaded from: classes2.dex */
public final class a implements b {

    /* renamed from: d, reason: collision with root package name */
    private final q f395d;

    /* renamed from: ae.a$a, reason: collision with other inner class name */
    public /* synthetic */ class C0006a {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f396a;

        static {
            int[] iArr = new int[Proxy.Type.values().length];
            try {
                iArr[Proxy.Type.DIRECT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            f396a = iArr;
        }
    }

    public a(q defaultDns) {
        m.g(defaultDns, "defaultDns");
        this.f395d = defaultDns;
    }

    public /* synthetic */ a(q qVar, int i10, g gVar) {
        this((i10 & 1) != 0 ? q.f24646b : qVar);
    }

    private final InetAddress b(Proxy proxy, v vVar, q qVar) {
        Proxy.Type type = proxy.type();
        if ((type == null ? -1 : C0006a.f396a[type.ordinal()]) == 1) {
            return (InetAddress) x.I(qVar.a(vVar.i()));
        }
        SocketAddress socketAddressAddress = proxy.address();
        m.e(socketAddressAddress, "null cannot be cast to non-null type java.net.InetSocketAddress");
        InetAddress address = ((InetSocketAddress) socketAddressAddress).getAddress();
        m.f(address, "address() as InetSocketAddress).address");
        return address;
    }

    @Override // yd.b
    public b0 a(f0 f0Var, d0 response) {
        Proxy proxy;
        q qVarC;
        PasswordAuthentication passwordAuthenticationRequestPasswordAuthentication;
        yd.a aVarA;
        m.g(response, "response");
        List<h> listK = response.k();
        b0 b0VarM0 = response.m0();
        v vVarJ = b0VarM0.j();
        boolean z10 = response.m() == 407;
        if (f0Var == null || (proxy = f0Var.b()) == null) {
            proxy = Proxy.NO_PROXY;
        }
        for (h hVar : listK) {
            if (p.q("Basic", hVar.c(), true)) {
                if (f0Var == null || (aVarA = f0Var.a()) == null || (qVarC = aVarA.c()) == null) {
                    qVarC = this.f395d;
                }
                if (z10) {
                    SocketAddress socketAddressAddress = proxy.address();
                    m.e(socketAddressAddress, "null cannot be cast to non-null type java.net.InetSocketAddress");
                    InetSocketAddress inetSocketAddress = (InetSocketAddress) socketAddressAddress;
                    String hostName = inetSocketAddress.getHostName();
                    m.f(proxy, "proxy");
                    passwordAuthenticationRequestPasswordAuthentication = Authenticator.requestPasswordAuthentication(hostName, b(proxy, vVarJ, qVarC), inetSocketAddress.getPort(), vVarJ.r(), hVar.b(), hVar.c(), vVarJ.t(), Authenticator.RequestorType.PROXY);
                } else {
                    String strI = vVarJ.i();
                    m.f(proxy, "proxy");
                    passwordAuthenticationRequestPasswordAuthentication = Authenticator.requestPasswordAuthentication(strI, b(proxy, vVarJ, qVarC), vVarJ.n(), vVarJ.r(), hVar.b(), hVar.c(), vVarJ.t(), Authenticator.RequestorType.SERVER);
                }
                if (passwordAuthenticationRequestPasswordAuthentication != null) {
                    String str = z10 ? "Proxy-Authorization" : "Authorization";
                    String userName = passwordAuthenticationRequestPasswordAuthentication.getUserName();
                    m.f(userName, "auth.userName");
                    char[] password = passwordAuthenticationRequestPasswordAuthentication.getPassword();
                    m.f(password, "auth.password");
                    return b0VarM0.h().c(str, o.a(userName, new String(password), hVar.a())).b();
                }
            }
        }
        return null;
    }
}
