package b5;

/* loaded from: classes.dex */
public abstract class a implements d {
    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }
}
