package b5;

import android.content.Intent;
import android.os.Parcel;

/* loaded from: classes.dex */
public final class e {
    public static <T extends d> byte[] a(T t10) {
        Parcel parcelObtain = Parcel.obtain();
        t10.writeToParcel(parcelObtain, 0);
        byte[] bArrMarshall = parcelObtain.marshall();
        parcelObtain.recycle();
        return bArrMarshall;
    }

    public static <T extends d> void b(T t10, Intent intent, String str) {
        intent.putExtra(str, a(t10));
    }
}
