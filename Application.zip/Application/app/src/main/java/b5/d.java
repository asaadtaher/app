package b5;

import android.os.Parcelable;

/* loaded from: classes.dex */
public interface d extends Parcelable {
    public static final String NULL = "SAFE_PARCELABLE_NULL_STRING";
}
