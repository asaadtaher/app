package bd;

import hd.c;

/* loaded from: classes2.dex */
public class a extends ad.a {

    /* renamed from: bd.a$a, reason: collision with other inner class name */
    private static final class C0093a {

        /* renamed from: a, reason: collision with root package name */
        public static final C0093a f6087a = new C0093a();

        /* renamed from: b, reason: collision with root package name */
        public static final Integer f6088b;

        static {
            Object obj;
            Integer num = null;
            try {
                obj = Class.forName("android.os.Build$VERSION").getField("SDK_INT").get(null);
            } catch (Throwable unused) {
            }
            Integer num2 = obj instanceof Integer ? (Integer) obj : null;
            if (num2 != null) {
                if (num2.intValue() > 0) {
                    num = num2;
                }
            }
            f6088b = num;
        }

        private C0093a() {
        }
    }

    private final boolean c(int i10) {
        Integer num = C0093a.f6088b;
        return num == null || num.intValue() >= i10;
    }

    @Override // zc.a
    public c b() {
        return c(34) ? new id.a() : super.b();
    }
}
