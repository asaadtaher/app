package c9;

import b6.i;

/* loaded from: classes.dex */
public interface e {
    i<String> a();

    i<com.google.firebase.installations.g> b(boolean z10);
}
