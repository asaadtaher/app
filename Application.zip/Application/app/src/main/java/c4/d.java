package c4;

/* loaded from: classes.dex */
public interface d {
    m create(h hVar);
}
