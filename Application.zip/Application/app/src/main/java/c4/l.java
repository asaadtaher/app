package c4;

import android.content.Context;

/* loaded from: classes.dex */
public final class l implements d4.b<k> {

    /* renamed from: a, reason: collision with root package name */
    private final sc.a<Context> f6286a;

    /* renamed from: b, reason: collision with root package name */
    private final sc.a<i> f6287b;

    public l(sc.a<Context> aVar, sc.a<i> aVar2) {
        this.f6286a = aVar;
        this.f6287b = aVar2;
    }

    public static l a(sc.a<Context> aVar, sc.a<i> aVar2) {
        return new l(aVar, aVar2);
    }

    public static k c(Context context, Object obj) {
        return new k(context, (i) obj);
    }

    @Override // sc.a
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public k get() {
        return c(this.f6286a.get(), this.f6287b.get());
    }
}
