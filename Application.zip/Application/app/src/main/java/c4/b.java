package c4;

import c4.g;
import java.util.Objects;

/* loaded from: classes.dex */
final class b extends g {

    /* renamed from: a, reason: collision with root package name */
    private final g.a f6264a;

    /* renamed from: b, reason: collision with root package name */
    private final long f6265b;

    b(g.a aVar, long j10) {
        Objects.requireNonNull(aVar, "Null status");
        this.f6264a = aVar;
        this.f6265b = j10;
    }

    @Override // c4.g
    public long b() {
        return this.f6265b;
    }

    @Override // c4.g
    public g.a c() {
        return this.f6264a;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof g)) {
            return false;
        }
        g gVar = (g) obj;
        return this.f6264a.equals(gVar.c()) && this.f6265b == gVar.b();
    }

    public int hashCode() {
        int iHashCode = (this.f6264a.hashCode() ^ 1000003) * 1000003;
        long j10 = this.f6265b;
        return iHashCode ^ ((int) (j10 ^ (j10 >>> 32)));
    }

    public String toString() {
        return "BackendResponse{status=" + this.f6264a + ", nextRequestWaitMillis=" + this.f6265b + "}";
    }
}
