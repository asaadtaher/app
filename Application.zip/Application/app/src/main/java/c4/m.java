package c4;

/* loaded from: classes.dex */
public interface m {
    b4.i a(b4.i iVar);

    g b(f fVar);
}
