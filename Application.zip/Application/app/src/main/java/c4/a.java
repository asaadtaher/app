package c4;

import c4.f;
import java.util.Arrays;
import java.util.Objects;

/* loaded from: classes.dex */
final class a extends f {

    /* renamed from: a, reason: collision with root package name */
    private final Iterable<b4.i> f6260a;

    /* renamed from: b, reason: collision with root package name */
    private final byte[] f6261b;

    static final class b extends f.a {

        /* renamed from: a, reason: collision with root package name */
        private Iterable<b4.i> f6262a;

        /* renamed from: b, reason: collision with root package name */
        private byte[] f6263b;

        b() {
        }

        @Override // c4.f.a
        public f a() {
            String str = "";
            if (this.f6262a == null) {
                str = " events";
            }
            if (str.isEmpty()) {
                return new a(this.f6262a, this.f6263b);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // c4.f.a
        public f.a b(Iterable<b4.i> iterable) {
            Objects.requireNonNull(iterable, "Null events");
            this.f6262a = iterable;
            return this;
        }

        @Override // c4.f.a
        public f.a c(byte[] bArr) {
            this.f6263b = bArr;
            return this;
        }
    }

    private a(Iterable<b4.i> iterable, byte[] bArr) {
        this.f6260a = iterable;
        this.f6261b = bArr;
    }

    @Override // c4.f
    public Iterable<b4.i> b() {
        return this.f6260a;
    }

    @Override // c4.f
    public byte[] c() {
        return this.f6261b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        if (this.f6260a.equals(fVar.b())) {
            if (Arrays.equals(this.f6261b, fVar instanceof a ? ((a) fVar).f6261b : fVar.c())) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return ((this.f6260a.hashCode() ^ 1000003) * 1000003) ^ Arrays.hashCode(this.f6261b);
    }

    public String toString() {
        return "BackendRequest{events=" + this.f6260a + ", extras=" + Arrays.toString(this.f6261b) + "}";
    }
}
