package c4;

import android.content.Context;
import java.util.Objects;

/* loaded from: classes.dex */
final class c extends h {

    /* renamed from: a, reason: collision with root package name */
    private final Context f6266a;

    /* renamed from: b, reason: collision with root package name */
    private final l4.a f6267b;

    /* renamed from: c, reason: collision with root package name */
    private final l4.a f6268c;

    /* renamed from: d, reason: collision with root package name */
    private final String f6269d;

    c(Context context, l4.a aVar, l4.a aVar2, String str) {
        Objects.requireNonNull(context, "Null applicationContext");
        this.f6266a = context;
        Objects.requireNonNull(aVar, "Null wallClock");
        this.f6267b = aVar;
        Objects.requireNonNull(aVar2, "Null monotonicClock");
        this.f6268c = aVar2;
        Objects.requireNonNull(str, "Null backendName");
        this.f6269d = str;
    }

    @Override // c4.h
    public Context b() {
        return this.f6266a;
    }

    @Override // c4.h
    public String c() {
        return this.f6269d;
    }

    @Override // c4.h
    public l4.a d() {
        return this.f6268c;
    }

    @Override // c4.h
    public l4.a e() {
        return this.f6267b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof h)) {
            return false;
        }
        h hVar = (h) obj;
        return this.f6266a.equals(hVar.b()) && this.f6267b.equals(hVar.e()) && this.f6268c.equals(hVar.d()) && this.f6269d.equals(hVar.c());
    }

    public int hashCode() {
        return ((((((this.f6266a.hashCode() ^ 1000003) * 1000003) ^ this.f6267b.hashCode()) * 1000003) ^ this.f6268c.hashCode()) * 1000003) ^ this.f6269d.hashCode();
    }

    public String toString() {
        return "CreationContext{applicationContext=" + this.f6266a + ", wallClock=" + this.f6267b + ", monotonicClock=" + this.f6268c + ", backendName=" + this.f6269d + "}";
    }
}
