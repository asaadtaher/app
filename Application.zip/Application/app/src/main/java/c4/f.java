package c4;

import c4.a;

/* loaded from: classes.dex */
public abstract class f {

    public static abstract class a {
        public abstract f a();

        public abstract a b(Iterable<b4.i> iterable);

        public abstract a c(byte[] bArr);
    }

    public static a a() {
        return new a.b();
    }

    public abstract Iterable<b4.i> b();

    public abstract byte[] c();
}
