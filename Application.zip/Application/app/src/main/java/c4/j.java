package c4;

import android.content.Context;

/* loaded from: classes.dex */
public final class j implements d4.b<i> {

    /* renamed from: a, reason: collision with root package name */
    private final sc.a<Context> f6278a;

    /* renamed from: b, reason: collision with root package name */
    private final sc.a<l4.a> f6279b;

    /* renamed from: c, reason: collision with root package name */
    private final sc.a<l4.a> f6280c;

    public j(sc.a<Context> aVar, sc.a<l4.a> aVar2, sc.a<l4.a> aVar3) {
        this.f6278a = aVar;
        this.f6279b = aVar2;
        this.f6280c = aVar3;
    }

    public static j a(sc.a<Context> aVar, sc.a<l4.a> aVar2, sc.a<l4.a> aVar3) {
        return new j(aVar, aVar2, aVar3);
    }

    public static i c(Context context, l4.a aVar, l4.a aVar2) {
        return new i(context, aVar, aVar2);
    }

    @Override // sc.a
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public i get() {
        return c(this.f6278a.get(), this.f6279b.get(), this.f6280c.get());
    }
}
