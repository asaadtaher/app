package c4;

import android.content.Context;

/* loaded from: classes.dex */
public abstract class h {
    public static h a(Context context, l4.a aVar, l4.a aVar2, String str) {
        return new c(context, aVar, aVar2, str);
    }

    public abstract Context b();

    public abstract String c();

    public abstract l4.a d();

    public abstract l4.a e();
}
