package c4;

import android.content.Context;

/* loaded from: classes.dex */
class i {

    /* renamed from: a, reason: collision with root package name */
    private final Context f6275a;

    /* renamed from: b, reason: collision with root package name */
    private final l4.a f6276b;

    /* renamed from: c, reason: collision with root package name */
    private final l4.a f6277c;

    i(Context context, l4.a aVar, l4.a aVar2) {
        this.f6275a = context;
        this.f6276b = aVar;
        this.f6277c = aVar2;
    }

    h a(String str) {
        return h.a(this.f6275a, this.f6276b, this.f6277c, str);
    }
}
