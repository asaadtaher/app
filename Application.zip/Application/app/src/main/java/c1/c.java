package c1;

import android.os.Binder;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.util.Log;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.dex */
abstract class c<Params, Progress, Result> {

    /* renamed from: f, reason: collision with root package name */
    private static final ThreadFactory f6127f;

    /* renamed from: g, reason: collision with root package name */
    private static final BlockingQueue<Runnable> f6128g;

    /* renamed from: h, reason: collision with root package name */
    public static final Executor f6129h;

    /* renamed from: i, reason: collision with root package name */
    private static f f6130i;

    /* renamed from: j, reason: collision with root package name */
    private static volatile Executor f6131j;

    /* renamed from: a, reason: collision with root package name */
    private final h<Params, Result> f6132a;

    /* renamed from: b, reason: collision with root package name */
    private final FutureTask<Result> f6133b;

    /* renamed from: c, reason: collision with root package name */
    private volatile g f6134c = g.PENDING;

    /* renamed from: d, reason: collision with root package name */
    final AtomicBoolean f6135d = new AtomicBoolean();

    /* renamed from: e, reason: collision with root package name */
    final AtomicBoolean f6136e = new AtomicBoolean();

    static class a implements ThreadFactory {

        /* renamed from: a, reason: collision with root package name */
        private final AtomicInteger f6137a = new AtomicInteger(1);

        a() {
        }

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(Runnable runnable) {
            return new Thread(runnable, "ModernAsyncTask #" + this.f6137a.getAndIncrement());
        }
    }

    class b extends h<Params, Result> {
        b() {
        }

        @Override // java.util.concurrent.Callable
        public Result call() {
            c.this.f6136e.set(true);
            Result result = null;
            try {
                Process.setThreadPriority(10);
                result = (Result) c.this.b(this.f6147a);
                Binder.flushPendingCommands();
                return result;
            } finally {
            }
        }
    }

    /* renamed from: c1.c$c, reason: collision with other inner class name */
    class C0100c extends FutureTask<Result> {
        C0100c(Callable callable) {
            super(callable);
        }

        @Override // java.util.concurrent.FutureTask
        protected void done() {
            try {
                c.this.m(get());
            } catch (InterruptedException e10) {
                Log.w("AsyncTask", e10);
            } catch (CancellationException unused) {
                c.this.m(null);
            } catch (ExecutionException e11) {
                throw new RuntimeException("An error occurred while executing doInBackground()", e11.getCause());
            } catch (Throwable th) {
                throw new RuntimeException("An error occurred while executing doInBackground()", th);
            }
        }
    }

    static /* synthetic */ class d {

        /* renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f6140a;

        static {
            int[] iArr = new int[g.values().length];
            f6140a = iArr;
            try {
                iArr[g.RUNNING.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f6140a[g.FINISHED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    private static class e<Data> {

        /* renamed from: a, reason: collision with root package name */
        final c f6141a;

        /* renamed from: b, reason: collision with root package name */
        final Data[] f6142b;

        e(c cVar, Data... dataArr) {
            this.f6141a = cVar;
            this.f6142b = dataArr;
        }
    }

    private static class f extends Handler {
        f() {
            super(Looper.getMainLooper());
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // android.os.Handler
        public void handleMessage(Message message) {
            e eVar = (e) message.obj;
            int i10 = message.what;
            if (i10 == 1) {
                eVar.f6141a.d(eVar.f6142b[0]);
            } else {
                if (i10 != 2) {
                    return;
                }
                eVar.f6141a.k(eVar.f6142b);
            }
        }
    }

    public enum g {
        PENDING,
        RUNNING,
        FINISHED
    }

    private static abstract class h<Params, Result> implements Callable<Result> {

        /* renamed from: a, reason: collision with root package name */
        Params[] f6147a;

        h() {
        }
    }

    static {
        a aVar = new a();
        f6127f = aVar;
        LinkedBlockingQueue linkedBlockingQueue = new LinkedBlockingQueue(10);
        f6128g = linkedBlockingQueue;
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(5, 128, 1L, TimeUnit.SECONDS, linkedBlockingQueue, aVar);
        f6129h = threadPoolExecutor;
        f6131j = threadPoolExecutor;
    }

    c() {
        b bVar = new b();
        this.f6132a = bVar;
        this.f6133b = new C0100c(bVar);
    }

    private static Handler e() {
        f fVar;
        synchronized (c.class) {
            if (f6130i == null) {
                f6130i = new f();
            }
            fVar = f6130i;
        }
        return fVar;
    }

    public final boolean a(boolean z10) {
        this.f6135d.set(true);
        return this.f6133b.cancel(z10);
    }

    protected abstract Result b(Params... paramsArr);

    public final c<Params, Progress, Result> c(Executor executor, Params... paramsArr) {
        if (this.f6134c == g.PENDING) {
            this.f6134c = g.RUNNING;
            j();
            this.f6132a.f6147a = paramsArr;
            executor.execute(this.f6133b);
            return this;
        }
        int i10 = d.f6140a[this.f6134c.ordinal()];
        if (i10 == 1) {
            throw new IllegalStateException("Cannot execute task: the task is already running.");
        }
        if (i10 != 2) {
            throw new IllegalStateException("We should never reach this state");
        }
        throw new IllegalStateException("Cannot execute task: the task has already been executed (a task can be executed only once)");
    }

    void d(Result result) {
        if (f()) {
            h(result);
        } else {
            i(result);
        }
        this.f6134c = g.FINISHED;
    }

    public final boolean f() {
        return this.f6135d.get();
    }

    protected void g() {
    }

    protected void h(Result result) {
        g();
    }

    protected void i(Result result) {
    }

    protected void j() {
    }

    protected void k(Progress... progressArr) {
    }

    Result l(Result result) {
        e().obtainMessage(1, new e(this, result)).sendToTarget();
        return result;
    }

    void m(Result result) {
        if (this.f6136e.get()) {
            return;
        }
        l(result);
    }
}
