package c1;

import android.content.Context;
import android.os.Handler;
import android.os.SystemClock;
import androidx.core.os.n;
import androidx.core.util.j;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public abstract class a<D> extends b<D> {

    /* renamed from: j, reason: collision with root package name */
    private final Executor f6109j;

    /* renamed from: k, reason: collision with root package name */
    volatile a<D>.RunnableC0098a f6110k;

    /* renamed from: l, reason: collision with root package name */
    volatile a<D>.RunnableC0098a f6111l;

    /* renamed from: m, reason: collision with root package name */
    long f6112m;

    /* renamed from: n, reason: collision with root package name */
    long f6113n;

    /* renamed from: o, reason: collision with root package name */
    Handler f6114o;

    /* renamed from: c1.a$a, reason: collision with other inner class name */
    final class RunnableC0098a extends c<Void, Void, D> implements Runnable {

        /* renamed from: k, reason: collision with root package name */
        private final CountDownLatch f6115k = new CountDownLatch(1);

        /* renamed from: l, reason: collision with root package name */
        boolean f6116l;

        RunnableC0098a() {
        }

        @Override // c1.c
        protected void h(D d10) {
            try {
                a.this.y(this, d10);
            } finally {
                this.f6115k.countDown();
            }
        }

        @Override // c1.c
        protected void i(D d10) {
            try {
                a.this.z(this, d10);
            } finally {
                this.f6115k.countDown();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // c1.c
        /* renamed from: n, reason: merged with bridge method [inline-methods] */
        public D b(Void... voidArr) {
            try {
                return (D) a.this.D();
            } catch (n e10) {
                if (f()) {
                    return null;
                }
                throw e10;
            }
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f6116l = false;
            a.this.A();
        }
    }

    public a(Context context) {
        this(context, c.f6129h);
    }

    private a(Context context, Executor executor) {
        super(context);
        this.f6113n = -10000L;
        this.f6109j = executor;
    }

    void A() {
        if (this.f6111l != null || this.f6110k == null) {
            return;
        }
        if (this.f6110k.f6116l) {
            this.f6110k.f6116l = false;
            this.f6114o.removeCallbacks(this.f6110k);
        }
        if (this.f6112m <= 0 || SystemClock.uptimeMillis() >= this.f6113n + this.f6112m) {
            this.f6110k.c(this.f6109j, null);
        } else {
            this.f6110k.f6116l = true;
            this.f6114o.postAtTime(this.f6110k, this.f6113n + this.f6112m);
        }
    }

    public abstract D B();

    public void C(D d10) {
    }

    protected D D() {
        return B();
    }

    @Override // c1.b
    @Deprecated
    public void h(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.h(str, fileDescriptor, printWriter, strArr);
        if (this.f6110k != null) {
            printWriter.print(str);
            printWriter.print("mTask=");
            printWriter.print(this.f6110k);
            printWriter.print(" waiting=");
            printWriter.println(this.f6110k.f6116l);
        }
        if (this.f6111l != null) {
            printWriter.print(str);
            printWriter.print("mCancellingTask=");
            printWriter.print(this.f6111l);
            printWriter.print(" waiting=");
            printWriter.println(this.f6111l.f6116l);
        }
        if (this.f6112m != 0) {
            printWriter.print(str);
            printWriter.print("mUpdateThrottle=");
            j.c(this.f6112m, printWriter);
            printWriter.print(" mLastLoadCompleteTime=");
            j.b(this.f6113n, SystemClock.uptimeMillis(), printWriter);
            printWriter.println();
        }
    }

    @Override // c1.b
    protected boolean l() {
        if (this.f6110k == null) {
            return false;
        }
        if (!this.f6122e) {
            this.f6125h = true;
        }
        if (this.f6111l != null) {
            if (this.f6110k.f6116l) {
                this.f6110k.f6116l = false;
                this.f6114o.removeCallbacks(this.f6110k);
            }
            this.f6110k = null;
            return false;
        }
        if (this.f6110k.f6116l) {
            this.f6110k.f6116l = false;
            this.f6114o.removeCallbacks(this.f6110k);
            this.f6110k = null;
            return false;
        }
        boolean zA = this.f6110k.a(false);
        if (zA) {
            this.f6111l = this.f6110k;
            x();
        }
        this.f6110k = null;
        return zA;
    }

    @Override // c1.b
    protected void n() {
        super.n();
        c();
        this.f6110k = new RunnableC0098a();
        A();
    }

    public void x() {
    }

    void y(a<D>.RunnableC0098a runnableC0098a, D d10) {
        C(d10);
        if (this.f6111l == runnableC0098a) {
            t();
            this.f6113n = SystemClock.uptimeMillis();
            this.f6111l = null;
            f();
            A();
        }
    }

    void z(a<D>.RunnableC0098a runnableC0098a, D d10) {
        if (this.f6110k != runnableC0098a) {
            y(runnableC0098a, d10);
            return;
        }
        if (j()) {
            C(d10);
            return;
        }
        d();
        this.f6113n = SystemClock.uptimeMillis();
        this.f6110k = null;
        g(d10);
    }
}
