package c1;

import android.content.Context;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* loaded from: classes.dex */
public class b<D> {

    /* renamed from: a, reason: collision with root package name */
    int f6118a;

    /* renamed from: b, reason: collision with root package name */
    InterfaceC0099b<D> f6119b;

    /* renamed from: c, reason: collision with root package name */
    a<D> f6120c;

    /* renamed from: d, reason: collision with root package name */
    Context f6121d;

    /* renamed from: e, reason: collision with root package name */
    boolean f6122e = false;

    /* renamed from: f, reason: collision with root package name */
    boolean f6123f = false;

    /* renamed from: g, reason: collision with root package name */
    boolean f6124g = true;

    /* renamed from: h, reason: collision with root package name */
    boolean f6125h = false;

    /* renamed from: i, reason: collision with root package name */
    boolean f6126i = false;

    public interface a<D> {
        void a(b<D> bVar);
    }

    /* renamed from: c1.b$b, reason: collision with other inner class name */
    public interface InterfaceC0099b<D> {
        void a(b<D> bVar, D d10);
    }

    public b(Context context) {
        this.f6121d = context.getApplicationContext();
    }

    public void b() {
        this.f6123f = true;
        k();
    }

    public boolean c() {
        return l();
    }

    public void d() {
        this.f6126i = false;
    }

    public String e(D d10) {
        StringBuilder sb2 = new StringBuilder(64);
        androidx.core.util.b.a(d10, sb2);
        sb2.append("}");
        return sb2.toString();
    }

    public void f() {
        a<D> aVar = this.f6120c;
        if (aVar != null) {
            aVar.a(this);
        }
    }

    public void g(D d10) {
        InterfaceC0099b<D> interfaceC0099b = this.f6119b;
        if (interfaceC0099b != null) {
            interfaceC0099b.a(this, d10);
        }
    }

    @Deprecated
    public void h(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mId=");
        printWriter.print(this.f6118a);
        printWriter.print(" mListener=");
        printWriter.println(this.f6119b);
        if (this.f6122e || this.f6125h || this.f6126i) {
            printWriter.print(str);
            printWriter.print("mStarted=");
            printWriter.print(this.f6122e);
            printWriter.print(" mContentChanged=");
            printWriter.print(this.f6125h);
            printWriter.print(" mProcessingChange=");
            printWriter.println(this.f6126i);
        }
        if (this.f6123f || this.f6124g) {
            printWriter.print(str);
            printWriter.print("mAbandoned=");
            printWriter.print(this.f6123f);
            printWriter.print(" mReset=");
            printWriter.println(this.f6124g);
        }
    }

    public void i() {
        n();
    }

    public boolean j() {
        return this.f6123f;
    }

    protected void k() {
    }

    protected boolean l() {
        throw null;
    }

    public void m() {
        if (this.f6122e) {
            i();
        } else {
            this.f6125h = true;
        }
    }

    protected void n() {
    }

    protected void o() {
    }

    protected void p() {
        throw null;
    }

    protected void q() {
    }

    public void r(int i10, InterfaceC0099b<D> interfaceC0099b) {
        if (this.f6119b != null) {
            throw new IllegalStateException("There is already a listener registered");
        }
        this.f6119b = interfaceC0099b;
        this.f6118a = i10;
    }

    public void s() {
        o();
        this.f6124g = true;
        this.f6122e = false;
        this.f6123f = false;
        this.f6125h = false;
        this.f6126i = false;
    }

    public void t() {
        if (this.f6126i) {
            m();
        }
    }

    public String toString() {
        StringBuilder sb2 = new StringBuilder(64);
        androidx.core.util.b.a(this, sb2);
        sb2.append(" id=");
        sb2.append(this.f6118a);
        sb2.append("}");
        return sb2.toString();
    }

    public final void u() {
        this.f6122e = true;
        this.f6124g = false;
        this.f6123f = false;
        p();
    }

    public void v() {
        this.f6122e = false;
        q();
    }

    public void w(InterfaceC0099b<D> interfaceC0099b) {
        InterfaceC0099b<D> interfaceC0099b2 = this.f6119b;
        if (interfaceC0099b2 == null) {
            throw new IllegalStateException("No listener register");
        }
        if (interfaceC0099b2 != interfaceC0099b) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        }
        this.f6119b = null;
    }
}
