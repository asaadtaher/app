package c7;

import java.io.IOException;
import java.util.Iterator;
import java.util.Objects;

/* loaded from: classes.dex */
public class e {

    /* renamed from: a, reason: collision with root package name */
    private final String f6688a;

    private e(String str) {
        this.f6688a = (String) k.n(str);
    }

    public static e e(char c10) {
        return new e(String.valueOf(c10));
    }

    public <A extends Appendable> A a(A a10, Iterator<? extends Object> it) throws IOException {
        k.n(a10);
        if (it.hasNext()) {
            while (true) {
                a10.append(f(it.next()));
                if (!it.hasNext()) {
                    break;
                }
                a10.append(this.f6688a);
            }
        }
        return a10;
    }

    public final StringBuilder b(StringBuilder sb2, Iterator<? extends Object> it) {
        try {
            a(sb2, it);
            return sb2;
        } catch (IOException e10) {
            throw new AssertionError(e10);
        }
    }

    public final String c(Iterable<? extends Object> iterable) {
        return d(iterable.iterator());
    }

    public final String d(Iterator<? extends Object> it) {
        return b(new StringBuilder(), it).toString();
    }

    CharSequence f(Object obj) {
        Objects.requireNonNull(obj);
        return obj instanceof CharSequence ? (CharSequence) obj : obj.toString();
    }
}
