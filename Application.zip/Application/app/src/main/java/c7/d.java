package c7;

/* loaded from: classes.dex */
public interface d<F, T> {
    T a(F f10);

    boolean equals(Object obj);
}
