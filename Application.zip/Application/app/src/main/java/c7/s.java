package c7;

/* loaded from: classes.dex */
public class s extends RuntimeException {
    public s(String str) {
        super(str);
    }

    public s(String str, Throwable th) {
        super(str, th);
    }
}
