package c7;

/* loaded from: classes.dex */
public interface o<T> {
    T get();
}
