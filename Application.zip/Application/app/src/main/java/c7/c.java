package c7;

/* loaded from: classes.dex */
abstract class c {
}
