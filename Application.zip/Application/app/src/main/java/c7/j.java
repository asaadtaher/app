package c7;

import java.util.Locale;
import java.util.logging.Logger;

/* loaded from: classes.dex */
final class j {

    /* renamed from: a, reason: collision with root package name */
    private static final Logger f6697a = Logger.getLogger(j.class.getName());

    /* renamed from: b, reason: collision with root package name */
    private static final i f6698b = c();

    private static final class b implements i {
        private b() {
        }
    }

    private j() {
    }

    static String a(String str) {
        if (d(str)) {
            return null;
        }
        return str;
    }

    static String b(double d10) {
        return String.format(Locale.ROOT, "%.4g", Double.valueOf(d10));
    }

    private static i c() {
        return new b();
    }

    static boolean d(String str) {
        return str == null || str.isEmpty();
    }
}
