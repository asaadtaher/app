package c7;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;

/* loaded from: classes.dex */
public final class f {

    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        private final String f6689a;

        /* renamed from: b, reason: collision with root package name */
        private final C0109b f6690b;

        /* renamed from: c, reason: collision with root package name */
        private C0109b f6691c;

        /* renamed from: d, reason: collision with root package name */
        private boolean f6692d;

        /* renamed from: e, reason: collision with root package name */
        private boolean f6693e;

        private static final class a extends C0109b {
            private a() {
                super();
            }
        }

        /* renamed from: c7.f$b$b, reason: collision with other inner class name */
        private static class C0109b {

            /* renamed from: a, reason: collision with root package name */
            String f6694a;

            /* renamed from: b, reason: collision with root package name */
            Object f6695b;

            /* renamed from: c, reason: collision with root package name */
            C0109b f6696c;

            private C0109b() {
            }
        }

        private b(String str) {
            C0109b c0109b = new C0109b();
            this.f6690b = c0109b;
            this.f6691c = c0109b;
            this.f6692d = false;
            this.f6693e = false;
            this.f6689a = (String) k.n(str);
        }

        private C0109b f() {
            C0109b c0109b = new C0109b();
            this.f6691c.f6696c = c0109b;
            this.f6691c = c0109b;
            return c0109b;
        }

        private b g(String str, Object obj) {
            C0109b c0109bF = f();
            c0109bF.f6695b = obj;
            c0109bF.f6694a = (String) k.n(str);
            return this;
        }

        private a h() {
            a aVar = new a();
            this.f6691c.f6696c = aVar;
            this.f6691c = aVar;
            return aVar;
        }

        private b i(String str, Object obj) {
            a aVarH = h();
            aVarH.f6695b = obj;
            aVarH.f6694a = (String) k.n(str);
            return this;
        }

        private static boolean j(Object obj) {
            return obj instanceof CharSequence ? ((CharSequence) obj).length() == 0 : obj instanceof Collection ? ((Collection) obj).isEmpty() : obj instanceof Map ? ((Map) obj).isEmpty() : obj instanceof h ? !((h) obj).a() : obj.getClass().isArray() && Array.getLength(obj) == 0;
        }

        public b a(String str, double d10) {
            return i(str, String.valueOf(d10));
        }

        public b b(String str, int i10) {
            return i(str, String.valueOf(i10));
        }

        public b c(String str, long j10) {
            return i(str, String.valueOf(j10));
        }

        public b d(String str, Object obj) {
            return g(str, obj);
        }

        public b e(String str, boolean z10) {
            return i(str, String.valueOf(z10));
        }

        public b k() {
            this.f6692d = true;
            return this;
        }

        /* JADX WARN: Removed duplicated region for block: B:12:0x0030  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public java.lang.String toString() {
            /*
                r8 = this;
                boolean r0 = r8.f6692d
                boolean r1 = r8.f6693e
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r3 = 32
                r2.<init>(r3)
                java.lang.String r3 = r8.f6689a
                r2.append(r3)
                r3 = 123(0x7b, float:1.72E-43)
                r2.append(r3)
                c7.f$b$b r3 = r8.f6690b
                c7.f$b$b r3 = r3.f6696c
                java.lang.String r4 = ""
            L1b:
                if (r3 == 0) goto L66
                java.lang.Object r5 = r3.f6695b
                boolean r6 = r3 instanceof c7.f.b.a
                if (r6 != 0) goto L30
                if (r5 != 0) goto L28
                if (r0 != 0) goto L63
                goto L30
            L28:
                if (r1 == 0) goto L30
                boolean r6 = j(r5)
                if (r6 != 0) goto L63
            L30:
                r2.append(r4)
                java.lang.String r4 = r3.f6694a
                if (r4 == 0) goto L3f
                r2.append(r4)
                r4 = 61
                r2.append(r4)
            L3f:
                if (r5 == 0) goto L5e
                java.lang.Class r4 = r5.getClass()
                boolean r4 = r4.isArray()
                if (r4 == 0) goto L5e
                r4 = 1
                java.lang.Object[] r6 = new java.lang.Object[r4]
                r7 = 0
                r6[r7] = r5
                java.lang.String r5 = java.util.Arrays.deepToString(r6)
                int r6 = r5.length()
                int r6 = r6 - r4
                r2.append(r5, r4, r6)
                goto L61
            L5e:
                r2.append(r5)
            L61:
                java.lang.String r4 = ", "
            L63:
                c7.f$b$b r3 = r3.f6696c
                goto L1b
            L66:
                r0 = 125(0x7d, float:1.75E-43)
                r2.append(r0)
                java.lang.String r0 = r2.toString()
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: c7.f.b.toString():java.lang.String");
        }
    }

    public static b a(Class<?> cls) {
        return new b(cls.getSimpleName());
    }

    public static b b(Object obj) {
        return new b(obj.getClass().getSimpleName());
    }
}
