package c7;

/* loaded from: classes.dex */
public final class r {
    public static void a(boolean z10, String str, Object obj) {
        if (!z10) {
            throw new s(n.c(str, obj));
        }
    }
}
