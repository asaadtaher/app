package c7;

/* loaded from: classes.dex */
public abstract class q {

    /* renamed from: a, reason: collision with root package name */
    private static final q f6712a = new a();

    class a extends q {
        a() {
        }

        @Override // c7.q
        public long a() {
            return System.nanoTime();
        }
    }

    protected q() {
    }

    public static q b() {
        return f6712a;
    }

    public abstract long a();
}
