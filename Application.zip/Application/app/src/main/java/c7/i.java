package c7;

/* loaded from: classes.dex */
interface i {
}
