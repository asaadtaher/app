package c7;

/* loaded from: classes.dex */
public final class l {

    /* renamed from: a, reason: collision with root package name */
    private final c7.a f6699a;

    /* renamed from: b, reason: collision with root package name */
    private final boolean f6700b;

    /* renamed from: c, reason: collision with root package name */
    private final b f6701c;

    /* renamed from: d, reason: collision with root package name */
    private final int f6702d;

    class a implements b {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ c7.a f6703a;

        a(c7.a aVar) {
            this.f6703a = aVar;
        }
    }

    private interface b {
    }

    private l(b bVar) {
        this(bVar, false, c7.a.c(), Integer.MAX_VALUE);
    }

    private l(b bVar, boolean z10, c7.a aVar, int i10) {
        this.f6701c = bVar;
        this.f6700b = z10;
        this.f6699a = aVar;
        this.f6702d = i10;
    }

    public static l a(char c10) {
        return b(c7.a.b(c10));
    }

    public static l b(c7.a aVar) {
        k.n(aVar);
        return new l(new a(aVar));
    }

    public l c() {
        return d(c7.a.e());
    }

    public l d(c7.a aVar) {
        k.n(aVar);
        return new l(this.f6701c, this.f6700b, aVar, this.f6702d);
    }
}
