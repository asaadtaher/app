package c7;

import java.io.Serializable;

/* loaded from: classes.dex */
public abstract class h<T> implements Serializable {
    h() {
    }

    public abstract boolean a();
}
