package c7;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: c7.a$a, reason: collision with other inner class name */
    static abstract class AbstractC0108a extends a {
        AbstractC0108a() {
        }
    }

    private static final class b extends AbstractC0108a {

        /* renamed from: a, reason: collision with root package name */
        private final char f6677a;

        b(char c10) {
            this.f6677a = c10;
        }

        public String toString() {
            return "CharMatcher.is('" + a.d(this.f6677a) + "')";
        }
    }

    static abstract class c extends AbstractC0108a {

        /* renamed from: a, reason: collision with root package name */
        private final String f6678a;

        c(String str) {
            this.f6678a = (String) k.n(str);
        }

        public final String toString() {
            return this.f6678a;
        }
    }

    private static final class d extends c {

        /* renamed from: b, reason: collision with root package name */
        static final d f6679b = new d();

        private d() {
            super("CharMatcher.none()");
        }
    }

    static final class e extends c {

        /* renamed from: b, reason: collision with root package name */
        static final int f6680b = Integer.numberOfLeadingZeros(31);

        /* renamed from: c, reason: collision with root package name */
        static final e f6681c = new e();

        e() {
            super("CharMatcher.whitespace()");
        }
    }

    protected a() {
    }

    public static a b(char c10) {
        return new b(c10);
    }

    public static a c() {
        return d.f6679b;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String d(char c10) {
        char[] cArr = {'\\', 'u', 0, 0, 0, 0};
        for (int i10 = 0; i10 < 4; i10++) {
            cArr[5 - i10] = "0123456789ABCDEF".charAt(c10 & 15);
            c10 = (char) (c10 >> 4);
        }
        return String.copyValueOf(cArr);
    }

    public static a e() {
        return e.f6681c;
    }
}
