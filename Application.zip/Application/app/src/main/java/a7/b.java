package a7;

@Deprecated
/* loaded from: classes.dex */
public class b extends i6.b {
}
