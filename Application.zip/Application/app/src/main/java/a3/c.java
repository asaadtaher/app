package a3;

import android.util.Base64;
import android.util.Log;
import b2.f0;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.jvm.internal.m;
import kotlin.jvm.internal.t;
import md.d;
import md.p;
import org.json.JSONObject;
import tc.x;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public static final c f27a = new c();

    /* renamed from: b, reason: collision with root package name */
    private static final String f28b = "/.well-known/oauth/openid/keys/";

    private c() {
    }

    public static final PublicKey b(String key) throws InvalidKeySpecException {
        m.g(key, "key");
        byte[] bArrDecode = Base64.decode(p.y(p.y(p.y(key, "\n", "", false, 4, null), "-----BEGIN PUBLIC KEY-----", "", false, 4, null), "-----END PUBLIC KEY-----", "", false, 4, null), 0);
        m.f(bArrDecode, "decode(pubKeyString, Base64.DEFAULT)");
        PublicKey publicKeyGeneratePublic = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(bArrDecode));
        m.f(publicKeyGeneratePublic, "kf.generatePublic(x509publicKey)");
        return publicKeyGeneratePublic;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final String c(final String kid) {
        m.g(kid, "kid");
        f0 f0Var = f0.f5388a;
        final URL url = new URL("https", m.n("www.", f0.u()), f28b);
        final ReentrantLock reentrantLock = new ReentrantLock();
        final Condition conditionNewCondition = reentrantLock.newCondition();
        final t tVar = new t();
        f0.t().execute(new Runnable() { // from class: a3.b
            @Override // java.lang.Runnable
            public final void run() throws IOException {
                c.d(url, tVar, kid, reentrantLock, conditionNewCondition);
            }
        });
        reentrantLock.lock();
        try {
            conditionNewCondition.await(5000L, TimeUnit.MILLISECONDS);
            reentrantLock.unlock();
            return (String) tVar.f17303a;
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Type inference failed for: r5v4, types: [T, java.lang.String] */
    public static final void d(URL openIdKeyUrl, t result, String kid, ReentrantLock lock, Condition condition) throws IOException {
        m.g(openIdKeyUrl, "$openIdKeyUrl");
        m.g(result, "$result");
        m.g(kid, "$kid");
        m.g(lock, "$lock");
        URLConnection uRLConnectionOpenConnection = openIdKeyUrl.openConnection();
        Objects.requireNonNull(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
        HttpURLConnection httpURLConnection = (HttpURLConnection) uRLConnectionOpenConnection;
        try {
            try {
                InputStream inputStream = httpURLConnection.getInputStream();
                m.f(inputStream, "connection.inputStream");
                Reader inputStreamReader = new InputStreamReader(inputStream, d.f17896b);
                String strC = cd.b.c(inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192));
                httpURLConnection.getInputStream().close();
                result.f17303a = new JSONObject(strC).optString(kid);
                httpURLConnection.disconnect();
                lock.lock();
            } catch (Exception e10) {
                String name = f27a.getClass().getName();
                String message = e10.getMessage();
                if (message == null) {
                    message = "Error getting public key";
                }
                Log.d(name, message);
                httpURLConnection.disconnect();
                lock.lock();
                try {
                    condition.signal();
                    x xVar = x.f21992a;
                } finally {
                }
            }
            try {
                condition.signal();
                x xVar2 = x.f21992a;
            } finally {
            }
        } catch (Throwable th) {
            httpURLConnection.disconnect();
            lock.lock();
            try {
                condition.signal();
                x xVar3 = x.f21992a;
                throw th;
            } finally {
            }
        }
    }

    public static final boolean e(PublicKey publicKey, String data, String signature) throws NoSuchAlgorithmException, SignatureException, InvalidKeyException {
        m.g(publicKey, "publicKey");
        m.g(data, "data");
        m.g(signature, "signature");
        try {
            Signature signature2 = Signature.getInstance("SHA256withRSA");
            signature2.initVerify(publicKey);
            byte[] bytes = data.getBytes(d.f17896b);
            m.f(bytes, "(this as java.lang.String).getBytes(charset)");
            signature2.update(bytes);
            byte[] bArrDecode = Base64.decode(signature, 8);
            m.f(bArrDecode, "decode(signature, Base64.URL_SAFE)");
            return signature2.verify(bArrDecode);
        } catch (Exception unused) {
            return false;
        }
    }
}
