package a;

/* loaded from: classes.dex */
public final class a {
    public final StackTraceElement a() {
        return b.b(new Exception(), c.class.getSimpleName());
    }
}
