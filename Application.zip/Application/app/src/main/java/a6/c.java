package a6;

/* loaded from: classes.dex */
final class c implements e {
    c() {
    }
}
