package a6;

import a5.r;
import android.content.Context;
import android.os.PowerManager;
import android.os.WorkSource;
import android.text.TextUtils;
import android.util.Log;
import f5.g;
import f5.m;
import f5.o;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import r5.h;
import r5.i;

/* loaded from: classes.dex */
public class a {

    /* renamed from: r, reason: collision with root package name */
    private static final long f366r = TimeUnit.DAYS.toMillis(366);

    /* renamed from: s, reason: collision with root package name */
    private static volatile ScheduledExecutorService f367s = null;

    /* renamed from: t, reason: collision with root package name */
    private static final Object f368t = new Object();

    /* renamed from: u, reason: collision with root package name */
    private static volatile e f369u = new c();

    /* renamed from: a, reason: collision with root package name */
    private final Object f370a;

    /* renamed from: b, reason: collision with root package name */
    private final PowerManager.WakeLock f371b;

    /* renamed from: c, reason: collision with root package name */
    private int f372c;

    /* renamed from: d, reason: collision with root package name */
    private Future<?> f373d;

    /* renamed from: e, reason: collision with root package name */
    private long f374e;

    /* renamed from: f, reason: collision with root package name */
    private final Set<f> f375f;

    /* renamed from: g, reason: collision with root package name */
    private boolean f376g;

    /* renamed from: h, reason: collision with root package name */
    private int f377h;

    /* renamed from: i, reason: collision with root package name */
    r5.b f378i;

    /* renamed from: j, reason: collision with root package name */
    private f5.e f379j;

    /* renamed from: k, reason: collision with root package name */
    private WorkSource f380k;

    /* renamed from: l, reason: collision with root package name */
    private final String f381l;

    /* renamed from: m, reason: collision with root package name */
    private final String f382m;

    /* renamed from: n, reason: collision with root package name */
    private final Context f383n;

    /* renamed from: o, reason: collision with root package name */
    private final Map<String, d> f384o;

    /* renamed from: p, reason: collision with root package name */
    private AtomicInteger f385p;

    /* renamed from: q, reason: collision with root package name */
    private final ScheduledExecutorService f386q;

    public a(Context context, int i10, String str) {
        String packageName = context.getPackageName();
        this.f370a = new Object();
        this.f372c = 0;
        this.f375f = new HashSet();
        this.f376g = true;
        this.f379j = g.c();
        this.f384o = new HashMap();
        this.f385p = new AtomicInteger(0);
        r.l(context, "WakeLock: context must not be null");
        r.h(str, "WakeLock: wakeLockName must not be empty");
        this.f383n = context.getApplicationContext();
        this.f382m = str;
        this.f378i = null;
        if ("com.google.android.gms".equals(context.getPackageName())) {
            this.f381l = str;
        } else {
            String strValueOf = String.valueOf(str);
            this.f381l = strValueOf.length() != 0 ? "*gcore*:".concat(strValueOf) : new String("*gcore*:");
        }
        PowerManager powerManager = (PowerManager) context.getSystemService("power");
        if (powerManager == null) {
            StringBuilder sb2 = new StringBuilder(29);
            sb2.append((CharSequence) "expected a non-null reference", 0, 29);
            throw new i(sb2.toString());
        }
        PowerManager.WakeLock wakeLockNewWakeLock = powerManager.newWakeLock(i10, str);
        this.f371b = wakeLockNewWakeLock;
        if (o.c(context)) {
            WorkSource workSourceB = o.b(context, m.a(packageName) ? context.getPackageName() : packageName);
            this.f380k = workSourceB;
            if (workSourceB != null) {
                i(wakeLockNewWakeLock, workSourceB);
            }
        }
        ScheduledExecutorService scheduledExecutorServiceUnconfigurableScheduledExecutorService = f367s;
        if (scheduledExecutorServiceUnconfigurableScheduledExecutorService == null) {
            synchronized (f368t) {
                scheduledExecutorServiceUnconfigurableScheduledExecutorService = f367s;
                if (scheduledExecutorServiceUnconfigurableScheduledExecutorService == null) {
                    h.a();
                    scheduledExecutorServiceUnconfigurableScheduledExecutorService = Executors.unconfigurableScheduledExecutorService(Executors.newScheduledThreadPool(1));
                    f367s = scheduledExecutorServiceUnconfigurableScheduledExecutorService;
                }
            }
        }
        this.f386q = scheduledExecutorServiceUnconfigurableScheduledExecutorService;
    }

    public static /* synthetic */ void e(a aVar) {
        synchronized (aVar.f370a) {
            if (aVar.b()) {
                Log.e("WakeLock", String.valueOf(aVar.f381l).concat(" ** IS FORCE-RELEASED ON TIMEOUT **"));
                aVar.g();
                if (aVar.b()) {
                    aVar.f372c = 1;
                    aVar.h(0);
                }
            }
        }
    }

    private final String f(String str) {
        if (this.f376g) {
            TextUtils.isEmpty(null);
        }
        return null;
    }

    private final void g() {
        if (this.f375f.isEmpty()) {
            return;
        }
        ArrayList arrayList = new ArrayList(this.f375f);
        this.f375f.clear();
        if (arrayList.size() <= 0) {
            return;
        }
        throw null;
    }

    private final void h(int i10) {
        synchronized (this.f370a) {
            if (b()) {
                if (this.f376g) {
                    int i11 = this.f372c - 1;
                    this.f372c = i11;
                    if (i11 > 0) {
                        return;
                    }
                } else {
                    this.f372c = 0;
                }
                g();
                Iterator<d> it = this.f384o.values().iterator();
                while (it.hasNext()) {
                    it.next().f388a = 0;
                }
                this.f384o.clear();
                Future<?> future = this.f373d;
                if (future != null) {
                    future.cancel(false);
                    this.f373d = null;
                    this.f374e = 0L;
                }
                this.f377h = 0;
                try {
                    if (this.f371b.isHeld()) {
                        try {
                            this.f371b.release();
                        } catch (RuntimeException e10) {
                            if (!e10.getClass().equals(RuntimeException.class)) {
                                throw e10;
                            }
                            Log.e("WakeLock", String.valueOf(this.f381l).concat(" failed to release!"), e10);
                            if (this.f378i != null) {
                            }
                        }
                    } else {
                        Log.e("WakeLock", String.valueOf(this.f381l).concat(" should be held!"));
                    }
                } finally {
                    if (this.f378i != null) {
                        this.f378i = null;
                    }
                }
            }
        }
    }

    private static void i(PowerManager.WakeLock wakeLock, WorkSource workSource) {
        try {
            wakeLock.setWorkSource(workSource);
        } catch (ArrayIndexOutOfBoundsException | IllegalArgumentException e10) {
            Log.wtf("WakeLock", e10.toString());
        }
    }

    public void a(long j10) {
        this.f385p.incrementAndGet();
        long jMax = Math.max(Math.min(Long.MAX_VALUE, f366r), 1L);
        if (j10 > 0) {
            jMax = Math.min(j10, jMax);
        }
        synchronized (this.f370a) {
            if (!b()) {
                this.f378i = r5.b.b(false, null);
                this.f371b.acquire();
                this.f379j.b();
            }
            this.f372c++;
            this.f377h++;
            f(null);
            d dVar = this.f384o.get(null);
            if (dVar == null) {
                dVar = new d(null);
                this.f384o.put(null, dVar);
            }
            dVar.f388a++;
            long jB = this.f379j.b();
            long j11 = Long.MAX_VALUE - jB > jMax ? jB + jMax : Long.MAX_VALUE;
            if (j11 > this.f374e) {
                this.f374e = j11;
                Future<?> future = this.f373d;
                if (future != null) {
                    future.cancel(false);
                }
                this.f373d = this.f386q.schedule(new Runnable() { // from class: a6.b
                    @Override // java.lang.Runnable
                    public final void run() {
                        a.e(this.f387a);
                    }
                }, jMax, TimeUnit.MILLISECONDS);
            }
        }
    }

    public boolean b() {
        boolean z10;
        synchronized (this.f370a) {
            z10 = this.f372c > 0;
        }
        return z10;
    }

    public void c() {
        if (this.f385p.decrementAndGet() < 0) {
            Log.e("WakeLock", String.valueOf(this.f381l).concat(" release without a matched acquire!"));
        }
        synchronized (this.f370a) {
            f(null);
            if (this.f384o.containsKey(null)) {
                d dVar = this.f384o.get(null);
                if (dVar != null) {
                    int i10 = dVar.f388a - 1;
                    dVar.f388a = i10;
                    if (i10 == 0) {
                        this.f384o.remove(null);
                    }
                }
            } else {
                Log.w("WakeLock", String.valueOf(this.f381l).concat(" counter does not exist"));
            }
            h(0);
        }
    }

    public void d(boolean z10) {
        synchronized (this.f370a) {
            this.f376g = z10;
        }
    }
}
