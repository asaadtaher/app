package a6;

/* loaded from: classes.dex */
final class d {

    /* renamed from: a, reason: collision with root package name */
    int f388a;

    private d() {
    }

    /* synthetic */ d(c cVar) {
    }
}
