package a6;

/* loaded from: classes.dex */
public interface e {
}
