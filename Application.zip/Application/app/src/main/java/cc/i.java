package cc;

import cc.a;
import java.util.ArrayList;
import tb.a;
import tb.r;

/* loaded from: classes.dex */
public final /* synthetic */ class i {
    public static tb.i<Object> h() {
        return new r();
    }

    public static /* synthetic */ void i(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        try {
            arrayList.add(0, bVar.b());
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void j(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        try {
            arrayList.add(0, bVar.f());
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void k(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        try {
            arrayList.add(0, bVar.d());
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void l(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        try {
            arrayList.add(0, bVar.c());
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void m(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        try {
            arrayList.add(0, bVar.g());
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void n(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        try {
            arrayList.add(0, bVar.e());
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static /* synthetic */ void o(a.b bVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        ArrayList arrayList2 = (ArrayList) obj;
        try {
            arrayList.add(0, bVar.a(arrayList2.get(0) == null ? null : a.c.values()[((Integer) arrayList2.get(0)).intValue()]));
        } catch (Throwable th) {
            arrayList = a.a(th);
        }
        eVar.a(arrayList);
    }

    public static void p(tb.c cVar, final a.b bVar) {
        tb.a aVar = new tb.a(cVar, "dev.flutter.pigeon.PathProviderApi.getTemporaryPath", h(), cVar.c());
        if (bVar != null) {
            aVar.e(new a.d() { // from class: cc.e
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    i.i(bVar, obj, eVar);
                }
            });
        } else {
            aVar.e(null);
        }
        tb.a aVar2 = new tb.a(cVar, "dev.flutter.pigeon.PathProviderApi.getApplicationSupportPath", h(), cVar.c());
        if (bVar != null) {
            aVar2.e(new a.d() { // from class: cc.h
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    i.j(bVar, obj, eVar);
                }
            });
        } else {
            aVar2.e(null);
        }
        tb.a aVar3 = new tb.a(cVar, "dev.flutter.pigeon.PathProviderApi.getApplicationDocumentsPath", h(), cVar.c());
        if (bVar != null) {
            aVar3.e(new a.d() { // from class: cc.f
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    i.k(bVar, obj, eVar);
                }
            });
        } else {
            aVar3.e(null);
        }
        tb.a aVar4 = new tb.a(cVar, "dev.flutter.pigeon.PathProviderApi.getApplicationCachePath", h(), cVar.c());
        if (bVar != null) {
            aVar4.e(new a.d() { // from class: cc.b
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    i.l(bVar, obj, eVar);
                }
            });
        } else {
            aVar4.e(null);
        }
        tb.a aVar5 = new tb.a(cVar, "dev.flutter.pigeon.PathProviderApi.getExternalStoragePath", h(), cVar.c());
        if (bVar != null) {
            aVar5.e(new a.d() { // from class: cc.g
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    i.m(bVar, obj, eVar);
                }
            });
        } else {
            aVar5.e(null);
        }
        tb.a aVar6 = new tb.a(cVar, "dev.flutter.pigeon.PathProviderApi.getExternalCachePaths", h(), cVar.c());
        if (bVar != null) {
            aVar6.e(new a.d() { // from class: cc.d
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    i.n(bVar, obj, eVar);
                }
            });
        } else {
            aVar6.e(null);
        }
        tb.a aVar7 = new tb.a(cVar, "dev.flutter.pigeon.PathProviderApi.getExternalStoragePaths", h(), cVar.c());
        if (bVar != null) {
            aVar7.e(new a.d() { // from class: cc.c
                @Override // tb.a.d
                public final void a(Object obj, a.e eVar) {
                    i.o(bVar, obj, eVar);
                }
            });
        } else {
            aVar7.e(null);
        }
    }
}
