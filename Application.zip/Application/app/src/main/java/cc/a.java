package cc;

import android.util.Log;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class a {

    /* renamed from: cc.a$a, reason: collision with other inner class name */
    public static class C0111a extends RuntimeException {

        /* renamed from: a, reason: collision with root package name */
        public final String f6751a;

        /* renamed from: b, reason: collision with root package name */
        public final Object f6752b;
    }

    public interface b {
        List<String> a(c cVar);

        String b();

        String c();

        String d();

        List<String> e();

        String f();

        String g();
    }

    public enum c {
        ROOT(0),
        MUSIC(1),
        PODCASTS(2),
        RINGTONES(3),
        ALARMS(4),
        NOTIFICATIONS(5),
        PICTURES(6),
        MOVIES(7),
        DOWNLOADS(8),
        DCIM(9),
        DOCUMENTS(10);


        /* renamed from: a, reason: collision with root package name */
        final int f6765a;

        c(int i10) {
            this.f6765a = i10;
        }
    }

    protected static ArrayList<Object> a(Throwable th) {
        Object obj;
        ArrayList<Object> arrayList = new ArrayList<>(3);
        if (th instanceof C0111a) {
            C0111a c0111a = (C0111a) th;
            arrayList.add(c0111a.f6751a);
            arrayList.add(c0111a.getMessage());
            obj = c0111a.f6752b;
        } else {
            arrayList.add(th.toString());
            arrayList.add(th.getClass().getSimpleName());
            obj = "Cause: " + th.getCause() + ", Stacktrace: " + Log.getStackTraceString(th);
        }
        arrayList.add(obj);
        return arrayList;
    }
}
