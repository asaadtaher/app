package b2;

import android.os.Handler;
import b2.n0;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public final class y0 extends FilterOutputStream implements z0 {

    /* renamed from: a, reason: collision with root package name */
    private final n0 f5609a;

    /* renamed from: b, reason: collision with root package name */
    private final Map<j0, b1> f5610b;

    /* renamed from: c, reason: collision with root package name */
    private final long f5611c;

    /* renamed from: d, reason: collision with root package name */
    private final long f5612d;

    /* renamed from: e, reason: collision with root package name */
    private long f5613e;

    /* renamed from: f, reason: collision with root package name */
    private long f5614f;

    /* renamed from: g, reason: collision with root package name */
    private b1 f5615g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public y0(OutputStream out, n0 requests, Map<j0, b1> progressMap, long j10) {
        super(out);
        kotlin.jvm.internal.m.g(out, "out");
        kotlin.jvm.internal.m.g(requests, "requests");
        kotlin.jvm.internal.m.g(progressMap, "progressMap");
        this.f5609a = requests;
        this.f5610b = progressMap;
        this.f5611c = j10;
        f0 f0Var = f0.f5388a;
        this.f5612d = f0.A();
    }

    private final void f(long j10) {
        b1 b1Var = this.f5615g;
        if (b1Var != null) {
            b1Var.b(j10);
        }
        long j11 = this.f5613e + j10;
        this.f5613e = j11;
        if (j11 >= this.f5614f + this.f5612d || j11 >= this.f5611c) {
            p();
        }
    }

    private final void p() {
        if (this.f5613e > this.f5614f) {
            for (final n0.a aVar : this.f5609a.y()) {
                if (aVar instanceof n0.c) {
                    Handler handlerX = this.f5609a.x();
                    if ((handlerX == null ? null : Boolean.valueOf(handlerX.post(new Runnable() { // from class: b2.x0
                        @Override // java.lang.Runnable
                        public final void run() {
                            y0.r(aVar, this);
                        }
                    }))) == null) {
                        ((n0.c) aVar).a(this.f5609a, this.f5613e, this.f5611c);
                    }
                }
            }
            this.f5614f = this.f5613e;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void r(n0.a callback, y0 this$0) {
        kotlin.jvm.internal.m.g(callback, "$callback");
        kotlin.jvm.internal.m.g(this$0, "this$0");
        ((n0.c) callback).a(this$0.f5609a, this$0.k(), this$0.m());
    }

    @Override // b2.z0
    public void b(j0 j0Var) {
        this.f5615g = j0Var != null ? this.f5610b.get(j0Var) : null;
    }

    @Override // java.io.FilterOutputStream, java.io.OutputStream, java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        super.close();
        Iterator<b1> it = this.f5610b.values().iterator();
        while (it.hasNext()) {
            it.next().d();
        }
        p();
    }

    public final long k() {
        return this.f5613e;
    }

    public final long m() {
        return this.f5611c;
    }

    @Override // java.io.FilterOutputStream, java.io.OutputStream
    public void write(int i10) throws IOException {
        ((FilterOutputStream) this).out.write(i10);
        f(1L);
    }

    @Override // java.io.FilterOutputStream, java.io.OutputStream
    public void write(byte[] buffer) throws IOException {
        kotlin.jvm.internal.m.g(buffer, "buffer");
        ((FilterOutputStream) this).out.write(buffer);
        f(buffer.length);
    }

    @Override // java.io.FilterOutputStream, java.io.OutputStream
    public void write(byte[] buffer, int i10, int i11) throws IOException {
        kotlin.jvm.internal.m.g(buffer, "buffer");
        ((FilterOutputStream) this).out.write(buffer, i10, i11);
        f(i11);
    }
}
