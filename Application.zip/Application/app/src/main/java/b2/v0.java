package b2;

import android.content.Intent;

/* loaded from: classes.dex */
public final class v0 {

    /* renamed from: d, reason: collision with root package name */
    public static final a f5593d = new a(null);

    /* renamed from: e, reason: collision with root package name */
    private static volatile v0 f5594e;

    /* renamed from: a, reason: collision with root package name */
    private final d1.a f5595a;

    /* renamed from: b, reason: collision with root package name */
    private final u0 f5596b;

    /* renamed from: c, reason: collision with root package name */
    private t0 f5597c;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final synchronized v0 a() {
            v0 v0Var;
            if (v0.f5594e == null) {
                f0 f0Var = f0.f5388a;
                d1.a aVarB = d1.a.b(f0.l());
                kotlin.jvm.internal.m.f(aVarB, "getInstance(applicationContext)");
                v0.f5594e = new v0(aVarB, new u0());
            }
            v0Var = v0.f5594e;
            if (v0Var == null) {
                kotlin.jvm.internal.m.u("instance");
                throw null;
            }
            return v0Var;
        }
    }

    public v0(d1.a localBroadcastManager, u0 profileCache) {
        kotlin.jvm.internal.m.g(localBroadcastManager, "localBroadcastManager");
        kotlin.jvm.internal.m.g(profileCache, "profileCache");
        this.f5595a = localBroadcastManager;
        this.f5596b = profileCache;
    }

    private final void e(t0 t0Var, t0 t0Var2) {
        Intent intent = new Intent("com.facebook.sdk.ACTION_CURRENT_PROFILE_CHANGED");
        intent.putExtra("com.facebook.sdk.EXTRA_OLD_PROFILE", t0Var);
        intent.putExtra("com.facebook.sdk.EXTRA_NEW_PROFILE", t0Var2);
        this.f5595a.d(intent);
    }

    private final void g(t0 t0Var, boolean z10) {
        t0 t0Var2 = this.f5597c;
        this.f5597c = t0Var;
        if (z10) {
            u0 u0Var = this.f5596b;
            if (t0Var != null) {
                u0Var.c(t0Var);
            } else {
                u0Var.a();
            }
        }
        r2.l0 l0Var = r2.l0.f20174a;
        if (r2.l0.e(t0Var2, t0Var)) {
            return;
        }
        e(t0Var2, t0Var);
    }

    public final t0 c() {
        return this.f5597c;
    }

    public final boolean d() {
        t0 t0VarB = this.f5596b.b();
        if (t0VarB == null) {
            return false;
        }
        g(t0VarB, false);
        return true;
    }

    public final void f(t0 t0Var) {
        g(t0Var, true);
    }
}
