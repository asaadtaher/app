package b2;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class d1 {

    /* renamed from: a, reason: collision with root package name */
    public static final d1 f5363a = new d1();

    /* renamed from: b, reason: collision with root package name */
    private static final String f5364b = d1.class.getName();

    /* renamed from: c, reason: collision with root package name */
    private static final AtomicBoolean f5365c = new AtomicBoolean(false);

    /* renamed from: d, reason: collision with root package name */
    private static final AtomicBoolean f5366d = new AtomicBoolean(false);

    /* renamed from: e, reason: collision with root package name */
    private static final a f5367e = new a(true, "com.facebook.sdk.AutoInitEnabled");

    /* renamed from: f, reason: collision with root package name */
    private static final a f5368f = new a(true, "com.facebook.sdk.AutoLogAppEventsEnabled");

    /* renamed from: g, reason: collision with root package name */
    private static final a f5369g = new a(true, "com.facebook.sdk.AdvertiserIDCollectionEnabled");

    /* renamed from: h, reason: collision with root package name */
    private static final a f5370h = new a(false, "auto_event_setup_enabled");

    /* renamed from: i, reason: collision with root package name */
    private static final a f5371i = new a(true, "com.facebook.sdk.MonitorEnabled");

    /* renamed from: j, reason: collision with root package name */
    private static SharedPreferences f5372j;

    private static final class a {

        /* renamed from: a, reason: collision with root package name */
        private boolean f5373a;

        /* renamed from: b, reason: collision with root package name */
        private String f5374b;

        /* renamed from: c, reason: collision with root package name */
        private Boolean f5375c;

        /* renamed from: d, reason: collision with root package name */
        private long f5376d;

        public a(boolean z10, String key) {
            kotlin.jvm.internal.m.g(key, "key");
            this.f5373a = z10;
            this.f5374b = key;
        }

        public final boolean a() {
            return this.f5373a;
        }

        public final String b() {
            return this.f5374b;
        }

        public final long c() {
            return this.f5376d;
        }

        public final Boolean d() {
            return this.f5375c;
        }

        public final boolean e() {
            Boolean bool = this.f5375c;
            return bool == null ? this.f5373a : bool.booleanValue();
        }

        public final void f(long j10) {
            this.f5376d = j10;
        }

        public final void g(Boolean bool) {
            this.f5375c = bool;
        }
    }

    private d1() {
    }

    public static final boolean b() {
        if (w2.a.d(d1.class)) {
            return false;
        }
        try {
            f5363a.h();
            return f5369g.e();
        } catch (Throwable th) {
            w2.a.b(th, d1.class);
            return false;
        }
    }

    public static final boolean c() {
        if (w2.a.d(d1.class)) {
            return false;
        }
        try {
            f5363a.h();
            return f5367e.e();
        } catch (Throwable th) {
            w2.a.b(th, d1.class);
            return false;
        }
    }

    public static final boolean d() {
        if (w2.a.d(d1.class)) {
            return false;
        }
        try {
            f5363a.h();
            return f5368f.e();
        } catch (Throwable th) {
            w2.a.b(th, d1.class);
            return false;
        }
    }

    public static final boolean e() {
        if (w2.a.d(d1.class)) {
            return false;
        }
        try {
            f5363a.h();
            return f5370h.e();
        } catch (Throwable th) {
            w2.a.b(th, d1.class);
            return false;
        }
    }

    private final void f() {
        if (w2.a.d(this)) {
            return;
        }
        try {
            a aVar = f5370h;
            n(aVar);
            final long jCurrentTimeMillis = System.currentTimeMillis();
            if (aVar.d() == null || jCurrentTimeMillis - aVar.c() >= 604800000) {
                aVar.g(null);
                aVar.f(0L);
                if (f5366d.compareAndSet(false, true)) {
                    f0 f0Var = f0.f5388a;
                    f0.t().execute(new Runnable() { // from class: b2.c1
                        @Override // java.lang.Runnable
                        public final void run() {
                            d1.g(jCurrentTimeMillis);
                        }
                    });
                }
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void g(long j10) {
        if (w2.a.d(d1.class)) {
            return;
        }
        try {
            if (f5369g.e()) {
                r2.v vVar = r2.v.f20292a;
                f0 f0Var = f0.f5388a;
                r2.r rVarN = r2.v.n(f0.m(), false);
                if (rVarN != null && rVarN.b()) {
                    r2.a aVarE = r2.a.f20067f.e(f0.l());
                    String strH = (aVarE == null || aVarE.h() == null) ? null : aVarE.h();
                    if (strH != null) {
                        Bundle bundle = new Bundle();
                        bundle.putString("advertiser_id", strH);
                        bundle.putString("fields", "auto_event_setup_enabled");
                        j0 j0VarX = j0.f5454n.x(null, "app", null);
                        j0VarX.H(bundle);
                        JSONObject jSONObjectC = j0VarX.k().c();
                        if (jSONObjectC != null) {
                            a aVar = f5370h;
                            aVar.g(Boolean.valueOf(jSONObjectC.optBoolean("auto_event_setup_enabled", false)));
                            aVar.f(j10);
                            f5363a.p(aVar);
                        }
                    }
                }
            }
            f5366d.set(false);
        } catch (Throwable th) {
            w2.a.b(th, d1.class);
        }
    }

    private final void h() {
        if (w2.a.d(this)) {
            return;
        }
        try {
            f0 f0Var = f0.f5388a;
            if (f0.F() && f5365c.compareAndSet(false, true)) {
                SharedPreferences sharedPreferences = f0.l().getSharedPreferences("com.facebook.sdk.USER_SETTINGS", 0);
                kotlin.jvm.internal.m.f(sharedPreferences, "FacebookSdk.getApplicationContext()\n            .getSharedPreferences(USER_SETTINGS, Context.MODE_PRIVATE)");
                f5372j = sharedPreferences;
                i(f5368f, f5369g, f5367e);
                f();
                m();
                l();
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    private final void i(a... aVarArr) {
        if (w2.a.d(this)) {
            return;
        }
        int i10 = 0;
        try {
            int length = aVarArr.length;
            while (i10 < length) {
                a aVar = aVarArr[i10];
                i10++;
                if (aVar == f5370h) {
                    f();
                } else if (aVar.d() == null) {
                    n(aVar);
                    if (aVar.d() == null) {
                        j(aVar);
                    }
                } else {
                    p(aVar);
                }
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    private final void j(a aVar) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            o();
            try {
                f0 f0Var = f0.f5388a;
                Context contextL = f0.l();
                ApplicationInfo applicationInfo = contextL.getPackageManager().getApplicationInfo(contextL.getPackageName(), 128);
                kotlin.jvm.internal.m.f(applicationInfo, "ctx.packageManager.getApplicationInfo(ctx.packageName, PackageManager.GET_META_DATA)");
                Bundle bundle = applicationInfo.metaData;
                if (bundle == null || !bundle.containsKey(aVar.b())) {
                    return;
                }
                aVar.g(Boolean.valueOf(applicationInfo.metaData.getBoolean(aVar.b(), aVar.a())));
            } catch (PackageManager.NameNotFoundException e10) {
                r2.l0 l0Var = r2.l0.f20174a;
                r2.l0.d0(f5364b, e10);
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public static final void k() {
        if (w2.a.d(d1.class)) {
            return;
        }
        try {
            f0 f0Var = f0.f5388a;
            Context contextL = f0.l();
            ApplicationInfo applicationInfo = contextL.getPackageManager().getApplicationInfo(contextL.getPackageName(), 128);
            kotlin.jvm.internal.m.f(applicationInfo, "ctx.packageManager.getApplicationInfo(ctx.packageName, PackageManager.GET_META_DATA)");
            Bundle bundle = applicationInfo.metaData;
            if (bundle == null || !bundle.getBoolean("com.facebook.sdk.AutoAppLinkEnabled", false)) {
                return;
            }
            c2.c0 c0Var = new c2.c0(contextL);
            Bundle bundle2 = new Bundle();
            r2.l0 l0Var = r2.l0.f20174a;
            if (!r2.l0.P()) {
                bundle2.putString("SchemeWarning", "You haven't set the Auto App Link URL scheme: fb<YOUR APP ID> in AndroidManifest");
                Log.w(f5364b, "You haven't set the Auto App Link URL scheme: fb<YOUR APP ID> in AndroidManifest");
            }
            c0Var.d("fb_auto_applink", bundle2);
        } catch (PackageManager.NameNotFoundException unused) {
        } catch (Throwable th) {
            w2.a.b(th, d1.class);
        }
    }

    private final void l() {
        int i10;
        int i11;
        ApplicationInfo applicationInfo;
        if (w2.a.d(this)) {
            return;
        }
        try {
            if (f5365c.get()) {
                f0 f0Var = f0.f5388a;
                if (f0.F()) {
                    Context contextL = f0.l();
                    int i12 = 0;
                    int i13 = ((f5367e.e() ? 1 : 0) << 0) | 0 | ((f5368f.e() ? 1 : 0) << 1) | ((f5369g.e() ? 1 : 0) << 2) | ((f5371i.e() ? 1 : 0) << 3);
                    SharedPreferences sharedPreferences = f5372j;
                    if (sharedPreferences == null) {
                        kotlin.jvm.internal.m.u("userSettingPref");
                        throw null;
                    }
                    int i14 = sharedPreferences.getInt("com.facebook.sdk.USER_SETTINGS_BITMASK", 0);
                    if (i14 != i13) {
                        SharedPreferences sharedPreferences2 = f5372j;
                        if (sharedPreferences2 == null) {
                            kotlin.jvm.internal.m.u("userSettingPref");
                            throw null;
                        }
                        sharedPreferences2.edit().putInt("com.facebook.sdk.USER_SETTINGS_BITMASK", i13).apply();
                        try {
                            applicationInfo = contextL.getPackageManager().getApplicationInfo(contextL.getPackageName(), 128);
                            kotlin.jvm.internal.m.f(applicationInfo, "ctx.packageManager.getApplicationInfo(ctx.packageName, PackageManager.GET_META_DATA)");
                        } catch (PackageManager.NameNotFoundException unused) {
                            i10 = 0;
                        }
                        if (applicationInfo.metaData == null) {
                            i11 = 0;
                            c2.c0 c0Var = new c2.c0(contextL);
                            Bundle bundle = new Bundle();
                            bundle.putInt("usage", i12);
                            bundle.putInt("initial", i11);
                            bundle.putInt("previous", i14);
                            bundle.putInt("current", i13);
                            c0Var.b(bundle);
                        }
                        String[] strArr = {"com.facebook.sdk.AutoInitEnabled", "com.facebook.sdk.AutoLogAppEventsEnabled", "com.facebook.sdk.AdvertiserIDCollectionEnabled", "com.facebook.sdk.MonitorEnabled"};
                        boolean[] zArr = {true, true, true, true};
                        int i15 = 0;
                        i10 = 0;
                        i11 = 0;
                        while (true) {
                            int i16 = i15 + 1;
                            try {
                                i10 |= (applicationInfo.metaData.containsKey(strArr[i15]) ? 1 : 0) << i15;
                                i11 |= (applicationInfo.metaData.getBoolean(strArr[i15], zArr[i15]) ? 1 : 0) << i15;
                                if (i16 > 3) {
                                    break;
                                } else {
                                    i15 = i16;
                                }
                            } catch (PackageManager.NameNotFoundException unused2) {
                                i12 = i11;
                                i11 = i12;
                                i12 = i10;
                                c2.c0 c0Var2 = new c2.c0(contextL);
                                Bundle bundle2 = new Bundle();
                                bundle2.putInt("usage", i12);
                                bundle2.putInt("initial", i11);
                                bundle2.putInt("previous", i14);
                                bundle2.putInt("current", i13);
                                c0Var2.b(bundle2);
                            }
                        }
                        i12 = i10;
                        c2.c0 c0Var22 = new c2.c0(contextL);
                        Bundle bundle22 = new Bundle();
                        bundle22.putInt("usage", i12);
                        bundle22.putInt("initial", i11);
                        bundle22.putInt("previous", i14);
                        bundle22.putInt("current", i13);
                        c0Var22.b(bundle22);
                    }
                }
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    private final void m() {
        if (w2.a.d(this)) {
            return;
        }
        try {
            f0 f0Var = f0.f5388a;
            Context contextL = f0.l();
            ApplicationInfo applicationInfo = contextL.getPackageManager().getApplicationInfo(contextL.getPackageName(), 128);
            kotlin.jvm.internal.m.f(applicationInfo, "ctx.packageManager.getApplicationInfo(ctx.packageName, PackageManager.GET_META_DATA)");
            Bundle bundle = applicationInfo.metaData;
            if (bundle != null) {
                if (!bundle.containsKey("com.facebook.sdk.AutoLogAppEventsEnabled")) {
                    Log.w(f5364b, "Please set a value for AutoLogAppEventsEnabled. Set the flag to TRUE if you want to collect app install, app launch and in-app purchase events automatically. To request user consent before collecting data, set the flag value to FALSE, then change to TRUE once user consent is received. Learn more: https://developers.facebook.com/docs/app-events/getting-started-app-events-android#disable-auto-events.");
                }
                if (!applicationInfo.metaData.containsKey("com.facebook.sdk.AdvertiserIDCollectionEnabled")) {
                    Log.w(f5364b, "You haven't set a value for AdvertiserIDCollectionEnabled. Set the flag to TRUE if you want to collect Advertiser ID for better advertising and analytics results. To request user consent before collecting data, set the flag value to FALSE, then change to TRUE once user consent is received. Learn more: https://developers.facebook.com/docs/app-events/getting-started-app-events-android#disable-auto-events.");
                }
                if (b()) {
                    return;
                }
                Log.w(f5364b, "The value for AdvertiserIDCollectionEnabled is currently set to FALSE so you're sending app events without collecting Advertiser ID. This can affect the quality of your advertising and analytics results.");
            }
        } catch (PackageManager.NameNotFoundException unused) {
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    private final void n(a aVar) {
        String str = "";
        if (w2.a.d(this)) {
            return;
        }
        try {
            o();
            try {
                SharedPreferences sharedPreferences = f5372j;
                if (sharedPreferences == null) {
                    kotlin.jvm.internal.m.u("userSettingPref");
                    throw null;
                }
                String string = sharedPreferences.getString(aVar.b(), "");
                if (string != null) {
                    str = string;
                }
                if (str.length() > 0) {
                    JSONObject jSONObject = new JSONObject(str);
                    aVar.g(Boolean.valueOf(jSONObject.getBoolean("value")));
                    aVar.f(jSONObject.getLong("last_timestamp"));
                }
            } catch (JSONException e10) {
                r2.l0 l0Var = r2.l0.f20174a;
                r2.l0.d0(f5364b, e10);
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    private final void o() {
        if (w2.a.d(this)) {
            return;
        }
        try {
            if (f5365c.get()) {
            } else {
                throw new g0("The UserSettingManager has not been initialized successfully");
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    private final void p(a aVar) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            o();
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("value", aVar.d());
                jSONObject.put("last_timestamp", aVar.c());
                SharedPreferences sharedPreferences = f5372j;
                if (sharedPreferences == null) {
                    kotlin.jvm.internal.m.u("userSettingPref");
                    throw null;
                }
                sharedPreferences.edit().putString(aVar.b(), jSONObject.toString()).apply();
                l();
            } catch (Exception e10) {
                r2.l0 l0Var = r2.l0.f20174a;
                r2.l0.d0(f5364b, e10);
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }
}
