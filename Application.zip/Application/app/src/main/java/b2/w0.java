package b2;

import android.os.Handler;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public final class w0 extends OutputStream implements z0 {

    /* renamed from: a, reason: collision with root package name */
    private final Handler f5599a;

    /* renamed from: b, reason: collision with root package name */
    private final Map<j0, b1> f5600b = new HashMap();

    /* renamed from: c, reason: collision with root package name */
    private j0 f5601c;

    /* renamed from: d, reason: collision with root package name */
    private b1 f5602d;

    /* renamed from: e, reason: collision with root package name */
    private int f5603e;

    public w0(Handler handler) {
        this.f5599a = handler;
    }

    @Override // b2.z0
    public void b(j0 j0Var) {
        this.f5601c = j0Var;
        this.f5602d = j0Var != null ? this.f5600b.get(j0Var) : null;
    }

    public final void d(long j10) {
        j0 j0Var = this.f5601c;
        if (j0Var == null) {
            return;
        }
        if (this.f5602d == null) {
            b1 b1Var = new b1(this.f5599a, j0Var);
            this.f5602d = b1Var;
            this.f5600b.put(j0Var, b1Var);
        }
        b1 b1Var2 = this.f5602d;
        if (b1Var2 != null) {
            b1Var2.c(j10);
        }
        this.f5603e += (int) j10;
    }

    public final int f() {
        return this.f5603e;
    }

    public final Map<j0, b1> k() {
        return this.f5600b;
    }

    @Override // java.io.OutputStream
    public void write(int i10) {
        d(1L);
    }

    @Override // java.io.OutputStream
    public void write(byte[] buffer) {
        kotlin.jvm.internal.m.g(buffer, "buffer");
        d(buffer.length);
    }

    @Override // java.io.OutputStream
    public void write(byte[] buffer, int i10, int i11) {
        kotlin.jvm.internal.m.g(buffer, "buffer");
        d(i11);
    }
}
