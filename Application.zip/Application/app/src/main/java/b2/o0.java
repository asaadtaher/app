package b2;

import android.util.Log;
import b2.a;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

/* loaded from: classes.dex */
public final class o0 {

    /* renamed from: i, reason: collision with root package name */
    public static final a f5526i = new a(null);

    /* renamed from: j, reason: collision with root package name */
    private static final String f5527j = o0.class.getCanonicalName();

    /* renamed from: a, reason: collision with root package name */
    private final j0 f5528a;

    /* renamed from: b, reason: collision with root package name */
    private final HttpURLConnection f5529b;

    /* renamed from: c, reason: collision with root package name */
    private final String f5530c;

    /* renamed from: d, reason: collision with root package name */
    private final JSONObject f5531d;

    /* renamed from: e, reason: collision with root package name */
    private final JSONArray f5532e;

    /* renamed from: f, reason: collision with root package name */
    private final v f5533f;

    /* renamed from: g, reason: collision with root package name */
    private final JSONObject f5534g;

    /* renamed from: h, reason: collision with root package name */
    private final JSONArray f5535h;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        private final o0 b(j0 j0Var, HttpURLConnection httpURLConnection, Object NULL, Object obj) throws JSONException {
            if (NULL instanceof JSONObject) {
                JSONObject jSONObject = (JSONObject) NULL;
                v vVarA = v.f5571t.a(jSONObject, obj, httpURLConnection);
                if (vVarA != null) {
                    Log.e(o0.f5527j, vVarA.toString());
                    if (vVarA.h() == 190) {
                        r2.l0 l0Var = r2.l0.f20174a;
                        if (r2.l0.T(j0Var.m())) {
                            if (vVarA.m() != 493) {
                                b2.a.f5323l.h(null);
                            } else {
                                a.c cVar = b2.a.f5323l;
                                b2.a aVarE = cVar.e();
                                if (kotlin.jvm.internal.m.b(aVarE != null ? Boolean.valueOf(aVarE.y()) : null, Boolean.FALSE)) {
                                    cVar.d();
                                }
                            }
                        }
                    }
                    return new o0(j0Var, httpURLConnection, vVarA);
                }
                r2.l0 l0Var2 = r2.l0.f20174a;
                Object objK = r2.l0.K(jSONObject, "body", "FACEBOOK_NON_JSON_RESULT");
                if (objK instanceof JSONObject) {
                    JSONObject jSONObject2 = (JSONObject) objK;
                    return new o0(j0Var, httpURLConnection, jSONObject2.toString(), jSONObject2);
                }
                if (objK instanceof JSONArray) {
                    JSONArray jSONArray = (JSONArray) objK;
                    return new o0(j0Var, httpURLConnection, jSONArray.toString(), jSONArray);
                }
                NULL = JSONObject.NULL;
                kotlin.jvm.internal.m.f(NULL, "NULL");
            }
            if (NULL == JSONObject.NULL) {
                return new o0(j0Var, httpURLConnection, NULL.toString(), (JSONObject) null);
            }
            throw new s(kotlin.jvm.internal.m.n("Got unexpected object type in response, class: ", NULL.getClass().getSimpleName()));
        }

        /* JADX WARN: Removed duplicated region for block: B:19:0x0053  */
        /* JADX WARN: Removed duplicated region for block: B:33:0x009b A[LOOP:0: B:23:0x0062->B:33:0x009b, LOOP_END] */
        /* JADX WARN: Removed duplicated region for block: B:41:0x009d A[EDGE_INSN: B:41:0x009d->B:34:0x009d BREAK  A[LOOP:0: B:23:0x0062->B:33:0x009b], SYNTHETIC] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private final java.util.List<b2.o0> c(java.net.HttpURLConnection r9, java.util.List<b2.j0> r10, java.lang.Object r11) throws org.json.JSONException {
            /*
                r8 = this;
                int r0 = r10.size()
                java.util.ArrayList r1 = new java.util.ArrayList
                r1.<init>(r0)
                r2 = 0
                r3 = 1
                if (r0 != r3) goto L4e
                java.lang.Object r3 = r10.get(r2)
                b2.j0 r3 = (b2.j0) r3
                org.json.JSONObject r4 = new org.json.JSONObject     // Catch: java.io.IOException -> L34 org.json.JSONException -> L40
                r4.<init>()     // Catch: java.io.IOException -> L34 org.json.JSONException -> L40
                java.lang.String r5 = "body"
                r4.put(r5, r11)     // Catch: java.io.IOException -> L34 org.json.JSONException -> L40
                if (r9 != 0) goto L22
                r5 = 200(0xc8, float:2.8E-43)
                goto L26
            L22:
                int r5 = r9.getResponseCode()     // Catch: java.io.IOException -> L34 org.json.JSONException -> L40
            L26:
                java.lang.String r6 = "code"
                r4.put(r6, r5)     // Catch: java.io.IOException -> L34 org.json.JSONException -> L40
                org.json.JSONArray r5 = new org.json.JSONArray     // Catch: java.io.IOException -> L34 org.json.JSONException -> L40
                r5.<init>()     // Catch: java.io.IOException -> L34 org.json.JSONException -> L40
                r5.put(r4)     // Catch: java.io.IOException -> L34 org.json.JSONException -> L40
                goto L4f
            L34:
                r4 = move-exception
                b2.o0 r5 = new b2.o0
                b2.v r6 = new b2.v
                r6.<init>(r9, r4)
                r5.<init>(r3, r9, r6)
                goto L4b
            L40:
                r4 = move-exception
                b2.o0 r5 = new b2.o0
                b2.v r6 = new b2.v
                r6.<init>(r9, r4)
                r5.<init>(r3, r9, r6)
            L4b:
                r1.add(r5)
            L4e:
                r5 = r11
            L4f:
                boolean r3 = r5 instanceof org.json.JSONArray
                if (r3 == 0) goto L9e
                r3 = r5
                org.json.JSONArray r3 = (org.json.JSONArray) r3
                int r4 = r3.length()
                if (r4 != r0) goto L9e
                int r0 = r3.length()
                if (r0 <= 0) goto L9d
            L62:
                int r3 = r2 + 1
                java.lang.Object r4 = r10.get(r2)
                b2.j0 r4 = (b2.j0) r4
                r6 = r5
                org.json.JSONArray r6 = (org.json.JSONArray) r6     // Catch: b2.s -> L7e org.json.JSONException -> L8a
                java.lang.Object r2 = r6.get(r2)     // Catch: b2.s -> L7e org.json.JSONException -> L8a
                java.lang.String r6 = "obj"
                kotlin.jvm.internal.m.f(r2, r6)     // Catch: b2.s -> L7e org.json.JSONException -> L8a
                b2.o0 r2 = r8.b(r4, r9, r2, r11)     // Catch: b2.s -> L7e org.json.JSONException -> L8a
                r1.add(r2)     // Catch: b2.s -> L7e org.json.JSONException -> L8a
                goto L98
            L7e:
                r2 = move-exception
                b2.o0 r6 = new b2.o0
                b2.v r7 = new b2.v
                r7.<init>(r9, r2)
                r6.<init>(r4, r9, r7)
                goto L95
            L8a:
                r2 = move-exception
                b2.o0 r6 = new b2.o0
                b2.v r7 = new b2.v
                r7.<init>(r9, r2)
                r6.<init>(r4, r9, r7)
            L95:
                r1.add(r6)
            L98:
                if (r3 < r0) goto L9b
                goto L9d
            L9b:
                r2 = r3
                goto L62
            L9d:
                return r1
            L9e:
                b2.s r9 = new b2.s
                java.lang.String r10 = "Unexpected number of results"
                r9.<init>(r10)
                throw r9
            */
            throw new UnsupportedOperationException("Method not decompiled: b2.o0.a.c(java.net.HttpURLConnection, java.util.List, java.lang.Object):java.util.List");
        }

        public final List<o0> a(List<j0> requests, HttpURLConnection httpURLConnection, s sVar) {
            kotlin.jvm.internal.m.g(requests, "requests");
            ArrayList arrayList = new ArrayList(uc.q.p(requests, 10));
            Iterator<T> it = requests.iterator();
            while (it.hasNext()) {
                arrayList.add(new o0((j0) it.next(), httpURLConnection, new v(httpURLConnection, sVar)));
            }
            return arrayList;
        }

        public final List<o0> d(InputStream inputStream, HttpURLConnection httpURLConnection, n0 requests) throws Throwable {
            kotlin.jvm.internal.m.g(requests, "requests");
            r2.l0 l0Var = r2.l0.f20174a;
            String strN0 = r2.l0.n0(inputStream);
            r2.c0.f20089e.c(r0.INCLUDE_RAW_RESPONSES, "Response", "Response (raw)\n  Size: %d\n  Response:\n%s\n", Integer.valueOf(strN0.length()), strN0);
            return e(strN0, httpURLConnection, requests);
        }

        public final List<o0> e(String responseString, HttpURLConnection httpURLConnection, n0 requests) throws JSONException {
            kotlin.jvm.internal.m.g(responseString, "responseString");
            kotlin.jvm.internal.m.g(requests, "requests");
            Object resultObject = new JSONTokener(responseString).nextValue();
            kotlin.jvm.internal.m.f(resultObject, "resultObject");
            List<o0> listC = c(httpURLConnection, requests, resultObject);
            r2.c0.f20089e.c(r0.REQUESTS, "Response", "Response\n  Id: %s\n  Size: %d\n  Responses:\n%s\n", requests.z(), Integer.valueOf(responseString.length()), listC);
            return listC;
        }

        public final List<o0> f(HttpURLConnection connection, n0 requests) {
            List<o0> listA;
            kotlin.jvm.internal.m.g(connection, "connection");
            kotlin.jvm.internal.m.g(requests, "requests");
            InputStream errorStream = null;
            try {
                try {
                    try {
                        f0 f0Var = f0.f5388a;
                    } catch (Exception e10) {
                        r2.c0.f20089e.c(r0.REQUESTS, "Response", "Response <Error>: %s", e10);
                        listA = a(requests, connection, new s(e10));
                    }
                } catch (s e11) {
                    r2.c0.f20089e.c(r0.REQUESTS, "Response", "Response <Error>: %s", e11);
                    listA = a(requests, connection, e11);
                }
                if (!f0.E()) {
                    Log.e(o0.f5527j, "GraphRequest can't be used when Facebook SDK isn't fully initialized");
                    throw new s("GraphRequest can't be used when Facebook SDK isn't fully initialized");
                }
                errorStream = connection.getResponseCode() >= 400 ? connection.getErrorStream() : connection.getInputStream();
                listA = d(errorStream, connection, requests);
                return listA;
            } finally {
                r2.l0 l0Var = r2.l0.f20174a;
                r2.l0.j(null);
            }
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public o0(j0 request, HttpURLConnection httpURLConnection, v error) {
        this(request, httpURLConnection, null, null, null, error);
        kotlin.jvm.internal.m.g(request, "request");
        kotlin.jvm.internal.m.g(error, "error");
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public o0(j0 request, HttpURLConnection httpURLConnection, String rawResponse, JSONArray graphObjects) {
        this(request, httpURLConnection, rawResponse, null, graphObjects, null);
        kotlin.jvm.internal.m.g(request, "request");
        kotlin.jvm.internal.m.g(rawResponse, "rawResponse");
        kotlin.jvm.internal.m.g(graphObjects, "graphObjects");
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public o0(j0 request, HttpURLConnection httpURLConnection, String rawResponse, JSONObject jSONObject) {
        this(request, httpURLConnection, rawResponse, jSONObject, null, null);
        kotlin.jvm.internal.m.g(request, "request");
        kotlin.jvm.internal.m.g(rawResponse, "rawResponse");
    }

    public o0(j0 request, HttpURLConnection httpURLConnection, String str, JSONObject jSONObject, JSONArray jSONArray, v vVar) {
        kotlin.jvm.internal.m.g(request, "request");
        this.f5528a = request;
        this.f5529b = httpURLConnection;
        this.f5530c = str;
        this.f5531d = jSONObject;
        this.f5532e = jSONArray;
        this.f5533f = vVar;
        this.f5534g = jSONObject;
        this.f5535h = jSONArray;
    }

    public final v b() {
        return this.f5533f;
    }

    public final JSONObject c() {
        return this.f5531d;
    }

    public final JSONObject d() {
        return this.f5534g;
    }

    public String toString() {
        String str;
        try {
            kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
            Locale locale = Locale.US;
            Object[] objArr = new Object[1];
            HttpURLConnection httpURLConnection = this.f5529b;
            objArr[0] = Integer.valueOf(httpURLConnection == null ? 200 : httpURLConnection.getResponseCode());
            str = String.format(locale, "%d", Arrays.copyOf(objArr, 1));
            kotlin.jvm.internal.m.f(str, "java.lang.String.format(locale, format, *args)");
        } catch (IOException unused) {
            str = "unknown";
        }
        String str2 = "{Response:  responseCode: " + str + ", graphObject: " + this.f5531d + ", error: " + this.f5533f + "}";
        kotlin.jvm.internal.m.f(str2, "StringBuilder()\n        .append(\"{Response: \")\n        .append(\" responseCode: \")\n        .append(responseCode)\n        .append(\", graphObject: \")\n        .append(graphObject)\n        .append(\", error: \")\n        .append(error)\n        .append(\"}\")\n        .toString()");
        return str2;
    }
}
