package b2;

/* loaded from: classes.dex */
public final class t extends s {

    /* renamed from: b, reason: collision with root package name */
    private final o0 f5558b;

    public t(o0 o0Var, String str) {
        super(str);
        this.f5558b = o0Var;
    }

    @Override // b2.s, java.lang.Throwable
    public String toString() {
        o0 o0Var = this.f5558b;
        v vVarB = o0Var == null ? null : o0Var.b();
        StringBuilder sb2 = new StringBuilder();
        sb2.append("{FacebookGraphResponseException: ");
        String message = getMessage();
        if (message != null) {
            sb2.append(message);
            sb2.append(" ");
        }
        if (vVarB != null) {
            sb2.append("httpResponseCode: ");
            sb2.append(vVarB.l());
            sb2.append(", facebookErrorCode: ");
            sb2.append(vVarB.h());
            sb2.append(", facebookErrorType: ");
            sb2.append(vVarB.j());
            sb2.append(", message: ");
            sb2.append(vVarB.i());
            sb2.append("}");
        }
        String string = sb2.toString();
        kotlin.jvm.internal.m.f(string, "errorStringBuilder.toString()");
        return string;
    }
}
