package b2;

/* loaded from: classes.dex */
public final /* synthetic */ class k {
    public static /* synthetic */ int a(long j10) {
        return (int) (j10 ^ (j10 >>> 32));
    }
}
