package b2;

import android.os.AsyncTask;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import java.net.HttpURLConnection;
import java.util.Arrays;
import java.util.List;

/* loaded from: classes.dex */
public class m0 extends AsyncTask<Void, Void, List<? extends o0>> {

    /* renamed from: d, reason: collision with root package name */
    public static final a f5511d = new a(null);

    /* renamed from: e, reason: collision with root package name */
    private static final String f5512e = m0.class.getCanonicalName();

    /* renamed from: a, reason: collision with root package name */
    private final HttpURLConnection f5513a;

    /* renamed from: b, reason: collision with root package name */
    private final n0 f5514b;

    /* renamed from: c, reason: collision with root package name */
    private Exception f5515c;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public m0(n0 requests) {
        this(null, requests);
        kotlin.jvm.internal.m.g(requests, "requests");
    }

    public m0(HttpURLConnection httpURLConnection, n0 requests) {
        kotlin.jvm.internal.m.g(requests, "requests");
        this.f5513a = httpURLConnection;
        this.f5514b = requests;
    }

    public List<o0> a(Void... params) {
        if (w2.a.d(this)) {
            return null;
        }
        try {
            kotlin.jvm.internal.m.g(params, "params");
            try {
                HttpURLConnection httpURLConnection = this.f5513a;
                return httpURLConnection == null ? this.f5514b.p() : j0.f5454n.o(httpURLConnection, this.f5514b);
            } catch (Exception e10) {
                this.f5515c = e10;
                return null;
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
            return null;
        }
    }

    protected void b(List<o0> result) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(result, "result");
            super.onPostExecute(result);
            Exception exc = this.f5515c;
            if (exc != null) {
                r2.l0 l0Var = r2.l0.f20174a;
                String str = f5512e;
                kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
                String str2 = String.format("onPostExecute: exception encountered during request: %s", Arrays.copyOf(new Object[]{exc.getMessage()}, 1));
                kotlin.jvm.internal.m.f(str2, "java.lang.String.format(format, *args)");
                r2.l0.e0(str, str2);
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    @Override // android.os.AsyncTask
    public /* bridge */ /* synthetic */ List<? extends o0> doInBackground(Void[] voidArr) {
        if (w2.a.d(this)) {
            return null;
        }
        try {
            return a(voidArr);
        } catch (Throwable th) {
            w2.a.b(th, this);
            return null;
        }
    }

    @Override // android.os.AsyncTask
    public /* bridge */ /* synthetic */ void onPostExecute(List<? extends o0> list) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            b(list);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    @Override // android.os.AsyncTask
    public void onPreExecute() {
        if (w2.a.d(this)) {
            return;
        }
        try {
            super.onPreExecute();
            f0 f0Var = f0.f5388a;
            if (f0.D()) {
                r2.l0 l0Var = r2.l0.f20174a;
                String str = f5512e;
                kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
                String str2 = String.format("execute async task: %s", Arrays.copyOf(new Object[]{this}, 1));
                kotlin.jvm.internal.m.f(str2, "java.lang.String.format(format, *args)");
                r2.l0.e0(str, str2);
            }
            if (this.f5514b.x() == null) {
                this.f5514b.J(Thread.currentThread() instanceof HandlerThread ? new Handler() : new Handler(Looper.getMainLooper()));
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public String toString() {
        String str = "{RequestAsyncTask:  connection: " + this.f5513a + ", requests: " + this.f5514b + "}";
        kotlin.jvm.internal.m.f(str, "StringBuilder()\n        .append(\"{RequestAsyncTask: \")\n        .append(\" connection: \")\n        .append(connection)\n        .append(\", requests: \")\n        .append(requests)\n        .append(\"}\")\n        .toString()");
        return str;
    }
}
