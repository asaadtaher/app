package b2;

import java.util.Random;
import r2.n;

/* loaded from: classes.dex */
public class s extends RuntimeException {

    /* renamed from: a, reason: collision with root package name */
    public static final a f5557a = new a(null);

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public s() {
    }

    public s(final String str) {
        super(str);
        Random random = new Random();
        if (str != null) {
            f0 f0Var = f0.f5388a;
            if (!f0.F() || random.nextInt(100) <= 50) {
                return;
            }
            r2.n nVar = r2.n.f20187a;
            r2.n.a(n.b.ErrorReport, new n.a() { // from class: b2.r
                @Override // r2.n.a
                public final void a(boolean z10) {
                    s.b(str, z10);
                }
            });
        }
    }

    public s(String str, Throwable th) {
        super(str, th);
    }

    public s(Throwable th) {
        super(th);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void b(String str, boolean z10) {
        if (z10) {
            try {
                x2.e eVar = x2.e.f23548a;
                x2.e.g(str);
            } catch (Exception unused) {
            }
        }
    }

    @Override // java.lang.Throwable
    public String toString() {
        String message = getMessage();
        return message == null ? "" : message;
    }
}
