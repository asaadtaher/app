package b2;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import b2.q0;
import com.payment.paymentsdk.PaymentSdkParams;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR;

    /* renamed from: l, reason: collision with root package name */
    public static final c f5323l = new c(null);

    /* renamed from: r, reason: collision with root package name */
    private static final Date f5324r;

    /* renamed from: s, reason: collision with root package name */
    private static final Date f5325s;

    /* renamed from: t, reason: collision with root package name */
    private static final Date f5326t;

    /* renamed from: u, reason: collision with root package name */
    private static final h f5327u;

    /* renamed from: a, reason: collision with root package name */
    private final Date f5328a;

    /* renamed from: b, reason: collision with root package name */
    private final Set<String> f5329b;

    /* renamed from: c, reason: collision with root package name */
    private final Set<String> f5330c;

    /* renamed from: d, reason: collision with root package name */
    private final Set<String> f5331d;

    /* renamed from: e, reason: collision with root package name */
    private final String f5332e;

    /* renamed from: f, reason: collision with root package name */
    private final h f5333f;

    /* renamed from: g, reason: collision with root package name */
    private final Date f5334g;

    /* renamed from: h, reason: collision with root package name */
    private final String f5335h;

    /* renamed from: i, reason: collision with root package name */
    private final String f5336i;

    /* renamed from: j, reason: collision with root package name */
    private final Date f5337j;

    /* renamed from: k, reason: collision with root package name */
    private final String f5338k;

    /* renamed from: b2.a$a, reason: collision with other inner class name */
    public interface InterfaceC0088a {
        void a(s sVar);

        void b(a aVar);
    }

    public static final class b implements Parcelable.Creator<a> {
        b() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public a createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new a(source);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public a[] newArray(int i10) {
            return new a[i10];
        }
    }

    public static final class c {
        private c() {
        }

        public /* synthetic */ c(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final a a(a current) {
            kotlin.jvm.internal.m.g(current, "current");
            return new a(current.w(), current.i(), current.x(), current.s(), current.l(), current.m(), current.v(), new Date(), new Date(), current.k(), null, 1024, null);
        }

        public final a b(JSONObject jsonObject) throws JSONException {
            kotlin.jvm.internal.m.g(jsonObject, "jsonObject");
            if (jsonObject.getInt("version") > 1) {
                throw new s("Unknown AccessToken serialization format.");
            }
            String token = jsonObject.getString(PaymentSdkParams.TOKEN);
            Date date = new Date(jsonObject.getLong("expires_at"));
            JSONArray permissionsArray = jsonObject.getJSONArray("permissions");
            JSONArray declinedPermissionsArray = jsonObject.getJSONArray("declined_permissions");
            JSONArray jSONArrayOptJSONArray = jsonObject.optJSONArray("expired_permissions");
            Date date2 = new Date(jsonObject.getLong("last_refresh"));
            String string = jsonObject.getString("source");
            kotlin.jvm.internal.m.f(string, "jsonObject.getString(SOURCE_KEY)");
            h hVarValueOf = h.valueOf(string);
            String applicationId = jsonObject.getString("application_id");
            String userId = jsonObject.getString("user_id");
            Date date3 = new Date(jsonObject.optLong("data_access_expiration_time", 0L));
            String strOptString = jsonObject.optString("graph_domain", null);
            kotlin.jvm.internal.m.f(token, "token");
            kotlin.jvm.internal.m.f(applicationId, "applicationId");
            kotlin.jvm.internal.m.f(userId, "userId");
            r2.l0 l0Var = r2.l0.f20174a;
            kotlin.jvm.internal.m.f(permissionsArray, "permissionsArray");
            List<String> listB0 = r2.l0.b0(permissionsArray);
            kotlin.jvm.internal.m.f(declinedPermissionsArray, "declinedPermissionsArray");
            return new a(token, applicationId, userId, listB0, r2.l0.b0(declinedPermissionsArray), jSONArrayOptJSONArray == null ? new ArrayList() : r2.l0.b0(jSONArrayOptJSONArray), hVarValueOf, date, date2, date3, strOptString);
        }

        public final a c(Bundle bundle) throws JSONException {
            String string;
            kotlin.jvm.internal.m.g(bundle, "bundle");
            List<String> listF = f(bundle, "com.facebook.TokenCachingStrategy.Permissions");
            List<String> listF2 = f(bundle, "com.facebook.TokenCachingStrategy.DeclinedPermissions");
            List<String> listF3 = f(bundle, "com.facebook.TokenCachingStrategy.ExpiredPermissions");
            q0.a aVar = q0.f5543c;
            String strA = aVar.a(bundle);
            r2.l0 l0Var = r2.l0.f20174a;
            if (r2.l0.X(strA)) {
                f0 f0Var = f0.f5388a;
                strA = f0.m();
            }
            String str = strA;
            String strF = aVar.f(bundle);
            if (strF == null) {
                return null;
            }
            JSONObject jSONObjectF = r2.l0.f(strF);
            if (jSONObjectF == null) {
                string = null;
            } else {
                try {
                    string = jSONObjectF.getString("id");
                } catch (JSONException unused) {
                    return null;
                }
            }
            if (str == null || string == null) {
                return null;
            }
            return new a(strF, str, string, listF, listF2, listF3, aVar.e(bundle), aVar.c(bundle), aVar.d(bundle), null, null, 1024, null);
        }

        public final void d() {
            a aVarI = g.f5412f.e().i();
            if (aVarI != null) {
                h(a(aVarI));
            }
        }

        public final a e() {
            return g.f5412f.e().i();
        }

        public final List<String> f(Bundle bundle, String str) {
            kotlin.jvm.internal.m.g(bundle, "bundle");
            ArrayList<String> stringArrayList = bundle.getStringArrayList(str);
            if (stringArrayList == null) {
                return uc.p.g();
            }
            List<String> listUnmodifiableList = Collections.unmodifiableList(new ArrayList(stringArrayList));
            kotlin.jvm.internal.m.f(listUnmodifiableList, "{\n            Collections.unmodifiableList(ArrayList(originalPermissions))\n          }");
            return listUnmodifiableList;
        }

        public final boolean g() {
            a aVarI = g.f5412f.e().i();
            return (aVarI == null || aVarI.y()) ? false : true;
        }

        public final void h(a aVar) {
            g.f5412f.e().r(aVar);
        }
    }

    public /* synthetic */ class d {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f5339a;

        static {
            int[] iArr = new int[h.valuesCustom().length];
            iArr[h.FACEBOOK_APPLICATION_WEB.ordinal()] = 1;
            iArr[h.CHROME_CUSTOM_TAB.ordinal()] = 2;
            iArr[h.WEB_VIEW.ordinal()] = 3;
            f5339a = iArr;
        }
    }

    static {
        Date date = new Date(Long.MAX_VALUE);
        f5324r = date;
        f5325s = date;
        f5326t = new Date();
        f5327u = h.FACEBOOK_APPLICATION_WEB;
        CREATOR = new b();
    }

    public a(Parcel parcel) {
        kotlin.jvm.internal.m.g(parcel, "parcel");
        this.f5328a = new Date(parcel.readLong());
        ArrayList arrayList = new ArrayList();
        parcel.readStringList(arrayList);
        Set<String> setUnmodifiableSet = Collections.unmodifiableSet(new HashSet(arrayList));
        kotlin.jvm.internal.m.f(setUnmodifiableSet, "unmodifiableSet(HashSet(permissionsList))");
        this.f5329b = setUnmodifiableSet;
        arrayList.clear();
        parcel.readStringList(arrayList);
        Set<String> setUnmodifiableSet2 = Collections.unmodifiableSet(new HashSet(arrayList));
        kotlin.jvm.internal.m.f(setUnmodifiableSet2, "unmodifiableSet(HashSet(permissionsList))");
        this.f5330c = setUnmodifiableSet2;
        arrayList.clear();
        parcel.readStringList(arrayList);
        Set<String> setUnmodifiableSet3 = Collections.unmodifiableSet(new HashSet(arrayList));
        kotlin.jvm.internal.m.f(setUnmodifiableSet3, "unmodifiableSet(HashSet(permissionsList))");
        this.f5331d = setUnmodifiableSet3;
        String string = parcel.readString();
        r2.m0 m0Var = r2.m0.f20185a;
        this.f5332e = r2.m0.k(string, PaymentSdkParams.TOKEN);
        String string2 = parcel.readString();
        this.f5333f = string2 != null ? h.valueOf(string2) : f5327u;
        this.f5334g = new Date(parcel.readLong());
        this.f5335h = r2.m0.k(parcel.readString(), "applicationId");
        this.f5336i = r2.m0.k(parcel.readString(), "userId");
        this.f5337j = new Date(parcel.readLong());
        this.f5338k = parcel.readString();
    }

    public a(String accessToken, String applicationId, String userId, Collection<String> collection, Collection<String> collection2, Collection<String> collection3, h hVar, Date date, Date date2, Date date3, String str) {
        kotlin.jvm.internal.m.g(accessToken, "accessToken");
        kotlin.jvm.internal.m.g(applicationId, "applicationId");
        kotlin.jvm.internal.m.g(userId, "userId");
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.g(accessToken, "accessToken");
        r2.m0.g(applicationId, "applicationId");
        r2.m0.g(userId, "userId");
        this.f5328a = date == null ? f5325s : date;
        Set<String> setUnmodifiableSet = Collections.unmodifiableSet(collection != null ? new HashSet(collection) : new HashSet());
        kotlin.jvm.internal.m.f(setUnmodifiableSet, "unmodifiableSet(if (permissions != null) HashSet(permissions) else HashSet())");
        this.f5329b = setUnmodifiableSet;
        Set<String> setUnmodifiableSet2 = Collections.unmodifiableSet(collection2 != null ? new HashSet(collection2) : new HashSet());
        kotlin.jvm.internal.m.f(setUnmodifiableSet2, "unmodifiableSet(\n            if (declinedPermissions != null) HashSet(declinedPermissions) else HashSet())");
        this.f5330c = setUnmodifiableSet2;
        Set<String> setUnmodifiableSet3 = Collections.unmodifiableSet(collection3 != null ? new HashSet(collection3) : new HashSet());
        kotlin.jvm.internal.m.f(setUnmodifiableSet3, "unmodifiableSet(\n            if (expiredPermissions != null) HashSet(expiredPermissions) else HashSet())");
        this.f5331d = setUnmodifiableSet3;
        this.f5332e = accessToken;
        this.f5333f = h(hVar == null ? f5327u : hVar, str);
        this.f5334g = date2 == null ? f5326t : date2;
        this.f5335h = applicationId;
        this.f5336i = userId;
        this.f5337j = (date3 == null || date3.getTime() == 0) ? f5325s : date3;
        this.f5338k = str == null ? "facebook" : str;
    }

    public /* synthetic */ a(String str, String str2, String str3, Collection collection, Collection collection2, Collection collection3, h hVar, Date date, Date date2, Date date3, String str4, int i10, kotlin.jvm.internal.g gVar) {
        this(str, str2, str3, collection, collection2, collection3, hVar, date, date2, date3, (i10 & 1024) != 0 ? "facebook" : str4);
    }

    private final String A() {
        f0 f0Var = f0.f5388a;
        return f0.H(r0.INCLUDE_ACCESS_TOKENS) ? this.f5332e : "ACCESS_TOKEN_REMOVED";
    }

    private final void b(StringBuilder sb2) {
        sb2.append(" permissions:");
        sb2.append("[");
        sb2.append(TextUtils.join(", ", this.f5329b));
        sb2.append("]");
    }

    private final h h(h hVar, String str) {
        if (str == null || !str.equals("instagram")) {
            return hVar;
        }
        int i10 = d.f5339a[hVar.ordinal()];
        return i10 != 1 ? i10 != 2 ? i10 != 3 ? hVar : h.INSTAGRAM_WEB_VIEW : h.INSTAGRAM_CUSTOM_CHROME_TAB : h.INSTAGRAM_APPLICATION_WEB;
    }

    public static final a j() {
        return f5323l.e();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        if (kotlin.jvm.internal.m.b(this.f5328a, aVar.f5328a) && kotlin.jvm.internal.m.b(this.f5329b, aVar.f5329b) && kotlin.jvm.internal.m.b(this.f5330c, aVar.f5330c) && kotlin.jvm.internal.m.b(this.f5331d, aVar.f5331d) && kotlin.jvm.internal.m.b(this.f5332e, aVar.f5332e) && this.f5333f == aVar.f5333f && kotlin.jvm.internal.m.b(this.f5334g, aVar.f5334g) && kotlin.jvm.internal.m.b(this.f5335h, aVar.f5335h) && kotlin.jvm.internal.m.b(this.f5336i, aVar.f5336i) && kotlin.jvm.internal.m.b(this.f5337j, aVar.f5337j)) {
            String str = this.f5338k;
            String str2 = aVar.f5338k;
            if (str == null ? str2 == null : kotlin.jvm.internal.m.b(str, str2)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        int iHashCode = (((((((((((((((((((527 + this.f5328a.hashCode()) * 31) + this.f5329b.hashCode()) * 31) + this.f5330c.hashCode()) * 31) + this.f5331d.hashCode()) * 31) + this.f5332e.hashCode()) * 31) + this.f5333f.hashCode()) * 31) + this.f5334g.hashCode()) * 31) + this.f5335h.hashCode()) * 31) + this.f5336i.hashCode()) * 31) + this.f5337j.hashCode()) * 31;
        String str = this.f5338k;
        return iHashCode + (str == null ? 0 : str.hashCode());
    }

    public final String i() {
        return this.f5335h;
    }

    public final Date k() {
        return this.f5337j;
    }

    public final Set<String> l() {
        return this.f5330c;
    }

    public final Set<String> m() {
        return this.f5331d;
    }

    public final Date n() {
        return this.f5328a;
    }

    public final String o() {
        return this.f5338k;
    }

    public final Date q() {
        return this.f5334g;
    }

    public final Set<String> s() {
        return this.f5329b;
    }

    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append("{AccessToken");
        sb2.append(" token:");
        sb2.append(A());
        b(sb2);
        sb2.append("}");
        String string = sb2.toString();
        kotlin.jvm.internal.m.f(string, "builder.toString()");
        return string;
    }

    public final h v() {
        return this.f5333f;
    }

    public final String w() {
        return this.f5332e;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int i10) {
        kotlin.jvm.internal.m.g(dest, "dest");
        dest.writeLong(this.f5328a.getTime());
        dest.writeStringList(new ArrayList(this.f5329b));
        dest.writeStringList(new ArrayList(this.f5330c));
        dest.writeStringList(new ArrayList(this.f5331d));
        dest.writeString(this.f5332e);
        dest.writeString(this.f5333f.name());
        dest.writeLong(this.f5334g.getTime());
        dest.writeString(this.f5335h);
        dest.writeString(this.f5336i);
        dest.writeLong(this.f5337j.getTime());
        dest.writeString(this.f5338k);
    }

    public final String x() {
        return this.f5336i;
    }

    public final boolean y() {
        return new Date().after(this.f5328a);
    }

    public final JSONObject z() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("version", 1);
        jSONObject.put(PaymentSdkParams.TOKEN, this.f5332e);
        jSONObject.put("expires_at", this.f5328a.getTime());
        jSONObject.put("permissions", new JSONArray((Collection) this.f5329b));
        jSONObject.put("declined_permissions", new JSONArray((Collection) this.f5330c));
        jSONObject.put("expired_permissions", new JSONArray((Collection) this.f5331d));
        jSONObject.put("last_refresh", this.f5334g.getTime());
        jSONObject.put("source", this.f5333f.name());
        jSONObject.put("application_id", this.f5335h);
        jSONObject.put("user_id", this.f5336i);
        jSONObject.put("data_access_expiration_time", this.f5337j.getTime());
        String str = this.f5338k;
        if (str != null) {
            jSONObject.put("graph_domain", str);
        }
        return jSONObject;
    }
}
