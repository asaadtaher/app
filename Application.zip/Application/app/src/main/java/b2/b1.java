package b2;

import android.os.Handler;
import b2.j0;

/* loaded from: classes.dex */
public final class b1 {

    /* renamed from: a, reason: collision with root package name */
    private final Handler f5349a;

    /* renamed from: b, reason: collision with root package name */
    private final j0 f5350b;

    /* renamed from: c, reason: collision with root package name */
    private final long f5351c;

    /* renamed from: d, reason: collision with root package name */
    private long f5352d;

    /* renamed from: e, reason: collision with root package name */
    private long f5353e;

    /* renamed from: f, reason: collision with root package name */
    private long f5354f;

    public b1(Handler handler, j0 request) {
        kotlin.jvm.internal.m.g(request, "request");
        this.f5349a = handler;
        this.f5350b = request;
        f0 f0Var = f0.f5388a;
        this.f5351c = f0.A();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void e(j0.b bVar, long j10, long j11) {
        ((j0.f) bVar).a(j10, j11);
    }

    public final void b(long j10) {
        long j11 = this.f5352d + j10;
        this.f5352d = j11;
        if (j11 >= this.f5353e + this.f5351c || j11 >= this.f5354f) {
            d();
        }
    }

    public final void c(long j10) {
        this.f5354f += j10;
    }

    public final void d() {
        if (this.f5352d > this.f5353e) {
            final j0.b bVarO = this.f5350b.o();
            final long j10 = this.f5354f;
            if (j10 <= 0 || !(bVarO instanceof j0.f)) {
                return;
            }
            final long j11 = this.f5352d;
            Handler handler = this.f5349a;
            if ((handler == null ? null : Boolean.valueOf(handler.post(new Runnable() { // from class: b2.a1
                @Override // java.lang.Runnable
                public final void run() {
                    b1.e(bVarO, j11, j10);
                }
            }))) == null) {
                ((j0.f) bVarO).a(j11, j10);
            }
            this.f5353e = this.f5352d;
        }
    }
}
