package b2;

import android.content.SharedPreferences;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class u0 {

    /* renamed from: b, reason: collision with root package name */
    public static final a f5569b = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private final SharedPreferences f5570a;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public u0() {
        f0 f0Var = f0.f5388a;
        SharedPreferences sharedPreferences = f0.l().getSharedPreferences("com.facebook.AccessTokenManager.SharedPreferences", 0);
        kotlin.jvm.internal.m.f(sharedPreferences, "FacebookSdk.getApplicationContext()\n            .getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE)");
        this.f5570a = sharedPreferences;
    }

    public final void a() {
        this.f5570a.edit().remove("com.facebook.ProfileManager.CachedProfile").apply();
    }

    public final t0 b() {
        String string = this.f5570a.getString("com.facebook.ProfileManager.CachedProfile", null);
        if (string != null) {
            try {
                return new t0(new JSONObject(string));
            } catch (JSONException unused) {
            }
        }
        return null;
    }

    public final void c(t0 profile) {
        kotlin.jvm.internal.m.g(profile, "profile");
        JSONObject jSONObjectH = profile.h();
        if (jSONObjectH != null) {
            this.f5570a.edit().putString("com.facebook.ProfileManager.CachedProfile", jSONObjectH.toString()).apply();
        }
    }
}
