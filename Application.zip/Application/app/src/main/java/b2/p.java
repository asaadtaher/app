package b2;

/* loaded from: classes.dex */
public interface p<RESULT> {
    void a(RESULT result);

    void b(s sVar);

    void onCancel();
}
