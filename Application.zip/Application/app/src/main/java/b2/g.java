package b2;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import b2.a;
import b2.j0;
import b2.n0;
import com.facebook.CurrentAccessTokenExpirationBroadcastReceiver;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: f, reason: collision with root package name */
    public static final a f5412f = new a(null);

    /* renamed from: g, reason: collision with root package name */
    private static g f5413g;

    /* renamed from: a, reason: collision with root package name */
    private final d1.a f5414a;

    /* renamed from: b, reason: collision with root package name */
    private final b2.b f5415b;

    /* renamed from: c, reason: collision with root package name */
    private b2.a f5416c;

    /* renamed from: d, reason: collision with root package name */
    private final AtomicBoolean f5417d;

    /* renamed from: e, reason: collision with root package name */
    private Date f5418e;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final j0 c(b2.a aVar, j0.b bVar) {
            e eVarF = f(aVar);
            Bundle bundle = new Bundle();
            bundle.putString("grant_type", eVarF.b());
            bundle.putString("client_id", aVar.i());
            bundle.putString("fields", "access_token,expires_at,expires_in,data_access_expiration_time,graph_domain");
            j0 j0VarX = j0.f5454n.x(aVar, eVarF.a(), bVar);
            j0VarX.H(bundle);
            j0VarX.G(p0.GET);
            return j0VarX;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final j0 d(b2.a aVar, j0.b bVar) {
            Bundle bundle = new Bundle();
            bundle.putString("fields", "permission,status");
            j0 j0VarX = j0.f5454n.x(aVar, "me/permissions", bVar);
            j0VarX.H(bundle);
            j0VarX.G(p0.GET);
            return j0VarX;
        }

        private final e f(b2.a aVar) {
            String strO = aVar.o();
            if (strO == null) {
                strO = "facebook";
            }
            return kotlin.jvm.internal.m.b(strO, "instagram") ? new c() : new b();
        }

        public final g e() {
            g gVar;
            g gVar2 = g.f5413g;
            if (gVar2 != null) {
                return gVar2;
            }
            synchronized (this) {
                gVar = g.f5413g;
                if (gVar == null) {
                    f0 f0Var = f0.f5388a;
                    d1.a aVarB = d1.a.b(f0.l());
                    kotlin.jvm.internal.m.f(aVarB, "getInstance(applicationContext)");
                    g gVar3 = new g(aVarB, new b2.b());
                    a aVar = g.f5412f;
                    g.f5413g = gVar3;
                    gVar = gVar3;
                }
            }
            return gVar;
        }
    }

    public static final class b implements e {

        /* renamed from: a, reason: collision with root package name */
        private final String f5419a = "oauth/access_token";

        /* renamed from: b, reason: collision with root package name */
        private final String f5420b = "fb_extend_sso_token";

        @Override // b2.g.e
        public String a() {
            return this.f5419a;
        }

        @Override // b2.g.e
        public String b() {
            return this.f5420b;
        }
    }

    public static final class c implements e {

        /* renamed from: a, reason: collision with root package name */
        private final String f5421a = "refresh_access_token";

        /* renamed from: b, reason: collision with root package name */
        private final String f5422b = "ig_refresh_token";

        @Override // b2.g.e
        public String a() {
            return this.f5421a;
        }

        @Override // b2.g.e
        public String b() {
            return this.f5422b;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    static final class d {

        /* renamed from: a, reason: collision with root package name */
        private String f5423a;

        /* renamed from: b, reason: collision with root package name */
        private int f5424b;

        /* renamed from: c, reason: collision with root package name */
        private int f5425c;

        /* renamed from: d, reason: collision with root package name */
        private Long f5426d;

        /* renamed from: e, reason: collision with root package name */
        private String f5427e;

        public final String a() {
            return this.f5423a;
        }

        public final Long b() {
            return this.f5426d;
        }

        public final int c() {
            return this.f5424b;
        }

        public final int d() {
            return this.f5425c;
        }

        public final String e() {
            return this.f5427e;
        }

        public final void f(String str) {
            this.f5423a = str;
        }

        public final void g(Long l10) {
            this.f5426d = l10;
        }

        public final void h(int i10) {
            this.f5424b = i10;
        }

        public final void i(int i10) {
            this.f5425c = i10;
        }

        public final void j(String str) {
            this.f5427e = str;
        }
    }

    public interface e {
        String a();

        String b();
    }

    public g(d1.a localBroadcastManager, b2.b accessTokenCache) {
        kotlin.jvm.internal.m.g(localBroadcastManager, "localBroadcastManager");
        kotlin.jvm.internal.m.g(accessTokenCache, "accessTokenCache");
        this.f5414a = localBroadcastManager;
        this.f5415b = accessTokenCache;
        this.f5417d = new AtomicBoolean(false);
        this.f5418e = new Date(0L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void l(g this$0, a.InterfaceC0088a interfaceC0088a) {
        kotlin.jvm.internal.m.g(this$0, "this$0");
        this$0.m(interfaceC0088a);
    }

    private final void m(final a.InterfaceC0088a interfaceC0088a) {
        final b2.a aVarI = i();
        if (aVarI == null) {
            if (interfaceC0088a == null) {
                return;
            }
            interfaceC0088a.a(new s("No current access token to refresh"));
            return;
        }
        if (!this.f5417d.compareAndSet(false, true)) {
            if (interfaceC0088a == null) {
                return;
            }
            interfaceC0088a.a(new s("Refresh already in progress"));
            return;
        }
        this.f5418e = new Date();
        final HashSet hashSet = new HashSet();
        final HashSet hashSet2 = new HashSet();
        final HashSet hashSet3 = new HashSet();
        final AtomicBoolean atomicBoolean = new AtomicBoolean(false);
        final d dVar = new d();
        a aVar = f5412f;
        n0 n0Var = new n0(aVar.d(aVarI, new j0.b() { // from class: b2.d
            @Override // b2.j0.b
            public final void b(o0 o0Var) {
                g.n(atomicBoolean, hashSet, hashSet2, hashSet3, o0Var);
            }
        }), aVar.c(aVarI, new j0.b() { // from class: b2.c
            @Override // b2.j0.b
            public final void b(o0 o0Var) {
                g.o(dVar, o0Var);
            }
        }));
        n0Var.k(new n0.a() { // from class: b2.e
            @Override // b2.n0.a
            public final void b(n0 n0Var2) throws Throwable {
                g.p(dVar, aVarI, interfaceC0088a, atomicBoolean, hashSet, hashSet2, hashSet3, this, n0Var2);
            }
        });
        n0Var.t();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00a4  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void n(java.util.concurrent.atomic.AtomicBoolean r6, java.util.Set r7, java.util.Set r8, java.util.Set r9, b2.o0 r10) {
        /*
            java.lang.String r0 = "$permissionsCallSucceeded"
            kotlin.jvm.internal.m.g(r6, r0)
            java.lang.String r0 = "$permissions"
            kotlin.jvm.internal.m.g(r7, r0)
            java.lang.String r0 = "$declinedPermissions"
            kotlin.jvm.internal.m.g(r8, r0)
            java.lang.String r0 = "$expiredPermissions"
            kotlin.jvm.internal.m.g(r9, r0)
            java.lang.String r0 = "response"
            kotlin.jvm.internal.m.g(r10, r0)
            org.json.JSONObject r10 = r10.d()
            if (r10 != 0) goto L20
            return
        L20:
            java.lang.String r0 = "data"
            org.json.JSONArray r10 = r10.optJSONArray(r0)
            if (r10 != 0) goto L29
            return
        L29:
            r0 = 1
            r6.set(r0)
            r6 = 0
            int r0 = r10.length()
            if (r0 <= 0) goto Lb9
        L34:
            int r1 = r6 + 1
            org.json.JSONObject r6 = r10.optJSONObject(r6)
            if (r6 != 0) goto L3e
            goto Lb3
        L3e:
            java.lang.String r2 = "permission"
            java.lang.String r2 = r6.optString(r2)
            java.lang.String r3 = "status"
            java.lang.String r6 = r6.optString(r3)
            r2.l0 r4 = r2.l0.f20174a
            boolean r4 = r2.l0.X(r2)
            if (r4 != 0) goto Lb3
            boolean r4 = r2.l0.X(r6)
            if (r4 != 0) goto Lb3
            kotlin.jvm.internal.m.f(r6, r3)
            java.util.Locale r4 = java.util.Locale.US
            java.lang.String r5 = "US"
            kotlin.jvm.internal.m.f(r4, r5)
            java.lang.String r6 = r6.toLowerCase(r4)
            java.lang.String r4 = "(this as java.lang.String).toLowerCase(locale)"
            kotlin.jvm.internal.m.f(r6, r4)
            kotlin.jvm.internal.m.f(r6, r3)
            int r3 = r6.hashCode()
            r4 = -1309235419(0xffffffffb1f6a725, float:-7.1785444E-9)
            if (r3 == r4) goto L9c
            r4 = 280295099(0x10b4f6bb, float:7.137763E-29)
            if (r3 == r4) goto L8f
            r4 = 568196142(0x21ddfc2e, float:1.5042294E-18)
            if (r3 == r4) goto L82
            goto La4
        L82:
            java.lang.String r3 = "declined"
            boolean r3 = r6.equals(r3)
            if (r3 != 0) goto L8b
            goto La4
        L8b:
            r8.add(r2)
            goto Lb3
        L8f:
            java.lang.String r3 = "granted"
            boolean r3 = r6.equals(r3)
            if (r3 != 0) goto L98
            goto La4
        L98:
            r7.add(r2)
            goto Lb3
        L9c:
            java.lang.String r3 = "expired"
            boolean r3 = r6.equals(r3)
            if (r3 != 0) goto Lb0
        La4:
            java.lang.String r2 = "Unexpected status: "
            java.lang.String r6 = kotlin.jvm.internal.m.n(r2, r6)
            java.lang.String r2 = "AccessTokenManager"
            android.util.Log.w(r2, r6)
            goto Lb3
        Lb0:
            r9.add(r2)
        Lb3:
            if (r1 < r0) goto Lb6
            goto Lb9
        Lb6:
            r6 = r1
            goto L34
        Lb9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b2.g.n(java.util.concurrent.atomic.AtomicBoolean, java.util.Set, java.util.Set, java.util.Set, b2.o0):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void o(d refreshResult, o0 response) {
        kotlin.jvm.internal.m.g(refreshResult, "$refreshResult");
        kotlin.jvm.internal.m.g(response, "response");
        JSONObject jSONObjectD = response.d();
        if (jSONObjectD == null) {
            return;
        }
        refreshResult.f(jSONObjectD.optString("access_token"));
        refreshResult.h(jSONObjectD.optInt("expires_at"));
        refreshResult.i(jSONObjectD.optInt("expires_in"));
        refreshResult.g(Long.valueOf(jSONObjectD.optLong("data_access_expiration_time")));
        refreshResult.j(jSONObjectD.optString("graph_domain", null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void p(d refreshResult, b2.a aVar, a.InterfaceC0088a interfaceC0088a, AtomicBoolean permissionsCallSucceeded, Set permissions, Set declinedPermissions, Set expiredPermissions, g this$0, n0 it) throws Throwable {
        b2.a aVar2;
        kotlin.jvm.internal.m.g(refreshResult, "$refreshResult");
        kotlin.jvm.internal.m.g(permissionsCallSucceeded, "$permissionsCallSucceeded");
        kotlin.jvm.internal.m.g(permissions, "$permissions");
        kotlin.jvm.internal.m.g(declinedPermissions, "$declinedPermissions");
        kotlin.jvm.internal.m.g(expiredPermissions, "$expiredPermissions");
        kotlin.jvm.internal.m.g(this$0, "this$0");
        kotlin.jvm.internal.m.g(it, "it");
        String strA = refreshResult.a();
        int iC = refreshResult.c();
        Long lB = refreshResult.b();
        String strE = refreshResult.e();
        try {
            a aVar3 = f5412f;
            if (aVar3.e().i() != null) {
                b2.a aVarI = aVar3.e().i();
                if ((aVarI == null ? null : aVarI.x()) == aVar.x()) {
                    if (!permissionsCallSucceeded.get() && strA == null && iC == 0) {
                        if (interfaceC0088a != null) {
                            interfaceC0088a.a(new s("Failed to refresh access token"));
                        }
                        this$0.f5417d.set(false);
                        return;
                    }
                    Date dateN = aVar.n();
                    if (refreshResult.c() != 0) {
                        dateN = new Date(refreshResult.c() * 1000);
                    } else if (refreshResult.d() != 0) {
                        dateN = new Date((refreshResult.d() * 1000) + new Date().getTime());
                    }
                    Date date = dateN;
                    if (strA == null) {
                        strA = aVar.w();
                    }
                    String str = strA;
                    String strI = aVar.i();
                    String strX = aVar.x();
                    Set setS = permissionsCallSucceeded.get() ? permissions : aVar.s();
                    Set setL = permissionsCallSucceeded.get() ? declinedPermissions : aVar.l();
                    Set setM = permissionsCallSucceeded.get() ? expiredPermissions : aVar.m();
                    h hVarV = aVar.v();
                    Date date2 = new Date();
                    Date date3 = lB != null ? new Date(lB.longValue() * 1000) : aVar.k();
                    if (strE == null) {
                        strE = aVar.o();
                    }
                    b2.a aVar4 = new b2.a(str, strI, strX, setS, setL, setM, hVarV, date, date2, date3, strE);
                    try {
                        aVar3.e().r(aVar4);
                        this$0.f5417d.set(false);
                        if (interfaceC0088a != null) {
                            interfaceC0088a.b(aVar4);
                            return;
                        }
                        return;
                    } catch (Throwable th) {
                        th = th;
                        aVar2 = aVar4;
                        this$0.f5417d.set(false);
                        if (interfaceC0088a != null && aVar2 != null) {
                            interfaceC0088a.b(aVar2);
                        }
                        throw th;
                    }
                }
            }
            if (interfaceC0088a != null) {
                interfaceC0088a.a(new s("No current access token to refresh"));
            }
            this$0.f5417d.set(false);
        } catch (Throwable th2) {
            th = th2;
            aVar2 = null;
        }
    }

    private final void q(b2.a aVar, b2.a aVar2) {
        f0 f0Var = f0.f5388a;
        Intent intent = new Intent(f0.l(), (Class<?>) CurrentAccessTokenExpirationBroadcastReceiver.class);
        intent.setAction("com.facebook.sdk.ACTION_CURRENT_ACCESS_TOKEN_CHANGED");
        intent.putExtra("com.facebook.sdk.EXTRA_OLD_ACCESS_TOKEN", aVar);
        intent.putExtra("com.facebook.sdk.EXTRA_NEW_ACCESS_TOKEN", aVar2);
        this.f5414a.d(intent);
    }

    private final void s(b2.a aVar, boolean z10) {
        b2.a aVar2 = this.f5416c;
        this.f5416c = aVar;
        this.f5417d.set(false);
        this.f5418e = new Date(0L);
        if (z10) {
            b2.b bVar = this.f5415b;
            if (aVar != null) {
                bVar.g(aVar);
            } else {
                bVar.a();
                r2.l0 l0Var = r2.l0.f20174a;
                f0 f0Var = f0.f5388a;
                r2.l0.i(f0.l());
            }
        }
        r2.l0 l0Var2 = r2.l0.f20174a;
        if (r2.l0.e(aVar2, aVar)) {
            return;
        }
        q(aVar2, aVar);
        t();
    }

    private final void t() {
        f0 f0Var = f0.f5388a;
        Context contextL = f0.l();
        a.c cVar = b2.a.f5323l;
        b2.a aVarE = cVar.e();
        AlarmManager alarmManager = (AlarmManager) contextL.getSystemService("alarm");
        if (cVar.g()) {
            if ((aVarE == null ? null : aVarE.n()) == null || alarmManager == null) {
                return;
            }
            Intent intent = new Intent(contextL, (Class<?>) CurrentAccessTokenExpirationBroadcastReceiver.class);
            intent.setAction("com.facebook.sdk.ACTION_CURRENT_ACCESS_TOKEN_CHANGED");
            try {
                alarmManager.set(1, aVarE.n().getTime(), Build.VERSION.SDK_INT >= 23 ? PendingIntent.getBroadcast(contextL, 0, intent, 67108864) : PendingIntent.getBroadcast(contextL, 0, intent, 0));
            } catch (Exception unused) {
            }
        }
    }

    private final boolean u() {
        b2.a aVarI = i();
        if (aVarI == null) {
            return false;
        }
        long time = new Date().getTime();
        return aVarI.v().b() && time - this.f5418e.getTime() > 3600000 && time - aVarI.q().getTime() > 86400000;
    }

    public final void g() {
        q(i(), i());
    }

    public final void h() {
        if (u()) {
            k(null);
        }
    }

    public final b2.a i() {
        return this.f5416c;
    }

    public final boolean j() {
        b2.a aVarF = this.f5415b.f();
        if (aVarF == null) {
            return false;
        }
        s(aVarF, false);
        return true;
    }

    public final void k(final a.InterfaceC0088a interfaceC0088a) {
        if (kotlin.jvm.internal.m.b(Looper.getMainLooper(), Looper.myLooper())) {
            m(interfaceC0088a);
        } else {
            new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: b2.f
                @Override // java.lang.Runnable
                public final void run() {
                    g.l(this.f5386a, interfaceC0088a);
                }
            });
        }
    }

    public final void r(b2.a aVar) {
        s(aVar, true);
    }
}
