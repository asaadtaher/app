package b2;

/* loaded from: classes.dex */
public final class o extends s {

    /* renamed from: b, reason: collision with root package name */
    public static final a f5525b = new a(null);

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public o(String str) {
        super(str);
    }
}
