package b2;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import b2.a;
import org.json.JSONException;
import org.json.JSONObject;
import r2.l0;

/* loaded from: classes.dex */
public final class t0 implements Parcelable {

    /* renamed from: a, reason: collision with root package name */
    private final String f5561a;

    /* renamed from: b, reason: collision with root package name */
    private final String f5562b;

    /* renamed from: c, reason: collision with root package name */
    private final String f5563c;

    /* renamed from: d, reason: collision with root package name */
    private final String f5564d;

    /* renamed from: e, reason: collision with root package name */
    private final String f5565e;

    /* renamed from: f, reason: collision with root package name */
    private final Uri f5566f;

    /* renamed from: g, reason: collision with root package name */
    private final Uri f5567g;

    /* renamed from: h, reason: collision with root package name */
    public static final b f5559h = new b(null);

    /* renamed from: i, reason: collision with root package name */
    private static final String f5560i = t0.class.getSimpleName();
    public static final Parcelable.Creator<t0> CREATOR = new a();

    public static final class a implements Parcelable.Creator<t0> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public t0 createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new t0(source, null);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public t0[] newArray(int i10) {
            return new t0[i10];
        }
    }

    public static final class b {

        public static final class a implements l0.a {
            a() {
            }

            @Override // r2.l0.a
            public void a(JSONObject jSONObject) {
                String strOptString = jSONObject == null ? null : jSONObject.optString("id");
                if (strOptString == null) {
                    Log.w(t0.f5560i, "No user ID returned on Me request");
                    return;
                }
                String strOptString2 = jSONObject.optString("link");
                String strOptString3 = jSONObject.optString("profile_picture", null);
                t0.f5559h.c(new t0(strOptString, jSONObject.optString("first_name"), jSONObject.optString("middle_name"), jSONObject.optString("last_name"), jSONObject.optString("name"), strOptString2 != null ? Uri.parse(strOptString2) : null, strOptString3 != null ? Uri.parse(strOptString3) : null));
            }

            @Override // r2.l0.a
            public void b(s sVar) {
                Log.e(t0.f5560i, kotlin.jvm.internal.m.n("Got unexpected exception: ", sVar));
            }
        }

        private b() {
        }

        public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final void a() {
            a.c cVar = b2.a.f5323l;
            b2.a aVarE = cVar.e();
            if (aVarE == null) {
                return;
            }
            if (!cVar.g()) {
                c(null);
            } else {
                r2.l0 l0Var = r2.l0.f20174a;
                r2.l0.D(aVarE.w(), new a());
            }
        }

        public final t0 b() {
            return v0.f5593d.a().c();
        }

        public final void c(t0 t0Var) {
            v0.f5593d.a().f(t0Var);
        }
    }

    private t0(Parcel parcel) {
        this.f5561a = parcel.readString();
        this.f5562b = parcel.readString();
        this.f5563c = parcel.readString();
        this.f5564d = parcel.readString();
        this.f5565e = parcel.readString();
        String string = parcel.readString();
        this.f5566f = string == null ? null : Uri.parse(string);
        String string2 = parcel.readString();
        this.f5567g = string2 != null ? Uri.parse(string2) : null;
    }

    public /* synthetic */ t0(Parcel parcel, kotlin.jvm.internal.g gVar) {
        this(parcel);
    }

    public t0(String str, String str2, String str3, String str4, String str5, Uri uri, Uri uri2) {
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.k(str, "id");
        this.f5561a = str;
        this.f5562b = str2;
        this.f5563c = str3;
        this.f5564d = str4;
        this.f5565e = str5;
        this.f5566f = uri;
        this.f5567g = uri2;
    }

    public t0(JSONObject jsonObject) {
        kotlin.jvm.internal.m.g(jsonObject, "jsonObject");
        this.f5561a = jsonObject.optString("id", null);
        this.f5562b = jsonObject.optString("first_name", null);
        this.f5563c = jsonObject.optString("middle_name", null);
        this.f5564d = jsonObject.optString("last_name", null);
        this.f5565e = jsonObject.optString("name", null);
        String strOptString = jsonObject.optString("link_uri", null);
        this.f5566f = strOptString == null ? null : Uri.parse(strOptString);
        String strOptString2 = jsonObject.optString("picture_uri", null);
        this.f5567g = strOptString2 != null ? Uri.parse(strOptString2) : null;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        String str;
        String str2;
        String str3;
        String str4;
        Uri uri;
        Uri uri2;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof t0)) {
            return false;
        }
        String str5 = this.f5561a;
        return ((str5 == null && ((t0) obj).f5561a == null) || kotlin.jvm.internal.m.b(str5, ((t0) obj).f5561a)) && (((str = this.f5562b) == null && ((t0) obj).f5562b == null) || kotlin.jvm.internal.m.b(str, ((t0) obj).f5562b)) && ((((str2 = this.f5563c) == null && ((t0) obj).f5563c == null) || kotlin.jvm.internal.m.b(str2, ((t0) obj).f5563c)) && ((((str3 = this.f5564d) == null && ((t0) obj).f5564d == null) || kotlin.jvm.internal.m.b(str3, ((t0) obj).f5564d)) && ((((str4 = this.f5565e) == null && ((t0) obj).f5565e == null) || kotlin.jvm.internal.m.b(str4, ((t0) obj).f5565e)) && ((((uri = this.f5566f) == null && ((t0) obj).f5566f == null) || kotlin.jvm.internal.m.b(uri, ((t0) obj).f5566f)) && (((uri2 = this.f5567g) == null && ((t0) obj).f5567g == null) || kotlin.jvm.internal.m.b(uri2, ((t0) obj).f5567g))))));
    }

    public final JSONObject h() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("id", this.f5561a);
            jSONObject.put("first_name", this.f5562b);
            jSONObject.put("middle_name", this.f5563c);
            jSONObject.put("last_name", this.f5564d);
            jSONObject.put("name", this.f5565e);
            Uri uri = this.f5566f;
            if (uri != null) {
                jSONObject.put("link_uri", uri.toString());
            }
            Uri uri2 = this.f5567g;
            if (uri2 != null) {
                jSONObject.put("picture_uri", uri2.toString());
            }
            return jSONObject;
        } catch (JSONException unused) {
            return null;
        }
    }

    public int hashCode() {
        String str = this.f5561a;
        int iHashCode = 527 + (str != null ? str.hashCode() : 0);
        String str2 = this.f5562b;
        if (str2 != null) {
            iHashCode = (iHashCode * 31) + str2.hashCode();
        }
        String str3 = this.f5563c;
        if (str3 != null) {
            iHashCode = (iHashCode * 31) + str3.hashCode();
        }
        String str4 = this.f5564d;
        if (str4 != null) {
            iHashCode = (iHashCode * 31) + str4.hashCode();
        }
        String str5 = this.f5565e;
        if (str5 != null) {
            iHashCode = (iHashCode * 31) + str5.hashCode();
        }
        Uri uri = this.f5566f;
        if (uri != null) {
            iHashCode = (iHashCode * 31) + uri.hashCode();
        }
        Uri uri2 = this.f5567g;
        return uri2 != null ? (iHashCode * 31) + uri2.hashCode() : iHashCode;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int i10) {
        kotlin.jvm.internal.m.g(dest, "dest");
        dest.writeString(this.f5561a);
        dest.writeString(this.f5562b);
        dest.writeString(this.f5563c);
        dest.writeString(this.f5564d);
        dest.writeString(this.f5565e);
        Uri uri = this.f5566f;
        dest.writeString(uri == null ? null : uri.toString());
        Uri uri2 = this.f5567g;
        dest.writeString(uri2 != null ? uri2.toString() : null);
    }
}
