package b2;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class l implements Parcelable {

    /* renamed from: a, reason: collision with root package name */
    private final String f5485a;

    /* renamed from: b, reason: collision with root package name */
    private final String f5486b;

    /* renamed from: c, reason: collision with root package name */
    private final String f5487c;

    /* renamed from: d, reason: collision with root package name */
    private final String f5488d;

    /* renamed from: e, reason: collision with root package name */
    private final long f5489e;

    /* renamed from: f, reason: collision with root package name */
    private final long f5490f;

    /* renamed from: g, reason: collision with root package name */
    private final String f5491g;

    /* renamed from: h, reason: collision with root package name */
    private final String f5492h;

    /* renamed from: i, reason: collision with root package name */
    private final String f5493i;

    /* renamed from: j, reason: collision with root package name */
    private final String f5494j;

    /* renamed from: k, reason: collision with root package name */
    private final String f5495k;

    /* renamed from: l, reason: collision with root package name */
    private final String f5496l;

    /* renamed from: r, reason: collision with root package name */
    private final String f5497r;

    /* renamed from: s, reason: collision with root package name */
    private final Set<String> f5498s;

    /* renamed from: t, reason: collision with root package name */
    private final String f5499t;

    /* renamed from: u, reason: collision with root package name */
    private final Map<String, Integer> f5500u;

    /* renamed from: v, reason: collision with root package name */
    private final Map<String, String> f5501v;

    /* renamed from: w, reason: collision with root package name */
    private final Map<String, String> f5502w;

    /* renamed from: x, reason: collision with root package name */
    private final String f5503x;

    /* renamed from: y, reason: collision with root package name */
    private final String f5504y;

    /* renamed from: z, reason: collision with root package name */
    public static final b f5484z = new b(null);
    public static final Parcelable.Creator<l> CREATOR = new a();

    public static final class a implements Parcelable.Creator<l> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public l createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new l(source);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public l[] newArray(int i10) {
            return new l[i10];
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final String a(JSONObject jSONObject, String name) {
            kotlin.jvm.internal.m.g(jSONObject, "<this>");
            kotlin.jvm.internal.m.g(name, "name");
            if (jSONObject.has(name)) {
                return jSONObject.getString(name);
            }
            return null;
        }
    }

    public l(Parcel parcel) {
        kotlin.jvm.internal.m.g(parcel, "parcel");
        String string = parcel.readString();
        r2.m0 m0Var = r2.m0.f20185a;
        this.f5485a = r2.m0.k(string, "jti");
        this.f5486b = r2.m0.k(parcel.readString(), "iss");
        this.f5487c = r2.m0.k(parcel.readString(), "aud");
        this.f5488d = r2.m0.k(parcel.readString(), "nonce");
        this.f5489e = parcel.readLong();
        this.f5490f = parcel.readLong();
        this.f5491g = r2.m0.k(parcel.readString(), "sub");
        this.f5492h = parcel.readString();
        this.f5493i = parcel.readString();
        this.f5494j = parcel.readString();
        this.f5495k = parcel.readString();
        this.f5496l = parcel.readString();
        this.f5497r = parcel.readString();
        ArrayList<String> arrayListCreateStringArrayList = parcel.createStringArrayList();
        this.f5498s = arrayListCreateStringArrayList != null ? Collections.unmodifiableSet(new HashSet(arrayListCreateStringArrayList)) : null;
        this.f5499t = parcel.readString();
        HashMap hashMap = parcel.readHashMap(kotlin.jvm.internal.l.f17298a.getClass().getClassLoader());
        hashMap = hashMap instanceof HashMap ? hashMap : null;
        this.f5500u = hashMap != null ? Collections.unmodifiableMap(hashMap) : null;
        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
        HashMap hashMap2 = parcel.readHashMap(wVar.getClass().getClassLoader());
        hashMap2 = hashMap2 instanceof HashMap ? hashMap2 : null;
        this.f5501v = hashMap2 != null ? Collections.unmodifiableMap(hashMap2) : null;
        HashMap hashMap3 = parcel.readHashMap(wVar.getClass().getClassLoader());
        hashMap3 = hashMap3 instanceof HashMap ? hashMap3 : null;
        this.f5502w = hashMap3 != null ? Collections.unmodifiableMap(hashMap3) : null;
        this.f5503x = parcel.readString();
        this.f5504y = parcel.readString();
    }

    public l(String encodedClaims, String expectedNonce) throws JSONException {
        Set<String> setUnmodifiableSet;
        Map<String, Integer> mapUnmodifiableMap;
        Map<String, String> mapUnmodifiableMap2;
        kotlin.jvm.internal.m.g(encodedClaims, "encodedClaims");
        kotlin.jvm.internal.m.g(expectedNonce, "expectedNonce");
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.g(encodedClaims, "encodedClaims");
        byte[] decodedBytes = Base64.decode(encodedClaims, 8);
        kotlin.jvm.internal.m.f(decodedBytes, "decodedBytes");
        JSONObject jSONObject = new JSONObject(new String(decodedBytes, md.d.f17896b));
        if (!b(jSONObject, expectedNonce)) {
            throw new IllegalArgumentException("Invalid claims".toString());
        }
        String string = jSONObject.getString("jti");
        kotlin.jvm.internal.m.f(string, "jsonObj.getString(JSON_KEY_JIT)");
        this.f5485a = string;
        String string2 = jSONObject.getString("iss");
        kotlin.jvm.internal.m.f(string2, "jsonObj.getString(JSON_KEY_ISS)");
        this.f5486b = string2;
        String string3 = jSONObject.getString("aud");
        kotlin.jvm.internal.m.f(string3, "jsonObj.getString(JSON_KEY_AUD)");
        this.f5487c = string3;
        String string4 = jSONObject.getString("nonce");
        kotlin.jvm.internal.m.f(string4, "jsonObj.getString(JSON_KEY_NONCE)");
        this.f5488d = string4;
        this.f5489e = jSONObject.getLong("exp");
        this.f5490f = jSONObject.getLong("iat");
        String string5 = jSONObject.getString("sub");
        kotlin.jvm.internal.m.f(string5, "jsonObj.getString(JSON_KEY_SUB)");
        this.f5491g = string5;
        b bVar = f5484z;
        this.f5492h = bVar.a(jSONObject, "name");
        this.f5493i = bVar.a(jSONObject, "given_name");
        this.f5494j = bVar.a(jSONObject, "middle_name");
        this.f5495k = bVar.a(jSONObject, "family_name");
        this.f5496l = bVar.a(jSONObject, "email");
        this.f5497r = bVar.a(jSONObject, "picture");
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("user_friends");
        Map<String, String> mapUnmodifiableMap3 = null;
        if (jSONArrayOptJSONArray == null) {
            setUnmodifiableSet = null;
        } else {
            r2.l0 l0Var = r2.l0.f20174a;
            setUnmodifiableSet = Collections.unmodifiableSet(r2.l0.a0(jSONArrayOptJSONArray));
        }
        this.f5498s = setUnmodifiableSet;
        this.f5499t = bVar.a(jSONObject, "user_birthday");
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("user_age_range");
        if (jSONObjectOptJSONObject == null) {
            mapUnmodifiableMap = null;
        } else {
            r2.l0 l0Var2 = r2.l0.f20174a;
            mapUnmodifiableMap = Collections.unmodifiableMap(r2.l0.n(jSONObjectOptJSONObject));
        }
        this.f5500u = mapUnmodifiableMap;
        JSONObject jSONObjectOptJSONObject2 = jSONObject.optJSONObject("user_hometown");
        if (jSONObjectOptJSONObject2 == null) {
            mapUnmodifiableMap2 = null;
        } else {
            r2.l0 l0Var3 = r2.l0.f20174a;
            mapUnmodifiableMap2 = Collections.unmodifiableMap(r2.l0.o(jSONObjectOptJSONObject2));
        }
        this.f5501v = mapUnmodifiableMap2;
        JSONObject jSONObjectOptJSONObject3 = jSONObject.optJSONObject("user_location");
        if (jSONObjectOptJSONObject3 != null) {
            r2.l0 l0Var4 = r2.l0.f20174a;
            mapUnmodifiableMap3 = Collections.unmodifiableMap(r2.l0.o(jSONObjectOptJSONObject3));
        }
        this.f5502w = mapUnmodifiableMap3;
        this.f5503x = bVar.a(jSONObject, "user_gender");
        this.f5504y = bVar.a(jSONObject, "user_link");
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x0052  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final boolean b(org.json.JSONObject r9, java.lang.String r10) {
        /*
            r8 = this;
            java.lang.String r0 = "iss"
            r1 = 0
            if (r9 != 0) goto L6
            return r1
        L6:
            java.lang.String r2 = "jti"
            java.lang.String r3 = r9.optString(r2)
            kotlin.jvm.internal.m.f(r3, r2)
            int r2 = r3.length()
            r3 = 1
            if (r2 != 0) goto L18
            r2 = 1
            goto L19
        L18:
            r2 = 0
        L19:
            if (r2 == 0) goto L1c
            return r1
        L1c:
            java.lang.String r2 = r9.optString(r0)     // Catch: java.net.MalformedURLException -> Ldd
            kotlin.jvm.internal.m.f(r2, r0)     // Catch: java.net.MalformedURLException -> Ldd
            int r0 = r2.length()     // Catch: java.net.MalformedURLException -> Ldd
            if (r0 != 0) goto L2b
            r0 = 1
            goto L2c
        L2b:
            r0 = 0
        L2c:
            if (r0 != 0) goto Ldd
            java.net.URL r0 = new java.net.URL     // Catch: java.net.MalformedURLException -> Ldd
            r0.<init>(r2)     // Catch: java.net.MalformedURLException -> Ldd
            java.lang.String r0 = r0.getHost()     // Catch: java.net.MalformedURLException -> Ldd
            java.lang.String r4 = "facebook.com"
            boolean r0 = kotlin.jvm.internal.m.b(r0, r4)     // Catch: java.net.MalformedURLException -> Ldd
            if (r0 != 0) goto L52
            java.net.URL r0 = new java.net.URL     // Catch: java.net.MalformedURLException -> Ldd
            r0.<init>(r2)     // Catch: java.net.MalformedURLException -> Ldd
            java.lang.String r0 = r0.getHost()     // Catch: java.net.MalformedURLException -> Ldd
            java.lang.String r2 = "www.facebook.com"
            boolean r0 = kotlin.jvm.internal.m.b(r0, r2)     // Catch: java.net.MalformedURLException -> Ldd
            if (r0 != 0) goto L52
            goto Ldd
        L52:
            java.lang.String r0 = "aud"
            java.lang.String r2 = r9.optString(r0)
            kotlin.jvm.internal.m.f(r2, r0)
            int r0 = r2.length()
            if (r0 != 0) goto L63
            r0 = 1
            goto L64
        L63:
            r0 = 0
        L64:
            if (r0 != 0) goto Ldd
            b2.f0 r0 = b2.f0.f5388a
            java.lang.String r0 = b2.f0.m()
            boolean r0 = kotlin.jvm.internal.m.b(r2, r0)
            if (r0 != 0) goto L73
            goto Ldd
        L73:
            java.util.Date r0 = new java.util.Date
            java.lang.String r2 = "exp"
            long r4 = r9.optLong(r2)
            r2 = 1000(0x3e8, float:1.401E-42)
            long r6 = (long) r2
            long r4 = r4 * r6
            r0.<init>(r4)
            java.util.Date r2 = new java.util.Date
            r2.<init>()
            boolean r0 = r2.after(r0)
            if (r0 == 0) goto L8f
            return r1
        L8f:
            java.lang.String r0 = "iat"
            long r4 = r9.optLong(r0)
            java.util.Date r0 = new java.util.Date
            long r4 = r4 * r6
            r6 = 600000(0x927c0, double:2.964394E-318)
            long r4 = r4 + r6
            r0.<init>(r4)
            java.util.Date r2 = new java.util.Date
            r2.<init>()
            boolean r0 = r2.after(r0)
            if (r0 == 0) goto Lac
            return r1
        Lac:
            java.lang.String r0 = "sub"
            java.lang.String r2 = r9.optString(r0)
            kotlin.jvm.internal.m.f(r2, r0)
            int r0 = r2.length()
            if (r0 != 0) goto Lbd
            r0 = 1
            goto Lbe
        Lbd:
            r0 = 0
        Lbe:
            if (r0 == 0) goto Lc1
            return r1
        Lc1:
            java.lang.String r0 = "nonce"
            java.lang.String r9 = r9.optString(r0)
            kotlin.jvm.internal.m.f(r9, r0)
            int r0 = r9.length()
            if (r0 != 0) goto Ld2
            r0 = 1
            goto Ld3
        Ld2:
            r0 = 0
        Ld3:
            if (r0 != 0) goto Ldd
            boolean r9 = kotlin.jvm.internal.m.b(r9, r10)
            if (r9 != 0) goto Ldc
            goto Ldd
        Ldc:
            return r3
        Ldd:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: b2.l.b(org.json.JSONObject, java.lang.String):boolean");
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof l)) {
            return false;
        }
        l lVar = (l) obj;
        return kotlin.jvm.internal.m.b(this.f5485a, lVar.f5485a) && kotlin.jvm.internal.m.b(this.f5486b, lVar.f5486b) && kotlin.jvm.internal.m.b(this.f5487c, lVar.f5487c) && kotlin.jvm.internal.m.b(this.f5488d, lVar.f5488d) && this.f5489e == lVar.f5489e && this.f5490f == lVar.f5490f && kotlin.jvm.internal.m.b(this.f5491g, lVar.f5491g) && kotlin.jvm.internal.m.b(this.f5492h, lVar.f5492h) && kotlin.jvm.internal.m.b(this.f5493i, lVar.f5493i) && kotlin.jvm.internal.m.b(this.f5494j, lVar.f5494j) && kotlin.jvm.internal.m.b(this.f5495k, lVar.f5495k) && kotlin.jvm.internal.m.b(this.f5496l, lVar.f5496l) && kotlin.jvm.internal.m.b(this.f5497r, lVar.f5497r) && kotlin.jvm.internal.m.b(this.f5498s, lVar.f5498s) && kotlin.jvm.internal.m.b(this.f5499t, lVar.f5499t) && kotlin.jvm.internal.m.b(this.f5500u, lVar.f5500u) && kotlin.jvm.internal.m.b(this.f5501v, lVar.f5501v) && kotlin.jvm.internal.m.b(this.f5502w, lVar.f5502w) && kotlin.jvm.internal.m.b(this.f5503x, lVar.f5503x) && kotlin.jvm.internal.m.b(this.f5504y, lVar.f5504y);
    }

    public final JSONObject h() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("jti", this.f5485a);
        jSONObject.put("iss", this.f5486b);
        jSONObject.put("aud", this.f5487c);
        jSONObject.put("nonce", this.f5488d);
        jSONObject.put("exp", this.f5489e);
        jSONObject.put("iat", this.f5490f);
        String str = this.f5491g;
        if (str != null) {
            jSONObject.put("sub", str);
        }
        String str2 = this.f5492h;
        if (str2 != null) {
            jSONObject.put("name", str2);
        }
        String str3 = this.f5493i;
        if (str3 != null) {
            jSONObject.put("given_name", str3);
        }
        String str4 = this.f5494j;
        if (str4 != null) {
            jSONObject.put("middle_name", str4);
        }
        String str5 = this.f5495k;
        if (str5 != null) {
            jSONObject.put("family_name", str5);
        }
        String str6 = this.f5496l;
        if (str6 != null) {
            jSONObject.put("email", str6);
        }
        String str7 = this.f5497r;
        if (str7 != null) {
            jSONObject.put("picture", str7);
        }
        if (this.f5498s != null) {
            jSONObject.put("user_friends", new JSONArray((Collection) this.f5498s));
        }
        String str8 = this.f5499t;
        if (str8 != null) {
            jSONObject.put("user_birthday", str8);
        }
        if (this.f5500u != null) {
            jSONObject.put("user_age_range", new JSONObject(this.f5500u));
        }
        if (this.f5501v != null) {
            jSONObject.put("user_hometown", new JSONObject(this.f5501v));
        }
        if (this.f5502w != null) {
            jSONObject.put("user_location", new JSONObject(this.f5502w));
        }
        String str9 = this.f5503x;
        if (str9 != null) {
            jSONObject.put("user_gender", str9);
        }
        String str10 = this.f5504y;
        if (str10 != null) {
            jSONObject.put("user_link", str10);
        }
        return jSONObject;
    }

    public int hashCode() {
        int iHashCode = (((((((((((((527 + this.f5485a.hashCode()) * 31) + this.f5486b.hashCode()) * 31) + this.f5487c.hashCode()) * 31) + this.f5488d.hashCode()) * 31) + k.a(this.f5489e)) * 31) + k.a(this.f5490f)) * 31) + this.f5491g.hashCode()) * 31;
        String str = this.f5492h;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        String str2 = this.f5493i;
        int iHashCode3 = (iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.f5494j;
        int iHashCode4 = (iHashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.f5495k;
        int iHashCode5 = (iHashCode4 + (str4 == null ? 0 : str4.hashCode())) * 31;
        String str5 = this.f5496l;
        int iHashCode6 = (iHashCode5 + (str5 == null ? 0 : str5.hashCode())) * 31;
        String str6 = this.f5497r;
        int iHashCode7 = (iHashCode6 + (str6 == null ? 0 : str6.hashCode())) * 31;
        Set<String> set = this.f5498s;
        int iHashCode8 = (iHashCode7 + (set == null ? 0 : set.hashCode())) * 31;
        String str7 = this.f5499t;
        int iHashCode9 = (iHashCode8 + (str7 == null ? 0 : str7.hashCode())) * 31;
        Map<String, Integer> map = this.f5500u;
        int iHashCode10 = (iHashCode9 + (map == null ? 0 : map.hashCode())) * 31;
        Map<String, String> map2 = this.f5501v;
        int iHashCode11 = (iHashCode10 + (map2 == null ? 0 : map2.hashCode())) * 31;
        Map<String, String> map3 = this.f5502w;
        int iHashCode12 = (iHashCode11 + (map3 == null ? 0 : map3.hashCode())) * 31;
        String str8 = this.f5503x;
        int iHashCode13 = (iHashCode12 + (str8 == null ? 0 : str8.hashCode())) * 31;
        String str9 = this.f5504y;
        return iHashCode13 + (str9 != null ? str9.hashCode() : 0);
    }

    public String toString() {
        String string = h().toString();
        kotlin.jvm.internal.m.f(string, "claimsJsonObject.toString()");
        return string;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int i10) {
        kotlin.jvm.internal.m.g(dest, "dest");
        dest.writeString(this.f5485a);
        dest.writeString(this.f5486b);
        dest.writeString(this.f5487c);
        dest.writeString(this.f5488d);
        dest.writeLong(this.f5489e);
        dest.writeLong(this.f5490f);
        dest.writeString(this.f5491g);
        dest.writeString(this.f5492h);
        dest.writeString(this.f5493i);
        dest.writeString(this.f5494j);
        dest.writeString(this.f5495k);
        dest.writeString(this.f5496l);
        dest.writeString(this.f5497r);
        dest.writeStringList(this.f5498s == null ? null : new ArrayList(this.f5498s));
        dest.writeString(this.f5499t);
        dest.writeMap(this.f5500u);
        dest.writeMap(this.f5501v);
        dest.writeMap(this.f5502w);
        dest.writeString(this.f5503x);
        dest.writeString(this.f5504y);
    }
}
