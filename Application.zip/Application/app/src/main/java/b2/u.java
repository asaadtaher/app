package b2;

/* loaded from: classes.dex */
public final class u extends s {

    /* renamed from: b, reason: collision with root package name */
    public static final a f5568b = new a(null);

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public u() {
    }

    public u(String str) {
        super(str);
    }
}
