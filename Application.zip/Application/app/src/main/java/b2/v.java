package b2;

import android.os.Parcel;
import android.os.Parcelable;
import java.net.HttpURLConnection;
import java.util.Arrays;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class v implements Parcelable {

    /* renamed from: a, reason: collision with root package name */
    private final int f5573a;

    /* renamed from: b, reason: collision with root package name */
    private final int f5574b;

    /* renamed from: c, reason: collision with root package name */
    private final int f5575c;

    /* renamed from: d, reason: collision with root package name */
    private final String f5576d;

    /* renamed from: e, reason: collision with root package name */
    private final String f5577e;

    /* renamed from: f, reason: collision with root package name */
    private final String f5578f;

    /* renamed from: g, reason: collision with root package name */
    private final JSONObject f5579g;

    /* renamed from: h, reason: collision with root package name */
    private final JSONObject f5580h;

    /* renamed from: i, reason: collision with root package name */
    private final Object f5581i;

    /* renamed from: j, reason: collision with root package name */
    private final HttpURLConnection f5582j;

    /* renamed from: k, reason: collision with root package name */
    private final String f5583k;

    /* renamed from: l, reason: collision with root package name */
    private s f5584l;

    /* renamed from: r, reason: collision with root package name */
    private final a f5585r;

    /* renamed from: s, reason: collision with root package name */
    private final String f5586s;

    /* renamed from: t, reason: collision with root package name */
    public static final c f5571t = new c(null);

    /* renamed from: u, reason: collision with root package name */
    private static final d f5572u = new d(200, 299);
    public static final Parcelable.Creator<v> CREATOR = new b();

    public enum a {
        LOGIN_RECOVERABLE,
        OTHER,
        TRANSIENT;

        /* renamed from: values, reason: to resolve conflict with enum method */
        public static a[] valuesCustom() {
            a[] aVarArrValuesCustom = values();
            return (a[]) Arrays.copyOf(aVarArrValuesCustom, aVarArrValuesCustom.length);
        }
    }

    public static final class b implements Parcelable.Creator<v> {
        b() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public v createFromParcel(Parcel parcel) {
            kotlin.jvm.internal.m.g(parcel, "parcel");
            return new v(parcel, (kotlin.jvm.internal.g) null);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public v[] newArray(int i10) {
            return new v[i10];
        }
    }

    public static final class c {
        private c() {
        }

        public /* synthetic */ c(kotlin.jvm.internal.g gVar) {
            this();
        }

        /* JADX WARN: Removed duplicated region for block: B:47:0x00d1 A[Catch: JSONException -> 0x012f, TryCatch #0 {JSONException -> 0x012f, blocks: (B:3:0x0012, B:5:0x0018, B:7:0x0024, B:9:0x0028, B:12:0x0036, B:47:0x00d1, B:33:0x0079, B:30:0x0070, B:27:0x0066, B:24:0x005e, B:21:0x0057, B:18:0x004d, B:15:0x0043, B:35:0x0085, B:38:0x0092, B:40:0x009b, B:44:0x00ac, B:49:0x00f2, B:51:0x00fc, B:53:0x010a, B:55:0x0113), top: B:59:0x0012 }] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final b2.v a(org.json.JSONObject r20, java.lang.Object r21, java.net.HttpURLConnection r22) throws org.json.JSONException {
            /*
                Method dump skipped, instructions count: 304
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: b2.v.c.a(org.json.JSONObject, java.lang.Object, java.net.HttpURLConnection):b2.v");
        }

        public final synchronized r2.j b() {
            r2.v vVar = r2.v.f20292a;
            f0 f0Var = f0.f5388a;
            r2.r rVarF = r2.v.f(f0.m());
            if (rVarF == null) {
                return r2.j.f20159g.b();
            }
            return rVarF.c();
        }

        public final d c() {
            return v.f5572u;
        }
    }

    public static final class d {

        /* renamed from: a, reason: collision with root package name */
        private final int f5591a;

        /* renamed from: b, reason: collision with root package name */
        private final int f5592b;

        public d(int i10, int i11) {
            this.f5591a = i10;
            this.f5592b = i11;
        }

        public final boolean a(int i10) {
            return i10 <= this.f5592b && this.f5591a <= i10;
        }
    }

    private v(int i10, int i11, int i12, String str, String str2, String str3, String str4, JSONObject jSONObject, JSONObject jSONObject2, Object obj, HttpURLConnection httpURLConnection, s sVar, boolean z10) {
        boolean z11;
        this.f5573a = i10;
        this.f5574b = i11;
        this.f5575c = i12;
        this.f5576d = str;
        this.f5577e = str3;
        this.f5578f = str4;
        this.f5579g = jSONObject;
        this.f5580h = jSONObject2;
        this.f5581i = obj;
        this.f5582j = httpURLConnection;
        this.f5583k = str2;
        if (sVar != null) {
            this.f5584l = sVar;
            z11 = true;
        } else {
            this.f5584l = new h0(this, i());
            z11 = false;
        }
        a aVarC = z11 ? a.OTHER : f5571t.b().c(i11, i12, z10);
        this.f5585r = aVarC;
        this.f5586s = f5571t.b().d(aVarC);
    }

    public /* synthetic */ v(int i10, int i11, int i12, String str, String str2, String str3, String str4, JSONObject jSONObject, JSONObject jSONObject2, Object obj, HttpURLConnection httpURLConnection, s sVar, boolean z10, kotlin.jvm.internal.g gVar) {
        this(i10, i11, i12, str, str2, str3, str4, jSONObject, jSONObject2, obj, httpURLConnection, sVar, z10);
    }

    public v(int i10, String str, String str2) {
        this(-1, i10, -1, str, str2, null, null, null, null, null, null, null, false);
    }

    private v(Parcel parcel) {
        this(parcel.readInt(), parcel.readInt(), parcel.readInt(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), null, null, null, null, null, false);
    }

    public /* synthetic */ v(Parcel parcel, kotlin.jvm.internal.g gVar) {
        this(parcel);
    }

    public v(HttpURLConnection httpURLConnection, Exception exc) {
        this(-1, -1, -1, null, null, null, null, null, null, null, httpURLConnection, exc instanceof s ? (s) exc : new s(exc), false);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public final int h() {
        return this.f5574b;
    }

    public final String i() {
        String str = this.f5583k;
        if (str != null) {
            return str;
        }
        s sVar = this.f5584l;
        if (sVar == null) {
            return null;
        }
        return sVar.getLocalizedMessage();
    }

    public final String j() {
        return this.f5576d;
    }

    public final s k() {
        return this.f5584l;
    }

    public final int l() {
        return this.f5573a;
    }

    public final int m() {
        return this.f5575c;
    }

    public String toString() {
        String str = "{HttpStatus: " + this.f5573a + ", errorCode: " + this.f5574b + ", subErrorCode: " + this.f5575c + ", errorType: " + this.f5576d + ", errorMessage: " + i() + "}";
        kotlin.jvm.internal.m.f(str, "StringBuilder(\"{HttpStatus: \")\n        .append(requestStatusCode)\n        .append(\", errorCode: \")\n        .append(errorCode)\n        .append(\", subErrorCode: \")\n        .append(subErrorCode)\n        .append(\", errorType: \")\n        .append(errorType)\n        .append(\", errorMessage: \")\n        .append(errorMessage)\n        .append(\"}\")\n        .toString()");
        return str;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel out, int i10) {
        kotlin.jvm.internal.m.g(out, "out");
        out.writeInt(this.f5573a);
        out.writeInt(this.f5574b);
        out.writeInt(this.f5575c);
        out.writeString(this.f5576d);
        out.writeString(i());
        out.writeString(this.f5577e);
        out.writeString(this.f5578f);
    }
}
