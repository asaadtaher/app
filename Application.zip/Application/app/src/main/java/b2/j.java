package b2;

import android.content.SharedPreferences;
import org.json.JSONException;

/* loaded from: classes.dex */
public final class j {

    /* renamed from: b, reason: collision with root package name */
    public static final a f5452b = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private final SharedPreferences f5453a;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public j() {
        f0 f0Var = f0.f5388a;
        SharedPreferences sharedPreferences = f0.l().getSharedPreferences("com.facebook.AuthenticationTokenManager.SharedPreferences", 0);
        kotlin.jvm.internal.m.f(sharedPreferences, "FacebookSdk.getApplicationContext()\n              .getSharedPreferences(\n                  AuthenticationTokenManager.SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE)");
        this(sharedPreferences);
    }

    public j(SharedPreferences sharedPreferences) {
        kotlin.jvm.internal.m.g(sharedPreferences, "sharedPreferences");
        this.f5453a = sharedPreferences;
    }

    public final void a() {
        this.f5453a.edit().remove("com.facebook.AuthenticationManager.CachedAuthenticationToken").apply();
    }

    public final void b(i authenticationToken) {
        kotlin.jvm.internal.m.g(authenticationToken, "authenticationToken");
        try {
            this.f5453a.edit().putString("com.facebook.AuthenticationManager.CachedAuthenticationToken", authenticationToken.h().toString()).apply();
        } catch (JSONException unused) {
        }
    }
}
