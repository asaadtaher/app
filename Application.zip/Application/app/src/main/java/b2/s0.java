package b2;

/* loaded from: classes.dex */
public interface s0 {
    void a(a aVar);

    void b();

    void c(Exception exc);
}
