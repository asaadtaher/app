package b2;

import java.util.Arrays;

/* loaded from: classes.dex */
public enum p0 {
    GET,
    POST,
    DELETE;

    /* renamed from: values, reason: to resolve conflict with enum method */
    public static p0[] valuesCustom() {
        p0[] p0VarArrValuesCustom = values();
        return (p0[]) Arrays.copyOf(p0VarArrValuesCustom, p0VarArrValuesCustom.length);
    }
}
