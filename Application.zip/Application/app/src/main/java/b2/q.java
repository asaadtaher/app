package b2;

/* loaded from: classes.dex */
public final class q extends s {

    /* renamed from: d, reason: collision with root package name */
    public static final a f5540d = new a(null);

    /* renamed from: b, reason: collision with root package name */
    private final int f5541b;

    /* renamed from: c, reason: collision with root package name */
    private final String f5542c;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public q(String str, int i10, String str2) {
        super(str);
        this.f5541b = i10;
        this.f5542c = str2;
    }

    @Override // b2.s, java.lang.Throwable
    public String toString() {
        String str = "{FacebookDialogException: errorCode: " + this.f5541b + ", message: " + getMessage() + ", url: " + this.f5542c + "}";
        kotlin.jvm.internal.m.f(str, "StringBuilder()\n        .append(\"{FacebookDialogException: \")\n        .append(\"errorCode: \")\n        .append(errorCode)\n        .append(\", message: \")\n        .append(message)\n        .append(\", url: \")\n        .append(failingUrl)\n        .append(\"}\")\n        .toString()");
        return str;
    }
}
