package b2;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Pair;
import b2.j0;
import b2.n0;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import r2.c0;

/* loaded from: classes.dex */
public final class j0 {

    /* renamed from: n, reason: collision with root package name */
    public static final c f5454n = new c(null);

    /* renamed from: o, reason: collision with root package name */
    public static final String f5455o = j0.class.getSimpleName();

    /* renamed from: p, reason: collision with root package name */
    private static final String f5456p;

    /* renamed from: q, reason: collision with root package name */
    private static String f5457q;

    /* renamed from: r, reason: collision with root package name */
    private static final Pattern f5458r;

    /* renamed from: s, reason: collision with root package name */
    private static volatile String f5459s;

    /* renamed from: a, reason: collision with root package name */
    private b2.a f5460a;

    /* renamed from: b, reason: collision with root package name */
    private String f5461b;

    /* renamed from: c, reason: collision with root package name */
    private JSONObject f5462c;

    /* renamed from: d, reason: collision with root package name */
    private String f5463d;

    /* renamed from: e, reason: collision with root package name */
    private String f5464e;

    /* renamed from: f, reason: collision with root package name */
    private boolean f5465f;

    /* renamed from: g, reason: collision with root package name */
    private Bundle f5466g;

    /* renamed from: h, reason: collision with root package name */
    private Object f5467h;

    /* renamed from: i, reason: collision with root package name */
    private String f5468i;

    /* renamed from: j, reason: collision with root package name */
    private b f5469j;

    /* renamed from: k, reason: collision with root package name */
    private p0 f5470k;

    /* renamed from: l, reason: collision with root package name */
    private boolean f5471l;

    /* renamed from: m, reason: collision with root package name */
    private String f5472m;

    private static final class a {

        /* renamed from: a, reason: collision with root package name */
        private final j0 f5473a;

        /* renamed from: b, reason: collision with root package name */
        private final Object f5474b;

        public a(j0 request, Object obj) {
            kotlin.jvm.internal.m.g(request, "request");
            this.f5473a = request;
            this.f5474b = obj;
        }

        public final j0 a() {
            return this.f5473a;
        }

        public final Object b() {
            return this.f5474b;
        }
    }

    public interface b {
        void b(o0 o0Var);
    }

    public static final class c {
        private c() {
        }

        public /* synthetic */ c(kotlin.jvm.internal.g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final String C(Object obj) {
            if (obj instanceof String) {
                return (String) obj;
            }
            if ((obj instanceof Boolean) || (obj instanceof Number)) {
                return obj.toString();
            }
            if (!(obj instanceof Date)) {
                throw new IllegalArgumentException("Unsupported parameter type.");
            }
            String str = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format((Date) obj);
            kotlin.jvm.internal.m.f(str, "iso8601DateFormat.format(value)");
            return str;
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final void D(org.json.JSONObject r10, java.lang.String r11, b2.j0.e r12) {
            /*
                r9 = this;
                boolean r0 = r9.u(r11)
                r1 = 1
                r2 = 0
                if (r0 == 0) goto L23
                r5 = 0
                r6 = 0
                r7 = 6
                r8 = 0
                java.lang.String r4 = ":"
                r3 = r11
                int r0 = md.g.S(r3, r4, r5, r6, r7, r8)
                java.lang.String r4 = "?"
                int r11 = md.g.S(r3, r4, r5, r6, r7, r8)
                r3 = 3
                if (r0 <= r3) goto L23
                r3 = -1
                if (r11 == r3) goto L21
                if (r0 >= r11) goto L23
            L21:
                r11 = 1
                goto L24
            L23:
                r11 = 0
            L24:
                java.util.Iterator r0 = r10.keys()
            L28:
                boolean r3 = r0.hasNext()
                if (r3 == 0) goto L53
                java.lang.Object r3 = r0.next()
                java.lang.String r3 = (java.lang.String) r3
                java.lang.Object r4 = r10.opt(r3)
                if (r11 == 0) goto L44
                java.lang.String r5 = "image"
                boolean r5 = md.g.q(r3, r5, r1)
                if (r5 == 0) goto L44
                r5 = 1
                goto L45
            L44:
                r5 = 0
            L45:
                java.lang.String r6 = "key"
                kotlin.jvm.internal.m.f(r3, r6)
                java.lang.String r6 = "value"
                kotlin.jvm.internal.m.f(r4, r6)
                r9.E(r3, r4, r12, r5)
                goto L28
            L53:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: b2.j0.c.D(org.json.JSONObject, java.lang.String, b2.j0$e):void");
        }

        private final void E(String str, Object obj, e eVar, boolean z10) {
            String string;
            String string2;
            String str2;
            Class<?> cls = obj.getClass();
            if (JSONObject.class.isAssignableFrom(cls)) {
                JSONObject jSONObject = (JSONObject) obj;
                if (z10) {
                    Iterator<String> itKeys = jSONObject.keys();
                    while (itKeys.hasNext()) {
                        String next = itKeys.next();
                        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
                        String str3 = String.format("%s[%s]", Arrays.copyOf(new Object[]{str, next}, 2));
                        kotlin.jvm.internal.m.f(str3, "java.lang.String.format(format, *args)");
                        Object objOpt = jSONObject.opt(next);
                        kotlin.jvm.internal.m.f(objOpt, "jsonObject.opt(propertyName)");
                        E(str3, objOpt, eVar, z10);
                    }
                    return;
                }
                if (jSONObject.has("id")) {
                    string2 = jSONObject.optString("id");
                    str2 = "jsonObject.optString(\"id\")";
                } else if (jSONObject.has("url")) {
                    string2 = jSONObject.optString("url");
                    str2 = "jsonObject.optString(\"url\")";
                } else {
                    if (!jSONObject.has("fbsdk:create_object")) {
                        return;
                    }
                    string2 = jSONObject.toString();
                    str2 = "jsonObject.toString()";
                }
                kotlin.jvm.internal.m.f(string2, str2);
                E(str, string2, eVar, z10);
                return;
            }
            if (!JSONArray.class.isAssignableFrom(cls)) {
                if (String.class.isAssignableFrom(cls) || Number.class.isAssignableFrom(cls) || Boolean.class.isAssignableFrom(cls)) {
                    string = obj.toString();
                } else {
                    if (!Date.class.isAssignableFrom(cls)) {
                        r2.l0 l0Var = r2.l0.f20174a;
                        r2.l0.e0(j0.f5455o, "The type of property " + str + " in the graph object is unknown. It won't be sent in the request.");
                        return;
                    }
                    string = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format((Date) obj);
                    kotlin.jvm.internal.m.f(string, "iso8601DateFormat.format(date)");
                }
                eVar.a(str, string);
                return;
            }
            JSONArray jSONArray = (JSONArray) obj;
            int length = jSONArray.length();
            if (length <= 0) {
                return;
            }
            int i10 = 0;
            while (true) {
                int i11 = i10 + 1;
                kotlin.jvm.internal.w wVar2 = kotlin.jvm.internal.w.f17306a;
                String str4 = String.format(Locale.ROOT, "%s[%d]", Arrays.copyOf(new Object[]{str, Integer.valueOf(i10)}, 2));
                kotlin.jvm.internal.m.f(str4, "java.lang.String.format(locale, format, *args)");
                Object objOpt2 = jSONArray.opt(i10);
                kotlin.jvm.internal.m.f(objOpt2, "jsonArray.opt(i)");
                E(str4, objOpt2, eVar, z10);
                if (i11 >= length) {
                    return;
                } else {
                    i10 = i11;
                }
            }
        }

        private final void F(n0 n0Var, r2.c0 c0Var, int i10, URL url, OutputStream outputStream, boolean z10) throws JSONException, IOException {
            h hVar = new h(outputStream, c0Var, z10);
            if (i10 != 1) {
                String strP = p(n0Var);
                if (strP.length() == 0) {
                    throw new s("App ID was not specified at the request or Settings.");
                }
                hVar.a("batch_app_id", strP);
                HashMap map = new HashMap();
                K(hVar, n0Var, map);
                if (c0Var != null) {
                    c0Var.b("  Attachments:\n");
                }
                I(map, hVar);
                return;
            }
            j0 j0VarV = n0Var.get(0);
            HashMap map2 = new HashMap();
            for (String key : j0VarV.u().keySet()) {
                Object obj = j0VarV.u().get(key);
                if (v(obj)) {
                    kotlin.jvm.internal.m.f(key, "key");
                    map2.put(key, new a(j0VarV, obj));
                }
            }
            if (c0Var != null) {
                c0Var.b("  Parameters:\n");
            }
            J(j0VarV.u(), hVar, j0VarV);
            if (c0Var != null) {
                c0Var.b("  Attachments:\n");
            }
            I(map2, hVar);
            JSONObject jSONObjectQ = j0VarV.q();
            if (jSONObjectQ != null) {
                String path = url.getPath();
                kotlin.jvm.internal.m.f(path, "url.path");
                D(jSONObjectQ, path, hVar);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void H(ArrayList callbacks, n0 requests) {
            kotlin.jvm.internal.m.g(callbacks, "$callbacks");
            kotlin.jvm.internal.m.g(requests, "$requests");
            Iterator it = callbacks.iterator();
            while (it.hasNext()) {
                Pair pair = (Pair) it.next();
                b bVar = (b) pair.first;
                Object obj = pair.second;
                kotlin.jvm.internal.m.f(obj, "pair.second");
                bVar.b((o0) obj);
            }
            Iterator<n0.a> it2 = requests.y().iterator();
            while (it2.hasNext()) {
                it2.next().b(requests);
            }
        }

        private final void I(Map<String, a> map, h hVar) throws IOException {
            for (Map.Entry<String, a> entry : map.entrySet()) {
                if (j0.f5454n.v(entry.getValue().b())) {
                    hVar.j(entry.getKey(), entry.getValue().b(), entry.getValue().a());
                }
            }
        }

        private final void J(Bundle bundle, h hVar, j0 j0Var) throws IOException {
            for (String key : bundle.keySet()) {
                Object obj = bundle.get(key);
                if (w(obj)) {
                    kotlin.jvm.internal.m.f(key, "key");
                    hVar.j(key, obj, j0Var);
                }
            }
        }

        private final void K(h hVar, Collection<j0> collection, Map<String, a> map) throws JSONException, IOException {
            JSONArray jSONArray = new JSONArray();
            Iterator<j0> it = collection.iterator();
            while (it.hasNext()) {
                it.next().C(jSONArray, map);
            }
            hVar.l("batch", jSONArray, collection);
        }

        private final void M(HttpURLConnection httpURLConnection, boolean z10) {
            if (!z10) {
                httpURLConnection.setRequestProperty("Content-Type", q());
            } else {
                httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                httpURLConnection.setRequestProperty("Content-Encoding", "gzip");
            }
        }

        private final HttpURLConnection g(URL url) throws IOException {
            URLConnection uRLConnectionOpenConnection = url.openConnection();
            Objects.requireNonNull(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
            HttpURLConnection httpURLConnection = (HttpURLConnection) uRLConnectionOpenConnection;
            httpURLConnection.setRequestProperty("User-Agent", r());
            httpURLConnection.setRequestProperty("Accept-Language", Locale.getDefault().toString());
            httpURLConnection.setChunkedStreamingMode(0);
            return httpURLConnection;
        }

        private final String p(n0 n0Var) {
            String strW = n0Var.w();
            if (strW != null && (!n0Var.isEmpty())) {
                return strW;
            }
            Iterator<j0> it = n0Var.iterator();
            while (it.hasNext()) {
                b2.a aVarM = it.next().m();
                if (aVarM != null) {
                    return aVarM.i();
                }
            }
            String str = j0.f5457q;
            if (str != null) {
                if (str.length() > 0) {
                    return str;
                }
            }
            f0 f0Var = f0.f5388a;
            return f0.m();
        }

        private final String q() {
            kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
            String str = String.format("multipart/form-data; boundary=%s", Arrays.copyOf(new Object[]{j0.f5456p}, 1));
            kotlin.jvm.internal.m.f(str, "java.lang.String.format(format, *args)");
            return str;
        }

        private final String r() {
            if (j0.f5459s == null) {
                kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
                String str = String.format("%s.%s", Arrays.copyOf(new Object[]{"FBAndroidSDK", "16.0.1"}, 2));
                kotlin.jvm.internal.m.f(str, "java.lang.String.format(format, *args)");
                j0.f5459s = str;
                r2.z zVar = r2.z.f20313a;
                String strA = r2.z.a();
                r2.l0 l0Var = r2.l0.f20174a;
                if (!r2.l0.X(strA)) {
                    String str2 = String.format(Locale.ROOT, "%s/%s", Arrays.copyOf(new Object[]{j0.f5459s, strA}, 2));
                    kotlin.jvm.internal.m.f(str2, "java.lang.String.format(locale, format, *args)");
                    j0.f5459s = str2;
                }
            }
            return j0.f5459s;
        }

        private final boolean s(n0 n0Var) {
            Iterator<n0.a> it = n0Var.y().iterator();
            while (it.hasNext()) {
                if (it.next() instanceof n0.c) {
                    return true;
                }
            }
            Iterator<j0> it2 = n0Var.iterator();
            while (it2.hasNext()) {
                if (it2.next().o() instanceof f) {
                    return true;
                }
            }
            return false;
        }

        private final boolean t(n0 n0Var) {
            Iterator<j0> it = n0Var.iterator();
            while (it.hasNext()) {
                j0 next = it.next();
                Iterator<String> it2 = next.u().keySet().iterator();
                while (it2.hasNext()) {
                    if (v(next.u().get(it2.next()))) {
                        return false;
                    }
                }
            }
            return true;
        }

        private final boolean u(String str) {
            Matcher matcher = j0.f5458r.matcher(str);
            if (matcher.matches()) {
                str = matcher.group(1);
                kotlin.jvm.internal.m.f(str, "matcher.group(1)");
            }
            return md.p.C(str, "me/", false, 2, null) || md.p.C(str, "/me/", false, 2, null);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final boolean v(Object obj) {
            return (obj instanceof Bitmap) || (obj instanceof byte[]) || (obj instanceof Uri) || (obj instanceof ParcelFileDescriptor) || (obj instanceof g);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final boolean w(Object obj) {
            return (obj instanceof String) || (obj instanceof Boolean) || (obj instanceof Number) || (obj instanceof Date);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void z(d dVar, o0 response) {
            kotlin.jvm.internal.m.g(response, "response");
            if (dVar == null) {
                return;
            }
            dVar.a(response.c(), response);
        }

        public final j0 A(b2.a aVar, String str, JSONObject jSONObject, b bVar) {
            j0 j0Var = new j0(aVar, str, null, p0.POST, bVar, null, 32, null);
            j0Var.F(jSONObject);
            return j0Var;
        }

        public final j0 B(b2.a aVar, String str, Bundle bundle, b bVar) {
            return new j0(aVar, str, bundle, p0.POST, bVar, null, 32, null);
        }

        public final void G(final n0 requests, List<o0> responses) {
            kotlin.jvm.internal.m.g(requests, "requests");
            kotlin.jvm.internal.m.g(responses, "responses");
            int size = requests.size();
            final ArrayList arrayList = new ArrayList();
            if (size > 0) {
                int i10 = 0;
                while (true) {
                    int i11 = i10 + 1;
                    j0 j0VarV = requests.get(i10);
                    if (j0VarV.o() != null) {
                        arrayList.add(new Pair(j0VarV.o(), responses.get(i10)));
                    }
                    if (i11 >= size) {
                        break;
                    } else {
                        i10 = i11;
                    }
                }
            }
            if (arrayList.size() > 0) {
                Runnable runnable = new Runnable() { // from class: b2.l0
                    @Override // java.lang.Runnable
                    public final void run() {
                        j0.c.H(arrayList, requests);
                    }
                };
                Handler handlerX = requests.x();
                if ((handlerX == null ? null : Boolean.valueOf(handlerX.post(runnable))) == null) {
                    runnable.run();
                }
            }
        }

        /* JADX WARN: Removed duplicated region for block: B:33:0x00f2  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final void L(b2.n0 r14, java.net.HttpURLConnection r15) throws java.lang.Throwable {
            /*
                Method dump skipped, instructions count: 246
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: b2.j0.c.L(b2.n0, java.net.HttpURLConnection):void");
        }

        public final HttpURLConnection N(n0 requests) throws Throwable {
            URL url;
            kotlin.jvm.internal.m.g(requests, "requests");
            O(requests);
            try {
                if (requests.size() == 1) {
                    url = new URL(requests.get(0).x());
                } else {
                    r2.h0 h0Var = r2.h0.f20148a;
                    url = new URL(r2.h0.h());
                }
                HttpURLConnection httpURLConnectionG = null;
                try {
                    httpURLConnectionG = g(url);
                    L(requests, httpURLConnectionG);
                    return httpURLConnectionG;
                } catch (IOException e10) {
                    r2.l0 l0Var = r2.l0.f20174a;
                    r2.l0.q(httpURLConnectionG);
                    throw new s("could not construct request body", e10);
                } catch (JSONException e11) {
                    r2.l0 l0Var2 = r2.l0.f20174a;
                    r2.l0.q(httpURLConnectionG);
                    throw new s("could not construct request body", e11);
                }
            } catch (MalformedURLException e12) {
                throw new s("could not construct URL for request", e12);
            }
        }

        public final void O(n0 requests) {
            kotlin.jvm.internal.m.g(requests, "requests");
            Iterator<j0> it = requests.iterator();
            while (it.hasNext()) {
                j0 next = it.next();
                if (p0.GET == next.t()) {
                    r2.l0 l0Var = r2.l0.f20174a;
                    if (r2.l0.X(next.u().getString("fields"))) {
                        c0.a aVar = r2.c0.f20089e;
                        r0 r0Var = r0.DEVELOPER_ERRORS;
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("GET requests for /");
                        String strR = next.r();
                        if (strR == null) {
                            strR = "";
                        }
                        sb2.append(strR);
                        sb2.append(" should contain an explicit \"fields\" parameter.");
                        aVar.a(r0Var, 5, "Request", sb2.toString());
                    }
                }
            }
        }

        public final o0 h(j0 request) {
            kotlin.jvm.internal.m.g(request, "request");
            List<o0> listK = k(request);
            if (listK.size() == 1) {
                return listK.get(0);
            }
            throw new s("invalid state: expected a single response");
        }

        public final List<o0> i(n0 requests) throws Throwable {
            Exception exc;
            HttpURLConnection httpURLConnectionN;
            List<o0> listO;
            kotlin.jvm.internal.m.g(requests, "requests");
            r2.m0 m0Var = r2.m0.f20185a;
            r2.m0.i(requests, "requests");
            HttpURLConnection httpURLConnection = null;
            try {
                httpURLConnectionN = N(requests);
                exc = null;
            } catch (Exception e10) {
                exc = e10;
                httpURLConnectionN = null;
            } catch (Throwable th) {
                th = th;
                r2.l0 l0Var = r2.l0.f20174a;
                r2.l0.q(httpURLConnection);
                throw th;
            }
            try {
                if (httpURLConnectionN != null) {
                    listO = o(httpURLConnectionN, requests);
                } else {
                    List<o0> listA = o0.f5526i.a(requests.A(), null, new s(exc));
                    G(requests, listA);
                    listO = listA;
                }
                r2.l0 l0Var2 = r2.l0.f20174a;
                r2.l0.q(httpURLConnectionN);
                return listO;
            } catch (Throwable th2) {
                th = th2;
                httpURLConnection = httpURLConnectionN;
                r2.l0 l0Var3 = r2.l0.f20174a;
                r2.l0.q(httpURLConnection);
                throw th;
            }
        }

        public final List<o0> j(Collection<j0> requests) {
            kotlin.jvm.internal.m.g(requests, "requests");
            return i(new n0(requests));
        }

        public final List<o0> k(j0... requests) {
            kotlin.jvm.internal.m.g(requests, "requests");
            return j(uc.k.C(requests));
        }

        public final m0 l(n0 requests) {
            kotlin.jvm.internal.m.g(requests, "requests");
            r2.m0 m0Var = r2.m0.f20185a;
            r2.m0.i(requests, "requests");
            m0 m0Var2 = new m0(requests);
            f0 f0Var = f0.f5388a;
            m0Var2.executeOnExecutor(f0.t(), new Void[0]);
            return m0Var2;
        }

        public final m0 m(Collection<j0> requests) {
            kotlin.jvm.internal.m.g(requests, "requests");
            return l(new n0(requests));
        }

        public final m0 n(j0... requests) {
            kotlin.jvm.internal.m.g(requests, "requests");
            return m(uc.k.C(requests));
        }

        public final List<o0> o(HttpURLConnection connection, n0 requests) {
            kotlin.jvm.internal.m.g(connection, "connection");
            kotlin.jvm.internal.m.g(requests, "requests");
            List<o0> listF = o0.f5526i.f(connection, requests);
            r2.l0 l0Var = r2.l0.f20174a;
            r2.l0.q(connection);
            int size = requests.size();
            if (size == listF.size()) {
                G(requests, listF);
                b2.g.f5412f.e().h();
                return listF;
            }
            kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
            String str = String.format(Locale.US, "Received %d responses while expecting %d", Arrays.copyOf(new Object[]{Integer.valueOf(listF.size()), Integer.valueOf(size)}, 2));
            kotlin.jvm.internal.m.f(str, "java.lang.String.format(locale, format, *args)");
            throw new s(str);
        }

        public final j0 x(b2.a aVar, String str, b bVar) {
            return new j0(aVar, str, null, null, bVar, null, 32, null);
        }

        public final j0 y(b2.a aVar, final d dVar) {
            return new j0(aVar, "me", null, null, new b() { // from class: b2.k0
                @Override // b2.j0.b
                public final void b(o0 o0Var) {
                    j0.c.z(dVar, o0Var);
                }
            }, null, 32, null);
        }
    }

    public interface d {
        void a(JSONObject jSONObject, o0 o0Var);
    }

    private interface e {
        void a(String str, String str2);
    }

    public interface f extends b {
        void a(long j10, long j11);
    }

    public static final class g<RESOURCE extends Parcelable> implements Parcelable {

        /* renamed from: a, reason: collision with root package name */
        private final String f5476a;

        /* renamed from: b, reason: collision with root package name */
        private final RESOURCE f5477b;

        /* renamed from: c, reason: collision with root package name */
        public static final b f5475c = new b(null);
        public static final Parcelable.Creator<g<?>> CREATOR = new a();

        public static final class a implements Parcelable.Creator<g<?>> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public g<?> createFromParcel(Parcel source) {
                kotlin.jvm.internal.m.g(source, "source");
                return new g<>(source, (kotlin.jvm.internal.g) null);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public g<?>[] newArray(int i10) {
                return new g[i10];
            }
        }

        public static final class b {
            private b() {
            }

            public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
                this();
            }
        }

        private g(Parcel parcel) {
            this.f5476a = parcel.readString();
            f0 f0Var = f0.f5388a;
            this.f5477b = (RESOURCE) parcel.readParcelable(f0.l().getClassLoader());
        }

        public /* synthetic */ g(Parcel parcel, kotlin.jvm.internal.g gVar) {
            this(parcel);
        }

        public g(RESOURCE resource, String str) {
            this.f5476a = str;
            this.f5477b = resource;
        }

        public final String b() {
            return this.f5476a;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 1;
        }

        public final RESOURCE h() {
            return this.f5477b;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int i10) {
            kotlin.jvm.internal.m.g(out, "out");
            out.writeString(this.f5476a);
            out.writeParcelable(this.f5477b, i10);
        }
    }

    private static final class h implements e {

        /* renamed from: a, reason: collision with root package name */
        private final OutputStream f5478a;

        /* renamed from: b, reason: collision with root package name */
        private final r2.c0 f5479b;

        /* renamed from: c, reason: collision with root package name */
        private boolean f5480c;

        /* renamed from: d, reason: collision with root package name */
        private final boolean f5481d;

        public h(OutputStream outputStream, r2.c0 c0Var, boolean z10) {
            kotlin.jvm.internal.m.g(outputStream, "outputStream");
            this.f5478a = outputStream;
            this.f5479b = c0Var;
            this.f5480c = true;
            this.f5481d = z10;
        }

        private final RuntimeException b() {
            return new IllegalArgumentException("value is not a supported type.");
        }

        @Override // b2.j0.e
        public void a(String key, String value) throws IOException {
            kotlin.jvm.internal.m.g(key, "key");
            kotlin.jvm.internal.m.g(value, "value");
            f(key, null, null);
            i("%s", value);
            k();
            r2.c0 c0Var = this.f5479b;
            if (c0Var == null) {
                return;
            }
            c0Var.d(kotlin.jvm.internal.m.n("    ", key), value);
        }

        public final void c(String format, Object... args) throws IOException {
            kotlin.jvm.internal.m.g(format, "format");
            kotlin.jvm.internal.m.g(args, "args");
            if (this.f5481d) {
                OutputStream outputStream = this.f5478a;
                kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
                Locale locale = Locale.US;
                Object[] objArrCopyOf = Arrays.copyOf(args, args.length);
                String str = String.format(locale, format, Arrays.copyOf(objArrCopyOf, objArrCopyOf.length));
                kotlin.jvm.internal.m.f(str, "java.lang.String.format(locale, format, *args)");
                String strEncode = URLEncoder.encode(str, "UTF-8");
                kotlin.jvm.internal.m.f(strEncode, "encode(String.format(Locale.US, format, *args), \"UTF-8\")");
                byte[] bytes = strEncode.getBytes(md.d.f17896b);
                kotlin.jvm.internal.m.f(bytes, "(this as java.lang.String).getBytes(charset)");
                outputStream.write(bytes);
                return;
            }
            if (this.f5480c) {
                OutputStream outputStream2 = this.f5478a;
                Charset charset = md.d.f17896b;
                byte[] bytes2 = "--".getBytes(charset);
                kotlin.jvm.internal.m.f(bytes2, "(this as java.lang.String).getBytes(charset)");
                outputStream2.write(bytes2);
                OutputStream outputStream3 = this.f5478a;
                String str2 = j0.f5456p;
                Objects.requireNonNull(str2, "null cannot be cast to non-null type java.lang.String");
                byte[] bytes3 = str2.getBytes(charset);
                kotlin.jvm.internal.m.f(bytes3, "(this as java.lang.String).getBytes(charset)");
                outputStream3.write(bytes3);
                OutputStream outputStream4 = this.f5478a;
                byte[] bytes4 = "\r\n".getBytes(charset);
                kotlin.jvm.internal.m.f(bytes4, "(this as java.lang.String).getBytes(charset)");
                outputStream4.write(bytes4);
                this.f5480c = false;
            }
            OutputStream outputStream5 = this.f5478a;
            kotlin.jvm.internal.w wVar2 = kotlin.jvm.internal.w.f17306a;
            Object[] objArrCopyOf2 = Arrays.copyOf(args, args.length);
            String str3 = String.format(format, Arrays.copyOf(objArrCopyOf2, objArrCopyOf2.length));
            kotlin.jvm.internal.m.f(str3, "java.lang.String.format(format, *args)");
            Charset charset2 = md.d.f17896b;
            Objects.requireNonNull(str3, "null cannot be cast to non-null type java.lang.String");
            byte[] bytes5 = str3.getBytes(charset2);
            kotlin.jvm.internal.m.f(bytes5, "(this as java.lang.String).getBytes(charset)");
            outputStream5.write(bytes5);
        }

        public final void d(String key, Bitmap bitmap) throws IOException {
            kotlin.jvm.internal.m.g(key, "key");
            kotlin.jvm.internal.m.g(bitmap, "bitmap");
            f(key, key, "image/png");
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, this.f5478a);
            i("", new Object[0]);
            k();
            r2.c0 c0Var = this.f5479b;
            if (c0Var == null) {
                return;
            }
            c0Var.d(kotlin.jvm.internal.m.n("    ", key), "<Image>");
        }

        public final void e(String key, byte[] bytes) throws IOException {
            kotlin.jvm.internal.m.g(key, "key");
            kotlin.jvm.internal.m.g(bytes, "bytes");
            f(key, key, "content/unknown");
            this.f5478a.write(bytes);
            i("", new Object[0]);
            k();
            r2.c0 c0Var = this.f5479b;
            if (c0Var == null) {
                return;
            }
            String strN = kotlin.jvm.internal.m.n("    ", key);
            kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
            String str = String.format(Locale.ROOT, "<Data: %d>", Arrays.copyOf(new Object[]{Integer.valueOf(bytes.length)}, 1));
            kotlin.jvm.internal.m.f(str, "java.lang.String.format(locale, format, *args)");
            c0Var.d(strN, str);
        }

        public final void f(String str, String str2, String str3) throws IOException {
            if (!this.f5481d) {
                c("Content-Disposition: form-data; name=\"%s\"", str);
                if (str2 != null) {
                    c("; filename=\"%s\"", str2);
                }
                i("", new Object[0]);
                if (str3 != null) {
                    i("%s: %s", "Content-Type", str3);
                }
                i("", new Object[0]);
                return;
            }
            OutputStream outputStream = this.f5478a;
            kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
            String str4 = String.format("%s=", Arrays.copyOf(new Object[]{str}, 1));
            kotlin.jvm.internal.m.f(str4, "java.lang.String.format(format, *args)");
            Charset charset = md.d.f17896b;
            Objects.requireNonNull(str4, "null cannot be cast to non-null type java.lang.String");
            byte[] bytes = str4.getBytes(charset);
            kotlin.jvm.internal.m.f(bytes, "(this as java.lang.String).getBytes(charset)");
            outputStream.write(bytes);
        }

        public final void g(String key, Uri contentUri, String str) throws IOException {
            int iP;
            kotlin.jvm.internal.m.g(key, "key");
            kotlin.jvm.internal.m.g(contentUri, "contentUri");
            if (str == null) {
                str = "content/unknown";
            }
            f(key, key, str);
            if (this.f5478a instanceof w0) {
                r2.l0 l0Var = r2.l0.f20174a;
                ((w0) this.f5478a).d(r2.l0.x(contentUri));
                iP = 0;
            } else {
                f0 f0Var = f0.f5388a;
                InputStream inputStreamOpenInputStream = f0.l().getContentResolver().openInputStream(contentUri);
                r2.l0 l0Var2 = r2.l0.f20174a;
                iP = r2.l0.p(inputStreamOpenInputStream, this.f5478a) + 0;
            }
            i("", new Object[0]);
            k();
            r2.c0 c0Var = this.f5479b;
            if (c0Var == null) {
                return;
            }
            String strN = kotlin.jvm.internal.m.n("    ", key);
            kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
            String str2 = String.format(Locale.ROOT, "<Data: %d>", Arrays.copyOf(new Object[]{Integer.valueOf(iP)}, 1));
            kotlin.jvm.internal.m.f(str2, "java.lang.String.format(locale, format, *args)");
            c0Var.d(strN, str2);
        }

        public final void h(String key, ParcelFileDescriptor descriptor, String str) throws IOException {
            int iP;
            kotlin.jvm.internal.m.g(key, "key");
            kotlin.jvm.internal.m.g(descriptor, "descriptor");
            if (str == null) {
                str = "content/unknown";
            }
            f(key, key, str);
            OutputStream outputStream = this.f5478a;
            if (outputStream instanceof w0) {
                ((w0) outputStream).d(descriptor.getStatSize());
                iP = 0;
            } else {
                ParcelFileDescriptor.AutoCloseInputStream autoCloseInputStream = new ParcelFileDescriptor.AutoCloseInputStream(descriptor);
                r2.l0 l0Var = r2.l0.f20174a;
                iP = r2.l0.p(autoCloseInputStream, this.f5478a) + 0;
            }
            i("", new Object[0]);
            k();
            r2.c0 c0Var = this.f5479b;
            if (c0Var == null) {
                return;
            }
            String strN = kotlin.jvm.internal.m.n("    ", key);
            kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
            String str2 = String.format(Locale.ROOT, "<Data: %d>", Arrays.copyOf(new Object[]{Integer.valueOf(iP)}, 1));
            kotlin.jvm.internal.m.f(str2, "java.lang.String.format(locale, format, *args)");
            c0Var.d(strN, str2);
        }

        public final void i(String format, Object... args) throws IOException {
            kotlin.jvm.internal.m.g(format, "format");
            kotlin.jvm.internal.m.g(args, "args");
            c(format, Arrays.copyOf(args, args.length));
            if (this.f5481d) {
                return;
            }
            c("\r\n", new Object[0]);
        }

        public final void j(String key, Object obj, j0 j0Var) throws IOException {
            kotlin.jvm.internal.m.g(key, "key");
            Closeable closeable = this.f5478a;
            if (closeable instanceof z0) {
                ((z0) closeable).b(j0Var);
            }
            c cVar = j0.f5454n;
            if (cVar.w(obj)) {
                a(key, cVar.C(obj));
                return;
            }
            if (obj instanceof Bitmap) {
                d(key, (Bitmap) obj);
                return;
            }
            if (obj instanceof byte[]) {
                e(key, (byte[]) obj);
                return;
            }
            if (obj instanceof Uri) {
                g(key, (Uri) obj, null);
                return;
            }
            if (obj instanceof ParcelFileDescriptor) {
                h(key, (ParcelFileDescriptor) obj, null);
                return;
            }
            if (!(obj instanceof g)) {
                throw b();
            }
            g gVar = (g) obj;
            Parcelable parcelableH = gVar.h();
            String strB = gVar.b();
            if (parcelableH instanceof ParcelFileDescriptor) {
                h(key, (ParcelFileDescriptor) parcelableH, strB);
            } else {
                if (!(parcelableH instanceof Uri)) {
                    throw b();
                }
                g(key, (Uri) parcelableH, strB);
            }
        }

        public final void k() throws IOException {
            if (!this.f5481d) {
                i("--%s", j0.f5456p);
                return;
            }
            OutputStream outputStream = this.f5478a;
            byte[] bytes = "&".getBytes(md.d.f17896b);
            kotlin.jvm.internal.m.f(bytes, "(this as java.lang.String).getBytes(charset)");
            outputStream.write(bytes);
        }

        public final void l(String key, JSONArray requestJsonArray, Collection<j0> requests) throws JSONException, IOException {
            kotlin.jvm.internal.m.g(key, "key");
            kotlin.jvm.internal.m.g(requestJsonArray, "requestJsonArray");
            kotlin.jvm.internal.m.g(requests, "requests");
            Closeable closeable = this.f5478a;
            if (!(closeable instanceof z0)) {
                String string = requestJsonArray.toString();
                kotlin.jvm.internal.m.f(string, "requestJsonArray.toString()");
                a(key, string);
                return;
            }
            z0 z0Var = (z0) closeable;
            f(key, null, null);
            c("[", new Object[0]);
            int i10 = 0;
            for (j0 j0Var : requests) {
                int i11 = i10 + 1;
                JSONObject jSONObject = requestJsonArray.getJSONObject(i10);
                z0Var.b(j0Var);
                if (i10 > 0) {
                    c(",%s", jSONObject.toString());
                } else {
                    c("%s", jSONObject.toString());
                }
                i10 = i11;
            }
            c("]", new Object[0]);
            r2.c0 c0Var = this.f5479b;
            if (c0Var == null) {
                return;
            }
            String strN = kotlin.jvm.internal.m.n("    ", key);
            String string2 = requestJsonArray.toString();
            kotlin.jvm.internal.m.f(string2, "requestJsonArray.toString()");
            c0Var.d(strN, string2);
        }
    }

    public static final class i implements e {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ArrayList<String> f5482a;

        i(ArrayList<String> arrayList) {
            this.f5482a = arrayList;
        }

        @Override // b2.j0.e
        public void a(String key, String value) {
            kotlin.jvm.internal.m.g(key, "key");
            kotlin.jvm.internal.m.g(value, "value");
            ArrayList<String> arrayList = this.f5482a;
            kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
            String str = String.format(Locale.US, "%s=%s", Arrays.copyOf(new Object[]{key, URLEncoder.encode(value, "UTF-8")}, 2));
            kotlin.jvm.internal.m.f(str, "java.lang.String.format(locale, format, *args)");
            arrayList.add(str);
        }
    }

    static {
        char[] charArray = "-_1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
        kotlin.jvm.internal.m.f(charArray, "(this as java.lang.String).toCharArray()");
        StringBuilder sb2 = new StringBuilder();
        SecureRandom secureRandom = new SecureRandom();
        int iNextInt = secureRandom.nextInt(11) + 30;
        if (iNextInt > 0) {
            int i10 = 0;
            do {
                i10++;
                sb2.append(charArray[secureRandom.nextInt(charArray.length)]);
            } while (i10 < iNextInt);
        }
        String string = sb2.toString();
        kotlin.jvm.internal.m.f(string, "buffer.toString()");
        f5456p = string;
        f5458r = Pattern.compile("^/?v\\d+\\.\\d+/(.*)");
    }

    public j0() {
        this(null, null, null, null, null, null, 63, null);
    }

    public j0(b2.a aVar, String str, Bundle bundle, p0 p0Var, b bVar, String str2) {
        this.f5465f = true;
        this.f5460a = aVar;
        this.f5461b = str;
        this.f5468i = str2;
        D(bVar);
        G(p0Var);
        this.f5466g = bundle != null ? new Bundle(bundle) : new Bundle();
        if (this.f5468i == null) {
            f0 f0Var = f0.f5388a;
            this.f5468i = f0.w();
        }
    }

    public /* synthetic */ j0(b2.a aVar, String str, Bundle bundle, p0 p0Var, b bVar, String str2, int i10, kotlin.jvm.internal.g gVar) {
        this((i10 & 1) != 0 ? null : aVar, (i10 & 2) != 0 ? null : str, (i10 & 4) != 0 ? null : bundle, (i10 & 8) != 0 ? null : p0Var, (i10 & 16) != 0 ? null : bVar, (i10 & 32) != 0 ? null : str2);
    }

    private final boolean A() {
        f0 f0Var = f0.f5388a;
        if (kotlin.jvm.internal.m.b(f0.x(), "instagram.com")) {
            return !z();
        }
        return true;
    }

    public static final j0 B(b2.a aVar, d dVar) {
        return f5454n.y(aVar, dVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void C(JSONArray jSONArray, Map<String, a> map) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        String str = this.f5463d;
        if (str != null) {
            jSONObject.put("name", str);
            jSONObject.put("omit_response_on_success", this.f5465f);
        }
        String str2 = this.f5464e;
        if (str2 != null) {
            jSONObject.put("depends_on", str2);
        }
        String strV = v();
        jSONObject.put("relative_url", strV);
        jSONObject.put("method", this.f5470k);
        b2.a aVar = this.f5460a;
        if (aVar != null) {
            r2.c0.f20089e.d(aVar.w());
        }
        ArrayList arrayList = new ArrayList();
        Iterator<String> it = this.f5466g.keySet().iterator();
        while (it.hasNext()) {
            Object obj = this.f5466g.get(it.next());
            if (f5454n.v(obj)) {
                kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
                String str3 = String.format(Locale.ROOT, "%s%d", Arrays.copyOf(new Object[]{"file", Integer.valueOf(map.size())}, 2));
                kotlin.jvm.internal.m.f(str3, "java.lang.String.format(locale, format, *args)");
                arrayList.add(str3);
                map.put(str3, new a(this, obj));
            }
        }
        if (!arrayList.isEmpty()) {
            jSONObject.put("attached_files", TextUtils.join(",", arrayList));
        }
        JSONObject jSONObject2 = this.f5462c;
        if (jSONObject2 != null) {
            ArrayList arrayList2 = new ArrayList();
            f5454n.D(jSONObject2, strV, new i(arrayList2));
            jSONObject.put("body", TextUtils.join("&", arrayList2));
        }
        jSONArray.put(jSONObject);
    }

    private final boolean J() {
        String strN = n();
        boolean zH = strN == null ? false : md.q.H(strN, "|", false, 2, null);
        if (((strN == null || !md.p.C(strN, "IG", false, 2, null) || zH) ? false : true) && z()) {
            return true;
        }
        return (A() || zH) ? false : true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void b(b bVar, o0 response) {
        kotlin.jvm.internal.m.g(response, "response");
        JSONObject jSONObjectC = response.c();
        JSONObject jSONObjectOptJSONObject = jSONObjectC == null ? null : jSONObjectC.optJSONObject("__debug__");
        JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject == null ? null : jSONObjectOptJSONObject.optJSONArray("messages");
        if (jSONArrayOptJSONArray != null) {
            int i10 = 0;
            int length = jSONArrayOptJSONArray.length();
            if (length > 0) {
                while (true) {
                    int i11 = i10 + 1;
                    JSONObject jSONObjectOptJSONObject2 = jSONArrayOptJSONArray.optJSONObject(i10);
                    String strOptString = jSONObjectOptJSONObject2 == null ? null : jSONObjectOptJSONObject2.optString("message");
                    String strOptString2 = jSONObjectOptJSONObject2 == null ? null : jSONObjectOptJSONObject2.optString("type");
                    String strOptString3 = jSONObjectOptJSONObject2 == null ? null : jSONObjectOptJSONObject2.optString("link");
                    if (strOptString != null && strOptString2 != null) {
                        r0 r0Var = r0.GRAPH_API_DEBUG_INFO;
                        if (kotlin.jvm.internal.m.b(strOptString2, "warning")) {
                            r0Var = r0.GRAPH_API_DEBUG_WARNING;
                        }
                        r2.l0 l0Var = r2.l0.f20174a;
                        if (!r2.l0.X(strOptString3)) {
                            strOptString = ((Object) strOptString) + " Link: " + ((Object) strOptString3);
                        }
                        c0.a aVar = r2.c0.f20089e;
                        String TAG = f5455o;
                        kotlin.jvm.internal.m.f(TAG, "TAG");
                        aVar.b(r0Var, TAG, strOptString);
                    }
                    if (i11 >= length) {
                        break;
                    } else {
                        i10 = i11;
                    }
                }
            }
        }
        if (bVar == null) {
            return;
        }
        bVar.b(response);
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x001f  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0054  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final void i() {
        /*
            r3 = this;
            android.os.Bundle r0 = r3.f5466g
            boolean r1 = r3.J()
            java.lang.String r2 = "access_token"
            if (r1 == 0) goto L12
            java.lang.String r1 = r3.p()
        Le:
            r0.putString(r2, r1)
            goto L19
        L12:
            java.lang.String r1 = r3.n()
            if (r1 == 0) goto L19
            goto Le
        L19:
            boolean r1 = r0.containsKey(r2)
            if (r1 != 0) goto L34
            r2.l0 r1 = r2.l0.f20174a
            b2.f0 r1 = b2.f0.f5388a
            java.lang.String r1 = b2.f0.r()
            boolean r1 = r2.l0.X(r1)
            if (r1 == 0) goto L34
            java.lang.String r1 = b2.j0.f5455o
            java.lang.String r2 = "Starting with v13 of the SDK, a client token must be embedded in your client code before making Graph API calls. Visit https://developers.facebook.com/docs/android/getting-started#client-token to learn how to implement this change."
            android.util.Log.w(r1, r2)
        L34:
            java.lang.String r1 = "sdk"
            java.lang.String r2 = "android"
            r0.putString(r1, r2)
            java.lang.String r1 = "format"
            java.lang.String r2 = "json"
            r0.putString(r1, r2)
            b2.f0 r1 = b2.f0.f5388a
            b2.r0 r1 = b2.r0.GRAPH_API_DEBUG_INFO
            boolean r1 = b2.f0.H(r1)
            java.lang.String r2 = "debug"
            if (r1 == 0) goto L54
            java.lang.String r1 = "info"
        L50:
            r0.putString(r2, r1)
            goto L5f
        L54:
            b2.r0 r1 = b2.r0.GRAPH_API_DEBUG_WARNING
            boolean r1 = b2.f0.H(r1)
            if (r1 == 0) goto L5f
            java.lang.String r1 = "warning"
            goto L50
        L5f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b2.j0.i():void");
    }

    private final String j(String str, boolean z10) {
        if (!z10 && this.f5470k == p0.POST) {
            return str;
        }
        Uri.Builder builderBuildUpon = Uri.parse(str).buildUpon();
        for (String str2 : this.f5466g.keySet()) {
            Object obj = this.f5466g.get(str2);
            if (obj == null) {
                obj = "";
            }
            c cVar = f5454n;
            if (cVar.w(obj)) {
                builderBuildUpon.appendQueryParameter(str2, cVar.C(obj).toString());
            } else if (this.f5470k != p0.GET) {
                kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
                String str3 = String.format(Locale.US, "Unsupported parameter type for GET request: %s", Arrays.copyOf(new Object[]{obj.getClass().getSimpleName()}, 1));
                kotlin.jvm.internal.m.f(str3, "java.lang.String.format(locale, format, *args)");
                throw new IllegalArgumentException(str3);
            }
        }
        String string = builderBuildUpon.toString();
        kotlin.jvm.internal.m.f(string, "uriBuilder.toString()");
        return string;
    }

    private final String n() {
        b2.a aVar = this.f5460a;
        if (aVar != null) {
            if (!this.f5466g.containsKey("access_token")) {
                String strW = aVar.w();
                r2.c0.f20089e.d(strW);
                return strW;
            }
        } else if (!this.f5466g.containsKey("access_token")) {
            return p();
        }
        return this.f5466g.getString("access_token");
    }

    private final String p() {
        f0 f0Var = f0.f5388a;
        String strM = f0.m();
        String strR = f0.r();
        if (strM.length() > 0) {
            if (strR.length() > 0) {
                return strM + '|' + strR;
            }
        }
        r2.l0 l0Var = r2.l0.f20174a;
        r2.l0.e0(f5455o, "Warning: Request without access token missing application ID or client token.");
        return null;
    }

    private final String s() {
        if (f5458r.matcher(this.f5461b).matches()) {
            return this.f5461b;
        }
        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
        String str = String.format("%s/%s", Arrays.copyOf(new Object[]{this.f5468i, this.f5461b}, 2));
        kotlin.jvm.internal.m.f(str, "java.lang.String.format(format, *args)");
        return str;
    }

    private final String y(String str) {
        if (!A()) {
            r2.h0 h0Var = r2.h0.f20148a;
            str = r2.h0.f();
        }
        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
        String str2 = String.format("%s/%s", Arrays.copyOf(new Object[]{str, s()}, 2));
        kotlin.jvm.internal.m.f(str2, "java.lang.String.format(format, *args)");
        return str2;
    }

    private final boolean z() {
        if (this.f5461b == null) {
            return false;
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append("^/?");
        f0 f0Var = f0.f5388a;
        sb2.append(f0.m());
        sb2.append("/?.*");
        return this.f5471l || Pattern.matches(sb2.toString(), this.f5461b) || Pattern.matches("^/?app/?.*", this.f5461b);
    }

    public final void D(final b bVar) {
        f0 f0Var = f0.f5388a;
        if (f0.H(r0.GRAPH_API_DEBUG_INFO) || f0.H(r0.GRAPH_API_DEBUG_WARNING)) {
            this.f5469j = new b() { // from class: b2.i0
                @Override // b2.j0.b
                public final void b(o0 o0Var) {
                    j0.b(bVar, o0Var);
                }
            };
        } else {
            this.f5469j = bVar;
        }
    }

    public final void E(boolean z10) {
        this.f5471l = z10;
    }

    public final void F(JSONObject jSONObject) {
        this.f5462c = jSONObject;
    }

    public final void G(p0 p0Var) {
        if (this.f5472m != null && p0Var != p0.GET) {
            throw new s("Can't change HTTP method on request with overridden URL.");
        }
        if (p0Var == null) {
            p0Var = p0.GET;
        }
        this.f5470k = p0Var;
    }

    public final void H(Bundle bundle) {
        kotlin.jvm.internal.m.g(bundle, "<set-?>");
        this.f5466g = bundle;
    }

    public final void I(Object obj) {
        this.f5467h = obj;
    }

    public final o0 k() {
        return f5454n.h(this);
    }

    public final m0 l() {
        return f5454n.n(this);
    }

    public final b2.a m() {
        return this.f5460a;
    }

    public final b o() {
        return this.f5469j;
    }

    public final JSONObject q() {
        return this.f5462c;
    }

    public final String r() {
        return this.f5461b;
    }

    public final p0 t() {
        return this.f5470k;
    }

    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append("{Request: ");
        sb2.append(" accessToken: ");
        Object obj = this.f5460a;
        if (obj == null) {
            obj = "null";
        }
        sb2.append(obj);
        sb2.append(", graphPath: ");
        sb2.append(this.f5461b);
        sb2.append(", graphObject: ");
        sb2.append(this.f5462c);
        sb2.append(", httpMethod: ");
        sb2.append(this.f5470k);
        sb2.append(", parameters: ");
        sb2.append(this.f5466g);
        sb2.append("}");
        String string = sb2.toString();
        kotlin.jvm.internal.m.f(string, "StringBuilder()\n        .append(\"{Request: \")\n        .append(\" accessToken: \")\n        .append(if (accessToken == null) \"null\" else accessToken)\n        .append(\", graphPath: \")\n        .append(graphPath)\n        .append(\", graphObject: \")\n        .append(graphObject)\n        .append(\", httpMethod: \")\n        .append(httpMethod)\n        .append(\", parameters: \")\n        .append(parameters)\n        .append(\"}\")\n        .toString()");
        return string;
    }

    public final Bundle u() {
        return this.f5466g;
    }

    public final String v() {
        if (this.f5472m != null) {
            throw new s("Can't override URL for a batch request");
        }
        r2.h0 h0Var = r2.h0.f20148a;
        String strY = y(r2.h0.h());
        i();
        Uri uri = Uri.parse(j(strY, true));
        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
        String str = String.format("%s?%s", Arrays.copyOf(new Object[]{uri.getPath(), uri.getQuery()}, 2));
        kotlin.jvm.internal.m.f(str, "java.lang.String.format(format, *args)");
        return str;
    }

    public final Object w() {
        return this.f5467h;
    }

    public final String x() {
        String strI;
        String str = this.f5472m;
        if (str != null) {
            return String.valueOf(str);
        }
        String str2 = this.f5461b;
        if (this.f5470k == p0.POST && str2 != null && md.p.p(str2, "/videos", false, 2, null)) {
            r2.h0 h0Var = r2.h0.f20148a;
            strI = r2.h0.j();
        } else {
            r2.h0 h0Var2 = r2.h0.f20148a;
            f0 f0Var = f0.f5388a;
            strI = r2.h0.i(f0.x());
        }
        String strY = y(strI);
        i();
        return j(strY, false);
    }
}
