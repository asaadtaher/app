package b2;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import b2.j0;
import b2.t0;
import c2.o;
import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;
import k2.h;
import org.json.JSONException;
import org.json.JSONObject;
import r2.b;
import r2.n;

/* loaded from: classes.dex */
public final class f0 {

    /* renamed from: d, reason: collision with root package name */
    private static Executor f5391d;

    /* renamed from: e, reason: collision with root package name */
    private static volatile String f5392e;

    /* renamed from: f, reason: collision with root package name */
    private static volatile String f5393f;

    /* renamed from: g, reason: collision with root package name */
    private static volatile String f5394g;

    /* renamed from: h, reason: collision with root package name */
    private static volatile Boolean f5395h;

    /* renamed from: j, reason: collision with root package name */
    private static volatile boolean f5397j;

    /* renamed from: k, reason: collision with root package name */
    private static boolean f5398k;

    /* renamed from: l, reason: collision with root package name */
    private static r2.b0<File> f5399l;

    /* renamed from: m, reason: collision with root package name */
    private static Context f5400m;

    /* renamed from: p, reason: collision with root package name */
    private static String f5403p;

    /* renamed from: q, reason: collision with root package name */
    public static boolean f5404q;

    /* renamed from: r, reason: collision with root package name */
    public static boolean f5405r;

    /* renamed from: s, reason: collision with root package name */
    public static boolean f5406s;

    /* renamed from: t, reason: collision with root package name */
    private static final AtomicBoolean f5407t;

    /* renamed from: u, reason: collision with root package name */
    private static volatile String f5408u;

    /* renamed from: v, reason: collision with root package name */
    private static volatile String f5409v;

    /* renamed from: w, reason: collision with root package name */
    private static a f5410w;

    /* renamed from: x, reason: collision with root package name */
    private static boolean f5411x;

    /* renamed from: a, reason: collision with root package name */
    public static final f0 f5388a = new f0();

    /* renamed from: b, reason: collision with root package name */
    private static final String f5389b = f0.class.getCanonicalName();

    /* renamed from: c, reason: collision with root package name */
    private static final HashSet<r0> f5390c = uc.m0.c(r0.DEVELOPER_ERRORS);

    /* renamed from: i, reason: collision with root package name */
    private static AtomicLong f5396i = new AtomicLong(65536);

    /* renamed from: n, reason: collision with root package name */
    private static int f5401n = 64206;

    /* renamed from: o, reason: collision with root package name */
    private static final ReentrantLock f5402o = new ReentrantLock();

    public interface a {
        j0 a(b2.a aVar, String str, JSONObject jSONObject, j0.b bVar);
    }

    public interface b {
        void a();
    }

    static {
        r2.h0 h0Var = r2.h0.f20148a;
        f5403p = r2.h0.a();
        f5407t = new AtomicBoolean(false);
        f5408u = "instagram.com";
        f5409v = "facebook.com";
        f5410w = new a() { // from class: b2.w
            @Override // b2.f0.a
            public final j0 a(a aVar, String str, JSONObject jSONObject, j0.b bVar) {
                return f0.C(aVar, str, jSONObject, bVar);
            }
        };
    }

    private f0() {
    }

    public static final long A() {
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.l();
        return f5396i.get();
    }

    public static final String B() {
        return "16.0.1";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final j0 C(b2.a aVar, String str, JSONObject jSONObject, j0.b bVar) {
        return j0.f5454n.A(aVar, str, jSONObject, bVar);
    }

    public static final boolean D() {
        return f5397j;
    }

    public static final synchronized boolean E() {
        return f5411x;
    }

    public static final boolean F() {
        return f5407t.get();
    }

    public static final boolean G() {
        return f5398k;
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x0016  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final boolean H(b2.r0 r2) {
        /*
            java.lang.String r0 = "behavior"
            kotlin.jvm.internal.m.g(r2, r0)
            java.util.HashSet<b2.r0> r0 = b2.f0.f5390c
            monitor-enter(r0)
            boolean r1 = D()     // Catch: java.lang.Throwable -> L19
            if (r1 == 0) goto L16
            boolean r2 = r0.contains(r2)     // Catch: java.lang.Throwable -> L19
            if (r2 == 0) goto L16
            r2 = 1
            goto L17
        L16:
            r2 = 0
        L17:
            monitor-exit(r0)
            return r2
        L19:
            r2 = move-exception
            monitor-exit(r0)
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: b2.f0.H(b2.r0):boolean");
    }

    public static final void I(Context context) throws PackageManager.NameNotFoundException {
        if (context == null) {
            return;
        }
        try {
            ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
            kotlin.jvm.internal.m.f(applicationInfo, "try {\n          context.packageManager.getApplicationInfo(\n              context.packageName, PackageManager.GET_META_DATA)\n        } catch (e: PackageManager.NameNotFoundException) {\n          return\n        }");
            if (applicationInfo.metaData == null) {
                return;
            }
            if (f5392e == null) {
                Object obj = applicationInfo.metaData.get("com.facebook.sdk.ApplicationId");
                if (obj instanceof String) {
                    String strSubstring = (String) obj;
                    Locale ROOT = Locale.ROOT;
                    kotlin.jvm.internal.m.f(ROOT, "ROOT");
                    String lowerCase = strSubstring.toLowerCase(ROOT);
                    kotlin.jvm.internal.m.f(lowerCase, "(this as java.lang.String).toLowerCase(locale)");
                    if (md.p.C(lowerCase, "fb", false, 2, null)) {
                        strSubstring = strSubstring.substring(2);
                        kotlin.jvm.internal.m.f(strSubstring, "(this as java.lang.String).substring(startIndex)");
                    }
                    f5392e = strSubstring;
                } else if (obj instanceof Number) {
                    throw new s("App Ids cannot be directly placed in the manifest.They must be prefixed by 'fb' or be placed in the string resource file.");
                }
            }
            if (f5393f == null) {
                f5393f = applicationInfo.metaData.getString("com.facebook.sdk.ApplicationName");
            }
            if (f5394g == null) {
                f5394g = applicationInfo.metaData.getString("com.facebook.sdk.ClientToken");
            }
            if (f5401n == 64206) {
                f5401n = applicationInfo.metaData.getInt("com.facebook.sdk.CallbackOffset", 64206);
            }
            if (f5395h == null) {
                f5395h = Boolean.valueOf(applicationInfo.metaData.getBoolean("com.facebook.sdk.CodelessDebugLogEnabled", false));
            }
        } catch (PackageManager.NameNotFoundException unused) {
        }
    }

    private final void J(Context context, String str) {
        try {
            if (w2.a.d(this)) {
                return;
            }
            try {
                r2.a aVarE = r2.a.f20067f.e(context);
                SharedPreferences sharedPreferences = context.getSharedPreferences("com.facebook.sdk.attributionTracking", 0);
                String strN = kotlin.jvm.internal.m.n(str, "ping");
                long j10 = sharedPreferences.getLong(strN, 0L);
                try {
                    k2.h hVar = k2.h.f16919a;
                    JSONObject jSONObjectA = k2.h.a(h.a.MOBILE_INSTALL_EVENT, aVarE, c2.o.f6225b.b(context), z(context), context);
                    kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
                    String str2 = String.format("%s/activities", Arrays.copyOf(new Object[]{str}, 1));
                    kotlin.jvm.internal.m.f(str2, "java.lang.String.format(format, *args)");
                    j0 j0VarA = f5410w.a(null, str2, jSONObjectA, null);
                    if (j10 == 0 && j0VarA.k().b() == null) {
                        SharedPreferences.Editor editorEdit = sharedPreferences.edit();
                        editorEdit.putLong(strN, System.currentTimeMillis());
                        editorEdit.apply();
                    }
                } catch (JSONException e10) {
                    throw new s("An error occurred while publishing install.", e10);
                }
            } catch (Exception e11) {
                r2.l0 l0Var = r2.l0.f20174a;
                r2.l0.d0("Facebook-publish", e11);
            }
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    public static final void K(Context context, final String applicationId) {
        if (w2.a.d(f0.class)) {
            return;
        }
        try {
            kotlin.jvm.internal.m.g(context, "context");
            kotlin.jvm.internal.m.g(applicationId, "applicationId");
            final Context applicationContext = context.getApplicationContext();
            t().execute(new Runnable() { // from class: b2.x
                @Override // java.lang.Runnable
                public final void run() {
                    f0.L(applicationContext, applicationId);
                }
            });
            r2.n nVar = r2.n.f20187a;
            if (r2.n.g(n.b.OnDeviceEventProcessing)) {
                m2.c cVar = m2.c.f17685a;
                if (m2.c.d()) {
                    m2.c.g(applicationId, "com.facebook.sdk.attributionTracking");
                }
            }
        } catch (Throwable th) {
            w2.a.b(th, f0.class);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void L(Context applicationContext, String applicationId) {
        kotlin.jvm.internal.m.g(applicationId, "$applicationId");
        f0 f0Var = f5388a;
        kotlin.jvm.internal.m.f(applicationContext, "applicationContext");
        f0Var.J(applicationContext, applicationId);
    }

    public static final synchronized void M(Context applicationContext) {
        kotlin.jvm.internal.m.g(applicationContext, "applicationContext");
        N(applicationContext, null);
    }

    public static final synchronized void N(Context applicationContext, final b bVar) {
        kotlin.jvm.internal.m.g(applicationContext, "applicationContext");
        AtomicBoolean atomicBoolean = f5407t;
        if (atomicBoolean.get()) {
            if (bVar != null) {
                bVar.a();
            }
            return;
        }
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.e(applicationContext, false);
        r2.m0.f(applicationContext, false);
        Context applicationContext2 = applicationContext.getApplicationContext();
        kotlin.jvm.internal.m.f(applicationContext2, "applicationContext.applicationContext");
        f5400m = applicationContext2;
        c2.o.f6225b.b(applicationContext);
        Context context = f5400m;
        if (context == null) {
            kotlin.jvm.internal.m.u("applicationContext");
            throw null;
        }
        I(context);
        String str = f5392e;
        if (str == null || str.length() == 0) {
            throw new s("A valid Facebook app id must be set in the AndroidManifest.xml or set by calling FacebookSdk.setApplicationId before initializing the sdk.");
        }
        String str2 = f5394g;
        if (str2 == null || str2.length() == 0) {
            throw new s("A valid Facebook app client token must be set in the AndroidManifest.xml or set by calling FacebookSdk.setClientToken before initializing the sdk.");
        }
        atomicBoolean.set(true);
        if (o()) {
            j();
        }
        Context context2 = f5400m;
        if (context2 == null) {
            kotlin.jvm.internal.m.u("applicationContext");
            throw null;
        }
        if (context2 instanceof Application) {
            d1 d1Var = d1.f5363a;
            if (d1.d()) {
                k2.f fVar = k2.f.f16906a;
                Context context3 = f5400m;
                if (context3 == null) {
                    kotlin.jvm.internal.m.u("applicationContext");
                    throw null;
                }
                k2.f.x((Application) context3, f5392e);
            }
        }
        r2.v vVar = r2.v.f20292a;
        r2.v.g();
        r2.e0 e0Var = r2.e0.f20120a;
        r2.e0.x();
        b.a aVar = r2.b.f20081b;
        Context context4 = f5400m;
        if (context4 == null) {
            kotlin.jvm.internal.m.u("applicationContext");
            throw null;
        }
        aVar.a(context4);
        f5399l = new r2.b0<>(new Callable() { // from class: b2.z
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return f0.O();
            }
        });
        r2.n nVar = r2.n.f20187a;
        r2.n.a(n.b.Instrument, new n.a() { // from class: b2.a0
            @Override // r2.n.a
            public final void a(boolean z10) {
                f0.P(z10);
            }
        });
        r2.n.a(n.b.AppEvents, new n.a() { // from class: b2.d0
            @Override // r2.n.a
            public final void a(boolean z10) {
                f0.Q(z10);
            }
        });
        r2.n.a(n.b.ChromeCustomTabsPrefetching, new n.a() { // from class: b2.e0
            @Override // r2.n.a
            public final void a(boolean z10) {
                f0.R(z10);
            }
        });
        r2.n.a(n.b.IgnoreAppSwitchToLoggedOut, new n.a() { // from class: b2.b0
            @Override // r2.n.a
            public final void a(boolean z10) {
                f0.S(z10);
            }
        });
        r2.n.a(n.b.BypassAppSwitch, new n.a() { // from class: b2.c0
            @Override // r2.n.a
            public final void a(boolean z10) {
                f0.T(z10);
            }
        });
        t().execute(new FutureTask(new Callable() { // from class: b2.y
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return f0.U(bVar);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final File O() {
        Context context = f5400m;
        if (context != null) {
            return context.getCacheDir();
        }
        kotlin.jvm.internal.m.u("applicationContext");
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void P(boolean z10) {
        if (z10) {
            t2.g gVar = t2.g.f21440a;
            t2.g.d();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void Q(boolean z10) {
        if (z10) {
            c2.y yVar = c2.y.f6250a;
            c2.y.a();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void R(boolean z10) {
        if (z10) {
            f5404q = true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void S(boolean z10) {
        if (z10) {
            f5405r = true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void T(boolean z10) {
        if (z10) {
            f5406s = true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Void U(b bVar) {
        g.f5412f.e().j();
        v0.f5593d.a().d();
        if (b2.a.f5323l.g()) {
            t0.b bVar2 = t0.f5559h;
            if (bVar2.b() == null) {
                bVar2.a();
            }
        }
        if (bVar != null) {
            bVar.a();
        }
        o.a aVar = c2.o.f6225b;
        aVar.e(l(), f5392e);
        d1 d1Var = d1.f5363a;
        d1.k();
        Context applicationContext = l().getApplicationContext();
        kotlin.jvm.internal.m.f(applicationContext, "getApplicationContext().applicationContext");
        aVar.f(applicationContext).a();
        return null;
    }

    public static final void j() {
        f5411x = true;
    }

    public static final boolean k() {
        d1 d1Var = d1.f5363a;
        return d1.b();
    }

    public static final Context l() {
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.l();
        Context context = f5400m;
        if (context != null) {
            return context;
        }
        kotlin.jvm.internal.m.u("applicationContext");
        throw null;
    }

    public static final String m() {
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.l();
        String str = f5392e;
        if (str != null) {
            return str;
        }
        throw new s("A valid Facebook app id must be set in the AndroidManifest.xml or set by calling FacebookSdk.setApplicationId before initializing the sdk.");
    }

    public static final String n() {
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.l();
        return f5393f;
    }

    public static final boolean o() {
        d1 d1Var = d1.f5363a;
        return d1.c();
    }

    public static final boolean p() {
        d1 d1Var = d1.f5363a;
        return d1.d();
    }

    public static final int q() {
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.l();
        return f5401n;
    }

    public static final String r() {
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.l();
        String str = f5394g;
        if (str != null) {
            return str;
        }
        throw new s("A valid Facebook client token must be set in the AndroidManifest.xml or set by calling FacebookSdk.setClientToken before initializing the sdk. Visit https://developers.facebook.com/docs/android/getting-started#add-app_id for more information.");
    }

    public static final boolean s() {
        d1 d1Var = d1.f5363a;
        return d1.e();
    }

    public static final Executor t() {
        ReentrantLock reentrantLock = f5402o;
        reentrantLock.lock();
        try {
            if (f5391d == null) {
                f5391d = AsyncTask.THREAD_POOL_EXECUTOR;
            }
            tc.x xVar = tc.x.f21992a;
            reentrantLock.unlock();
            Executor executor = f5391d;
            if (executor != null) {
                return executor;
            }
            throw new IllegalStateException("Required value was null.".toString());
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }

    public static final String u() {
        return f5409v;
    }

    public static final String v() {
        return "fb.gg";
    }

    public static final String w() {
        r2.l0 l0Var = r2.l0.f20174a;
        String str = f5389b;
        kotlin.jvm.internal.w wVar = kotlin.jvm.internal.w.f17306a;
        String str2 = String.format("getGraphApiVersion: %s", Arrays.copyOf(new Object[]{f5403p}, 1));
        kotlin.jvm.internal.m.f(str2, "java.lang.String.format(format, *args)");
        r2.l0.e0(str, str2);
        return f5403p;
    }

    public static final String x() {
        b2.a aVarE = b2.a.f5323l.e();
        String strO = aVarE != null ? aVarE.o() : null;
        r2.l0 l0Var = r2.l0.f20174a;
        return r2.l0.B(strO);
    }

    public static final String y() {
        return f5408u;
    }

    public static final boolean z(Context context) {
        kotlin.jvm.internal.m.g(context, "context");
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.l();
        return context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).getBoolean("limitEventUsage", false);
    }
}
