package b2;

import android.content.SharedPreferences;
import android.os.Bundle;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: d, reason: collision with root package name */
    public static final a f5344d = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private final SharedPreferences f5345a;

    /* renamed from: b, reason: collision with root package name */
    private final C0089b f5346b;

    /* renamed from: c, reason: collision with root package name */
    private q0 f5347c;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    /* renamed from: b2.b$b, reason: collision with other inner class name */
    public static final class C0089b {
        public final q0 a() {
            f0 f0Var = f0.f5388a;
            return new q0(f0.l(), null, 2, null);
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public b() {
        f0 f0Var = f0.f5388a;
        SharedPreferences sharedPreferences = f0.l().getSharedPreferences("com.facebook.AccessTokenManager.SharedPreferences", 0);
        kotlin.jvm.internal.m.f(sharedPreferences, "FacebookSdk.getApplicationContext()\n              .getSharedPreferences(\n                  AccessTokenManager.SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE)");
        this(sharedPreferences, new C0089b());
    }

    public b(SharedPreferences sharedPreferences, C0089b tokenCachingStrategyFactory) {
        kotlin.jvm.internal.m.g(sharedPreferences, "sharedPreferences");
        kotlin.jvm.internal.m.g(tokenCachingStrategyFactory, "tokenCachingStrategyFactory");
        this.f5345a = sharedPreferences;
        this.f5346b = tokenCachingStrategyFactory;
    }

    private final b2.a b() {
        String string = this.f5345a.getString("com.facebook.AccessTokenManager.CachedAccessToken", null);
        if (string == null) {
            return null;
        }
        try {
            return b2.a.f5323l.b(new JSONObject(string));
        } catch (JSONException unused) {
            return null;
        }
    }

    private final b2.a c() {
        Bundle bundleC = d().c();
        if (bundleC == null || !q0.f5543c.g(bundleC)) {
            return null;
        }
        return b2.a.f5323l.c(bundleC);
    }

    private final q0 d() {
        if (w2.a.d(this)) {
            return null;
        }
        try {
            if (this.f5347c == null) {
                synchronized (this) {
                    if (this.f5347c == null) {
                        this.f5347c = this.f5346b.a();
                    }
                    tc.x xVar = tc.x.f21992a;
                }
            }
            q0 q0Var = this.f5347c;
            if (q0Var != null) {
                return q0Var;
            }
            throw new IllegalStateException("Required value was null.".toString());
        } catch (Throwable th) {
            w2.a.b(th, this);
            return null;
        }
    }

    private final boolean e() {
        return this.f5345a.contains("com.facebook.AccessTokenManager.CachedAccessToken");
    }

    private final boolean h() {
        f0 f0Var = f0.f5388a;
        return f0.G();
    }

    public final void a() {
        this.f5345a.edit().remove("com.facebook.AccessTokenManager.CachedAccessToken").apply();
        if (h()) {
            d().a();
        }
    }

    public final b2.a f() {
        if (e()) {
            return b();
        }
        if (!h()) {
            return null;
        }
        b2.a aVarC = c();
        if (aVarC == null) {
            return aVarC;
        }
        g(aVarC);
        d().a();
        return aVarC;
    }

    public final void g(b2.a accessToken) {
        kotlin.jvm.internal.m.g(accessToken, "accessToken");
        try {
            this.f5345a.edit().putString("com.facebook.AccessTokenManager.CachedAccessToken", accessToken.z().toString()).apply();
        } catch (JSONException unused) {
        }
    }
}
