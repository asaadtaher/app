package b2;

/* loaded from: classes.dex */
public interface z0 {
    void b(j0 j0Var);
}
