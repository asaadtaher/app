package b2;

/* loaded from: classes.dex */
public final class h0 extends s {

    /* renamed from: c, reason: collision with root package name */
    public static final a f5443c = new a(null);

    /* renamed from: b, reason: collision with root package name */
    private final v f5444b;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h0(v requestError, String str) {
        super(str);
        kotlin.jvm.internal.m.g(requestError, "requestError");
        this.f5444b = requestError;
    }

    public final v c() {
        return this.f5444b;
    }

    @Override // b2.s, java.lang.Throwable
    public String toString() {
        String str = "{FacebookServiceException: httpResponseCode: " + this.f5444b.l() + ", facebookErrorCode: " + this.f5444b.h() + ", facebookErrorType: " + this.f5444b.j() + ", message: " + this.f5444b.i() + "}";
        kotlin.jvm.internal.m.f(str, "StringBuilder()\n        .append(\"{FacebookServiceException: \")\n        .append(\"httpResponseCode: \")\n        .append(requestError.requestStatusCode)\n        .append(\", facebookErrorCode: \")\n        .append(requestError.errorCode)\n        .append(\", facebookErrorType: \")\n        .append(requestError.errorType)\n        .append(\", message: \")\n        .append(requestError.errorMessage)\n        .append(\"}\")\n        .toString()");
        return str;
    }
}
