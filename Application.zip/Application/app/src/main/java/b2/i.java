package b2;

import android.os.Parcel;
import android.os.Parcelable;
import com.facebook.AuthenticationTokenManager;
import com.payment.paymentsdk.PaymentSdkParams;
import java.io.IOException;
import java.security.spec.InvalidKeySpecException;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class i implements Parcelable {

    /* renamed from: a, reason: collision with root package name */
    private final String f5446a;

    /* renamed from: b, reason: collision with root package name */
    private final String f5447b;

    /* renamed from: c, reason: collision with root package name */
    private final m f5448c;

    /* renamed from: d, reason: collision with root package name */
    private final l f5449d;

    /* renamed from: e, reason: collision with root package name */
    private final String f5450e;

    /* renamed from: f, reason: collision with root package name */
    public static final b f5445f = new b(null);
    public static final Parcelable.Creator<i> CREATOR = new a();

    public static final class a implements Parcelable.Creator<i> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public i createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new i(source);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public i[] newArray(int i10) {
            return new i[i10];
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final void a(i iVar) {
            AuthenticationTokenManager.f6896d.a().e(iVar);
        }
    }

    public i(Parcel parcel) {
        kotlin.jvm.internal.m.g(parcel, "parcel");
        String string = parcel.readString();
        r2.m0 m0Var = r2.m0.f20185a;
        this.f5446a = r2.m0.k(string, PaymentSdkParams.TOKEN);
        this.f5447b = r2.m0.k(parcel.readString(), "expectedNonce");
        Parcelable parcelable = parcel.readParcelable(m.class.getClassLoader());
        if (parcelable == null) {
            throw new IllegalStateException("Required value was null.".toString());
        }
        this.f5448c = (m) parcelable;
        Parcelable parcelable2 = parcel.readParcelable(l.class.getClassLoader());
        if (parcelable2 == null) {
            throw new IllegalStateException("Required value was null.".toString());
        }
        this.f5449d = (l) parcelable2;
        this.f5450e = r2.m0.k(parcel.readString(), "signature");
    }

    public i(String token, String expectedNonce) {
        kotlin.jvm.internal.m.g(token, "token");
        kotlin.jvm.internal.m.g(expectedNonce, "expectedNonce");
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.g(token, PaymentSdkParams.TOKEN);
        r2.m0.g(expectedNonce, "expectedNonce");
        List listR0 = md.q.r0(token, new String[]{"."}, false, 0, 6, null);
        if (!(listR0.size() == 3)) {
            throw new IllegalArgumentException("Invalid IdToken string".toString());
        }
        String str = (String) listR0.get(0);
        String str2 = (String) listR0.get(1);
        String str3 = (String) listR0.get(2);
        this.f5446a = token;
        this.f5447b = expectedNonce;
        m mVar = new m(str);
        this.f5448c = mVar;
        this.f5449d = new l(str2, expectedNonce);
        if (!b(str, str2, str3, mVar.b())) {
            throw new IllegalArgumentException("Invalid Signature".toString());
        }
        this.f5450e = str3;
    }

    private final boolean b(String str, String str2, String str3, String str4) {
        try {
            a3.c cVar = a3.c.f27a;
            String strC = a3.c.c(str4);
            if (strC == null) {
                return false;
            }
            return a3.c.e(a3.c.b(strC), str + '.' + str2, str3);
        } catch (IOException | InvalidKeySpecException unused) {
            return false;
        }
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return kotlin.jvm.internal.m.b(this.f5446a, iVar.f5446a) && kotlin.jvm.internal.m.b(this.f5447b, iVar.f5447b) && kotlin.jvm.internal.m.b(this.f5448c, iVar.f5448c) && kotlin.jvm.internal.m.b(this.f5449d, iVar.f5449d) && kotlin.jvm.internal.m.b(this.f5450e, iVar.f5450e);
    }

    public final JSONObject h() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("token_string", this.f5446a);
        jSONObject.put("expected_nonce", this.f5447b);
        jSONObject.put("header", this.f5448c.i());
        jSONObject.put("claims", this.f5449d.h());
        jSONObject.put("signature", this.f5450e);
        return jSONObject;
    }

    public int hashCode() {
        return ((((((((527 + this.f5446a.hashCode()) * 31) + this.f5447b.hashCode()) * 31) + this.f5448c.hashCode()) * 31) + this.f5449d.hashCode()) * 31) + this.f5450e.hashCode();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int i10) {
        kotlin.jvm.internal.m.g(dest, "dest");
        dest.writeString(this.f5446a);
        dest.writeString(this.f5447b);
        dest.writeParcelable(this.f5448c, i10);
        dest.writeParcelable(this.f5449d, i10);
        dest.writeString(this.f5450e);
    }
}
