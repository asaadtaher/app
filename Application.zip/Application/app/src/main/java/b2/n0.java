package b2;

import android.os.Handler;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.dex */
public final class n0 extends AbstractList<j0> {

    /* renamed from: g, reason: collision with root package name */
    public static final b f5517g = new b(null);

    /* renamed from: h, reason: collision with root package name */
    private static final AtomicInteger f5518h = new AtomicInteger();

    /* renamed from: a, reason: collision with root package name */
    private Handler f5519a;

    /* renamed from: b, reason: collision with root package name */
    private int f5520b;

    /* renamed from: c, reason: collision with root package name */
    private final String f5521c;

    /* renamed from: d, reason: collision with root package name */
    private List<j0> f5522d;

    /* renamed from: e, reason: collision with root package name */
    private List<a> f5523e;

    /* renamed from: f, reason: collision with root package name */
    private String f5524f;

    public interface a {
        void b(n0 n0Var);
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public interface c extends a {
        void a(n0 n0Var, long j10, long j11);
    }

    public n0(Collection<j0> requests) {
        kotlin.jvm.internal.m.g(requests, "requests");
        this.f5521c = String.valueOf(Integer.valueOf(f5518h.incrementAndGet()));
        this.f5523e = new ArrayList();
        this.f5522d = new ArrayList(requests);
    }

    public n0(j0... requests) {
        kotlin.jvm.internal.m.g(requests, "requests");
        this.f5521c = String.valueOf(Integer.valueOf(f5518h.incrementAndGet()));
        this.f5523e = new ArrayList();
        this.f5522d = new ArrayList(uc.j.c(requests));
    }

    private final List<o0> r() {
        return j0.f5454n.i(this);
    }

    private final m0 u() {
        return j0.f5454n.l(this);
    }

    public final List<j0> A() {
        return this.f5522d;
    }

    public int B() {
        return this.f5522d.size();
    }

    public final int C() {
        return this.f5520b;
    }

    public /* bridge */ int D(j0 j0Var) {
        return super.indexOf(j0Var);
    }

    public /* bridge */ int E(j0 j0Var) {
        return super.lastIndexOf(j0Var);
    }

    @Override // java.util.AbstractList, java.util.List
    /* renamed from: F, reason: merged with bridge method [inline-methods] */
    public final /* bridge */ j0 remove(int i10) {
        return H(i10);
    }

    public /* bridge */ boolean G(j0 j0Var) {
        return super.remove(j0Var);
    }

    public j0 H(int i10) {
        return this.f5522d.remove(i10);
    }

    @Override // java.util.AbstractList, java.util.List
    /* renamed from: I, reason: merged with bridge method [inline-methods] */
    public j0 set(int i10, j0 element) {
        kotlin.jvm.internal.m.g(element, "element");
        return this.f5522d.set(i10, element);
    }

    public final void J(Handler handler) {
        this.f5519a = handler;
    }

    @Override // java.util.AbstractList, java.util.List
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public void add(int i10, j0 element) {
        kotlin.jvm.internal.m.g(element, "element");
        this.f5522d.add(i10, element);
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public void clear() {
        this.f5522d.clear();
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final /* bridge */ boolean contains(Object obj) {
        if (obj == null ? true : obj instanceof j0) {
            return m((j0) obj);
        }
        return false;
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    /* renamed from: f, reason: merged with bridge method [inline-methods] */
    public boolean add(j0 element) {
        kotlin.jvm.internal.m.g(element, "element");
        return this.f5522d.add(element);
    }

    @Override // java.util.AbstractList, java.util.List
    public final /* bridge */ int indexOf(Object obj) {
        if (obj == null ? true : obj instanceof j0) {
            return D((j0) obj);
        }
        return -1;
    }

    public final void k(a callback) {
        kotlin.jvm.internal.m.g(callback, "callback");
        if (this.f5523e.contains(callback)) {
            return;
        }
        this.f5523e.add(callback);
    }

    @Override // java.util.AbstractList, java.util.List
    public final /* bridge */ int lastIndexOf(Object obj) {
        if (obj == null ? true : obj instanceof j0) {
            return E((j0) obj);
        }
        return -1;
    }

    public /* bridge */ boolean m(j0 j0Var) {
        return super.contains(j0Var);
    }

    public final List<o0> p() {
        return r();
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final /* bridge */ boolean remove(Object obj) {
        if (obj == null ? true : obj instanceof j0) {
            return G((j0) obj);
        }
        return false;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final /* bridge */ int size() {
        return B();
    }

    public final m0 t() {
        return u();
    }

    @Override // java.util.AbstractList, java.util.List
    /* renamed from: v, reason: merged with bridge method [inline-methods] */
    public j0 get(int i10) {
        return this.f5522d.get(i10);
    }

    public final String w() {
        return this.f5524f;
    }

    public final Handler x() {
        return this.f5519a;
    }

    public final List<a> y() {
        return this.f5523e;
    }

    public final String z() {
        return this.f5521c;
    }
}
