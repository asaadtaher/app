package b2;

import android.content.Intent;

/* loaded from: classes.dex */
public interface n {

    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        public static final a f5516a = new a();

        private a() {
        }

        public static final n a() {
            return new r2.d();
        }
    }

    boolean onActivityResult(int i10, int i11, Intent intent);
}
