package b2;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class m implements Parcelable {

    /* renamed from: a, reason: collision with root package name */
    private final String f5508a;

    /* renamed from: b, reason: collision with root package name */
    private final String f5509b;

    /* renamed from: c, reason: collision with root package name */
    private final String f5510c;

    /* renamed from: d, reason: collision with root package name */
    public static final b f5507d = new b(null);
    public static final Parcelable.Creator<m> CREATOR = new a();

    public static final class a implements Parcelable.Creator<m> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public m createFromParcel(Parcel source) {
            kotlin.jvm.internal.m.g(source, "source");
            return new m(source);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public m[] newArray(int i10) {
            return new m[i10];
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    public m(Parcel parcel) {
        kotlin.jvm.internal.m.g(parcel, "parcel");
        String string = parcel.readString();
        r2.m0 m0Var = r2.m0.f20185a;
        this.f5508a = r2.m0.k(string, "alg");
        this.f5509b = r2.m0.k(parcel.readString(), "typ");
        this.f5510c = r2.m0.k(parcel.readString(), "kid");
    }

    public m(String encodedHeaderString) throws JSONException {
        kotlin.jvm.internal.m.g(encodedHeaderString, "encodedHeaderString");
        if (!h(encodedHeaderString)) {
            throw new IllegalArgumentException("Invalid Header".toString());
        }
        byte[] decodedBytes = Base64.decode(encodedHeaderString, 0);
        kotlin.jvm.internal.m.f(decodedBytes, "decodedBytes");
        JSONObject jSONObject = new JSONObject(new String(decodedBytes, md.d.f17896b));
        String string = jSONObject.getString("alg");
        kotlin.jvm.internal.m.f(string, "jsonObj.getString(\"alg\")");
        this.f5508a = string;
        String string2 = jSONObject.getString("typ");
        kotlin.jvm.internal.m.f(string2, "jsonObj.getString(\"typ\")");
        this.f5509b = string2;
        String string3 = jSONObject.getString("kid");
        kotlin.jvm.internal.m.f(string3, "jsonObj.getString(\"kid\")");
        this.f5510c = string3;
    }

    private final boolean h(String str) {
        r2.m0 m0Var = r2.m0.f20185a;
        r2.m0.g(str, "encodedHeaderString");
        byte[] decodedBytes = Base64.decode(str, 0);
        kotlin.jvm.internal.m.f(decodedBytes, "decodedBytes");
        try {
            JSONObject jSONObject = new JSONObject(new String(decodedBytes, md.d.f17896b));
            String alg = jSONObject.optString("alg");
            kotlin.jvm.internal.m.f(alg, "alg");
            boolean z10 = (alg.length() > 0) && kotlin.jvm.internal.m.b(alg, "RS256");
            String strOptString = jSONObject.optString("kid");
            kotlin.jvm.internal.m.f(strOptString, "jsonObj.optString(\"kid\")");
            boolean z11 = strOptString.length() > 0;
            String strOptString2 = jSONObject.optString("typ");
            kotlin.jvm.internal.m.f(strOptString2, "jsonObj.optString(\"typ\")");
            return z10 && z11 && (strOptString2.length() > 0);
        } catch (JSONException unused) {
            return false;
        }
    }

    public final String b() {
        return this.f5510c;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof m)) {
            return false;
        }
        m mVar = (m) obj;
        return kotlin.jvm.internal.m.b(this.f5508a, mVar.f5508a) && kotlin.jvm.internal.m.b(this.f5509b, mVar.f5509b) && kotlin.jvm.internal.m.b(this.f5510c, mVar.f5510c);
    }

    public int hashCode() {
        return ((((527 + this.f5508a.hashCode()) * 31) + this.f5509b.hashCode()) * 31) + this.f5510c.hashCode();
    }

    public final JSONObject i() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("alg", this.f5508a);
        jSONObject.put("typ", this.f5509b);
        jSONObject.put("kid", this.f5510c);
        return jSONObject;
    }

    public String toString() {
        String string = i().toString();
        kotlin.jvm.internal.m.f(string, "headerJsonObject.toString()");
        return string;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int i10) {
        kotlin.jvm.internal.m.g(dest, "dest");
        dest.writeString(this.f5508a);
        dest.writeString(this.f5509b);
        dest.writeString(this.f5510c);
    }
}
