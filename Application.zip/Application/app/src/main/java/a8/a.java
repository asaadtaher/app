package a8;

/* loaded from: classes.dex */
public abstract class a {
    public abstract String a();
}
