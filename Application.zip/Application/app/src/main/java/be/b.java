package be;

import ee.c;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;
import md.p;
import yd.b0;
import yd.d0;
import yd.u;
import zd.d;

/* loaded from: classes2.dex */
public final class b {

    /* renamed from: c, reason: collision with root package name */
    public static final a f6091c = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private final b0 f6092a;

    /* renamed from: b, reason: collision with root package name */
    private final d0 f6093b;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }

        /* JADX WARN: Removed duplicated region for block: B:24:0x003b  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final boolean a(yd.d0 r5, yd.b0 r6) {
            /*
                r4 = this;
                java.lang.String r0 = "response"
                kotlin.jvm.internal.m.g(r5, r0)
                java.lang.String r0 = "request"
                kotlin.jvm.internal.m.g(r6, r0)
                int r0 = r5.m()
                r1 = 200(0xc8, float:2.8E-43)
                r2 = 0
                if (r0 == r1) goto L65
                r1 = 410(0x19a, float:5.75E-43)
                if (r0 == r1) goto L65
                r1 = 414(0x19e, float:5.8E-43)
                if (r0 == r1) goto L65
                r1 = 501(0x1f5, float:7.02E-43)
                if (r0 == r1) goto L65
                r1 = 203(0xcb, float:2.84E-43)
                if (r0 == r1) goto L65
                r1 = 204(0xcc, float:2.86E-43)
                if (r0 == r1) goto L65
                r1 = 307(0x133, float:4.3E-43)
                if (r0 == r1) goto L3b
                r1 = 308(0x134, float:4.32E-43)
                if (r0 == r1) goto L65
                r1 = 404(0x194, float:5.66E-43)
                if (r0 == r1) goto L65
                r1 = 405(0x195, float:5.68E-43)
                if (r0 == r1) goto L65
                switch(r0) {
                    case 300: goto L65;
                    case 301: goto L65;
                    case 302: goto L3b;
                    default: goto L3a;
                }
            L3a:
                return r2
            L3b:
                r0 = 2
                java.lang.String r1 = "Expires"
                r3 = 0
                java.lang.String r0 = yd.d0.C(r5, r1, r3, r0, r3)
                if (r0 != 0) goto L65
                yd.d r0 = r5.d()
                int r0 = r0.c()
                r1 = -1
                if (r0 != r1) goto L65
                yd.d r0 = r5.d()
                boolean r0 = r0.b()
                if (r0 != 0) goto L65
                yd.d r0 = r5.d()
                boolean r0 = r0.a()
                if (r0 != 0) goto L65
                return r2
            L65:
                yd.d r5 = r5.d()
                boolean r5 = r5.h()
                if (r5 != 0) goto L7a
                yd.d r5 = r6.b()
                boolean r5 = r5.h()
                if (r5 != 0) goto L7a
                r2 = 1
            L7a:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: be.b.a.a(yd.d0, yd.b0):boolean");
        }
    }

    /* renamed from: be.b$b, reason: collision with other inner class name */
    public static final class C0095b {

        /* renamed from: a, reason: collision with root package name */
        private final long f6094a;

        /* renamed from: b, reason: collision with root package name */
        private final b0 f6095b;

        /* renamed from: c, reason: collision with root package name */
        private final d0 f6096c;

        /* renamed from: d, reason: collision with root package name */
        private Date f6097d;

        /* renamed from: e, reason: collision with root package name */
        private String f6098e;

        /* renamed from: f, reason: collision with root package name */
        private Date f6099f;

        /* renamed from: g, reason: collision with root package name */
        private String f6100g;

        /* renamed from: h, reason: collision with root package name */
        private Date f6101h;

        /* renamed from: i, reason: collision with root package name */
        private long f6102i;

        /* renamed from: j, reason: collision with root package name */
        private long f6103j;

        /* renamed from: k, reason: collision with root package name */
        private String f6104k;

        /* renamed from: l, reason: collision with root package name */
        private int f6105l;

        public C0095b(long j10, b0 request, d0 d0Var) {
            m.g(request, "request");
            this.f6094a = j10;
            this.f6095b = request;
            this.f6096c = d0Var;
            this.f6105l = -1;
            if (d0Var != null) {
                this.f6102i = d0Var.n0();
                this.f6103j = d0Var.j0();
                u uVarK = d0Var.K();
                int size = uVarK.size();
                for (int i10 = 0; i10 < size; i10++) {
                    String strF = uVarK.f(i10);
                    String strP = uVarK.p(i10);
                    if (p.q(strF, "Date", true)) {
                        this.f6097d = c.a(strP);
                        this.f6098e = strP;
                    } else if (p.q(strF, "Expires", true)) {
                        this.f6101h = c.a(strP);
                    } else if (p.q(strF, "Last-Modified", true)) {
                        this.f6099f = c.a(strP);
                        this.f6100g = strP;
                    } else if (p.q(strF, "ETag", true)) {
                        this.f6104k = strP;
                    } else if (p.q(strF, "Age", true)) {
                        this.f6105l = d.V(strP, -1);
                    }
                }
            }
        }

        private final long a() {
            Date date = this.f6097d;
            long jMax = date != null ? Math.max(0L, this.f6103j - date.getTime()) : 0L;
            int i10 = this.f6105l;
            if (i10 != -1) {
                jMax = Math.max(jMax, TimeUnit.SECONDS.toMillis(i10));
            }
            long j10 = this.f6103j;
            return jMax + (j10 - this.f6102i) + (this.f6094a - j10);
        }

        private final b c() {
            if (this.f6096c == null) {
                return new b(this.f6095b, null);
            }
            if ((!this.f6095b.f() || this.f6096c.r() != null) && b.f6091c.a(this.f6096c, this.f6095b)) {
                yd.d dVarB = this.f6095b.b();
                if (dVarB.g() || e(this.f6095b)) {
                    return new b(this.f6095b, null);
                }
                yd.d dVarD = this.f6096c.d();
                long jA = a();
                long jD = d();
                if (dVarB.c() != -1) {
                    jD = Math.min(jD, TimeUnit.SECONDS.toMillis(dVarB.c()));
                }
                long millis = 0;
                long millis2 = dVarB.e() != -1 ? TimeUnit.SECONDS.toMillis(dVarB.e()) : 0L;
                if (!dVarD.f() && dVarB.d() != -1) {
                    millis = TimeUnit.SECONDS.toMillis(dVarB.d());
                }
                if (!dVarD.g()) {
                    long j10 = millis2 + jA;
                    if (j10 < millis + jD) {
                        d0.a aVarC0 = this.f6096c.c0();
                        if (j10 >= jD) {
                            aVarC0.a("Warning", "110 HttpURLConnection \"Response is stale\"");
                        }
                        if (jA > 86400000 && f()) {
                            aVarC0.a("Warning", "113 HttpURLConnection \"Heuristic expiration\"");
                        }
                        return new b(null, aVarC0.c());
                    }
                }
                String str = this.f6104k;
                String str2 = "If-Modified-Since";
                if (str != null) {
                    str2 = "If-None-Match";
                } else if (this.f6099f != null) {
                    str = this.f6100g;
                } else {
                    if (this.f6097d == null) {
                        return new b(this.f6095b, null);
                    }
                    str = this.f6098e;
                }
                u.a aVarK = this.f6095b.e().k();
                m.d(str);
                aVarK.d(str2, str);
                return new b(this.f6095b.h().d(aVarK.e()).b(), this.f6096c);
            }
            return new b(this.f6095b, null);
        }

        private final long d() {
            d0 d0Var = this.f6096c;
            m.d(d0Var);
            if (d0Var.d().c() != -1) {
                return TimeUnit.SECONDS.toMillis(r0.c());
            }
            Date date = this.f6101h;
            if (date != null) {
                Date date2 = this.f6097d;
                long time = date.getTime() - (date2 != null ? date2.getTime() : this.f6103j);
                if (time > 0) {
                    return time;
                }
                return 0L;
            }
            if (this.f6099f == null || this.f6096c.m0().j().o() != null) {
                return 0L;
            }
            Date date3 = this.f6097d;
            long time2 = date3 != null ? date3.getTime() : this.f6102i;
            Date date4 = this.f6099f;
            m.d(date4);
            long time3 = time2 - date4.getTime();
            if (time3 > 0) {
                return time3 / 10;
            }
            return 0L;
        }

        private final boolean e(b0 b0Var) {
            return (b0Var.d("If-Modified-Since") == null && b0Var.d("If-None-Match") == null) ? false : true;
        }

        private final boolean f() {
            d0 d0Var = this.f6096c;
            m.d(d0Var);
            return d0Var.d().c() == -1 && this.f6101h == null;
        }

        public final b b() {
            b bVarC = c();
            return (bVarC.b() == null || !this.f6095b.b().i()) ? bVarC : new b(null, null);
        }
    }

    public b(b0 b0Var, d0 d0Var) {
        this.f6092a = b0Var;
        this.f6093b = d0Var;
    }

    public final d0 a() {
        return this.f6093b;
    }

    public final b0 b() {
        return this.f6092a;
    }
}
