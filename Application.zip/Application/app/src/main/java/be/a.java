package be;

import be.b;
import java.io.IOException;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;
import md.p;
import yd.a0;
import yd.b0;
import yd.c;
import yd.d0;
import yd.e;
import yd.e0;
import yd.r;
import yd.u;
import yd.w;
import zd.d;

/* loaded from: classes2.dex */
public final class a implements w {

    /* renamed from: b, reason: collision with root package name */
    public static final C0094a f6089b = new C0094a(null);

    /* renamed from: a, reason: collision with root package name */
    private final c f6090a;

    /* renamed from: be.a$a, reason: collision with other inner class name */
    public static final class C0094a {
        private C0094a() {
        }

        public /* synthetic */ C0094a(g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final u c(u uVar, u uVar2) {
            u.a aVar = new u.a();
            int size = uVar.size();
            for (int i10 = 0; i10 < size; i10++) {
                String strF = uVar.f(i10);
                String strP = uVar.p(i10);
                if ((!p.q("Warning", strF, true) || !p.C(strP, "1", false, 2, null)) && (d(strF) || !e(strF) || uVar2.b(strF) == null)) {
                    aVar.d(strF, strP);
                }
            }
            int size2 = uVar2.size();
            for (int i11 = 0; i11 < size2; i11++) {
                String strF2 = uVar2.f(i11);
                if (!d(strF2) && e(strF2)) {
                    aVar.d(strF2, uVar2.p(i11));
                }
            }
            return aVar.e();
        }

        private final boolean d(String str) {
            return p.q("Content-Length", str, true) || p.q("Content-Encoding", str, true) || p.q("Content-Type", str, true);
        }

        private final boolean e(String str) {
            return (p.q("Connection", str, true) || p.q("Keep-Alive", str, true) || p.q("Proxy-Authenticate", str, true) || p.q("Proxy-Authorization", str, true) || p.q("TE", str, true) || p.q("Trailers", str, true) || p.q("Transfer-Encoding", str, true) || p.q("Upgrade", str, true)) ? false : true;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final d0 f(d0 d0Var) {
            return (d0Var != null ? d0Var.b() : null) != null ? d0Var.c0().b(null).c() : d0Var;
        }
    }

    public a(c cVar) {
    }

    @Override // yd.w
    public d0 intercept(w.a chain) throws IOException {
        r rVarS;
        m.g(chain, "chain");
        e eVarCall = chain.call();
        b bVarB = new b.C0095b(System.currentTimeMillis(), chain.f(), null).b();
        b0 b0VarB = bVarB.b();
        d0 d0VarA = bVarB.a();
        de.e eVar = eVarCall instanceof de.e ? (de.e) eVarCall : null;
        if (eVar == null || (rVarS = eVar.s()) == null) {
            rVarS = r.f24649b;
        }
        if (b0VarB == null && d0VarA == null) {
            d0 d0VarC = new d0.a().r(chain.f()).p(a0.HTTP_1_1).g(504).m("Unsatisfiable Request (only-if-cached)").b(d.f25112c).s(-1L).q(System.currentTimeMillis()).c();
            rVarS.z(eVarCall, d0VarC);
            return d0VarC;
        }
        if (b0VarB == null) {
            m.d(d0VarA);
            d0 d0VarC2 = d0VarA.c0().d(f6089b.f(d0VarA)).c();
            rVarS.b(eVarCall, d0VarC2);
            return d0VarC2;
        }
        if (d0VarA != null) {
            rVarS.a(eVarCall, d0VarA);
        }
        d0 d0VarA2 = chain.a(b0VarB);
        if (d0VarA != null) {
            boolean z10 = false;
            if (d0VarA2 != null && d0VarA2.m() == 304) {
                z10 = true;
            }
            if (z10) {
                d0.a aVarC0 = d0VarA.c0();
                C0094a c0094a = f6089b;
                aVarC0.k(c0094a.c(d0VarA.K(), d0VarA2.K())).s(d0VarA2.n0()).q(d0VarA2.j0()).d(c0094a.f(d0VarA)).n(c0094a.f(d0VarA2)).c();
                e0 e0VarB = d0VarA2.b();
                m.d(e0VarB);
                e0VarB.close();
                m.d(this.f6090a);
                throw null;
            }
            e0 e0VarB2 = d0VarA.b();
            if (e0VarB2 != null) {
                d.m(e0VarB2);
            }
        }
        m.d(d0VarA2);
        d0.a aVarC02 = d0VarA2.c0();
        C0094a c0094a2 = f6089b;
        return aVarC02.d(c0094a2.f(d0VarA)).n(c0094a2.f(d0VarA2)).c();
    }
}
