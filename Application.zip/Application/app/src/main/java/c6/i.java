package c6;

/* loaded from: classes.dex */
public final class i {

    /* renamed from: a, reason: collision with root package name */
    public static final int f6423a = 2131820577;

    /* renamed from: b, reason: collision with root package name */
    public static final int f6424b = 2131820619;

    /* renamed from: c, reason: collision with root package name */
    public static final int f6425c = 2131820620;

    /* renamed from: d, reason: collision with root package name */
    public static final int f6426d = 2131820621;

    /* renamed from: e, reason: collision with root package name */
    public static final int f6427e = 2131820622;

    /* renamed from: f, reason: collision with root package name */
    public static final int f6428f = 2131820669;

    /* renamed from: g, reason: collision with root package name */
    public static final int f6429g = 2131820670;

    /* renamed from: h, reason: collision with root package name */
    public static final int f6430h = 2131820735;

    /* renamed from: i, reason: collision with root package name */
    public static final int f6431i = 2131820736;

    /* renamed from: j, reason: collision with root package name */
    public static final int f6432j = 2131820737;

    /* renamed from: k, reason: collision with root package name */
    public static final int f6433k = 2131820738;

    /* renamed from: l, reason: collision with root package name */
    public static final int f6434l = 2131820751;

    /* renamed from: m, reason: collision with root package name */
    public static final int f6435m = 2131820752;

    /* renamed from: n, reason: collision with root package name */
    public static final int f6436n = 2131820757;

    /* renamed from: o, reason: collision with root package name */
    public static final int f6437o = 2131820758;

    /* renamed from: p, reason: collision with root package name */
    public static final int f6438p = 2131820766;

    /* renamed from: q, reason: collision with root package name */
    public static final int f6439q = 2131820773;

    /* renamed from: r, reason: collision with root package name */
    public static final int f6440r = 2131820774;

    /* renamed from: s, reason: collision with root package name */
    public static final int f6441s = 2131820775;

    /* renamed from: t, reason: collision with root package name */
    public static final int f6442t = 2131820776;

    /* renamed from: u, reason: collision with root package name */
    public static final int f6443u = 2131820777;

    /* renamed from: v, reason: collision with root package name */
    public static final int f6444v = 2131820788;

    /* renamed from: w, reason: collision with root package name */
    public static final int f6445w = 2131820932;
}
