package c6;

import com.schoolz.io.R;

/* loaded from: classes.dex */
public final class k {
    public static final int A0 = 21;
    public static final int A2 = 0;
    public static final int A3 = 1;
    public static final int A4 = 3;
    public static final int A5 = 9;
    public static final int A6 = 61;
    public static final int B = 0;
    public static final int B0 = 22;
    public static final int B1 = 0;
    public static final int B2 = 1;
    public static final int B3 = 2;
    public static final int B4 = 4;
    public static final int B5 = 10;
    public static final int B6 = 64;
    public static final int C = 1;
    public static final int C0 = 23;
    public static final int C1 = 1;
    public static final int C2 = 2;
    public static final int C4 = 5;
    public static final int C5 = 11;
    public static final int C6 = 65;
    public static final int D = 2;
    public static final int D0 = 24;
    public static final int D1 = 2;
    public static final int D2 = 3;
    public static final int D4 = 6;
    public static final int D5 = 12;
    public static final int D6 = 66;
    public static final int E = 3;
    public static final int E0 = 25;
    public static final int E3 = 0;
    public static final int E5 = 13;
    public static final int E6 = 67;
    public static final int F = 4;
    public static final int F0 = 26;
    public static final int F2 = 1;
    public static final int F3 = 1;
    public static final int F5 = 14;
    public static final int F6 = 68;
    public static final int G = 5;
    public static final int G0 = 27;
    public static final int G2 = 2;
    public static final int G3 = 2;
    public static final int G5 = 15;
    public static final int G6 = 69;
    public static final int H = 6;
    public static final int H0 = 28;
    public static final int H2 = 3;
    public static final int H3 = 3;
    public static final int H4 = 0;
    public static final int H5 = 16;
    public static final int H6 = 70;
    public static final int I = 7;
    public static final int I0 = 29;
    public static final int I2 = 4;
    public static final int I3 = 4;
    public static final int I4 = 1;
    public static final int I5 = 17;
    public static final int I6 = 71;
    public static final int J = 8;
    public static final int J0 = 30;
    public static final int J2 = 5;
    public static final int J4 = 2;
    public static final int J5 = 18;
    public static final int J6 = 72;
    public static final int K = 9;
    public static final int K0 = 31;
    public static final int K2 = 7;
    public static final int K4 = 3;
    public static final int K5 = 19;
    public static final int K6 = 73;
    public static final int L = 10;
    public static final int L0 = 32;
    public static final int L2 = 8;
    public static final int L4 = 4;
    public static final int L5 = 20;
    public static final int M = 11;
    public static final int M0 = 33;
    public static final int M2 = 9;
    public static final int M4 = 5;
    public static final int M5 = 21;
    public static final int M6 = 0;
    public static final int N = 12;
    public static final int N0 = 34;
    public static final int N2 = 10;
    public static final int N4 = 6;
    public static final int N5 = 22;
    public static final int N6 = 1;
    public static final int O = 13;
    public static final int O0 = 35;
    public static final int O4 = 7;
    public static final int O5 = 23;
    public static final int O6 = 2;
    public static final int P = 14;
    public static final int P0 = 36;
    public static final int P2 = 0;
    public static final int P4 = 8;
    public static final int P5 = 24;
    public static final int Q = 15;
    public static final int Q0 = 37;
    public static final int Q2 = 1;
    public static final int Q4 = 9;
    public static final int Q5 = 25;
    public static final int R = 16;
    public static final int R0 = 39;
    public static final int R2 = 2;
    public static final int R5 = 26;
    public static final int S = 17;
    public static final int S0 = 40;
    public static final int S2 = 3;
    public static final int S5 = 27;
    public static final int T = 18;
    public static final int T0 = 41;
    public static final int T2 = 4;
    public static final int T5 = 28;
    public static final int U = 19;
    public static final int U2 = 5;
    public static final int U5 = 29;
    public static final int V = 20;
    public static final int V2 = 6;
    public static final int V5 = 30;
    public static final int W = 21;
    public static final int W2 = 7;
    public static final int W5 = 31;
    public static final int X = 23;
    public static final int X0 = 0;
    public static final int X1 = 0;
    public static final int X2 = 8;
    public static final int X5 = 32;
    public static final int Y0 = 1;
    public static final int Y1 = 1;
    public static final int Y2 = 9;
    public static final int Y5 = 33;
    public static final int Z1 = 2;
    public static final int Z5 = 34;

    /* renamed from: a1, reason: collision with root package name */
    public static final int f6471a1 = 0;

    /* renamed from: a2, reason: collision with root package name */
    public static final int f6472a2 = 3;

    /* renamed from: a6, reason: collision with root package name */
    public static final int f6476a6 = 35;

    /* renamed from: b1, reason: collision with root package name */
    public static final int f6479b1 = 1;

    /* renamed from: b2, reason: collision with root package name */
    public static final int f6480b2 = 4;

    /* renamed from: b3, reason: collision with root package name */
    public static final int f6481b3 = 0;

    /* renamed from: b5, reason: collision with root package name */
    public static final int f6483b5 = 0;

    /* renamed from: b6, reason: collision with root package name */
    public static final int f6484b6 = 36;

    /* renamed from: c0, reason: collision with root package name */
    public static final int f6486c0 = 0;

    /* renamed from: c1, reason: collision with root package name */
    public static final int f6487c1 = 2;

    /* renamed from: c2, reason: collision with root package name */
    public static final int f6488c2 = 5;

    /* renamed from: c3, reason: collision with root package name */
    public static final int f6489c3 = 1;

    /* renamed from: c4, reason: collision with root package name */
    public static final int f6490c4 = 0;

    /* renamed from: c5, reason: collision with root package name */
    public static final int f6491c5 = 1;

    /* renamed from: c6, reason: collision with root package name */
    public static final int f6492c6 = 37;

    /* renamed from: d2, reason: collision with root package name */
    public static final int f6496d2 = 6;

    /* renamed from: d3, reason: collision with root package name */
    public static final int f6497d3 = 2;

    /* renamed from: d5, reason: collision with root package name */
    public static final int f6499d5 = 2;

    /* renamed from: d6, reason: collision with root package name */
    public static final int f6500d6 = 38;

    /* renamed from: e3, reason: collision with root package name */
    public static final int f6505e3 = 3;

    /* renamed from: e5, reason: collision with root package name */
    public static final int f6507e5 = 3;

    /* renamed from: e6, reason: collision with root package name */
    public static final int f6508e6 = 39;

    /* renamed from: f0, reason: collision with root package name */
    public static final int f6510f0 = 0;

    /* renamed from: f2, reason: collision with root package name */
    public static final int f6512f2 = 0;

    /* renamed from: f3, reason: collision with root package name */
    public static final int f6513f3 = 4;

    /* renamed from: f5, reason: collision with root package name */
    public static final int f6515f5 = 4;

    /* renamed from: f6, reason: collision with root package name */
    public static final int f6516f6 = 40;

    /* renamed from: g0, reason: collision with root package name */
    public static final int f6518g0 = 1;

    /* renamed from: g2, reason: collision with root package name */
    public static final int f6520g2 = 1;

    /* renamed from: g3, reason: collision with root package name */
    public static final int f6521g3 = 6;

    /* renamed from: g4, reason: collision with root package name */
    public static final int f6522g4 = 0;

    /* renamed from: g5, reason: collision with root package name */
    public static final int f6523g5 = 5;

    /* renamed from: g6, reason: collision with root package name */
    public static final int f6524g6 = 41;

    /* renamed from: h0, reason: collision with root package name */
    public static final int f6526h0 = 2;

    /* renamed from: h2, reason: collision with root package name */
    public static final int f6528h2 = 2;

    /* renamed from: h3, reason: collision with root package name */
    public static final int f6529h3 = 7;

    /* renamed from: h5, reason: collision with root package name */
    public static final int f6531h5 = 6;

    /* renamed from: h6, reason: collision with root package name */
    public static final int f6532h6 = 42;

    /* renamed from: i0, reason: collision with root package name */
    public static final int f6534i0 = 3;

    /* renamed from: i2, reason: collision with root package name */
    public static final int f6536i2 = 3;

    /* renamed from: i3, reason: collision with root package name */
    public static final int f6537i3 = 8;

    /* renamed from: i5, reason: collision with root package name */
    public static final int f6539i5 = 7;

    /* renamed from: i6, reason: collision with root package name */
    public static final int f6540i6 = 43;

    /* renamed from: j0, reason: collision with root package name */
    public static final int f6542j0 = 4;

    /* renamed from: j2, reason: collision with root package name */
    public static final int f6544j2 = 4;

    /* renamed from: j3, reason: collision with root package name */
    public static final int f6545j3 = 9;

    /* renamed from: j4, reason: collision with root package name */
    public static final int f6546j4 = 0;

    /* renamed from: j5, reason: collision with root package name */
    public static final int f6547j5 = 8;

    /* renamed from: j6, reason: collision with root package name */
    public static final int f6548j6 = 44;

    /* renamed from: k0, reason: collision with root package name */
    public static final int f6550k0 = 5;

    /* renamed from: k2, reason: collision with root package name */
    public static final int f6552k2 = 5;

    /* renamed from: k3, reason: collision with root package name */
    public static final int f6553k3 = 10;

    /* renamed from: k5, reason: collision with root package name */
    public static final int f6555k5 = 9;

    /* renamed from: k6, reason: collision with root package name */
    public static final int f6556k6 = 45;

    /* renamed from: l0, reason: collision with root package name */
    public static final int f6558l0 = 6;

    /* renamed from: l2, reason: collision with root package name */
    public static final int f6560l2 = 6;

    /* renamed from: l5, reason: collision with root package name */
    public static final int f6563l5 = 10;

    /* renamed from: l6, reason: collision with root package name */
    public static final int f6564l6 = 46;

    /* renamed from: m0, reason: collision with root package name */
    public static final int f6566m0 = 7;

    /* renamed from: m2, reason: collision with root package name */
    public static final int f6568m2 = 7;

    /* renamed from: m5, reason: collision with root package name */
    public static final int f6571m5 = 12;

    /* renamed from: m6, reason: collision with root package name */
    public static final int f6572m6 = 47;

    /* renamed from: n, reason: collision with root package name */
    public static final int f6573n = 0;

    /* renamed from: n0, reason: collision with root package name */
    public static final int f6574n0 = 8;

    /* renamed from: n2, reason: collision with root package name */
    public static final int f6576n2 = 8;

    /* renamed from: n4, reason: collision with root package name */
    public static final int f6578n4 = 0;

    /* renamed from: n5, reason: collision with root package name */
    public static final int f6579n5 = 14;

    /* renamed from: n6, reason: collision with root package name */
    public static final int f6580n6 = 48;

    /* renamed from: o, reason: collision with root package name */
    public static final int f6581o = 1;

    /* renamed from: o0, reason: collision with root package name */
    public static final int f6582o0 = 9;

    /* renamed from: o2, reason: collision with root package name */
    public static final int f6584o2 = 9;

    /* renamed from: o3, reason: collision with root package name */
    public static final int f6585o3 = 0;

    /* renamed from: o4, reason: collision with root package name */
    public static final int f6586o4 = 1;

    /* renamed from: o6, reason: collision with root package name */
    public static final int f6588o6 = 49;

    /* renamed from: p, reason: collision with root package name */
    public static final int f6589p = 2;

    /* renamed from: p0, reason: collision with root package name */
    public static final int f6590p0 = 10;

    /* renamed from: p2, reason: collision with root package name */
    public static final int f6592p2 = 10;

    /* renamed from: p3, reason: collision with root package name */
    public static final int f6593p3 = 1;

    /* renamed from: p4, reason: collision with root package name */
    public static final int f6594p4 = 2;

    /* renamed from: p5, reason: collision with root package name */
    public static final int f6595p5 = 0;

    /* renamed from: p6, reason: collision with root package name */
    public static final int f6596p6 = 50;

    /* renamed from: q0, reason: collision with root package name */
    public static final int f6598q0 = 11;

    /* renamed from: q2, reason: collision with root package name */
    public static final int f6600q2 = 11;

    /* renamed from: q4, reason: collision with root package name */
    public static final int f6602q4 = 3;

    /* renamed from: q6, reason: collision with root package name */
    public static final int f6604q6 = 51;

    /* renamed from: r0, reason: collision with root package name */
    public static final int f6606r0 = 12;

    /* renamed from: r2, reason: collision with root package name */
    public static final int f6608r2 = 12;

    /* renamed from: r3, reason: collision with root package name */
    public static final int f6609r3 = 0;

    /* renamed from: r4, reason: collision with root package name */
    public static final int f6610r4 = 4;

    /* renamed from: r5, reason: collision with root package name */
    public static final int f6611r5 = 0;

    /* renamed from: r6, reason: collision with root package name */
    public static final int f6612r6 = 52;

    /* renamed from: s0, reason: collision with root package name */
    public static final int f6614s0 = 13;

    /* renamed from: s1, reason: collision with root package name */
    public static final int f6615s1 = 0;

    /* renamed from: s2, reason: collision with root package name */
    public static final int f6616s2 = 13;

    /* renamed from: s3, reason: collision with root package name */
    public static final int f6617s3 = 1;

    /* renamed from: s4, reason: collision with root package name */
    public static final int f6618s4 = 5;

    /* renamed from: s5, reason: collision with root package name */
    public static final int f6619s5 = 1;

    /* renamed from: s6, reason: collision with root package name */
    public static final int f6620s6 = 53;

    /* renamed from: t0, reason: collision with root package name */
    public static final int f6622t0 = 14;

    /* renamed from: t1, reason: collision with root package name */
    public static final int f6623t1 = 1;

    /* renamed from: t2, reason: collision with root package name */
    public static final int f6624t2 = 14;

    /* renamed from: t4, reason: collision with root package name */
    public static final int f6626t4 = 6;

    /* renamed from: t5, reason: collision with root package name */
    public static final int f6627t5 = 2;

    /* renamed from: t6, reason: collision with root package name */
    public static final int f6628t6 = 54;

    /* renamed from: u0, reason: collision with root package name */
    public static final int f6630u0 = 15;

    /* renamed from: u2, reason: collision with root package name */
    public static final int f6632u2 = 15;

    /* renamed from: u4, reason: collision with root package name */
    public static final int f6634u4 = 7;

    /* renamed from: u5, reason: collision with root package name */
    public static final int f6635u5 = 3;

    /* renamed from: u6, reason: collision with root package name */
    public static final int f6636u6 = 55;

    /* renamed from: v0, reason: collision with root package name */
    public static final int f6638v0 = 16;

    /* renamed from: v2, reason: collision with root package name */
    public static final int f6640v2 = 16;

    /* renamed from: v3, reason: collision with root package name */
    public static final int f6641v3 = 0;

    /* renamed from: v4, reason: collision with root package name */
    public static final int f6642v4 = 8;

    /* renamed from: v5, reason: collision with root package name */
    public static final int f6643v5 = 4;

    /* renamed from: v6, reason: collision with root package name */
    public static final int f6644v6 = 56;

    /* renamed from: w0, reason: collision with root package name */
    public static final int f6646w0 = 17;

    /* renamed from: w1, reason: collision with root package name */
    public static final int f6647w1 = 0;

    /* renamed from: w2, reason: collision with root package name */
    public static final int f6648w2 = 19;

    /* renamed from: w3, reason: collision with root package name */
    public static final int f6649w3 = 1;

    /* renamed from: w4, reason: collision with root package name */
    public static final int f6650w4 = 9;

    /* renamed from: w5, reason: collision with root package name */
    public static final int f6651w5 = 5;

    /* renamed from: w6, reason: collision with root package name */
    public static final int f6652w6 = 57;

    /* renamed from: x0, reason: collision with root package name */
    public static final int f6654x0 = 18;

    /* renamed from: x2, reason: collision with root package name */
    public static final int f6656x2 = 20;

    /* renamed from: x3, reason: collision with root package name */
    public static final int f6657x3 = 2;

    /* renamed from: x5, reason: collision with root package name */
    public static final int f6659x5 = 6;

    /* renamed from: x6, reason: collision with root package name */
    public static final int f6660x6 = 58;

    /* renamed from: y0, reason: collision with root package name */
    public static final int f6662y0 = 19;

    /* renamed from: y2, reason: collision with root package name */
    public static final int f6664y2 = 21;

    /* renamed from: y5, reason: collision with root package name */
    public static final int f6667y5 = 7;

    /* renamed from: y6, reason: collision with root package name */
    public static final int f6668y6 = 59;

    /* renamed from: z0, reason: collision with root package name */
    public static final int f6670z0 = 20;

    /* renamed from: z3, reason: collision with root package name */
    public static final int f6673z3 = 0;

    /* renamed from: z4, reason: collision with root package name */
    public static final int f6674z4 = 2;

    /* renamed from: z5, reason: collision with root package name */
    public static final int f6675z5 = 8;

    /* renamed from: z6, reason: collision with root package name */
    public static final int f6676z6 = 60;

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f6469a = {R.attr.background, R.attr.backgroundSplit, R.attr.backgroundStacked, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.customNavigationLayout, R.attr.displayOptions, R.attr.divider, R.attr.elevation, R.attr.height, R.attr.hideOnContentScroll, R.attr.homeAsUpIndicator, R.attr.homeLayout, R.attr.icon, R.attr.indeterminateProgressStyle, R.attr.itemPadding, R.attr.logo, R.attr.navigationMode, R.attr.popupTheme, R.attr.progressBarPadding, R.attr.progressBarStyle, R.attr.subtitle, R.attr.subtitleTextStyle, R.attr.title, R.attr.titleTextStyle};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f6477b = {android.R.attr.layout_gravity};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f6485c = {android.R.attr.minWidth};

    /* renamed from: d, reason: collision with root package name */
    public static final int[] f6493d = new int[0];

    /* renamed from: e, reason: collision with root package name */
    public static final int[] f6501e = {R.attr.background, R.attr.backgroundSplit, R.attr.closeItemLayout, R.attr.height, R.attr.subtitleTextStyle, R.attr.titleTextStyle};

    /* renamed from: f, reason: collision with root package name */
    public static final int[] f6509f = {R.attr.expandActivityOverflowButtonDrawable, R.attr.initialActivityCount};

    /* renamed from: g, reason: collision with root package name */
    public static final int[] f6517g = {android.R.attr.layout, R.attr.buttonIconDimen, R.attr.buttonPanelSideLayout, R.attr.listItemLayout, R.attr.listLayout, R.attr.multiChoiceItemLayout, R.attr.showTitle, R.attr.singleChoiceItemLayout};

    /* renamed from: h, reason: collision with root package name */
    public static final int[] f6525h = {android.R.attr.dither, android.R.attr.visible, android.R.attr.variablePadding, android.R.attr.constantSize, android.R.attr.enterFadeDuration, android.R.attr.exitFadeDuration};

    /* renamed from: i, reason: collision with root package name */
    public static final int[] f6533i = {android.R.attr.id, android.R.attr.drawable};

    /* renamed from: j, reason: collision with root package name */
    public static final int[] f6541j = {android.R.attr.drawable, android.R.attr.toId, android.R.attr.fromId, android.R.attr.reversible};

    /* renamed from: k, reason: collision with root package name */
    public static final int[] f6549k = {android.R.attr.background, android.R.attr.touchscreenBlocksFocus, android.R.attr.keyboardNavigationCluster, R.attr.elevation, R.attr.expanded, R.attr.liftOnScroll, R.attr.liftOnScrollColor, R.attr.liftOnScrollTargetViewId, R.attr.statusBarForeground};

    /* renamed from: l, reason: collision with root package name */
    public static final int[] f6557l = {R.attr.state_collapsed, R.attr.state_collapsible, R.attr.state_liftable, R.attr.state_lifted};

    /* renamed from: m, reason: collision with root package name */
    public static final int[] f6565m = {R.attr.layout_scrollEffect, R.attr.layout_scrollFlags, R.attr.layout_scrollInterpolator};

    /* renamed from: q, reason: collision with root package name */
    public static final int[] f6597q = new int[0];

    /* renamed from: r, reason: collision with root package name */
    public static final int[] f6605r = {android.R.attr.src, R.attr.srcCompat, R.attr.tint, R.attr.tintMode};

    /* renamed from: s, reason: collision with root package name */
    public static final int[] f6613s = {android.R.attr.thumb, R.attr.tickMark, R.attr.tickMarkTint, R.attr.tickMarkTintMode};

    /* renamed from: t, reason: collision with root package name */
    public static final int[] f6621t = {android.R.attr.textAppearance, android.R.attr.drawableTop, android.R.attr.drawableBottom, android.R.attr.drawableLeft, android.R.attr.drawableRight, android.R.attr.drawableStart, android.R.attr.drawableEnd};

    /* renamed from: u, reason: collision with root package name */
    public static final int[] f6629u = {android.R.attr.textAppearance, R.attr.autoSizeMaxTextSize, R.attr.autoSizeMinTextSize, R.attr.autoSizePresetSizes, R.attr.autoSizeStepGranularity, R.attr.autoSizeTextType, R.attr.drawableBottomCompat, R.attr.drawableEndCompat, R.attr.drawableLeftCompat, R.attr.drawableRightCompat, R.attr.drawableStartCompat, R.attr.drawableTint, R.attr.drawableTintMode, R.attr.drawableTopCompat, R.attr.emojiCompatEnabled, R.attr.firstBaselineToTopHeight, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.lastBaselineToBottomHeight, R.attr.lineHeight, R.attr.textAllCaps, R.attr.textLocale};

    /* renamed from: v, reason: collision with root package name */
    public static final int[] f6637v = {android.R.attr.windowIsFloating, android.R.attr.windowAnimationStyle, R.attr.actionBarDivider, R.attr.actionBarItemBackground, R.attr.actionBarPopupTheme, R.attr.actionBarSize, R.attr.actionBarSplitStyle, R.attr.actionBarStyle, R.attr.actionBarTabBarStyle, R.attr.actionBarTabStyle, R.attr.actionBarTabTextStyle, R.attr.actionBarTheme, R.attr.actionBarWidgetTheme, R.attr.actionButtonStyle, R.attr.actionDropDownStyle, R.attr.actionMenuTextAppearance, R.attr.actionMenuTextColor, R.attr.actionModeBackground, R.attr.actionModeCloseButtonStyle, R.attr.actionModeCloseContentDescription, R.attr.actionModeCloseDrawable, R.attr.actionModeCopyDrawable, R.attr.actionModeCutDrawable, R.attr.actionModeFindDrawable, R.attr.actionModePasteDrawable, R.attr.actionModePopupWindowStyle, R.attr.actionModeSelectAllDrawable, R.attr.actionModeShareDrawable, R.attr.actionModeSplitBackground, R.attr.actionModeStyle, R.attr.actionModeTheme, R.attr.actionModeWebSearchDrawable, R.attr.actionOverflowButtonStyle, R.attr.actionOverflowMenuStyle, R.attr.activityChooserViewStyle, R.attr.alertDialogButtonGroupStyle, R.attr.alertDialogCenterButtons, R.attr.alertDialogStyle, R.attr.alertDialogTheme, R.attr.autoCompleteTextViewStyle, R.attr.borderlessButtonStyle, R.attr.buttonBarButtonStyle, R.attr.buttonBarNegativeButtonStyle, R.attr.buttonBarNeutralButtonStyle, R.attr.buttonBarPositiveButtonStyle, R.attr.buttonBarStyle, R.attr.buttonStyle, R.attr.buttonStyleSmall, R.attr.checkboxStyle, R.attr.checkedTextViewStyle, R.attr.colorAccent, R.attr.colorBackgroundFloating, R.attr.colorButtonNormal, R.attr.colorControlActivated, R.attr.colorControlHighlight, R.attr.colorControlNormal, R.attr.colorError, R.attr.colorPrimary, R.attr.colorPrimaryDark, R.attr.colorSwitchThumbNormal, R.attr.controlBackground, R.attr.dialogCornerRadius, R.attr.dialogPreferredPadding, R.attr.dialogTheme, R.attr.dividerHorizontal, R.attr.dividerVertical, R.attr.dropDownListViewStyle, R.attr.dropdownListPreferredItemHeight, R.attr.editTextBackground, R.attr.editTextColor, R.attr.editTextStyle, R.attr.homeAsUpIndicator, R.attr.imageButtonStyle, R.attr.listChoiceBackgroundIndicator, R.attr.listChoiceIndicatorMultipleAnimated, R.attr.listChoiceIndicatorSingleAnimated, R.attr.listDividerAlertDialog, R.attr.listMenuViewStyle, R.attr.listPopupWindowStyle, R.attr.listPreferredItemHeight, R.attr.listPreferredItemHeightLarge, R.attr.listPreferredItemHeightSmall, R.attr.listPreferredItemPaddingEnd, R.attr.listPreferredItemPaddingLeft, R.attr.listPreferredItemPaddingRight, R.attr.listPreferredItemPaddingStart, R.attr.panelBackground, R.attr.panelMenuListTheme, R.attr.panelMenuListWidth, R.attr.popupMenuStyle, R.attr.popupWindowStyle, R.attr.radioButtonStyle, R.attr.ratingBarStyle, R.attr.ratingBarStyleIndicator, R.attr.ratingBarStyleSmall, R.attr.searchViewStyle, R.attr.seekBarStyle, R.attr.selectableItemBackground, R.attr.selectableItemBackgroundBorderless, R.attr.spinnerDropDownItemStyle, R.attr.spinnerStyle, R.attr.switchStyle, R.attr.textAppearanceLargePopupMenu, R.attr.textAppearanceListItem, R.attr.textAppearanceListItemSecondary, R.attr.textAppearanceListItemSmall, R.attr.textAppearancePopupMenuHeader, R.attr.textAppearanceSearchResultSubtitle, R.attr.textAppearanceSearchResultTitle, R.attr.textAppearanceSmallPopupMenu, R.attr.textColorAlertDialogListItem, R.attr.textColorSearchUrl, R.attr.toolbarNavigationButtonStyle, R.attr.toolbarStyle, R.attr.tooltipForegroundColor, R.attr.tooltipFrameBackground, R.attr.viewInflaterClass, R.attr.windowActionBar, R.attr.windowActionBarOverlay, R.attr.windowActionModeOverlay, R.attr.windowFixedHeightMajor, R.attr.windowFixedHeightMinor, R.attr.windowFixedWidthMajor, R.attr.windowFixedWidthMinor, R.attr.windowMinWidthMajor, R.attr.windowMinWidthMinor, R.attr.windowNoTitle};

    /* renamed from: w, reason: collision with root package name */
    public static final int[] f6645w = {R.attr.autoAdjustToWithinGrandparentBounds, R.attr.backgroundColor, R.attr.badgeGravity, R.attr.badgeHeight, R.attr.badgeRadius, R.attr.badgeShapeAppearance, R.attr.badgeShapeAppearanceOverlay, R.attr.badgeText, R.attr.badgeTextAppearance, R.attr.badgeTextColor, R.attr.badgeVerticalPadding, R.attr.badgeWidePadding, R.attr.badgeWidth, R.attr.badgeWithTextHeight, R.attr.badgeWithTextRadius, R.attr.badgeWithTextShapeAppearance, R.attr.badgeWithTextShapeAppearanceOverlay, R.attr.badgeWithTextWidth, R.attr.horizontalOffset, R.attr.horizontalOffsetWithText, R.attr.largeFontVerticalOffsetAdjustment, R.attr.maxCharacterCount, R.attr.maxNumber, R.attr.number, R.attr.offsetAlignmentMode, R.attr.verticalOffset, R.attr.verticalOffsetWithText};

    /* renamed from: x, reason: collision with root package name */
    public static final int[] f6653x = {android.R.attr.indeterminate, R.attr.hideAnimationBehavior, R.attr.indicatorColor, R.attr.minHideDelay, R.attr.showAnimationBehavior, R.attr.showDelay, R.attr.trackColor, R.attr.trackCornerRadius, R.attr.trackThickness};

    /* renamed from: y, reason: collision with root package name */
    public static final int[] f6661y = {R.attr.addElevationShadow, R.attr.backgroundTint, R.attr.elevation, R.attr.fabAlignmentMode, R.attr.fabAlignmentModeEndMargin, R.attr.fabAnchorMode, R.attr.fabAnimationMode, R.attr.fabCradleMargin, R.attr.fabCradleRoundedCornerRadius, R.attr.fabCradleVerticalOffset, R.attr.hideOnScroll, R.attr.menuAlignmentMode, R.attr.navigationIconTint, R.attr.paddingBottomSystemWindowInsets, R.attr.paddingLeftSystemWindowInsets, R.attr.paddingRightSystemWindowInsets, R.attr.removeEmbeddedFabElevation};

    /* renamed from: z, reason: collision with root package name */
    public static final int[] f6669z = {android.R.attr.minHeight, R.attr.compatShadowEnabled, R.attr.itemHorizontalTranslationEnabled, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay};
    public static final int[] A = {android.R.attr.maxWidth, android.R.attr.maxHeight, android.R.attr.elevation, R.attr.backgroundTint, R.attr.behavior_draggable, R.attr.behavior_expandedOffset, R.attr.behavior_fitToContents, R.attr.behavior_halfExpandedRatio, R.attr.behavior_hideable, R.attr.behavior_peekHeight, R.attr.behavior_saveFlags, R.attr.behavior_significantVelocityThreshold, R.attr.behavior_skipCollapsed, R.attr.gestureInsetBottomIgnored, R.attr.marginLeftSystemWindowInsets, R.attr.marginRightSystemWindowInsets, R.attr.marginTopSystemWindowInsets, R.attr.paddingBottomSystemWindowInsets, R.attr.paddingLeftSystemWindowInsets, R.attr.paddingRightSystemWindowInsets, R.attr.paddingTopSystemWindowInsets, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.shouldRemoveExpandedCorners};
    public static final int[] Y = {R.attr.allowStacking};
    public static final int[] Z = {R.attr.queryPatterns, R.attr.shortcutMatchRequired};

    /* renamed from: a0, reason: collision with root package name */
    public static final int[] f6470a0 = {android.R.attr.minWidth, android.R.attr.minHeight, R.attr.cardBackgroundColor, R.attr.cardCornerRadius, R.attr.cardElevation, R.attr.cardMaxElevation, R.attr.cardPreventCornerOverlap, R.attr.cardUseCompatPadding, R.attr.contentPadding, R.attr.contentPaddingBottom, R.attr.contentPaddingLeft, R.attr.contentPaddingRight, R.attr.contentPaddingTop};

    /* renamed from: b0, reason: collision with root package name */
    public static final int[] f6478b0 = {R.attr.carousel_alignment, R.attr.carousel_backwardTransition, R.attr.carousel_emptyViewsBehavior, R.attr.carousel_firstView, R.attr.carousel_forwardTransition, R.attr.carousel_infinite, R.attr.carousel_nextState, R.attr.carousel_previousState, R.attr.carousel_touchUpMode, R.attr.carousel_touchUp_dampeningFactor, R.attr.carousel_touchUp_velocityThreshold};

    /* renamed from: d0, reason: collision with root package name */
    public static final int[] f6494d0 = {android.R.attr.checkMark, R.attr.checkMarkCompat, R.attr.checkMarkTint, R.attr.checkMarkTintMode};

    /* renamed from: e0, reason: collision with root package name */
    public static final int[] f6502e0 = {android.R.attr.textAppearance, android.R.attr.textSize, android.R.attr.textColor, android.R.attr.ellipsize, android.R.attr.maxWidth, android.R.attr.text, android.R.attr.checkable, R.attr.checkedIcon, R.attr.checkedIconEnabled, R.attr.checkedIconTint, R.attr.checkedIconVisible, R.attr.chipBackgroundColor, R.attr.chipCornerRadius, R.attr.chipEndPadding, R.attr.chipIcon, R.attr.chipIconEnabled, R.attr.chipIconSize, R.attr.chipIconTint, R.attr.chipIconVisible, R.attr.chipMinHeight, R.attr.chipMinTouchTargetSize, R.attr.chipStartPadding, R.attr.chipStrokeColor, R.attr.chipStrokeWidth, R.attr.chipSurfaceColor, R.attr.closeIcon, R.attr.closeIconEnabled, R.attr.closeIconEndPadding, R.attr.closeIconSize, R.attr.closeIconStartPadding, R.attr.closeIconTint, R.attr.closeIconVisible, R.attr.ensureMinTouchTargetSize, R.attr.hideMotionSpec, R.attr.iconEndPadding, R.attr.iconStartPadding, R.attr.rippleColor, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.showMotionSpec, R.attr.textEndPadding, R.attr.textStartPadding};
    public static final int[] U0 = {R.attr.checkedChip, R.attr.chipSpacing, R.attr.chipSpacingHorizontal, R.attr.chipSpacingVertical, R.attr.selectionRequired, R.attr.singleLine, R.attr.singleSelection};
    public static final int[] V0 = {R.attr.indicatorDirectionCircular, R.attr.indicatorInset, R.attr.indicatorSize};
    public static final int[] W0 = {R.attr.clockFaceBackgroundColor, R.attr.clockNumberTextColor};
    public static final int[] Z0 = {R.attr.clockHandColor, R.attr.materialCircleRadius, R.attr.selectorSize};

    /* renamed from: d1, reason: collision with root package name */
    public static final int[] f6495d1 = {R.attr.collapsedTitleGravity, R.attr.collapsedTitleTextAppearance, R.attr.collapsedTitleTextColor, R.attr.contentScrim, R.attr.expandedTitleGravity, R.attr.expandedTitleMargin, R.attr.expandedTitleMarginBottom, R.attr.expandedTitleMarginEnd, R.attr.expandedTitleMarginStart, R.attr.expandedTitleMarginTop, R.attr.expandedTitleTextAppearance, R.attr.expandedTitleTextColor, R.attr.extraMultilineHeightEnabled, R.attr.forceApplySystemWindowInsetTop, R.attr.maxLines, R.attr.scrimAnimationDuration, R.attr.scrimVisibleHeightTrigger, R.attr.statusBarScrim, R.attr.title, R.attr.titleCollapseMode, R.attr.titleEnabled, R.attr.titlePositionInterpolator, R.attr.titleTextEllipsize, R.attr.toolbarId};

    /* renamed from: e1, reason: collision with root package name */
    public static final int[] f6503e1 = {R.attr.layout_collapseMode, R.attr.layout_collapseParallaxMultiplier};

    /* renamed from: f1, reason: collision with root package name */
    public static final int[] f6511f1 = {android.R.attr.color, android.R.attr.alpha, android.R.attr.lStar, R.attr.alpha, R.attr.lStar};

    /* renamed from: g1, reason: collision with root package name */
    public static final int[] f6519g1 = {android.R.attr.button, R.attr.buttonCompat, R.attr.buttonTint, R.attr.buttonTintMode};

    /* renamed from: h1, reason: collision with root package name */
    public static final int[] f6527h1 = {android.R.attr.orientation, android.R.attr.id, android.R.attr.visibility, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_marginLeft, android.R.attr.layout_marginTop, android.R.attr.layout_marginRight, android.R.attr.layout_marginBottom, android.R.attr.maxWidth, android.R.attr.maxHeight, android.R.attr.minWidth, android.R.attr.minHeight, android.R.attr.alpha, android.R.attr.transformPivotX, android.R.attr.transformPivotY, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.layout_marginStart, android.R.attr.layout_marginEnd, android.R.attr.translationZ, android.R.attr.elevation, R.attr.animateCircleAngleTo, R.attr.animateRelativeTo, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraint_referenced_ids, R.attr.constraint_referenced_tags, R.attr.drawPath, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.guidelineUseRtl, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBaseline_toBottomOf, R.attr.layout_constraintBaseline_toTopOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBaseline, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.layout_marginBaseline, R.attr.layout_wrapBehaviorInParent, R.attr.motionProgress, R.attr.motionStagger, R.attr.pathMotionArc, R.attr.pivotAnchor, R.attr.polarRelativeTo, R.attr.quantizeMotionInterpolator, R.attr.quantizeMotionPhase, R.attr.quantizeMotionSteps, R.attr.transformPivotTarget, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.visibilityMode};

    /* renamed from: i1, reason: collision with root package name */
    public static final int[] f6535i1 = {android.R.attr.orientation, android.R.attr.padding, android.R.attr.paddingLeft, android.R.attr.paddingTop, android.R.attr.paddingRight, android.R.attr.paddingBottom, android.R.attr.visibility, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_margin, android.R.attr.layout_marginLeft, android.R.attr.layout_marginTop, android.R.attr.layout_marginRight, android.R.attr.layout_marginBottom, android.R.attr.maxWidth, android.R.attr.maxHeight, android.R.attr.minWidth, android.R.attr.minHeight, android.R.attr.paddingStart, android.R.attr.paddingEnd, android.R.attr.layout_marginStart, android.R.attr.layout_marginEnd, android.R.attr.elevation, android.R.attr.layout_marginHorizontal, android.R.attr.layout_marginVertical, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.circularflow_angles, R.attr.circularflow_defaultAngle, R.attr.circularflow_defaultRadius, R.attr.circularflow_radiusInDP, R.attr.circularflow_viewCenter, R.attr.constraintSet, R.attr.constraint_referenced_ids, R.attr.constraint_referenced_tags, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.guidelineUseRtl, R.attr.layoutDescription, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBaseline_toBottomOf, R.attr.layout_constraintBaseline_toTopOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBaseline, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.layout_marginBaseline, R.attr.layout_optimizationLevel, R.attr.layout_wrapBehaviorInParent};

    /* renamed from: j1, reason: collision with root package name */
    public static final int[] f6543j1 = {R.attr.content, R.attr.placeholder_emptyVisibility};

    /* renamed from: k1, reason: collision with root package name */
    public static final int[] f6551k1 = {android.R.attr.orientation, android.R.attr.id, android.R.attr.visibility, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_marginLeft, android.R.attr.layout_marginTop, android.R.attr.layout_marginRight, android.R.attr.layout_marginBottom, android.R.attr.maxWidth, android.R.attr.maxHeight, android.R.attr.minWidth, android.R.attr.minHeight, android.R.attr.pivotX, android.R.attr.pivotY, android.R.attr.alpha, android.R.attr.transformPivotX, android.R.attr.transformPivotY, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.layout_marginStart, android.R.attr.layout_marginEnd, android.R.attr.translationZ, android.R.attr.elevation, R.attr.animateCircleAngleTo, R.attr.animateRelativeTo, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraintRotate, R.attr.constraint_referenced_ids, R.attr.constraint_referenced_tags, R.attr.deriveConstraintsFrom, R.attr.drawPath, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.guidelineUseRtl, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBaseline_toBottomOf, R.attr.layout_constraintBaseline_toTopOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBaseline, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.layout_marginBaseline, R.attr.layout_wrapBehaviorInParent, R.attr.motionProgress, R.attr.motionStagger, R.attr.pathMotionArc, R.attr.pivotAnchor, R.attr.polarRelativeTo, R.attr.quantizeMotionSteps, R.attr.transitionEasing, R.attr.transitionPathRotate};

    /* renamed from: l1, reason: collision with root package name */
    public static final int[] f6559l1 = {R.attr.keylines, R.attr.statusBarBackground};

    /* renamed from: m1, reason: collision with root package name */
    public static final int[] f6567m1 = {android.R.attr.layout_gravity, R.attr.layout_anchor, R.attr.layout_anchorGravity, R.attr.layout_behavior, R.attr.layout_dodgeInsetEdges, R.attr.layout_insetEdge, R.attr.layout_keyline};

    /* renamed from: n1, reason: collision with root package name */
    public static final int[] f6575n1 = {R.attr.attributeName, R.attr.customBoolean, R.attr.customColorDrawableValue, R.attr.customColorValue, R.attr.customDimension, R.attr.customFloatValue, R.attr.customIntegerValue, R.attr.customPixelDimension, R.attr.customReference, R.attr.customStringValue, R.attr.methodName};

    /* renamed from: o1, reason: collision with root package name */
    public static final int[] f6583o1 = {R.attr.arrowHeadLength, R.attr.arrowShaftLength, R.attr.barLength, R.attr.color, R.attr.drawableSize, R.attr.gapBetweenBars, R.attr.spinBars, R.attr.thickness};

    /* renamed from: p1, reason: collision with root package name */
    public static final int[] f6591p1 = {R.attr.elevation};

    /* renamed from: q1, reason: collision with root package name */
    public static final int[] f6599q1 = {R.attr.collapsedSize, R.attr.elevation, R.attr.extendMotionSpec, R.attr.extendStrategy, R.attr.hideMotionSpec, R.attr.showMotionSpec, R.attr.shrinkMotionSpec};

    /* renamed from: r1, reason: collision with root package name */
    public static final int[] f6607r1 = {R.attr.behavior_autoHide, R.attr.behavior_autoShrink};

    /* renamed from: u1, reason: collision with root package name */
    public static final int[] f6631u1 = {android.R.attr.enabled, R.attr.backgroundTint, R.attr.backgroundTintMode, R.attr.borderWidth, R.attr.elevation, R.attr.ensureMinTouchTargetSize, R.attr.fabCustomSize, R.attr.fabSize, R.attr.hideMotionSpec, R.attr.hoveredFocusedTranslationZ, R.attr.maxImageSize, R.attr.pressedTranslationZ, R.attr.rippleColor, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.showMotionSpec, R.attr.useCompatPadding};

    /* renamed from: v1, reason: collision with root package name */
    public static final int[] f6639v1 = {R.attr.behavior_autoHide};

    /* renamed from: x1, reason: collision with root package name */
    public static final int[] f6655x1 = {R.attr.itemSpacing, R.attr.lineSpacing};

    /* renamed from: y1, reason: collision with root package name */
    public static final int[] f6663y1 = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery, R.attr.fontProviderSystemFontFamily};

    /* renamed from: z1, reason: collision with root package name */
    public static final int[] f6671z1 = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
    public static final int[] A1 = {android.R.attr.foreground, android.R.attr.foregroundGravity, R.attr.foregroundInsidePadding};
    public static final int[] E1 = {android.R.attr.name, android.R.attr.id, android.R.attr.tag};
    public static final int[] F1 = {android.R.attr.name, android.R.attr.tag};
    public static final int[] G1 = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
    public static final int[] H1 = {android.R.attr.color, android.R.attr.offset};
    public static final int[] I1 = {R.attr.altSrc, R.attr.blendSrc, R.attr.brightness, R.attr.contrast, R.attr.crossfade, R.attr.imagePanX, R.attr.imagePanY, R.attr.imageRotate, R.attr.imageZoom, R.attr.overlay, R.attr.round, R.attr.roundPercent, R.attr.saturation, R.attr.warmth};
    public static final int[] J1 = {R.attr.marginLeftSystemWindowInsets, R.attr.marginRightSystemWindowInsets, R.attr.marginTopSystemWindowInsets, R.attr.paddingBottomSystemWindowInsets, R.attr.paddingLeftSystemWindowInsets, R.attr.paddingRightSystemWindowInsets, R.attr.paddingStartSystemWindowInsets, R.attr.paddingTopSystemWindowInsets};
    public static final int[] K1 = {android.R.attr.alpha, android.R.attr.transformPivotX, android.R.attr.transformPivotY, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.translationZ, android.R.attr.elevation, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transformPivotTarget, R.attr.transitionEasing, R.attr.transitionPathRotate};
    public static final int[] L1 = {android.R.attr.alpha, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.translationZ, android.R.attr.elevation, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.waveOffset, R.attr.wavePeriod, R.attr.wavePhase, R.attr.waveShape, R.attr.waveVariesBy};
    public static final int[] M1 = {R.attr.curveFit, R.attr.drawPath, R.attr.framePosition, R.attr.keyPositionType, R.attr.motionTarget, R.attr.pathMotionArc, R.attr.percentHeight, R.attr.percentWidth, R.attr.percentX, R.attr.percentY, R.attr.sizePercent, R.attr.transitionEasing};
    public static final int[] N1 = {android.R.attr.alpha, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.translationZ, android.R.attr.elevation, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.waveDecay, R.attr.waveOffset, R.attr.wavePeriod, R.attr.wavePhase, R.attr.waveShape};
    public static final int[] O1 = {R.attr.framePosition, R.attr.motionTarget, R.attr.motion_postLayoutCollision, R.attr.motion_triggerOnCollision, R.attr.onCross, R.attr.onNegativeCross, R.attr.onPositiveCross, R.attr.triggerId, R.attr.triggerReceiver, R.attr.triggerSlack, R.attr.viewTransitionOnCross, R.attr.viewTransitionOnNegativeCross, R.attr.viewTransitionOnPositiveCross};
    public static final int[] P1 = {android.R.attr.orientation, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_marginLeft, android.R.attr.layout_marginTop, android.R.attr.layout_marginRight, android.R.attr.layout_marginBottom, android.R.attr.layout_marginStart, android.R.attr.layout_marginEnd, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraint_referenced_ids, R.attr.constraint_referenced_tags, R.attr.guidelineUseRtl, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBaseline_toBottomOf, R.attr.layout_constraintBaseline_toTopOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBaseline, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.layout_marginBaseline, R.attr.layout_wrapBehaviorInParent, R.attr.maxHeight, R.attr.maxWidth, R.attr.minHeight, R.attr.minWidth};
    public static final int[] Q1 = {android.R.attr.gravity, android.R.attr.orientation, android.R.attr.baselineAligned, android.R.attr.baselineAlignedChildIndex, android.R.attr.weightSum, R.attr.divider, R.attr.dividerPadding, R.attr.measureWithLargestChild, R.attr.showDividers};
    public static final int[] R1 = {android.R.attr.layout_gravity, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_weight};
    public static final int[] S1 = {R.attr.indeterminateAnimationType, R.attr.indicatorDirectionLinear};
    public static final int[] T1 = {android.R.attr.dropDownHorizontalOffset, android.R.attr.dropDownVerticalOffset};
    public static final int[] U1 = {R.attr.backgroundInsetBottom, R.attr.backgroundInsetEnd, R.attr.backgroundInsetStart, R.attr.backgroundInsetTop, R.attr.backgroundTint};
    public static final int[] V1 = {R.attr.materialAlertDialogBodyTextStyle, R.attr.materialAlertDialogButtonSpacerVisibility, R.attr.materialAlertDialogTheme, R.attr.materialAlertDialogTitleIconStyle, R.attr.materialAlertDialogTitlePanelStyle, R.attr.materialAlertDialogTitleTextStyle};
    public static final int[] W1 = {android.R.attr.inputType, android.R.attr.popupElevation, R.attr.dropDownBackgroundTint, R.attr.simpleItemLayout, R.attr.simpleItemSelectedColor, R.attr.simpleItemSelectedRippleColor, R.attr.simpleItems};

    /* renamed from: e2, reason: collision with root package name */
    public static final int[] f6504e2 = {android.R.attr.background, android.R.attr.insetLeft, android.R.attr.insetRight, android.R.attr.insetTop, android.R.attr.insetBottom, android.R.attr.checkable, R.attr.backgroundTint, R.attr.backgroundTintMode, R.attr.cornerRadius, R.attr.elevation, R.attr.icon, R.attr.iconGravity, R.attr.iconPadding, R.attr.iconSize, R.attr.iconTint, R.attr.iconTintMode, R.attr.rippleColor, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.strokeColor, R.attr.strokeWidth, R.attr.toggleCheckedStateOnClick};

    /* renamed from: z2, reason: collision with root package name */
    public static final int[] f6672z2 = {android.R.attr.enabled, R.attr.checkedButton, R.attr.selectionRequired, R.attr.singleSelection};
    public static final int[] E2 = {android.R.attr.windowFullscreen, R.attr.backgroundTint, R.attr.dayInvalidStyle, R.attr.daySelectedStyle, R.attr.dayStyle, R.attr.dayTodayStyle, R.attr.nestedScrollable, R.attr.rangeFillColor, R.attr.yearSelectedStyle, R.attr.yearStyle, R.attr.yearTodayStyle};
    public static final int[] O2 = {android.R.attr.insetLeft, android.R.attr.insetRight, android.R.attr.insetTop, android.R.attr.insetBottom, R.attr.itemFillColor, R.attr.itemShapeAppearance, R.attr.itemShapeAppearanceOverlay, R.attr.itemStrokeColor, R.attr.itemStrokeWidth, R.attr.itemTextColor};
    public static final int[] Z2 = {android.R.attr.checkable, R.attr.cardForegroundColor, R.attr.checkedIcon, R.attr.checkedIconGravity, R.attr.checkedIconMargin, R.attr.checkedIconSize, R.attr.checkedIconTint, R.attr.rippleColor, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.state_dragged, R.attr.strokeColor, R.attr.strokeWidth};

    /* renamed from: a3, reason: collision with root package name */
    public static final int[] f6473a3 = {android.R.attr.button, R.attr.buttonCompat, R.attr.buttonIcon, R.attr.buttonIconTint, R.attr.buttonIconTintMode, R.attr.buttonTint, R.attr.centerIfNoTextEnabled, R.attr.checkedState, R.attr.errorAccessibilityLabel, R.attr.errorShown, R.attr.useMaterialThemeColors};

    /* renamed from: l3, reason: collision with root package name */
    public static final int[] f6561l3 = {R.attr.state_error, R.attr.state_indeterminate};

    /* renamed from: m3, reason: collision with root package name */
    public static final int[] f6569m3 = {R.attr.dividerColor, R.attr.dividerInsetEnd, R.attr.dividerInsetStart, R.attr.dividerThickness, R.attr.lastItemDecorated};

    /* renamed from: n3, reason: collision with root package name */
    public static final int[] f6577n3 = {R.attr.buttonTint, R.attr.useMaterialThemeColors};

    /* renamed from: q3, reason: collision with root package name */
    public static final int[] f6601q3 = {R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay};

    /* renamed from: t3, reason: collision with root package name */
    public static final int[] f6625t3 = {R.attr.thumbIcon, R.attr.thumbIconSize, R.attr.thumbIconTint, R.attr.thumbIconTintMode, R.attr.trackDecoration, R.attr.trackDecorationTint, R.attr.trackDecorationTintMode};

    /* renamed from: u3, reason: collision with root package name */
    public static final int[] f6633u3 = {android.R.attr.letterSpacing, android.R.attr.lineHeight, R.attr.lineHeight};

    /* renamed from: y3, reason: collision with root package name */
    public static final int[] f6665y3 = {android.R.attr.textAppearance, android.R.attr.lineHeight, R.attr.lineHeight};
    public static final int[] C3 = {R.attr.backgroundTint, R.attr.clockIcon, R.attr.keyboardIcon};
    public static final int[] D3 = {R.attr.logoAdjustViewBounds, R.attr.logoScaleType, R.attr.navigationIconTint, R.attr.subtitleCentered, R.attr.titleCentered};
    public static final int[] J3 = {android.R.attr.enabled, android.R.attr.id, android.R.attr.visible, android.R.attr.menuCategory, android.R.attr.orderInCategory, android.R.attr.checkableBehavior};
    public static final int[] K3 = {android.R.attr.icon, android.R.attr.enabled, android.R.attr.id, android.R.attr.checked, android.R.attr.visible, android.R.attr.menuCategory, android.R.attr.orderInCategory, android.R.attr.title, android.R.attr.titleCondensed, android.R.attr.alphabeticShortcut, android.R.attr.numericShortcut, android.R.attr.checkable, android.R.attr.onClick, R.attr.actionLayout, R.attr.actionProviderClass, R.attr.actionViewClass, R.attr.alphabeticModifiers, R.attr.contentDescription, R.attr.iconTint, R.attr.iconTintMode, R.attr.numericModifiers, R.attr.showAsAction, R.attr.tooltipText};
    public static final int[] L3 = {android.R.attr.windowAnimationStyle, android.R.attr.itemTextAppearance, android.R.attr.horizontalDivider, android.R.attr.verticalDivider, android.R.attr.headerBackground, android.R.attr.itemBackground, android.R.attr.itemIconDisabledAlpha, R.attr.preserveIconSpacing, R.attr.subMenuArrow};
    public static final int[] M3 = {R.attr.mock_diagonalsColor, R.attr.mock_label, R.attr.mock_labelBackgroundColor, R.attr.mock_labelColor, R.attr.mock_showDiagonals, R.attr.mock_showLabel};
    public static final int[] N3 = {R.attr.animateCircleAngleTo, R.attr.animateRelativeTo, R.attr.drawPath, R.attr.motionPathRotate, R.attr.motionStagger, R.attr.pathMotionArc, R.attr.quantizeMotionInterpolator, R.attr.quantizeMotionPhase, R.attr.quantizeMotionSteps, R.attr.transitionEasing};
    public static final int[] O3 = {R.attr.onHide, R.attr.onShow};
    public static final int[] P3 = {R.attr.applyMotionScene, R.attr.currentState, R.attr.layoutDescription, R.attr.motionDebug, R.attr.motionProgress, R.attr.showPaths};
    public static final int[] Q3 = {R.attr.defaultDuration, R.attr.layoutDuringTransition};
    public static final int[] R3 = {R.attr.telltales_tailColor, R.attr.telltales_tailScale, R.attr.telltales_velocityMode};
    public static final int[] S3 = {android.R.attr.height, android.R.attr.width, android.R.attr.color, R.attr.marginHorizontal, R.attr.shapeAppearance};
    public static final int[] T3 = {R.attr.activeIndicatorLabelPadding, R.attr.backgroundTint, R.attr.elevation, R.attr.itemActiveIndicatorStyle, R.attr.itemBackground, R.attr.itemIconSize, R.attr.itemIconTint, R.attr.itemPaddingBottom, R.attr.itemPaddingTop, R.attr.itemRippleColor, R.attr.itemTextAppearanceActive, R.attr.itemTextAppearanceActiveBoldEnabled, R.attr.itemTextAppearanceInactive, R.attr.itemTextColor, R.attr.labelVisibilityMode, R.attr.menu};
    public static final int[] U3 = {R.attr.headerLayout, R.attr.itemMinHeight, R.attr.menuGravity, R.attr.paddingBottomSystemWindowInsets, R.attr.paddingStartSystemWindowInsets, R.attr.paddingTopSystemWindowInsets, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay};
    public static final int[] V3 = {android.R.attr.layout_gravity, android.R.attr.background, android.R.attr.fitsSystemWindows, android.R.attr.maxWidth, R.attr.bottomInsetScrimEnabled, R.attr.dividerInsetEnd, R.attr.dividerInsetStart, R.attr.drawerLayoutCornerSize, R.attr.elevation, R.attr.headerLayout, R.attr.itemBackground, R.attr.itemHorizontalPadding, R.attr.itemIconPadding, R.attr.itemIconSize, R.attr.itemIconTint, R.attr.itemMaxLines, R.attr.itemRippleColor, R.attr.itemShapeAppearance, R.attr.itemShapeAppearanceOverlay, R.attr.itemShapeFillColor, R.attr.itemShapeInsetBottom, R.attr.itemShapeInsetEnd, R.attr.itemShapeInsetStart, R.attr.itemShapeInsetTop, R.attr.itemTextAppearance, R.attr.itemTextAppearanceActiveBoldEnabled, R.attr.itemTextColor, R.attr.itemVerticalPadding, R.attr.menu, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.subheaderColor, R.attr.subheaderInsetEnd, R.attr.subheaderInsetStart, R.attr.subheaderTextAppearance, R.attr.topInsetScrimEnabled};
    public static final int[] W3 = {R.attr.clickAction, R.attr.targetId};
    public static final int[] X3 = {R.attr.autoCompleteMode, R.attr.dragDirection, R.attr.dragScale, R.attr.dragThreshold, R.attr.limitBoundsTo, R.attr.maxAcceleration, R.attr.maxVelocity, R.attr.moveWhenScrollAtTop, R.attr.nestedScrollFlags, R.attr.onTouchUp, R.attr.rotationCenterId, R.attr.springBoundary, R.attr.springDamping, R.attr.springMass, R.attr.springStiffness, R.attr.springStopThreshold, R.attr.touchAnchorId, R.attr.touchAnchorSide, R.attr.touchRegionId};
    public static final int[] Y3 = {android.R.attr.popupBackground, android.R.attr.popupAnimationStyle, R.attr.overlapAnchor};
    public static final int[] Z3 = {R.attr.state_above_anchor};

    /* renamed from: a4, reason: collision with root package name */
    public static final int[] f6474a4 = {android.R.attr.visibility, android.R.attr.alpha, R.attr.layout_constraintTag, R.attr.motionProgress, R.attr.visibilityMode};

    /* renamed from: b4, reason: collision with root package name */
    public static final int[] f6482b4 = {R.attr.materialCircleRadius};

    /* renamed from: d4, reason: collision with root package name */
    public static final int[] f6498d4 = {R.attr.minSeparation, R.attr.values};

    /* renamed from: e4, reason: collision with root package name */
    public static final int[] f6506e4 = {R.attr.paddingBottomNoButtons, R.attr.paddingTopNoTitle};

    /* renamed from: f4, reason: collision with root package name */
    public static final int[] f6514f4 = {android.R.attr.orientation, android.R.attr.clipToPadding, android.R.attr.descendantFocusability, R.attr.fastScrollEnabled, R.attr.fastScrollHorizontalThumbDrawable, R.attr.fastScrollHorizontalTrackDrawable, R.attr.fastScrollVerticalThumbDrawable, R.attr.fastScrollVerticalTrackDrawable, R.attr.layoutManager, R.attr.reverseLayout, R.attr.spanCount, R.attr.stackFromEnd};

    /* renamed from: h4, reason: collision with root package name */
    public static final int[] f6530h4 = {R.attr.insetForeground};

    /* renamed from: i4, reason: collision with root package name */
    public static final int[] f6538i4 = {R.attr.behavior_overlapTop};

    /* renamed from: k4, reason: collision with root package name */
    public static final int[] f6554k4 = {android.R.attr.textAppearance, android.R.attr.text, android.R.attr.hint, R.attr.backgroundTint, R.attr.defaultMarginsEnabled, R.attr.defaultScrollFlagsEnabled, R.attr.elevation, R.attr.forceDefaultNavigationOnClickListener, R.attr.hideNavigationIcon, R.attr.navigationIconTint, R.attr.strokeColor, R.attr.strokeWidth, R.attr.tintNavigationIcon};

    /* renamed from: l4, reason: collision with root package name */
    public static final int[] f6562l4 = {android.R.attr.textAppearance, android.R.attr.focusable, android.R.attr.maxWidth, android.R.attr.text, android.R.attr.hint, android.R.attr.inputType, android.R.attr.imeOptions, R.attr.animateMenuItems, R.attr.animateNavigationIcon, R.attr.autoShowKeyboard, R.attr.backHandlingEnabled, R.attr.backgroundTint, R.attr.closeIcon, R.attr.commitIcon, R.attr.defaultQueryHint, R.attr.goIcon, R.attr.headerLayout, R.attr.hideNavigationIcon, R.attr.iconifiedByDefault, R.attr.layout, R.attr.queryBackground, R.attr.queryHint, R.attr.searchHintIcon, R.attr.searchIcon, R.attr.searchPrefixText, R.attr.submitBackground, R.attr.suggestionRowLayout, R.attr.useDrawerArrowDrawable, R.attr.voiceIcon};

    /* renamed from: m4, reason: collision with root package name */
    public static final int[] f6570m4 = {R.attr.cornerFamily, R.attr.cornerFamilyBottomLeft, R.attr.cornerFamilyBottomRight, R.attr.cornerFamilyTopLeft, R.attr.cornerFamilyTopRight, R.attr.cornerSize, R.attr.cornerSizeBottomLeft, R.attr.cornerSizeBottomRight, R.attr.cornerSizeTopLeft, R.attr.cornerSizeTopRight};

    /* renamed from: x4, reason: collision with root package name */
    public static final int[] f6658x4 = {R.attr.contentPadding, R.attr.contentPaddingBottom, R.attr.contentPaddingEnd, R.attr.contentPaddingLeft, R.attr.contentPaddingRight, R.attr.contentPaddingStart, R.attr.contentPaddingTop, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.strokeColor, R.attr.strokeWidth};

    /* renamed from: y4, reason: collision with root package name */
    public static final int[] f6666y4 = {android.R.attr.maxWidth, android.R.attr.maxHeight, android.R.attr.elevation, R.attr.backgroundTint, R.attr.behavior_draggable, R.attr.coplanarSiblingViewId, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay};
    public static final int[] E4 = {android.R.attr.enabled, android.R.attr.value, android.R.attr.stepSize, android.R.attr.valueFrom, android.R.attr.valueTo, R.attr.haloColor, R.attr.haloRadius, R.attr.labelBehavior, R.attr.labelStyle, R.attr.minTouchTargetSize, R.attr.thumbColor, R.attr.thumbElevation, R.attr.thumbRadius, R.attr.thumbStrokeColor, R.attr.thumbStrokeWidth, R.attr.tickColor, R.attr.tickColorActive, R.attr.tickColorInactive, R.attr.tickRadiusActive, R.attr.tickRadiusInactive, R.attr.tickVisible, R.attr.trackColor, R.attr.trackColorActive, R.attr.trackColorInactive, R.attr.trackHeight};
    public static final int[] F4 = {R.attr.snackbarButtonStyle, R.attr.snackbarStyle, R.attr.snackbarTextViewStyle};
    public static final int[] G4 = {android.R.attr.maxWidth, R.attr.actionTextColorAlpha, R.attr.animationMode, R.attr.backgroundOverlayColorAlpha, R.attr.backgroundTint, R.attr.backgroundTintMode, R.attr.elevation, R.attr.maxActionInlineWidth, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay};
    public static final int[] R4 = {android.R.attr.entries, android.R.attr.popupBackground, android.R.attr.prompt, android.R.attr.dropDownWidth, R.attr.popupTheme};
    public static final int[] S4 = {android.R.attr.id, R.attr.constraints};
    public static final int[] T4 = {android.R.attr.dither, android.R.attr.visible, android.R.attr.variablePadding, android.R.attr.constantSize, android.R.attr.enterFadeDuration, android.R.attr.exitFadeDuration};
    public static final int[] U4 = {android.R.attr.drawable};
    public static final int[] V4 = {R.attr.defaultState};
    public static final int[] W4 = {android.R.attr.textOn, android.R.attr.textOff, android.R.attr.thumb, R.attr.showText, R.attr.splitTrack, R.attr.switchMinWidth, R.attr.switchPadding, R.attr.switchTextAppearance, R.attr.thumbTextPadding, R.attr.thumbTint, R.attr.thumbTintMode, R.attr.track, R.attr.trackTint, R.attr.trackTintMode};
    public static final int[] X4 = {R.attr.useMaterialThemeColors};
    public static final int[] Y4 = {android.R.attr.icon, android.R.attr.layout, android.R.attr.text};
    public static final int[] Z4 = {R.attr.tabBackground, R.attr.tabContentStart, R.attr.tabGravity, R.attr.tabIconTint, R.attr.tabIconTintMode, R.attr.tabIndicator, R.attr.tabIndicatorAnimationDuration, R.attr.tabIndicatorAnimationMode, R.attr.tabIndicatorColor, R.attr.tabIndicatorFullWidth, R.attr.tabIndicatorGravity, R.attr.tabIndicatorHeight, R.attr.tabInlineLabel, R.attr.tabMaxWidth, R.attr.tabMinWidth, R.attr.tabMode, R.attr.tabPadding, R.attr.tabPaddingBottom, R.attr.tabPaddingEnd, R.attr.tabPaddingStart, R.attr.tabPaddingTop, R.attr.tabRippleColor, R.attr.tabSelectedTextAppearance, R.attr.tabSelectedTextColor, R.attr.tabTextAppearance, R.attr.tabTextColor, R.attr.tabUnboundedRipple};

    /* renamed from: a5, reason: collision with root package name */
    public static final int[] f6475a5 = {android.R.attr.textSize, android.R.attr.typeface, android.R.attr.textStyle, android.R.attr.textColor, android.R.attr.textColorHint, android.R.attr.textColorLink, android.R.attr.shadowColor, android.R.attr.shadowDx, android.R.attr.shadowDy, android.R.attr.shadowRadius, android.R.attr.fontFamily, android.R.attr.textFontWeight, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.textAllCaps, R.attr.textLocale};

    /* renamed from: o5, reason: collision with root package name */
    public static final int[] f6587o5 = {R.attr.textInputLayoutFocusedRectEnabled};

    /* renamed from: q5, reason: collision with root package name */
    public static final int[] f6603q5 = {android.R.attr.enabled, android.R.attr.textColorHint, android.R.attr.maxWidth, android.R.attr.minWidth, android.R.attr.hint, android.R.attr.maxEms, android.R.attr.minEms, R.attr.boxBackgroundColor, R.attr.boxBackgroundMode, R.attr.boxCollapsedPaddingTop, R.attr.boxCornerRadiusBottomEnd, R.attr.boxCornerRadiusBottomStart, R.attr.boxCornerRadiusTopEnd, R.attr.boxCornerRadiusTopStart, R.attr.boxStrokeColor, R.attr.boxStrokeErrorColor, R.attr.boxStrokeWidth, R.attr.boxStrokeWidthFocused, R.attr.counterEnabled, R.attr.counterMaxLength, R.attr.counterOverflowTextAppearance, R.attr.counterOverflowTextColor, R.attr.counterTextAppearance, R.attr.counterTextColor, R.attr.cursorColor, R.attr.cursorErrorColor, R.attr.endIconCheckable, R.attr.endIconContentDescription, R.attr.endIconDrawable, R.attr.endIconMinSize, R.attr.endIconMode, R.attr.endIconScaleType, R.attr.endIconTint, R.attr.endIconTintMode, R.attr.errorAccessibilityLiveRegion, R.attr.errorContentDescription, R.attr.errorEnabled, R.attr.errorIconDrawable, R.attr.errorIconTint, R.attr.errorIconTintMode, R.attr.errorTextAppearance, R.attr.errorTextColor, R.attr.expandedHintEnabled, R.attr.helperText, R.attr.helperTextEnabled, R.attr.helperTextTextAppearance, R.attr.helperTextTextColor, R.attr.hintAnimationEnabled, R.attr.hintEnabled, R.attr.hintTextAppearance, R.attr.hintTextColor, R.attr.passwordToggleContentDescription, R.attr.passwordToggleDrawable, R.attr.passwordToggleEnabled, R.attr.passwordToggleTint, R.attr.passwordToggleTintMode, R.attr.placeholderText, R.attr.placeholderTextAppearance, R.attr.placeholderTextColor, R.attr.prefixText, R.attr.prefixTextAppearance, R.attr.prefixTextColor, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.startIconCheckable, R.attr.startIconContentDescription, R.attr.startIconDrawable, R.attr.startIconMinSize, R.attr.startIconScaleType, R.attr.startIconTint, R.attr.startIconTintMode, R.attr.suffixText, R.attr.suffixTextAppearance, R.attr.suffixTextColor};
    public static final int[] L6 = {android.R.attr.textAppearance, R.attr.enforceMaterialTheme, R.attr.enforceTextAppearance};
    public static final int[] P6 = {android.R.attr.gravity, android.R.attr.minHeight, R.attr.buttonGravity, R.attr.collapseContentDescription, R.attr.collapseIcon, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.logo, R.attr.logoDescription, R.attr.maxButtonHeight, R.attr.menu, R.attr.navigationContentDescription, R.attr.navigationIcon, R.attr.popupTheme, R.attr.subtitle, R.attr.subtitleTextAppearance, R.attr.subtitleTextColor, R.attr.title, R.attr.titleMargin, R.attr.titleMarginBottom, R.attr.titleMarginEnd, R.attr.titleMarginStart, R.attr.titleMarginTop, R.attr.titleMargins, R.attr.titleTextAppearance, R.attr.titleTextColor};
    public static final int[] Q6 = {android.R.attr.textAppearance, android.R.attr.textColor, android.R.attr.padding, android.R.attr.layout_margin, android.R.attr.minWidth, android.R.attr.minHeight, android.R.attr.text, R.attr.backgroundTint};
    public static final int[] R6 = {android.R.attr.transformPivotX, android.R.attr.transformPivotY, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.translationZ, android.R.attr.elevation, R.attr.transformPivotTarget};
    public static final int[] S6 = {android.R.attr.id, R.attr.autoTransition, R.attr.constraintSetEnd, R.attr.constraintSetStart, R.attr.duration, R.attr.layoutDuringTransition, R.attr.motionInterpolator, R.attr.pathMotionArc, R.attr.staggered, R.attr.transitionDisable, R.attr.transitionFlags};
    public static final int[] T6 = {R.attr.constraints, R.attr.region_heightLessThan, R.attr.region_heightMoreThan, R.attr.region_widthLessThan, R.attr.region_widthMoreThan};
    public static final int[] U6 = {android.R.attr.theme, android.R.attr.focusable, R.attr.paddingEnd, R.attr.paddingStart, R.attr.theme};
    public static final int[] V6 = {android.R.attr.background, R.attr.backgroundTint, R.attr.backgroundTintMode};
    public static final int[] W6 = {android.R.attr.orientation};
    public static final int[] X6 = {android.R.attr.id, android.R.attr.layout, android.R.attr.inflatedId};
}
