package c6;

/* loaded from: classes.dex */
public final class f {
    public static final int A = 2131296603;
    public static final int B = 2131296604;
    public static final int C = 2131296605;
    public static final int D = 2131296608;
    public static final int E = 2131296610;
    public static final int F = 2131296611;
    public static final int G = 2131296615;
    public static final int H = 2131296617;
    public static final int I = 2131296621;
    public static final int J = 2131296737;
    public static final int K = 2131296763;
    public static final int L = 2131296776;
    public static final int M = 2131296777;
    public static final int N = 2131296827;
    public static final int O = 2131296828;
    public static final int P = 2131296830;
    public static final int Q = 2131296831;
    public static final int R = 2131296832;
    public static final int S = 2131296833;
    public static final int T = 2131296834;
    public static final int U = 2131296835;
    public static final int V = 2131296843;
    public static final int W = 2131296854;

    /* renamed from: a, reason: collision with root package name */
    public static final int f6375a = 2131296378;

    /* renamed from: b, reason: collision with root package name */
    public static final int f6376b = 2131296394;

    /* renamed from: c, reason: collision with root package name */
    public static final int f6377c = 2131296396;

    /* renamed from: d, reason: collision with root package name */
    public static final int f6378d = 2131296417;

    /* renamed from: e, reason: collision with root package name */
    public static final int f6379e = 2131296425;

    /* renamed from: f, reason: collision with root package name */
    public static final int f6380f = 2131296445;

    /* renamed from: g, reason: collision with root package name */
    public static final int f6381g = 2131296447;

    /* renamed from: h, reason: collision with root package name */
    public static final int f6382h = 2131296448;

    /* renamed from: i, reason: collision with root package name */
    public static final int f6383i = 2131296507;

    /* renamed from: j, reason: collision with root package name */
    public static final int f6384j = 2131296534;

    /* renamed from: k, reason: collision with root package name */
    public static final int f6385k = 2131296570;

    /* renamed from: l, reason: collision with root package name */
    public static final int f6386l = 2131296571;

    /* renamed from: m, reason: collision with root package name */
    public static final int f6387m = 2131296572;

    /* renamed from: n, reason: collision with root package name */
    public static final int f6388n = 2131296574;

    /* renamed from: o, reason: collision with root package name */
    public static final int f6389o = 2131296575;

    /* renamed from: p, reason: collision with root package name */
    public static final int f6390p = 2131296577;

    /* renamed from: q, reason: collision with root package name */
    public static final int f6391q = 2131296578;

    /* renamed from: r, reason: collision with root package name */
    public static final int f6392r = 2131296580;

    /* renamed from: s, reason: collision with root package name */
    public static final int f6393s = 2131296587;

    /* renamed from: t, reason: collision with root package name */
    public static final int f6394t = 2131296593;

    /* renamed from: u, reason: collision with root package name */
    public static final int f6395u = 2131296595;

    /* renamed from: v, reason: collision with root package name */
    public static final int f6396v = 2131296596;

    /* renamed from: w, reason: collision with root package name */
    public static final int f6397w = 2131296597;

    /* renamed from: x, reason: collision with root package name */
    public static final int f6398x = 2131296598;

    /* renamed from: y, reason: collision with root package name */
    public static final int f6399y = 2131296601;

    /* renamed from: z, reason: collision with root package name */
    public static final int f6400z = 2131296602;
}
