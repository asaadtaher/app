package c6;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public static final int f6401a = 2131361794;

    /* renamed from: b, reason: collision with root package name */
    public static final int f6402b = 2131361836;

    /* renamed from: c, reason: collision with root package name */
    public static final int f6403c = 2131361848;
}
