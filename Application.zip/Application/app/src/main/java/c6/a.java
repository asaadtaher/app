package c6;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static final int f6293a = 2130837534;

    /* renamed from: b, reason: collision with root package name */
    public static final int f6294b = 2130837535;

    /* renamed from: c, reason: collision with root package name */
    public static final int f6295c = 2130837536;

    /* renamed from: d, reason: collision with root package name */
    public static final int f6296d = 2130837537;
}
