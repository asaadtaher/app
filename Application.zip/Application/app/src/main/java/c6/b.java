package c6;

/* loaded from: classes.dex */
public final class b {
    public static final int A = 2130903903;
    public static final int B = 2130903904;
    public static final int C = 2130903906;
    public static final int D = 2130903908;
    public static final int E = 2130903909;
    public static final int F = 2130903910;
    public static final int G = 2130903914;
    public static final int H = 2130903915;
    public static final int I = 2130903916;
    public static final int J = 2130903918;
    public static final int K = 2130903921;
    public static final int L = 2130903949;
    public static final int M = 2130904016;
    public static final int N = 2130904089;
    public static final int O = 2130904116;
    public static final int P = 2130904117;
    public static final int Q = 2130904118;
    public static final int R = 2130904119;
    public static final int S = 2130904120;
    public static final int T = 2130904121;
    public static final int U = 2130904122;
    public static final int V = 2130904205;
    public static final int W = 2130904235;
    public static final int X = 2130904246;
    public static final int Y = 2130904290;

    /* renamed from: a, reason: collision with root package name */
    public static final int f6297a = 2130903106;

    /* renamed from: b, reason: collision with root package name */
    public static final int f6298b = 2130903167;

    /* renamed from: c, reason: collision with root package name */
    public static final int f6299c = 2130903169;

    /* renamed from: d, reason: collision with root package name */
    public static final int f6300d = 2130903249;

    /* renamed from: e, reason: collision with root package name */
    public static final int f6301e = 2130903279;

    /* renamed from: f, reason: collision with root package name */
    public static final int f6302f = 2130903320;

    /* renamed from: g, reason: collision with root package name */
    public static final int f6303g = 2130903321;

    /* renamed from: h, reason: collision with root package name */
    public static final int f6304h = 2130903323;

    /* renamed from: i, reason: collision with root package name */
    public static final int f6305i = 2130903339;

    /* renamed from: j, reason: collision with root package name */
    public static final int f6306j = 2130903341;

    /* renamed from: k, reason: collision with root package name */
    public static final int f6307k = 2130903348;

    /* renamed from: l, reason: collision with root package name */
    public static final int f6308l = 2130903355;

    /* renamed from: m, reason: collision with root package name */
    public static final int f6309m = 2130903362;

    /* renamed from: n, reason: collision with root package name */
    public static final int f6310n = 2130903499;

    /* renamed from: o, reason: collision with root package name */
    public static final int f6311o = 2130903501;

    /* renamed from: p, reason: collision with root package name */
    public static final int f6312p = 2130903502;

    /* renamed from: q, reason: collision with root package name */
    public static final int f6313q = 2130903503;

    /* renamed from: r, reason: collision with root package name */
    public static final int f6314r = 2130903505;

    /* renamed from: s, reason: collision with root package name */
    public static final int f6315s = 2130903669;

    /* renamed from: t, reason: collision with root package name */
    public static final int f6316t = 2130903670;

    /* renamed from: u, reason: collision with root package name */
    public static final int f6317u = 2130903828;

    /* renamed from: v, reason: collision with root package name */
    public static final int f6318v = 2130903829;

    /* renamed from: w, reason: collision with root package name */
    public static final int f6319w = 2130903842;

    /* renamed from: x, reason: collision with root package name */
    public static final int f6320x = 2130903850;

    /* renamed from: y, reason: collision with root package name */
    public static final int f6321y = 2130903864;

    /* renamed from: z, reason: collision with root package name */
    public static final int f6322z = 2130903900;
}
