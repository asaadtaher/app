package c6;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public static final int f6323a = 2131034261;

    /* renamed from: b, reason: collision with root package name */
    public static final int f6324b = 2131034875;

    /* renamed from: c, reason: collision with root package name */
    public static final int f6325c = 2131034900;

    /* renamed from: d, reason: collision with root package name */
    public static final int f6326d = 2131034927;

    /* renamed from: e, reason: collision with root package name */
    public static final int f6327e = 2131034928;

    /* renamed from: f, reason: collision with root package name */
    public static final int f6328f = 2131034931;
}
