package ba;

/* loaded from: classes.dex */
public interface l {
    String a(Object obj);
}
