package ba;

/* loaded from: classes.dex */
public interface h extends m, k {
}
