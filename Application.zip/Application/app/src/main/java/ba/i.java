package ba;

/* loaded from: classes.dex */
public final class i implements h {

    /* renamed from: a, reason: collision with root package name */
    private final l f5997a;

    /* renamed from: b, reason: collision with root package name */
    private final f<b> f5998b;

    public i(l lVar, f<b> fVar) {
        this.f5997a = lVar;
        this.f5998b = fVar;
    }

    public i(l lVar, x9.c cVar, aa.b bVar) {
        this(lVar, new a(cVar, bVar, new b()));
    }

    @Override // ba.k
    public x9.i a(int i10) {
        if (!y9.a.a(i10)) {
            return ((b) this.f5998b.a(this.f5997a.a(Integer.valueOf(i10)))).b(i10);
        }
        throw new IllegalArgumentException(i10 + " calling code belongs to a geo entity");
    }

    @Override // ba.m
    public x9.i b(String str) {
        if (y9.a.b(str)) {
            return ((b) this.f5998b.a(this.f5997a.a(str))).c(str);
        }
        throw new IllegalArgumentException(str + " region code is a non-geo entity");
    }
}
