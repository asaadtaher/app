package ba;

/* loaded from: classes.dex */
final class b implements g {

    /* renamed from: a, reason: collision with root package name */
    private final e<Integer> f5991a = e.b();

    /* renamed from: b, reason: collision with root package name */
    private final e<String> f5992b = e.c();

    b() {
    }

    @Override // ba.g
    public void a(x9.i iVar) {
        (y9.a.b(this.f5992b.d().a(iVar)) ? this.f5992b : this.f5991a).a(iVar);
    }

    x9.i b(int i10) {
        return this.f5991a.e(Integer.valueOf(i10));
    }

    x9.i c(String str) {
        return this.f5992b.e(str);
    }
}
