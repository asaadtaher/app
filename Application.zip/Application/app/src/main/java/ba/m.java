package ba;

/* loaded from: classes.dex */
public interface m {
    x9.i b(String str);
}
