package ba;

/* loaded from: classes.dex */
public interface c {
}
