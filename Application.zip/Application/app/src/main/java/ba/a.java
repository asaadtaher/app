package ba;

import ba.g;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/* loaded from: classes.dex */
final class a<T extends g> implements f<T> {

    /* renamed from: a, reason: collision with root package name */
    private final x9.c f5987a;

    /* renamed from: b, reason: collision with root package name */
    private final aa.b f5988b;

    /* renamed from: c, reason: collision with root package name */
    private final T f5989c;

    /* renamed from: d, reason: collision with root package name */
    private final Map<String, String> f5990d = new ConcurrentHashMap();

    a(x9.c cVar, aa.b bVar, T t10) {
        this.f5987a = cVar;
        this.f5988b = bVar;
        this.f5989c = t10;
    }

    private synchronized void b(String str) {
        if (this.f5990d.containsKey(str)) {
            return;
        }
        Iterator<x9.i> it = c(str).iterator();
        while (it.hasNext()) {
            this.f5989c.a(it.next());
        }
        this.f5990d.put(str, str);
    }

    private Collection<x9.i> c(String str) {
        try {
            return this.f5988b.d(this.f5987a.a(str));
        } catch (IllegalArgumentException | IllegalStateException e10) {
            throw new IllegalStateException("Failed to read file " + str, e10);
        }
    }

    @Override // ba.f
    public T a(String str) {
        if (!this.f5990d.containsKey(str)) {
            b(str);
        }
        return this.f5989c;
    }
}
