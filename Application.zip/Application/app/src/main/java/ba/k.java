package ba;

/* loaded from: classes.dex */
public interface k {
    x9.i a(int i10);
}
