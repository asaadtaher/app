package ba;

/* loaded from: classes.dex */
public final class n implements m {

    /* renamed from: a, reason: collision with root package name */
    private final l f6001a;

    /* renamed from: b, reason: collision with root package name */
    private final f<e<String>> f6002b;

    public n(l lVar, f<e<String>> fVar) {
        this.f6001a = lVar;
        this.f6002b = fVar;
    }

    public n(l lVar, x9.c cVar, aa.b bVar) {
        this(lVar, new a(cVar, bVar, e.c()));
    }
}
