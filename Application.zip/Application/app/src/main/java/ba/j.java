package ba;

import java.util.regex.Pattern;

/* loaded from: classes.dex */
public final class j implements l {

    /* renamed from: b, reason: collision with root package name */
    private static final Pattern f5999b = Pattern.compile("^[\\p{L}\\p{N}]+$");

    /* renamed from: a, reason: collision with root package name */
    private final String f6000a;

    public j(String str) {
        this.f6000a = str + "_";
    }

    @Override // ba.l
    public String a(Object obj) {
        String string = obj.toString();
        if (f5999b.matcher(string).matches()) {
            return this.f6000a + obj;
        }
        throw new IllegalArgumentException("Invalid key: " + string);
    }
}
