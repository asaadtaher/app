package ba;

import ba.g;

/* loaded from: classes.dex */
public interface f<T extends g> {
    T a(String str);
}
