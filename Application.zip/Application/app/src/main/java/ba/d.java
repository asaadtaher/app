package ba;

/* loaded from: classes.dex */
public final class d implements c {

    /* renamed from: a, reason: collision with root package name */
    private final l f5993a;

    /* renamed from: b, reason: collision with root package name */
    private final f<e<Integer>> f5994b;

    public d(l lVar, f<e<Integer>> fVar) {
        this.f5993a = lVar;
        this.f5994b = fVar;
    }

    public d(l lVar, x9.c cVar, aa.b bVar) {
        this(lVar, new a(cVar, bVar, e.b()));
    }
}
