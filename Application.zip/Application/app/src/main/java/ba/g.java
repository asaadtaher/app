package ba;

/* loaded from: classes.dex */
interface g {
    void a(x9.i iVar);
}
