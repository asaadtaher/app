package ba;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/* loaded from: classes.dex */
final class e<T> implements g {

    /* renamed from: a, reason: collision with root package name */
    private final ConcurrentMap<T, x9.i> f5995a = new ConcurrentHashMap();

    /* renamed from: b, reason: collision with root package name */
    private final c<T> f5996b;

    class a implements c<String> {
        a() {
        }

        @Override // ba.e.c
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public String a(x9.i iVar) {
            return iVar.d();
        }
    }

    class b implements c<Integer> {
        b() {
        }

        @Override // ba.e.c
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public Integer a(x9.i iVar) {
            return Integer.valueOf(iVar.a());
        }
    }

    interface c<T> {
        T a(x9.i iVar);
    }

    private e(c<T> cVar) {
        this.f5996b = cVar;
    }

    static e<Integer> b() {
        return new e<>(new b());
    }

    static e<String> c() {
        return new e<>(new a());
    }

    @Override // ba.g
    public void a(x9.i iVar) {
        this.f5995a.put(this.f5996b.a(iVar), iVar);
    }

    c<T> d() {
        return this.f5996b;
    }

    x9.i e(T t10) {
        if (t10 != null) {
            return this.f5995a.get(t10);
        }
        return null;
    }
}
