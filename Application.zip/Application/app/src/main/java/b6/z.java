package b6;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class z implements e0 {

    /* renamed from: a, reason: collision with root package name */
    private final Executor f5984a;

    /* renamed from: b, reason: collision with root package name */
    private final Object f5985b = new Object();

    /* renamed from: c, reason: collision with root package name */
    private e f5986c;

    public z(Executor executor, e eVar) {
        this.f5984a = executor;
        this.f5986c = eVar;
    }

    @Override // b6.e0
    public final void d(i iVar) {
        if (iVar.r() || iVar.p()) {
            return;
        }
        synchronized (this.f5985b) {
            if (this.f5986c == null) {
                return;
            }
            this.f5984a.execute(new y(this, iVar));
        }
    }

    @Override // b6.e0
    public final void j() {
        synchronized (this.f5985b) {
            this.f5986c = null;
        }
    }
}
