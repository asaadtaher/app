package b6;

import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class c0 implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ i f5933a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ d0 f5934b;

    c0(d0 d0Var, i iVar) {
        this.f5934b = d0Var;
        this.f5933a = iVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            i iVarA = this.f5934b.f5936b.a(this.f5933a.n());
            if (iVarA == null) {
                this.f5934b.c(new NullPointerException("Continuation returned null"));
                return;
            }
            Executor executor = k.f5951b;
            iVarA.i(executor, this.f5934b);
            iVarA.f(executor, this.f5934b);
            iVarA.a(executor, this.f5934b);
        } catch (g e10) {
            if (e10.getCause() instanceof Exception) {
                this.f5934b.c((Exception) e10.getCause());
            } else {
                this.f5934b.c(e10);
            }
        } catch (CancellationException unused) {
            this.f5934b.b();
        } catch (Exception e11) {
            this.f5934b.c(e11);
        }
    }
}
