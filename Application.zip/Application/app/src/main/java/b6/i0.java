package b6;

import android.app.Activity;
import com.google.android.gms.common.api.internal.LifecycleCallback;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
final class i0 extends LifecycleCallback {

    /* renamed from: b, reason: collision with root package name */
    private final List f5942b;

    private i0(z4.f fVar) {
        super(fVar);
        this.f5942b = new ArrayList();
        this.f7277a.a("TaskOnStopCallback", this);
    }

    public static i0 l(Activity activity) {
        z4.f fVarC = LifecycleCallback.c(activity);
        i0 i0Var = (i0) fVarC.b("TaskOnStopCallback", i0.class);
        return i0Var == null ? new i0(fVarC) : i0Var;
    }

    @Override // com.google.android.gms.common.api.internal.LifecycleCallback
    public final void k() {
        synchronized (this.f5942b) {
            Iterator it = this.f5942b.iterator();
            while (it.hasNext()) {
                e0 e0Var = (e0) ((WeakReference) it.next()).get();
                if (e0Var != null) {
                    e0Var.j();
                }
            }
            this.f5942b.clear();
        }
    }

    public final void m(e0 e0Var) {
        synchronized (this.f5942b) {
            this.f5942b.add(new WeakReference(e0Var));
        }
    }
}
