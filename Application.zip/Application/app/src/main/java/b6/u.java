package b6;

/* loaded from: classes.dex */
final class u implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ v f5973a;

    u(v vVar) {
        this.f5973a = vVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        synchronized (this.f5973a.f5975b) {
            v vVar = this.f5973a;
            if (vVar.f5976c != null) {
                vVar.f5976c.b();
            }
        }
    }
}
