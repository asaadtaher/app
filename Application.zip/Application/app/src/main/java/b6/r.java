package b6;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class r implements e0 {

    /* renamed from: a, reason: collision with root package name */
    private final Executor f5965a;

    /* renamed from: b, reason: collision with root package name */
    private final a f5966b;

    /* renamed from: c, reason: collision with root package name */
    private final j0 f5967c;

    public r(Executor executor, a aVar, j0 j0Var) {
        this.f5965a = executor;
        this.f5966b = aVar;
        this.f5967c = j0Var;
    }

    @Override // b6.e0
    public final void d(i iVar) {
        this.f5965a.execute(new q(this, iVar));
    }

    @Override // b6.e0
    public final void j() {
        throw new UnsupportedOperationException();
    }
}
