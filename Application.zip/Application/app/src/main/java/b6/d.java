package b6;

/* loaded from: classes.dex */
public interface d<TResult> {
    void a(i<TResult> iVar);
}
