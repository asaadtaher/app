package b6;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class g0 implements Executor {
    g0() {
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        runnable.run();
    }
}
