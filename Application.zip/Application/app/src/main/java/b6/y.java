package b6;

/* loaded from: classes.dex */
final class y implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ i f5982a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ z f5983b;

    y(z zVar, i iVar) {
        this.f5983b = zVar;
        this.f5982a = iVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        synchronized (this.f5983b.f5985b) {
            z zVar = this.f5983b;
            if (zVar.f5986c != null) {
                zVar.f5986c.c((Exception) a5.r.k(this.f5982a.m()));
            }
        }
    }
}
