package b6;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class v implements e0 {

    /* renamed from: a, reason: collision with root package name */
    private final Executor f5974a;

    /* renamed from: b, reason: collision with root package name */
    private final Object f5975b = new Object();

    /* renamed from: c, reason: collision with root package name */
    private c f5976c;

    public v(Executor executor, c cVar) {
        this.f5974a = executor;
        this.f5976c = cVar;
    }

    @Override // b6.e0
    public final void d(i iVar) {
        if (iVar.p()) {
            synchronized (this.f5975b) {
                if (this.f5976c == null) {
                    return;
                }
                this.f5974a.execute(new u(this));
            }
        }
    }

    @Override // b6.e0
    public final void j() {
        synchronized (this.f5975b) {
            this.f5976c = null;
        }
    }
}
