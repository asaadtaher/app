package b6;

/* loaded from: classes.dex */
public class j<TResult> {

    /* renamed from: a, reason: collision with root package name */
    private final j0 f5943a = new j0();

    public i<TResult> a() {
        return this.f5943a;
    }

    public void b(Exception exc) {
        this.f5943a.u(exc);
    }

    public void c(TResult tresult) {
        this.f5943a.v(tresult);
    }

    public boolean d(Exception exc) {
        return this.f5943a.x(exc);
    }

    public boolean e(TResult tresult) {
        return this.f5943a.y(tresult);
    }
}
