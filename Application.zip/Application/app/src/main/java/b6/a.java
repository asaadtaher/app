package b6;

/* loaded from: classes.dex */
public interface a<TResult, TContinuationResult> {
    TContinuationResult a(i<TResult> iVar);
}
