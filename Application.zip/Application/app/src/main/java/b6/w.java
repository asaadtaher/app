package b6;

/* loaded from: classes.dex */
final class w implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ i f5977a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ x f5978b;

    w(x xVar, i iVar) {
        this.f5978b = xVar;
        this.f5977a = iVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        synchronized (this.f5978b.f5980b) {
            x xVar = this.f5978b;
            if (xVar.f5981c != null) {
                xVar.f5981c.a(this.f5977a);
            }
        }
    }
}
