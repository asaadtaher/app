package b6;

/* loaded from: classes.dex */
public interface c {
    void b();
}
