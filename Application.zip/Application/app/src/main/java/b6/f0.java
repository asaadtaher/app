package b6;

import java.util.ArrayDeque;
import java.util.Queue;

/* loaded from: classes.dex */
final class f0 {

    /* renamed from: a, reason: collision with root package name */
    private final Object f5938a = new Object();

    /* renamed from: b, reason: collision with root package name */
    private Queue f5939b;

    /* renamed from: c, reason: collision with root package name */
    private boolean f5940c;

    f0() {
    }

    public final void a(e0 e0Var) {
        synchronized (this.f5938a) {
            if (this.f5939b == null) {
                this.f5939b = new ArrayDeque();
            }
            this.f5939b.add(e0Var);
        }
    }

    public final void b(i iVar) {
        e0 e0Var;
        synchronized (this.f5938a) {
            if (this.f5939b != null && !this.f5940c) {
                this.f5940c = true;
                while (true) {
                    synchronized (this.f5938a) {
                        e0Var = (e0) this.f5939b.poll();
                        if (e0Var == null) {
                            this.f5940c = false;
                            return;
                        }
                    }
                    e0Var.d(iVar);
                }
            }
        }
    }
}
