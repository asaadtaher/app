package b6;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class h0 implements Executor {

    /* renamed from: a, reason: collision with root package name */
    private final Handler f5941a = new s5.a(Looper.getMainLooper());

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        this.f5941a.post(runnable);
    }
}
