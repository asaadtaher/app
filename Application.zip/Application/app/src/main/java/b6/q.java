package b6;

/* loaded from: classes.dex */
final class q implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ i f5963a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ r f5964b;

    q(r rVar, i iVar) {
        this.f5964b = rVar;
        this.f5963a = iVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        if (this.f5963a.p()) {
            this.f5964b.f5967c.w();
            return;
        }
        try {
            this.f5964b.f5967c.v(this.f5964b.f5966b.a(this.f5963a));
        } catch (g e10) {
            if (e10.getCause() instanceof Exception) {
                this.f5964b.f5967c.u((Exception) e10.getCause());
            } else {
                this.f5964b.f5967c.u(e10);
            }
        } catch (Exception e11) {
            this.f5964b.f5967c.u(e11);
        }
    }
}
