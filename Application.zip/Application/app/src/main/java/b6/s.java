package b6;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class s implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ i f5968a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ t f5969b;

    s(t tVar, i iVar) {
        this.f5969b = tVar;
        this.f5968a = iVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            i iVar = (i) this.f5969b.f5971b.a(this.f5968a);
            if (iVar == null) {
                this.f5969b.c(new NullPointerException("Continuation returned null"));
                return;
            }
            Executor executor = k.f5951b;
            iVar.i(executor, this.f5969b);
            iVar.f(executor, this.f5969b);
            iVar.a(executor, this.f5969b);
        } catch (g e10) {
            if (e10.getCause() instanceof Exception) {
                this.f5969b.f5972c.u((Exception) e10.getCause());
            } else {
                this.f5969b.f5972c.u(e10);
            }
        } catch (Exception e11) {
            this.f5969b.f5972c.u(e11);
        }
    }
}
