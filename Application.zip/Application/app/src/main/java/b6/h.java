package b6;

/* loaded from: classes.dex */
public interface h<TResult, TContinuationResult> {
    i<TContinuationResult> a(TResult tresult);
}
