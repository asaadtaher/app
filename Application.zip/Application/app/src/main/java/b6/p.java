package b6;

import java.util.concurrent.ExecutionException;

/* loaded from: classes.dex */
final class p<T> implements o<T> {

    /* renamed from: a, reason: collision with root package name */
    private final Object f5955a = new Object();

    /* renamed from: b, reason: collision with root package name */
    private final int f5956b;

    /* renamed from: c, reason: collision with root package name */
    private final j0 f5957c;

    /* renamed from: d, reason: collision with root package name */
    private int f5958d;

    /* renamed from: e, reason: collision with root package name */
    private int f5959e;

    /* renamed from: f, reason: collision with root package name */
    private int f5960f;

    /* renamed from: g, reason: collision with root package name */
    private Exception f5961g;

    /* renamed from: h, reason: collision with root package name */
    private boolean f5962h;

    public p(int i10, j0 j0Var) {
        this.f5956b = i10;
        this.f5957c = j0Var;
    }

    private final void d() {
        if (this.f5958d + this.f5959e + this.f5960f == this.f5956b) {
            if (this.f5961g == null) {
                if (this.f5962h) {
                    this.f5957c.w();
                    return;
                } else {
                    this.f5957c.v(null);
                    return;
                }
            }
            this.f5957c.u(new ExecutionException(this.f5959e + " out of " + this.f5956b + " underlying tasks failed", this.f5961g));
        }
    }

    @Override // b6.f
    public final void a(T t10) {
        synchronized (this.f5955a) {
            this.f5958d++;
            d();
        }
    }

    @Override // b6.c
    public final void b() {
        synchronized (this.f5955a) {
            this.f5960f++;
            this.f5962h = true;
            d();
        }
    }

    @Override // b6.e
    public final void c(Exception exc) {
        synchronized (this.f5955a) {
            this.f5959e++;
            this.f5961g = exc;
            d();
        }
    }
}
