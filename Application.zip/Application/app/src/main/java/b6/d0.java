package b6;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class d0<TResult, TContinuationResult> implements f<TContinuationResult>, e, c, e0 {

    /* renamed from: a, reason: collision with root package name */
    private final Executor f5935a;

    /* renamed from: b, reason: collision with root package name */
    private final h f5936b;

    /* renamed from: c, reason: collision with root package name */
    private final j0 f5937c;

    public d0(Executor executor, h hVar, j0 j0Var) {
        this.f5935a = executor;
        this.f5936b = hVar;
        this.f5937c = j0Var;
    }

    @Override // b6.f
    public final void a(TContinuationResult tcontinuationresult) {
        this.f5937c.v(tcontinuationresult);
    }

    @Override // b6.c
    public final void b() {
        this.f5937c.w();
    }

    @Override // b6.e
    public final void c(Exception exc) {
        this.f5937c.u(exc);
    }

    @Override // b6.e0
    public final void d(i iVar) {
        this.f5935a.execute(new c0(this, iVar));
    }

    @Override // b6.e0
    public final void j() {
        throw new UnsupportedOperationException();
    }
}
