package b6;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class t<TResult, TContinuationResult> implements f<TContinuationResult>, e, c, e0 {

    /* renamed from: a, reason: collision with root package name */
    private final Executor f5970a;

    /* renamed from: b, reason: collision with root package name */
    private final a f5971b;

    /* renamed from: c, reason: collision with root package name */
    private final j0 f5972c;

    public t(Executor executor, a aVar, j0 j0Var) {
        this.f5970a = executor;
        this.f5971b = aVar;
        this.f5972c = j0Var;
    }

    @Override // b6.f
    public final void a(TContinuationResult tcontinuationresult) {
        this.f5972c.v(tcontinuationresult);
    }

    @Override // b6.c
    public final void b() {
        this.f5972c.w();
    }

    @Override // b6.e
    public final void c(Exception exc) {
        this.f5972c.u(exc);
    }

    @Override // b6.e0
    public final void d(i iVar) {
        this.f5970a.execute(new s(this, iVar));
    }

    @Override // b6.e0
    public final void j() {
        throw new UnsupportedOperationException();
    }
}
