package b6;

/* loaded from: classes.dex */
interface e0<TResult> {
    void d(i iVar);

    void j();
}
