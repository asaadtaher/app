package b6;

/* loaded from: classes.dex */
public interface f<TResult> {
    void a(TResult tresult);
}
