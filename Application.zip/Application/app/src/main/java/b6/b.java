package b6;

/* loaded from: classes.dex */
public final class b extends IllegalStateException {
    private b(String str, Throwable th) {
        super(str, th);
    }

    public static IllegalStateException a(i<?> iVar) {
        if (!iVar.q()) {
            return new IllegalStateException("DuplicateTaskCompletionException can only be created from completed Task.");
        }
        Exception excM = iVar.m();
        return new b("Complete with: ".concat(excM != null ? "failure" : iVar.r() ? "result ".concat(String.valueOf(iVar.n())) : iVar.p() ? "cancellation" : "unknown issue"), excM);
    }
}
