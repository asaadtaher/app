package b6;

import java.util.concurrent.Callable;

/* loaded from: classes.dex */
final class k0 implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ j0 f5952a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ Callable f5953b;

    k0(j0 j0Var, Callable callable) {
        this.f5952a = j0Var;
        this.f5953b = callable;
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            this.f5952a.v(this.f5953b.call());
        } catch (Exception e10) {
            this.f5952a.u(e10);
        } catch (Throwable th) {
            this.f5952a.u(new RuntimeException(th));
        }
    }
}
