package b6;

/* loaded from: classes.dex */
public class g extends RuntimeException {
    public g(Throwable th) {
        super(th);
    }
}
