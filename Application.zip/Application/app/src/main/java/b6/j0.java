package b6;

import android.app.Activity;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class j0<TResult> extends i<TResult> {

    /* renamed from: a, reason: collision with root package name */
    private final Object f5944a = new Object();

    /* renamed from: b, reason: collision with root package name */
    private final f0 f5945b = new f0();

    /* renamed from: c, reason: collision with root package name */
    private boolean f5946c;

    /* renamed from: d, reason: collision with root package name */
    private volatile boolean f5947d;

    /* renamed from: e, reason: collision with root package name */
    private Object f5948e;

    /* renamed from: f, reason: collision with root package name */
    private Exception f5949f;

    j0() {
    }

    private final void A() {
        if (this.f5947d) {
            throw new CancellationException("Task is already canceled.");
        }
    }

    private final void B() {
        if (this.f5946c) {
            throw b.a(this);
        }
    }

    private final void C() {
        synchronized (this.f5944a) {
            if (this.f5946c) {
                this.f5945b.b(this);
            }
        }
    }

    private final void z() {
        a5.r.n(this.f5946c, "Task is not yet complete");
    }

    @Override // b6.i
    public final i<TResult> a(Executor executor, c cVar) {
        this.f5945b.a(new v(executor, cVar));
        C();
        return this;
    }

    @Override // b6.i
    public final i<TResult> b(d<TResult> dVar) {
        this.f5945b.a(new x(k.f5950a, dVar));
        C();
        return this;
    }

    @Override // b6.i
    public final i<TResult> c(Executor executor, d<TResult> dVar) {
        this.f5945b.a(new x(executor, dVar));
        C();
        return this;
    }

    @Override // b6.i
    public final i<TResult> d(Activity activity, e eVar) {
        z zVar = new z(k.f5950a, eVar);
        this.f5945b.a(zVar);
        i0.l(activity).m(zVar);
        C();
        return this;
    }

    @Override // b6.i
    public final i<TResult> e(e eVar) {
        f(k.f5950a, eVar);
        return this;
    }

    @Override // b6.i
    public final i<TResult> f(Executor executor, e eVar) {
        this.f5945b.a(new z(executor, eVar));
        C();
        return this;
    }

    @Override // b6.i
    public final i<TResult> g(Activity activity, f<? super TResult> fVar) {
        b0 b0Var = new b0(k.f5950a, fVar);
        this.f5945b.a(b0Var);
        i0.l(activity).m(b0Var);
        C();
        return this;
    }

    @Override // b6.i
    public final i<TResult> h(f<? super TResult> fVar) {
        i(k.f5950a, fVar);
        return this;
    }

    @Override // b6.i
    public final i<TResult> i(Executor executor, f<? super TResult> fVar) {
        this.f5945b.a(new b0(executor, fVar));
        C();
        return this;
    }

    @Override // b6.i
    public final <TContinuationResult> i<TContinuationResult> j(a<TResult, TContinuationResult> aVar) {
        return k(k.f5950a, aVar);
    }

    @Override // b6.i
    public final <TContinuationResult> i<TContinuationResult> k(Executor executor, a<TResult, TContinuationResult> aVar) {
        j0 j0Var = new j0();
        this.f5945b.a(new r(executor, aVar, j0Var));
        C();
        return j0Var;
    }

    @Override // b6.i
    public final <TContinuationResult> i<TContinuationResult> l(Executor executor, a<TResult, i<TContinuationResult>> aVar) {
        j0 j0Var = new j0();
        this.f5945b.a(new t(executor, aVar, j0Var));
        C();
        return j0Var;
    }

    @Override // b6.i
    public final Exception m() {
        Exception exc;
        synchronized (this.f5944a) {
            exc = this.f5949f;
        }
        return exc;
    }

    @Override // b6.i
    public final TResult n() {
        TResult tresult;
        synchronized (this.f5944a) {
            z();
            A();
            Exception exc = this.f5949f;
            if (exc != null) {
                throw new g(exc);
            }
            tresult = (TResult) this.f5948e;
        }
        return tresult;
    }

    @Override // b6.i
    public final <X extends Throwable> TResult o(Class<X> cls) {
        TResult tresult;
        synchronized (this.f5944a) {
            z();
            A();
            if (cls.isInstance(this.f5949f)) {
                throw cls.cast(this.f5949f);
            }
            Exception exc = this.f5949f;
            if (exc != null) {
                throw new g(exc);
            }
            tresult = (TResult) this.f5948e;
        }
        return tresult;
    }

    @Override // b6.i
    public final boolean p() {
        return this.f5947d;
    }

    @Override // b6.i
    public final boolean q() {
        boolean z10;
        synchronized (this.f5944a) {
            z10 = this.f5946c;
        }
        return z10;
    }

    @Override // b6.i
    public final boolean r() {
        boolean z10;
        synchronized (this.f5944a) {
            z10 = false;
            if (this.f5946c && !this.f5947d && this.f5949f == null) {
                z10 = true;
            }
        }
        return z10;
    }

    @Override // b6.i
    public final <TContinuationResult> i<TContinuationResult> s(h<TResult, TContinuationResult> hVar) {
        Executor executor = k.f5950a;
        j0 j0Var = new j0();
        this.f5945b.a(new d0(executor, hVar, j0Var));
        C();
        return j0Var;
    }

    @Override // b6.i
    public final <TContinuationResult> i<TContinuationResult> t(Executor executor, h<TResult, TContinuationResult> hVar) {
        j0 j0Var = new j0();
        this.f5945b.a(new d0(executor, hVar, j0Var));
        C();
        return j0Var;
    }

    public final void u(Exception exc) {
        a5.r.l(exc, "Exception must not be null");
        synchronized (this.f5944a) {
            B();
            this.f5946c = true;
            this.f5949f = exc;
        }
        this.f5945b.b(this);
    }

    public final void v(Object obj) {
        synchronized (this.f5944a) {
            B();
            this.f5946c = true;
            this.f5948e = obj;
        }
        this.f5945b.b(this);
    }

    public final boolean w() {
        synchronized (this.f5944a) {
            if (this.f5946c) {
                return false;
            }
            this.f5946c = true;
            this.f5947d = true;
            this.f5945b.b(this);
            return true;
        }
    }

    public final boolean x(Exception exc) {
        a5.r.l(exc, "Exception must not be null");
        synchronized (this.f5944a) {
            if (this.f5946c) {
                return false;
            }
            this.f5946c = true;
            this.f5949f = exc;
            this.f5945b.b(this);
            return true;
        }
    }

    public final boolean y(Object obj) {
        synchronized (this.f5944a) {
            if (this.f5946c) {
                return false;
            }
            this.f5946c = true;
            this.f5948e = obj;
            this.f5945b.b(this);
            return true;
        }
    }
}
