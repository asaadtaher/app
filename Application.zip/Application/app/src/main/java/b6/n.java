package b6;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/* loaded from: classes.dex */
final class n<T> implements o<T> {

    /* renamed from: a, reason: collision with root package name */
    private final CountDownLatch f5954a = new CountDownLatch(1);

    /* synthetic */ n(m mVar) {
    }

    @Override // b6.f
    public final void a(T t10) {
        this.f5954a.countDown();
    }

    @Override // b6.c
    public final void b() {
        this.f5954a.countDown();
    }

    @Override // b6.e
    public final void c(Exception exc) {
        this.f5954a.countDown();
    }

    public final void d() throws InterruptedException {
        this.f5954a.await();
    }

    public final boolean e(long j10, TimeUnit timeUnit) {
        return this.f5954a.await(j10, timeUnit);
    }
}
