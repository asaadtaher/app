package b6;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class b0 implements e0 {

    /* renamed from: a, reason: collision with root package name */
    private final Executor f5930a;

    /* renamed from: b, reason: collision with root package name */
    private final Object f5931b = new Object();

    /* renamed from: c, reason: collision with root package name */
    private f f5932c;

    public b0(Executor executor, f fVar) {
        this.f5930a = executor;
        this.f5932c = fVar;
    }

    @Override // b6.e0
    public final void d(i iVar) {
        if (iVar.r()) {
            synchronized (this.f5931b) {
                if (this.f5932c == null) {
                    return;
                }
                this.f5930a.execute(new a0(this, iVar));
            }
        }
    }

    @Override // b6.e0
    public final void j() {
        synchronized (this.f5931b) {
            this.f5932c = null;
        }
    }
}
