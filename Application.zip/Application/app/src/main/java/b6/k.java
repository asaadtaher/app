package b6;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class k {

    /* renamed from: a, reason: collision with root package name */
    public static final Executor f5950a = new h0();

    /* renamed from: b, reason: collision with root package name */
    static final Executor f5951b = new g0();
}
