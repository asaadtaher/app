package b6;

/* loaded from: classes.dex */
public interface e {
    void c(Exception exc);
}
