package b6;

/* loaded from: classes.dex */
final class a0 implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ i f5928a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ b0 f5929b;

    a0(b0 b0Var, i iVar) {
        this.f5929b = b0Var;
        this.f5928a = iVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        synchronized (this.f5929b.f5931b) {
            b0 b0Var = this.f5929b;
            if (b0Var.f5932c != null) {
                b0Var.f5932c.a(this.f5928a.n());
            }
        }
    }
}
