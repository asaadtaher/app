package b6;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: classes.dex */
public final class l {
    public static <TResult> TResult a(i<TResult> iVar) {
        a5.r.i();
        a5.r.l(iVar, "Task must not be null");
        if (iVar.q()) {
            return (TResult) h(iVar);
        }
        n nVar = new n(null);
        i(iVar, nVar);
        nVar.d();
        return (TResult) h(iVar);
    }

    public static <TResult> TResult b(i<TResult> iVar, long j10, TimeUnit timeUnit) throws TimeoutException {
        a5.r.i();
        a5.r.l(iVar, "Task must not be null");
        a5.r.l(timeUnit, "TimeUnit must not be null");
        if (iVar.q()) {
            return (TResult) h(iVar);
        }
        n nVar = new n(null);
        i(iVar, nVar);
        if (nVar.e(j10, timeUnit)) {
            return (TResult) h(iVar);
        }
        throw new TimeoutException("Timed out waiting for Task");
    }

    @Deprecated
    public static <TResult> i<TResult> c(Executor executor, Callable<TResult> callable) {
        a5.r.l(executor, "Executor must not be null");
        a5.r.l(callable, "Callback must not be null");
        j0 j0Var = new j0();
        executor.execute(new k0(j0Var, callable));
        return j0Var;
    }

    public static <TResult> i<TResult> d(Exception exc) {
        j0 j0Var = new j0();
        j0Var.u(exc);
        return j0Var;
    }

    public static <TResult> i<TResult> e(TResult tresult) {
        j0 j0Var = new j0();
        j0Var.v(tresult);
        return j0Var;
    }

    public static i<Void> f(Collection<? extends i<?>> collection) {
        if (collection == null || collection.isEmpty()) {
            return e(null);
        }
        Iterator<? extends i<?>> it = collection.iterator();
        while (it.hasNext()) {
            Objects.requireNonNull(it.next(), "null tasks are not accepted");
        }
        j0 j0Var = new j0();
        p pVar = new p(collection.size(), j0Var);
        Iterator<? extends i<?>> it2 = collection.iterator();
        while (it2.hasNext()) {
            i(it2.next(), pVar);
        }
        return j0Var;
    }

    public static i<Void> g(i<?>... iVarArr) {
        return (iVarArr == null || iVarArr.length == 0) ? e(null) : f(Arrays.asList(iVarArr));
    }

    private static Object h(i iVar) throws ExecutionException {
        if (iVar.r()) {
            return iVar.n();
        }
        if (iVar.p()) {
            throw new CancellationException("Task is already canceled");
        }
        throw new ExecutionException(iVar.m());
    }

    private static void i(i iVar, o oVar) {
        Executor executor = k.f5951b;
        iVar.i(executor, oVar);
        iVar.f(executor, oVar);
        iVar.a(executor, oVar);
    }
}
