package b1;

import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.internal.m;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    private final Map<b<?>, Object> f5316a = new LinkedHashMap();

    /* renamed from: b1.a$a, reason: collision with other inner class name */
    public static final class C0087a extends a {

        /* renamed from: b, reason: collision with root package name */
        public static final C0087a f5317b = new C0087a();

        private C0087a() {
        }

        @Override // b1.a
        public <T> T a(b<T> key) {
            m.g(key, "key");
            return null;
        }
    }

    public interface b<T> {
    }

    public abstract <T> T a(b<T> bVar);

    public final Map<b<?>, Object> b() {
        return this.f5316a;
    }
}
