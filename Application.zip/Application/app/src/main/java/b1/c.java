package b1;

import androidx.lifecycle.f0;
import androidx.lifecycle.i0;
import ed.l;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.jvm.internal.m;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    private final List<f<?>> f5319a = new ArrayList();

    public final <T extends f0> void a(kd.c<T> clazz, l<? super a, ? extends T> initializer) {
        m.g(clazz, "clazz");
        m.g(initializer, "initializer");
        this.f5319a.add(new f<>(dd.a.a(clazz), initializer));
    }

    public final i0.b b() {
        f[] fVarArr = (f[]) this.f5319a.toArray(new f[0]);
        return new b((f[]) Arrays.copyOf(fVarArr, fVarArr.length));
    }
}
