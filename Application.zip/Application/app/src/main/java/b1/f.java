package b1;

import androidx.lifecycle.f0;
import ed.l;
import kotlin.jvm.internal.m;

/* loaded from: classes.dex */
public final class f<T extends f0> {

    /* renamed from: a, reason: collision with root package name */
    private final Class<T> f5321a;

    /* renamed from: b, reason: collision with root package name */
    private final l<a, T> f5322b;

    /* JADX WARN: Multi-variable type inference failed */
    public f(Class<T> clazz, l<? super a, ? extends T> initializer) {
        m.g(clazz, "clazz");
        m.g(initializer, "initializer");
        this.f5321a = clazz;
        this.f5322b = initializer;
    }

    public final Class<T> a() {
        return this.f5321a;
    }

    public final l<a, T> b() {
        return this.f5322b;
    }
}
