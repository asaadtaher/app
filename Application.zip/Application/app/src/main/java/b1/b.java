package b1;

import androidx.lifecycle.f0;
import androidx.lifecycle.i0;
import androidx.lifecycle.j0;
import kotlin.jvm.internal.m;

/* loaded from: classes.dex */
public final class b implements i0.b {

    /* renamed from: a, reason: collision with root package name */
    private final f<?>[] f5318a;

    public b(f<?>... initializers) {
        m.g(initializers, "initializers");
        this.f5318a = initializers;
    }

    @Override // androidx.lifecycle.i0.b
    public /* synthetic */ f0 create(Class cls) {
        return j0.a(this, cls);
    }

    @Override // androidx.lifecycle.i0.b
    public <T extends f0> T create(Class<T> modelClass, a extras) {
        m.g(modelClass, "modelClass");
        m.g(extras, "extras");
        T t10 = null;
        for (f<?> fVar : this.f5318a) {
            if (m.b(fVar.a(), modelClass)) {
                T tInvoke = fVar.b().invoke(extras);
                t10 = tInvoke instanceof f0 ? tInvoke : null;
            }
        }
        if (t10 != null) {
            return t10;
        }
        throw new IllegalArgumentException("No initializer set for given class " + modelClass.getName());
    }
}
