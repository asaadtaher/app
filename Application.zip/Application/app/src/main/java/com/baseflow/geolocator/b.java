package com.baseflow.geolocator;

import android.content.Context;
import android.content.IntentFilter;
import android.util.Log;
import tb.d;
import u1.u;

/* loaded from: classes.dex */
public class b implements d.InterfaceC0377d {

    /* renamed from: a, reason: collision with root package name */
    private tb.d f6830a;

    /* renamed from: b, reason: collision with root package name */
    private Context f6831b;

    /* renamed from: c, reason: collision with root package name */
    private u f6832c;

    private void c() {
        u uVar;
        Context context = this.f6831b;
        if (context == null || (uVar = this.f6832c) == null) {
            return;
        }
        context.unregisterReceiver(uVar);
    }

    @Override // tb.d.InterfaceC0377d
    public void a(Object obj, d.b bVar) {
        if (this.f6831b == null) {
            return;
        }
        IntentFilter intentFilter = new IntentFilter("android.location.PROVIDERS_CHANGED");
        intentFilter.addAction("android.intent.action.PROVIDER_CHANGED");
        u uVar = new u(bVar);
        this.f6832c = uVar;
        androidx.core.content.a.n(this.f6831b, uVar, intentFilter, 2);
    }

    @Override // tb.d.InterfaceC0377d
    public void b(Object obj) {
        c();
    }

    void d(Context context) {
        this.f6831b = context;
    }

    void e(Context context, tb.c cVar) {
        if (this.f6830a != null) {
            Log.w("LocationServiceHandler", "Setting a event call handler before the last was disposed.");
            f();
        }
        tb.d dVar = new tb.d(cVar, "flutter.baseflow.com/geolocator_service_updates_android");
        this.f6830a = dVar;
        dVar.d(this);
        this.f6831b = context;
    }

    void f() {
        if (this.f6830a == null) {
            return;
        }
        c();
        this.f6830a.d(null);
        this.f6830a = null;
    }
}
