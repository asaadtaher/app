package com.baseflow.geolocator;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.util.Log;
import java.util.HashMap;
import java.util.Map;
import tb.k;
import u1.n;
import u1.p;
import u1.r;
import u1.s;
import u1.x;

/* loaded from: classes.dex */
class j implements k.c {

    /* renamed from: a, reason: collision with root package name */
    private final v1.b f6848a;

    /* renamed from: b, reason: collision with root package name */
    private final u1.k f6849b;

    /* renamed from: c, reason: collision with root package name */
    private final u1.m f6850c;

    /* renamed from: d, reason: collision with root package name */
    final Map<String, p> f6851d = new HashMap();

    /* renamed from: e, reason: collision with root package name */
    private Context f6852e;

    /* renamed from: f, reason: collision with root package name */
    private Activity f6853f;

    /* renamed from: g, reason: collision with root package name */
    private tb.k f6854g;

    j(v1.b bVar, u1.k kVar, u1.m mVar) {
        this.f6848a = bVar;
        this.f6849b = kVar;
        this.f6850c = mVar;
    }

    private void h(final k.d dVar, Context context) {
        n nVarA = this.f6850c.a(context, new t1.a() { // from class: com.baseflow.geolocator.d
            @Override // t1.a
            public final void a(t1.b bVar) {
                j.i(dVar, bVar);
            }
        });
        if (nVarA != null) {
            dVar.a(Integer.valueOf(nVarA.ordinal()));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void i(k.d dVar, t1.b bVar) {
        dVar.b(bVar.toString(), bVar.b(), null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void j(boolean[] zArr, p pVar, String str, k.d dVar, Location location) {
        if (zArr[0]) {
            return;
        }
        zArr[0] = true;
        this.f6849b.f(pVar);
        this.f6851d.remove(str);
        dVar.a(r.b(location));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void k(boolean[] zArr, p pVar, String str, k.d dVar, t1.b bVar) {
        if (zArr[0]) {
            return;
        }
        zArr[0] = true;
        this.f6849b.f(pVar);
        this.f6851d.remove(str);
        dVar.b(bVar.toString(), bVar.b(), null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void l(k.d dVar, Location location) {
        dVar.a(r.b(location));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void m(k.d dVar, t1.b bVar) {
        dVar.b(bVar.toString(), bVar.b(), null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void n(k.d dVar, v1.a aVar) {
        dVar.a(Integer.valueOf(aVar.b()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void o(k.d dVar, t1.b bVar) {
        dVar.b(bVar.toString(), bVar.b(), null);
    }

    private void p(tb.j jVar, k.d dVar) {
        String str = (String) ((Map) jVar.f21945b).get("requestId");
        p pVar = this.f6851d.get(str);
        if (pVar != null) {
            pVar.c();
        }
        this.f6851d.remove(str);
        dVar.a(null);
    }

    private void q(k.d dVar) {
        try {
            dVar.a(Integer.valueOf(this.f6848a.a(this.f6852e).b()));
        } catch (t1.c unused) {
            t1.b bVar = t1.b.permissionDefinitionsNotFound;
            dVar.b(bVar.toString(), bVar.b(), null);
        }
    }

    private void r(tb.j jVar, final k.d dVar) {
        try {
            if (!this.f6848a.d(this.f6852e)) {
                t1.b bVar = t1.b.permissionDenied;
                dVar.b(bVar.toString(), bVar.b(), null);
                return;
            }
            Map map = (Map) jVar.f21945b;
            boolean zBooleanValue = map.get("forceLocationManager") != null ? ((Boolean) map.get("forceLocationManager")).booleanValue() : false;
            s sVarE = s.e(map);
            final String str = (String) map.get("requestId");
            final boolean[] zArr = {false};
            final p pVarA = this.f6849b.a(this.f6852e, zBooleanValue, sVarE);
            this.f6851d.put(str, pVarA);
            this.f6849b.e(pVarA, this.f6853f, new x() { // from class: com.baseflow.geolocator.g
                @Override // u1.x
                public final void a(Location location) {
                    this.f6841a.j(zArr, pVarA, str, dVar, location);
                }
            }, new t1.a() { // from class: com.baseflow.geolocator.c
                @Override // t1.a
                public final void a(t1.b bVar2) {
                    this.f6833a.k(zArr, pVarA, str, dVar, bVar2);
                }
            });
        } catch (t1.c unused) {
            t1.b bVar2 = t1.b.permissionDefinitionsNotFound;
            dVar.b(bVar2.toString(), bVar2.b(), null);
        }
    }

    private void s(tb.j jVar, final k.d dVar) {
        try {
            if (this.f6848a.d(this.f6852e)) {
                Boolean bool = (Boolean) jVar.a("forceLocationManager");
                this.f6849b.b(this.f6852e, bool != null && bool.booleanValue(), new x() { // from class: com.baseflow.geolocator.h
                    @Override // u1.x
                    public final void a(Location location) {
                        j.l(dVar, location);
                    }
                }, new t1.a() { // from class: com.baseflow.geolocator.f
                    @Override // t1.a
                    public final void a(t1.b bVar) {
                        j.m(dVar, bVar);
                    }
                });
            } else {
                t1.b bVar = t1.b.permissionDenied;
                dVar.b(bVar.toString(), bVar.b(), null);
            }
        } catch (t1.c unused) {
            t1.b bVar2 = t1.b.permissionDefinitionsNotFound;
            dVar.b(bVar2.toString(), bVar2.b(), null);
        }
    }

    private void t(k.d dVar) {
        this.f6849b.d(this.f6852e, new u1.c(dVar));
    }

    private void u(final k.d dVar) {
        try {
            this.f6848a.f(this.f6853f, new v1.c() { // from class: com.baseflow.geolocator.i
                @Override // v1.c
                public final void a(v1.a aVar) {
                    j.n(dVar, aVar);
                }
            }, new t1.a() { // from class: com.baseflow.geolocator.e
                @Override // t1.a
                public final void a(t1.b bVar) {
                    j.o(dVar, bVar);
                }
            });
        } catch (t1.c unused) {
            t1.b bVar = t1.b.permissionDefinitionsNotFound;
            dVar.b(bVar.toString(), bVar.b(), null);
        }
    }

    @Override // tb.k.c
    public void onMethodCall(tb.j jVar, k.d dVar) {
        boolean zB;
        String str = jVar.f21944a;
        str.hashCode();
        switch (str) {
            case "getCurrentPosition":
                r(jVar, dVar);
                return;
            case "getLastKnownPosition":
                s(jVar, dVar);
                return;
            case "openLocationSettings":
                zB = w1.a.b(this.f6852e);
                break;
            case "openAppSettings":
                zB = w1.a.a(this.f6852e);
                break;
            case "isLocationServiceEnabled":
                t(dVar);
                return;
            case "checkPermission":
                q(dVar);
                return;
            case "requestPermission":
                u(dVar);
                return;
            case "getLocationAccuracy":
                h(dVar, this.f6852e);
                return;
            case "cancelGetCurrentPosition":
                p(jVar, dVar);
                return;
            default:
                dVar.c();
                return;
        }
        dVar.a(Boolean.valueOf(zB));
    }

    void v(Activity activity) {
        this.f6853f = activity;
    }

    void w(Context context, tb.c cVar) {
        if (this.f6854g != null) {
            Log.w("MethodCallHandlerImpl", "Setting a method call handler before the last was disposed.");
            x();
        }
        tb.k kVar = new tb.k(cVar, "flutter.baseflow.com/geolocator_android");
        this.f6854g = kVar;
        kVar.e(this);
        this.f6852e = context;
    }

    void x() {
        tb.k kVar = this.f6854g;
        if (kVar == null) {
            Log.d("MethodCallHandlerImpl", "Tried to stop listening when no MethodChannel had been initialized.");
        } else {
            kVar.e(null);
            this.f6854g = null;
        }
    }
}
