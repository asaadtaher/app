package com.baseflow.geolocator;

import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.net.wifi.WifiManager;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import com.baseflow.geolocator.GeolocatorLocationService;
import tb.d;
import u1.p;
import u1.r;
import u1.s;
import u1.x;

/* loaded from: classes.dex */
public class GeolocatorLocationService extends Service {

    /* renamed from: i, reason: collision with root package name */
    private p f6814i;

    /* renamed from: a, reason: collision with root package name */
    private final String f6806a = "GeolocatorLocationService:Wakelock";

    /* renamed from: b, reason: collision with root package name */
    private final String f6807b = "GeolocatorLocationService:WifiLock";

    /* renamed from: c, reason: collision with root package name */
    private final a f6808c = new a(this);

    /* renamed from: d, reason: collision with root package name */
    private boolean f6809d = false;

    /* renamed from: e, reason: collision with root package name */
    private int f6810e = 0;

    /* renamed from: f, reason: collision with root package name */
    private int f6811f = 0;

    /* renamed from: g, reason: collision with root package name */
    private Activity f6812g = null;

    /* renamed from: h, reason: collision with root package name */
    private u1.k f6813h = null;

    /* renamed from: j, reason: collision with root package name */
    private PowerManager.WakeLock f6815j = null;

    /* renamed from: k, reason: collision with root package name */
    private WifiManager.WifiLock f6816k = null;

    /* renamed from: l, reason: collision with root package name */
    private u1.b f6817l = null;

    class a extends Binder {

        /* renamed from: c, reason: collision with root package name */
        private final GeolocatorLocationService f6818c;

        a(GeolocatorLocationService geolocatorLocationService) {
            this.f6818c = geolocatorLocationService;
        }

        public GeolocatorLocationService a() {
            return this.f6818c;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void i(d.b bVar, Location location) {
        bVar.a(r.b(location));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void j(d.b bVar, t1.b bVar2) {
        bVar.b(bVar2.toString(), bVar2.b(), null);
    }

    private void k(u1.d dVar) {
        WifiManager wifiManager;
        PowerManager powerManager;
        l();
        if (dVar.e() && (powerManager = (PowerManager) getApplicationContext().getSystemService("power")) != null) {
            PowerManager.WakeLock wakeLockNewWakeLock = powerManager.newWakeLock(1, "GeolocatorLocationService:Wakelock");
            this.f6815j = wakeLockNewWakeLock;
            wakeLockNewWakeLock.setReferenceCounted(false);
            this.f6815j.acquire();
        }
        if (!dVar.f() || (wifiManager = (WifiManager) getApplicationContext().getSystemService("wifi")) == null) {
            return;
        }
        WifiManager.WifiLock wifiLockCreateWifiLock = wifiManager.createWifiLock(3, "GeolocatorLocationService:WifiLock");
        this.f6816k = wifiLockCreateWifiLock;
        wifiLockCreateWifiLock.setReferenceCounted(false);
        this.f6816k.acquire();
    }

    private void l() {
        PowerManager.WakeLock wakeLock = this.f6815j;
        if (wakeLock != null && wakeLock.isHeld()) {
            this.f6815j.release();
            this.f6815j = null;
        }
        WifiManager.WifiLock wifiLock = this.f6816k;
        if (wifiLock == null || !wifiLock.isHeld()) {
            return;
        }
        this.f6816k.release();
        this.f6816k = null;
    }

    public boolean c(boolean z10) {
        return z10 ? this.f6811f == 1 : this.f6810e == 0;
    }

    public void d(u1.d dVar) {
        u1.b bVar = this.f6817l;
        if (bVar != null) {
            bVar.f(dVar, this.f6809d);
            k(dVar);
        }
    }

    public void e() {
        if (this.f6809d) {
            Log.d("FlutterGeolocator", "Stop service in foreground.");
            if (Build.VERSION.SDK_INT >= 24) {
                stopForeground(1);
            } else {
                stopForeground(true);
            }
            l();
            this.f6809d = false;
            this.f6817l = null;
        }
    }

    public void f(u1.d dVar) {
        if (this.f6817l != null) {
            Log.d("FlutterGeolocator", "Service already in foreground mode.");
            d(dVar);
        } else {
            Log.d("FlutterGeolocator", "Start service in foreground mode.");
            u1.b bVar = new u1.b(getApplicationContext(), "geolocator_channel_01", 75415, dVar);
            this.f6817l = bVar;
            bVar.d("Background Location");
            startForeground(75415, this.f6817l.a());
            this.f6809d = true;
        }
        k(dVar);
    }

    public void g() {
        this.f6810e++;
        Log.d("FlutterGeolocator", "Flutter engine connected. Connected engine count " + this.f6810e);
    }

    public void h() {
        this.f6810e--;
        Log.d("FlutterGeolocator", "Flutter engine disconnected. Connected engine count " + this.f6810e);
    }

    public void m(Activity activity) {
        this.f6812g = activity;
    }

    public void n(boolean z10, s sVar, final d.b bVar) {
        this.f6811f++;
        u1.k kVar = this.f6813h;
        if (kVar != null) {
            p pVarA = kVar.a(getApplicationContext(), Boolean.TRUE.equals(Boolean.valueOf(z10)), sVar);
            this.f6814i = pVarA;
            this.f6813h.e(pVarA, this.f6812g, new x() { // from class: s1.b
                @Override // u1.x
                public final void a(Location location) {
                    GeolocatorLocationService.i(bVar, location);
                }
            }, new t1.a() { // from class: s1.a
                @Override // t1.a
                public final void a(t1.b bVar2) {
                    GeolocatorLocationService.j(bVar, bVar2);
                }
            });
        }
    }

    public void o() {
        u1.k kVar;
        this.f6811f--;
        Log.d("FlutterGeolocator", "Stopping location service.");
        p pVar = this.f6814i;
        if (pVar == null || (kVar = this.f6813h) == null) {
            return;
        }
        kVar.f(pVar);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        Log.d("FlutterGeolocator", "Binding to location service.");
        return this.f6808c;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        Log.d("FlutterGeolocator", "Creating service.");
        this.f6813h = new u1.k();
    }

    @Override // android.app.Service
    public void onDestroy() {
        Log.d("FlutterGeolocator", "Destroying location service.");
        o();
        e();
        this.f6813h = null;
        this.f6817l = null;
        Log.d("FlutterGeolocator", "Destroyed location service.");
        super.onDestroy();
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i10, int i11) {
        return 1;
    }

    @Override // android.app.Service
    public boolean onUnbind(Intent intent) {
        Log.d("FlutterGeolocator", "Unbinding from location service.");
        return super.onUnbind(intent);
    }
}
