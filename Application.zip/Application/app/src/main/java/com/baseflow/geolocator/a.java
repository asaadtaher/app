package com.baseflow.geolocator;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.baseflow.geolocator.GeolocatorLocationService;
import kb.a;

/* loaded from: classes.dex */
public class a implements kb.a, lb.a {

    /* renamed from: d, reason: collision with root package name */
    private GeolocatorLocationService f6823d;

    /* renamed from: e, reason: collision with root package name */
    private j f6824e;

    /* renamed from: f, reason: collision with root package name */
    private m f6825f;

    /* renamed from: h, reason: collision with root package name */
    private b f6827h;

    /* renamed from: i, reason: collision with root package name */
    private lb.c f6828i;

    /* renamed from: g, reason: collision with root package name */
    private final ServiceConnection f6826g = new ServiceConnectionC0113a();

    /* renamed from: a, reason: collision with root package name */
    private final v1.b f6820a = new v1.b();

    /* renamed from: b, reason: collision with root package name */
    private final u1.k f6821b = new u1.k();

    /* renamed from: c, reason: collision with root package name */
    private final u1.m f6822c = new u1.m();

    /* renamed from: com.baseflow.geolocator.a$a, reason: collision with other inner class name */
    class ServiceConnectionC0113a implements ServiceConnection {
        ServiceConnectionC0113a() {
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            fb.b.a("FlutterGeolocator", "Geolocator foreground service connected");
            if (iBinder instanceof GeolocatorLocationService.a) {
                a.this.g(((GeolocatorLocationService.a) iBinder).a());
            }
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            fb.b.a("FlutterGeolocator", "Geolocator foreground service disconnected");
            if (a.this.f6823d != null) {
                a.this.f6823d.m(null);
                a.this.f6823d = null;
            }
        }
    }

    private void d(Context context) {
        context.bindService(new Intent(context, (Class<?>) GeolocatorLocationService.class), this.f6826g, 1);
    }

    private void e() {
        lb.c cVar = this.f6828i;
        if (cVar != null) {
            cVar.e(this.f6821b);
            this.f6828i.f(this.f6820a);
        }
    }

    private void f() {
        fb.b.a("FlutterGeolocator", "Disposing Geolocator services");
        j jVar = this.f6824e;
        if (jVar != null) {
            jVar.x();
            this.f6824e.v(null);
            this.f6824e = null;
        }
        m mVar = this.f6825f;
        if (mVar != null) {
            mVar.k();
            this.f6825f.i(null);
            this.f6825f = null;
        }
        b bVar = this.f6827h;
        if (bVar != null) {
            bVar.d(null);
            this.f6827h.f();
            this.f6827h = null;
        }
        GeolocatorLocationService geolocatorLocationService = this.f6823d;
        if (geolocatorLocationService != null) {
            geolocatorLocationService.m(null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void g(GeolocatorLocationService geolocatorLocationService) {
        fb.b.a("FlutterGeolocator", "Initializing Geolocator services");
        this.f6823d = geolocatorLocationService;
        geolocatorLocationService.g();
        m mVar = this.f6825f;
        if (mVar != null) {
            mVar.i(geolocatorLocationService);
        }
    }

    private void h() {
        lb.c cVar = this.f6828i;
        if (cVar != null) {
            cVar.a(this.f6821b);
            this.f6828i.b(this.f6820a);
        }
    }

    private void i(Context context) {
        GeolocatorLocationService geolocatorLocationService = this.f6823d;
        if (geolocatorLocationService != null) {
            geolocatorLocationService.h();
        }
        context.unbindService(this.f6826g);
    }

    @Override // lb.a
    public void onAttachedToActivity(lb.c cVar) {
        fb.b.a("FlutterGeolocator", "Attaching Geolocator to activity");
        this.f6828i = cVar;
        h();
        j jVar = this.f6824e;
        if (jVar != null) {
            jVar.v(cVar.c());
        }
        m mVar = this.f6825f;
        if (mVar != null) {
            mVar.h(cVar.c());
        }
        GeolocatorLocationService geolocatorLocationService = this.f6823d;
        if (geolocatorLocationService != null) {
            geolocatorLocationService.m(this.f6828i.c());
        }
    }

    @Override // kb.a
    public void onAttachedToEngine(a.b bVar) {
        j jVar = new j(this.f6820a, this.f6821b, this.f6822c);
        this.f6824e = jVar;
        jVar.w(bVar.a(), bVar.b());
        m mVar = new m(this.f6820a);
        this.f6825f = mVar;
        mVar.j(bVar.a(), bVar.b());
        b bVar2 = new b();
        this.f6827h = bVar2;
        bVar2.d(bVar.a());
        this.f6827h.e(bVar.a(), bVar.b());
        d(bVar.a());
    }

    @Override // lb.a
    public void onDetachedFromActivity() {
        fb.b.a("FlutterGeolocator", "Detaching Geolocator from activity");
        e();
        j jVar = this.f6824e;
        if (jVar != null) {
            jVar.v(null);
        }
        m mVar = this.f6825f;
        if (mVar != null) {
            mVar.h(null);
        }
        GeolocatorLocationService geolocatorLocationService = this.f6823d;
        if (geolocatorLocationService != null) {
            geolocatorLocationService.m(null);
        }
        if (this.f6828i != null) {
            this.f6828i = null;
        }
    }

    @Override // lb.a
    public void onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity();
    }

    @Override // kb.a
    public void onDetachedFromEngine(a.b bVar) {
        i(bVar.a());
        f();
    }

    @Override // lb.a
    public void onReattachedToActivityForConfigChanges(lb.c cVar) {
        onAttachedToActivity(cVar);
    }
}
