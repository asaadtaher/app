package com.baseflow.geolocator;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.util.Log;
import java.util.Map;
import tb.d;
import u1.p;
import u1.r;
import u1.s;
import u1.x;

/* loaded from: classes.dex */
class m implements d.InterfaceC0377d {

    /* renamed from: a, reason: collision with root package name */
    private final v1.b f6857a;

    /* renamed from: b, reason: collision with root package name */
    private tb.d f6858b;

    /* renamed from: c, reason: collision with root package name */
    private Context f6859c;

    /* renamed from: d, reason: collision with root package name */
    private Activity f6860d;

    /* renamed from: e, reason: collision with root package name */
    private GeolocatorLocationService f6861e;

    /* renamed from: f, reason: collision with root package name */
    private u1.k f6862f = new u1.k();

    /* renamed from: g, reason: collision with root package name */
    private p f6863g;

    public m(v1.b bVar) {
        this.f6857a = bVar;
    }

    private void e(boolean z10) {
        u1.k kVar;
        Log.e("FlutterGeolocator", "Geolocator position updates stopped");
        GeolocatorLocationService geolocatorLocationService = this.f6861e;
        if (geolocatorLocationService == null || !geolocatorLocationService.c(z10)) {
            Log.e("FlutterGeolocator", "There is still another flutter engine connected, not stopping location service");
        } else {
            this.f6861e.o();
            this.f6861e.e();
        }
        p pVar = this.f6863g;
        if (pVar == null || (kVar = this.f6862f) == null) {
            return;
        }
        kVar.f(pVar);
        this.f6863g = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void f(d.b bVar, Location location) {
        bVar.a(r.b(location));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void g(d.b bVar, t1.b bVar2) {
        bVar.b(bVar2.toString(), bVar2.b(), null);
    }

    @Override // tb.d.InterfaceC0377d
    public void a(Object obj, final d.b bVar) {
        try {
            if (!this.f6857a.d(this.f6859c)) {
                t1.b bVar2 = t1.b.permissionDenied;
                bVar.b(bVar2.toString(), bVar2.b(), null);
                return;
            }
            if (this.f6861e == null) {
                Log.e("FlutterGeolocator", "Location background service has not started correctly");
                return;
            }
            Map map = (Map) obj;
            boolean zBooleanValue = false;
            if (map != null && map.get("forceLocationManager") != null) {
                zBooleanValue = ((Boolean) map.get("forceLocationManager")).booleanValue();
            }
            s sVarE = s.e(map);
            u1.d dVarH = map != null ? u1.d.h((Map) map.get("foregroundNotificationConfig")) : null;
            if (dVarH != null) {
                Log.e("FlutterGeolocator", "Geolocator position updates started using Android foreground service");
                this.f6861e.n(zBooleanValue, sVarE, bVar);
                this.f6861e.f(dVarH);
            } else {
                Log.e("FlutterGeolocator", "Geolocator position updates started");
                p pVarA = this.f6862f.a(this.f6859c, Boolean.TRUE.equals(Boolean.valueOf(zBooleanValue)), sVarE);
                this.f6863g = pVarA;
                this.f6862f.e(pVarA, this.f6860d, new x() { // from class: com.baseflow.geolocator.l
                    @Override // u1.x
                    public final void a(Location location) {
                        m.f(bVar, location);
                    }
                }, new t1.a() { // from class: com.baseflow.geolocator.k
                    @Override // t1.a
                    public final void a(t1.b bVar3) {
                        m.g(bVar, bVar3);
                    }
                });
            }
        } catch (t1.c unused) {
            t1.b bVar3 = t1.b.permissionDefinitionsNotFound;
            bVar.b(bVar3.toString(), bVar3.b(), null);
        }
    }

    @Override // tb.d.InterfaceC0377d
    public void b(Object obj) {
        e(true);
    }

    public void h(Activity activity) {
        if (activity == null && this.f6863g != null && this.f6858b != null) {
            k();
        }
        this.f6860d = activity;
    }

    public void i(GeolocatorLocationService geolocatorLocationService) {
        this.f6861e = geolocatorLocationService;
    }

    void j(Context context, tb.c cVar) {
        if (this.f6858b != null) {
            Log.w("FlutterGeolocator", "Setting a event call handler before the last was disposed.");
            k();
        }
        tb.d dVar = new tb.d(cVar, "flutter.baseflow.com/geolocator_updates_android");
        this.f6858b = dVar;
        dVar.d(this);
        this.f6859c = context;
    }

    void k() {
        if (this.f6858b == null) {
            Log.d("FlutterGeolocator", "Tried to stop listening when no MethodChannel had been initialized.");
            return;
        }
        e(false);
        this.f6858b.d(null);
        this.f6858b = null;
    }
}
