package com.facebook;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import b2.f0;
import b2.i;
import b2.j;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;
import r2.l0;

/* loaded from: classes.dex */
public final class AuthenticationTokenManager {

    /* renamed from: d, reason: collision with root package name */
    public static final a f6896d = new a(null);

    /* renamed from: e, reason: collision with root package name */
    private static AuthenticationTokenManager f6897e;

    /* renamed from: a, reason: collision with root package name */
    private final d1.a f6898a;

    /* renamed from: b, reason: collision with root package name */
    private final j f6899b;

    /* renamed from: c, reason: collision with root package name */
    private i f6900c;

    public static final class CurrentAuthenticationTokenChangedBroadcastReceiver extends BroadcastReceiver {
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            m.g(context, "context");
            m.g(intent, "intent");
        }
    }

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }

        public final AuthenticationTokenManager a() {
            AuthenticationTokenManager authenticationTokenManager;
            AuthenticationTokenManager authenticationTokenManager2 = AuthenticationTokenManager.f6897e;
            if (authenticationTokenManager2 != null) {
                return authenticationTokenManager2;
            }
            synchronized (this) {
                authenticationTokenManager = AuthenticationTokenManager.f6897e;
                if (authenticationTokenManager == null) {
                    f0 f0Var = f0.f5388a;
                    d1.a aVarB = d1.a.b(f0.l());
                    m.f(aVarB, "getInstance(applicationContext)");
                    AuthenticationTokenManager authenticationTokenManager3 = new AuthenticationTokenManager(aVarB, new j());
                    a aVar = AuthenticationTokenManager.f6896d;
                    AuthenticationTokenManager.f6897e = authenticationTokenManager3;
                    authenticationTokenManager = authenticationTokenManager3;
                }
            }
            return authenticationTokenManager;
        }
    }

    public AuthenticationTokenManager(d1.a localBroadcastManager, j authenticationTokenCache) {
        m.g(localBroadcastManager, "localBroadcastManager");
        m.g(authenticationTokenCache, "authenticationTokenCache");
        this.f6898a = localBroadcastManager;
        this.f6899b = authenticationTokenCache;
    }

    private final void d(i iVar, i iVar2) {
        f0 f0Var = f0.f5388a;
        Intent intent = new Intent(f0.l(), (Class<?>) CurrentAuthenticationTokenChangedBroadcastReceiver.class);
        intent.setAction("com.facebook.sdk.ACTION_CURRENT_AUTHENTICATION_TOKEN_CHANGED");
        intent.putExtra("com.facebook.sdk.EXTRA_OLD_AUTHENTICATION_TOKEN", iVar);
        intent.putExtra("com.facebook.sdk.EXTRA_NEW_AUTHENTICATION_TOKEN", iVar2);
        this.f6898a.d(intent);
    }

    private final void f(i iVar, boolean z10) {
        i iVarC = c();
        this.f6900c = iVar;
        if (z10) {
            j jVar = this.f6899b;
            if (iVar != null) {
                jVar.b(iVar);
            } else {
                jVar.a();
                l0 l0Var = l0.f20174a;
                f0 f0Var = f0.f5388a;
                l0.i(f0.l());
            }
        }
        l0 l0Var2 = l0.f20174a;
        if (l0.e(iVarC, iVar)) {
            return;
        }
        d(iVarC, iVar);
    }

    public final i c() {
        return this.f6900c;
    }

    public final void e(i iVar) {
        f(iVar, true);
    }
}
