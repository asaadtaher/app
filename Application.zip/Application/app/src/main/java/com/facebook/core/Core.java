package com.facebook.core;

/* loaded from: classes.dex */
public final class Core {
}
