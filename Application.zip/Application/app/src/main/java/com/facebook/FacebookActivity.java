package com.facebook;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.s;
import b2.f0;
import b3.y;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;
import p2.b;
import p2.c;
import r2.e0;
import r2.i;
import r2.l0;

/* loaded from: classes.dex */
public class FacebookActivity extends s {

    /* renamed from: u, reason: collision with root package name */
    public static final a f6918u = new a(null);

    /* renamed from: v, reason: collision with root package name */
    private static final String f6919v = FacebookActivity.class.getName();

    /* renamed from: t, reason: collision with root package name */
    private Fragment f6920t;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }
    }

    private final void w() {
        Intent requestIntent = getIntent();
        e0 e0Var = e0.f20120a;
        m.f(requestIntent, "requestIntent");
        b2.s sVarQ = e0.q(e0.u(requestIntent));
        Intent intent = getIntent();
        m.f(intent, "intent");
        setResult(0, e0.m(intent, null, sVarQ));
        finish();
    }

    @Override // androidx.fragment.app.s, android.app.Activity
    public void dump(String prefix, FileDescriptor fileDescriptor, PrintWriter writer, String[] strArr) {
        if (w2.a.d(this)) {
            return;
        }
        try {
            m.g(prefix, "prefix");
            m.g(writer, "writer");
            z2.a aVarA = z2.a.f24941a.a();
            if (m.b(aVarA == null ? null : Boolean.valueOf(aVarA.a(prefix, writer, strArr)), Boolean.TRUE)) {
                return;
            }
            super.dump(prefix, fileDescriptor, writer, strArr);
        } catch (Throwable th) {
            w2.a.b(th, this);
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        m.g(newConfig, "newConfig");
        super.onConfigurationChanged(newConfig);
        Fragment fragment = this.f6920t;
        if (fragment == null) {
            return;
        }
        fragment.onConfigurationChanged(newConfig);
    }

    @Override // androidx.fragment.app.s, androidx.activity.ComponentActivity, androidx.core.app.i, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = getIntent();
        f0 f0Var = f0.f5388a;
        if (!f0.F()) {
            l0 l0Var = l0.f20174a;
            l0.e0(f6919v, "Facebook SDK not initialized. Make sure you call sdkInitialize inside your Application's onCreate method.");
            Context applicationContext = getApplicationContext();
            m.f(applicationContext, "applicationContext");
            f0.M(applicationContext);
        }
        setContentView(c.f18832a);
        if (m.b("PassThrough", intent.getAction())) {
            w();
        } else {
            this.f6920t = v();
        }
    }

    public final Fragment u() {
        return this.f6920t;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v5, types: [androidx.fragment.app.Fragment, androidx.fragment.app.m, r2.i] */
    protected Fragment v() {
        y yVar;
        Intent intent = getIntent();
        FragmentManager supportFragmentManager = getSupportFragmentManager();
        m.f(supportFragmentManager, "supportFragmentManager");
        Fragment fragmentK0 = supportFragmentManager.k0("SingleFragment");
        if (fragmentK0 != null) {
            return fragmentK0;
        }
        if (m.b("FacebookDialogFragment", intent.getAction())) {
            iVar = new i();            iVar.setRetainInstance(true);
            iVar.show(supportFragmentManager, "SingleFragment");
            yVar = iVar;
        } else {
            y yVar2 = new y();
            yVar2.setRetainInstance(true);
            supportFragmentManager.p().b(b.f18828c, yVar2, "SingleFragment").g();
            yVar = yVar2;
        }
        return yVar;
    }
}
