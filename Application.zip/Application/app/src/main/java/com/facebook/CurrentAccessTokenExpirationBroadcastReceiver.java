package com.facebook;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import b2.f0;
import b2.g;
import kotlin.jvm.internal.m;

/* loaded from: classes.dex */
public final class CurrentAccessTokenExpirationBroadcastReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        m.g(context, "context");
        m.g(intent, "intent");
        if (m.b("com.facebook.sdk.ACTION_CURRENT_ACCESS_TOKEN_CHANGED", intent.getAction())) {
            f0 f0Var = f0.f5388a;
            if (f0.F()) {
                g.f5412f.e().g();
            }
        }
    }
}
