package com.facebook;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;

/* loaded from: classes.dex */
public final class CustomTabActivity extends Activity {

    /* renamed from: b, reason: collision with root package name */
    public static final a f6901b = new a(null);

    /* renamed from: c, reason: collision with root package name */
    public static final String f6902c = m.n(CustomTabActivity.class.getSimpleName(), ".action_customTabRedirect");

    /* renamed from: d, reason: collision with root package name */
    public static final String f6903d = m.n(CustomTabActivity.class.getSimpleName(), ".action_destroy");

    /* renamed from: a, reason: collision with root package name */
    private BroadcastReceiver f6904a;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }
    }

    public static final class b extends BroadcastReceiver {
        b() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            m.g(context, "context");
            m.g(intent, "intent");
            CustomTabActivity.this.finish();
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i10, int i11, Intent intent) {
        super.onActivityResult(i10, i11, intent);
        if (i11 == 0) {
            Intent intent2 = new Intent(f6902c);
            intent2.putExtra(CustomTabMainActivity.f6910g, getIntent().getDataString());
            d1.a.b(this).d(intent2);
            b bVar = new b();
            d1.a.b(this).c(bVar, new IntentFilter(f6903d));
            this.f6904a = bVar;
        }
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = new Intent(this, (Class<?>) CustomTabMainActivity.class);
        intent.setAction(f6902c);
        intent.putExtra(CustomTabMainActivity.f6910g, getIntent().getDataString());
        intent.addFlags(603979776);
        startActivityForResult(intent, 2);
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        BroadcastReceiver broadcastReceiver = this.f6904a;
        if (broadcastReceiver != null) {
            d1.a.b(this).e(broadcastReceiver);
        }
        super.onDestroy();
    }
}
