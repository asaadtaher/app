package com.facebook;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import b3.i0;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;
import r2.e;
import r2.e0;
import r2.l0;
import r2.x;

/* loaded from: classes.dex */
public final class CustomTabMainActivity extends Activity {

    /* renamed from: c, reason: collision with root package name */
    public static final a f6906c = new a(null);

    /* renamed from: d, reason: collision with root package name */
    public static final String f6907d = m.n(CustomTabMainActivity.class.getSimpleName(), ".extra_action");

    /* renamed from: e, reason: collision with root package name */
    public static final String f6908e = m.n(CustomTabMainActivity.class.getSimpleName(), ".extra_params");

    /* renamed from: f, reason: collision with root package name */
    public static final String f6909f = m.n(CustomTabMainActivity.class.getSimpleName(), ".extra_chromePackage");

    /* renamed from: g, reason: collision with root package name */
    public static final String f6910g = m.n(CustomTabMainActivity.class.getSimpleName(), ".extra_url");

    /* renamed from: h, reason: collision with root package name */
    public static final String f6911h = m.n(CustomTabMainActivity.class.getSimpleName(), ".extra_targetApp");

    /* renamed from: i, reason: collision with root package name */
    public static final String f6912i = m.n(CustomTabMainActivity.class.getSimpleName(), ".action_refresh");

    /* renamed from: j, reason: collision with root package name */
    public static final String f6913j = m.n(CustomTabMainActivity.class.getSimpleName(), ".no_activity_exception");

    /* renamed from: a, reason: collision with root package name */
    private boolean f6914a = true;

    /* renamed from: b, reason: collision with root package name */
    private BroadcastReceiver f6915b;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final Bundle b(String str) {
            Uri uri = Uri.parse(str);
            l0 l0Var = l0.f20174a;
            Bundle bundleJ0 = l0.j0(uri.getQuery());
            bundleJ0.putAll(l0.j0(uri.getFragment()));
            return bundleJ0;
        }
    }

    public /* synthetic */ class b {

        /* renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f6916a;

        static {
            int[] iArr = new int[i0.valuesCustom().length];
            iArr[i0.INSTAGRAM.ordinal()] = 1;
            f6916a = iArr;
        }
    }

    public static final class c extends BroadcastReceiver {
        c() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            m.g(context, "context");
            m.g(intent, "intent");
            Intent intent2 = new Intent(CustomTabMainActivity.this, (Class<?>) CustomTabMainActivity.class);
            intent2.setAction(CustomTabMainActivity.f6912i);
            String str = CustomTabMainActivity.f6910g;
            intent2.putExtra(str, intent.getStringExtra(str));
            intent2.addFlags(603979776);
            CustomTabMainActivity.this.startActivity(intent2);
        }
    }

    private final void a(int i10, Intent intent) {
        BroadcastReceiver broadcastReceiver = this.f6915b;
        if (broadcastReceiver != null) {
            d1.a.b(this).e(broadcastReceiver);
        }
        if (intent != null) {
            String stringExtra = intent.getStringExtra(f6910g);
            Bundle bundleB = stringExtra != null ? f6906c.b(stringExtra) : new Bundle();
            e0 e0Var = e0.f20120a;
            Intent intent2 = getIntent();
            m.f(intent2, "intent");
            Intent intentM = e0.m(intent2, bundleB, null);
            if (intentM != null) {
                intent = intentM;
            }
        } else {
            e0 e0Var2 = e0.f20120a;
            Intent intent3 = getIntent();
            m.f(intent3, "intent");
            intent = e0.m(intent3, null, null);
        }
        setResult(i10, intent);
        finish();
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        String stringExtra;
        super.onCreate(bundle);
        String str = CustomTabActivity.f6902c;
        if (m.b(str, getIntent().getAction())) {
            setResult(0);
        } else {
            if (bundle != null || (stringExtra = getIntent().getStringExtra(f6907d)) == null) {
                return;
            }
            Bundle bundleExtra = getIntent().getBundleExtra(f6908e);
            boolean zA = (b.f6916a[i0.f5688b.a(getIntent().getStringExtra(f6911h)).ordinal()] == 1 ? new x(stringExtra, bundleExtra) : new e(stringExtra, bundleExtra)).a(this, getIntent().getStringExtra(f6909f));
            this.f6914a = false;
            if (zA) {
                c cVar = new c();
                this.f6915b = cVar;
                d1.a.b(this).c(cVar, new IntentFilter(str));
                return;
            }
            setResult(0, getIntent().putExtra(f6913j, true));
        }
        finish();
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        m.g(intent, "intent");
        super.onNewIntent(intent);
        if (m.b(f6912i, intent.getAction())) {
            d1.a.b(this).d(new Intent(CustomTabActivity.f6903d));
        } else if (!m.b(CustomTabActivity.f6902c, intent.getAction())) {
            return;
        }
        a(-1, intent);
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        if (this.f6914a) {
            a(0, null);
        }
        this.f6914a = true;
    }
}
