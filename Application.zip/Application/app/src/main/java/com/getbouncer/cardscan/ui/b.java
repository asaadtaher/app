package com.getbouncer.cardscan.ui;

import android.content.Context;
import android.content.Intent;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultRegistry;
import com.getbouncer.cardscan.ui.c;
import e3.f;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.m;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: b, reason: collision with root package name */
    public static final c f7008b = new c(null);

    /* renamed from: c, reason: collision with root package name */
    private static final C0120b f7009c = new C0120b();

    /* renamed from: a, reason: collision with root package name */
    private androidx.activity.result.c f7010a;

    public interface a {
        void a(com.getbouncer.cardscan.ui.c cVar);
    }

    /* renamed from: com.getbouncer.cardscan.ui.b$b, reason: collision with other inner class name */
    public static final class C0120b extends f.a {
        C0120b() {
        }

        @Override // f.a
        /* renamed from: d, reason: merged with bridge method [inline-methods] */
        public Intent a(Context context, f input) {
            m.g(context, "context");
            m.g(input, "input");
            return b.f7008b.a(context, input);
        }

        @Override // f.a
        /* renamed from: e, reason: merged with bridge method [inline-methods] */
        public com.getbouncer.cardscan.ui.c c(int i10, Intent intent) {
            return b.f7008b.e(intent);
        }
    }

    public static final class c {

        /* synthetic */ class a implements androidx.activity.result.b, h {

            /* renamed from: a, reason: collision with root package name */
            final /* synthetic */ a f7011a;

            a(a aVar) {
                this.f7011a = aVar;
            }

            @Override // kotlin.jvm.internal.h
            public final tc.c a() {
                return new k(1, this.f7011a, a.class, "onCardScanSheetResult", "onCardScanSheetResult(Lcom/getbouncer/cardscan/ui/CardScanSheetResult;)V", 0);
            }

            @Override // androidx.activity.result.b
            /* renamed from: c, reason: merged with bridge method [inline-methods] */
            public final void b(com.getbouncer.cardscan.ui.c p02) {
                m.g(p02, "p0");
                this.f7011a.a(p02);
            }

            public final boolean equals(Object obj) {
                if ((obj instanceof androidx.activity.result.b) && (obj instanceof h)) {
                    return m.b(a(), ((h) obj).a());
                }
                return false;
            }

            public final int hashCode() {
                return a().hashCode();
            }
        }

        private c() {
        }

        public /* synthetic */ c(g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final Intent a(Context context, f fVar) {
            Intent intentPutExtra = new Intent(context, (Class<?>) CardScanActivity.class).putExtra("request", fVar);
            m.f(intentPutExtra, "putExtra(...)");
            return intentPutExtra;
        }

        public static /* synthetic */ b d(c cVar, ComponentActivity componentActivity, a aVar, ActivityResultRegistry activityResultRegistry, int i10, Object obj) {
            if ((i10 & 4) != 0) {
                activityResultRegistry = componentActivity.getActivityResultRegistry();
                m.f(activityResultRegistry, "<get-activityResultRegistry>(...)");
            }
            return cVar.c(componentActivity, aVar, activityResultRegistry);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final com.getbouncer.cardscan.ui.c e(Intent intent) {
            com.getbouncer.cardscan.ui.c cVar = intent != null ? (com.getbouncer.cardscan.ui.c) intent.getParcelableExtra("result") : null;
            return cVar == null ? new c.C0122c(new g3.a("No data in the result intent")) : cVar;
        }

        public final b c(ComponentActivity from, a cardScanResultCallback, ActivityResultRegistry registry) {
            m.g(from, "from");
            m.g(cardScanResultCallback, "cardScanResultCallback");
            m.g(registry, "registry");
            b bVar = new b(null);
            androidx.activity.result.c cVarRegisterForActivityResult = from.registerForActivityResult(b.f7009c, registry, new a(cardScanResultCallback));
            m.f(cVarRegisterForActivityResult, "registerForActivityResult(...)");
            bVar.f7010a = cVarRegisterForActivityResult;
            return bVar;
        }
    }

    private b() {
    }

    public /* synthetic */ b(g gVar) {
        this();
    }

    public final void c(boolean z10, boolean z11, boolean z12) {
        androidx.activity.result.c cVar = this.f7010a;
        if (cVar == null) {
            m.u("launcher");
            cVar = null;
        }
        cVar.a(new f(z10, z11, z12));
    }
}
