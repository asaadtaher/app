package com.getbouncer.cardscan.ui.result;

import androidx.annotation.Keep;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.getbouncer.cardscan.ui.result.a;
import com.getbouncer.scan.framework.ResultAggregator;
import e3.g;
import e3.h;
import ed.p;
import f3.b;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import kotlin.coroutines.jvm.internal.d;
import kotlin.jvm.internal.m;
import nd.k0;
import p3.l;
import q3.f;
import tc.q;
import tc.x;
import u3.k;

/* loaded from: classes.dex */
public final class MainLoopAggregator extends ResultAggregator<b.C0209b, com.getbouncer.cardscan.ui.result.a, b.c, InterimResult, FinalResult> {

    /* renamed from: i, reason: collision with root package name */
    private final b f7015i;

    @Keep
    public static final class FinalResult {
        private final l averageFrameRate;
        private final String pan;
        private final Map<h, List<g>> savedFrames;

        /* JADX WARN: Multi-variable type inference failed */
        public FinalResult(String pan, Map<h, ? extends List<g>> savedFrames, l averageFrameRate) {
            m.g(pan, "pan");
            m.g(savedFrames, "savedFrames");
            m.g(averageFrameRate, "averageFrameRate");
            this.pan = pan;
            this.savedFrames = savedFrames;
            this.averageFrameRate = averageFrameRate;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ FinalResult copy$default(FinalResult finalResult, String str, Map map, l lVar, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = finalResult.pan;
            }
            if ((i10 & 2) != 0) {
                map = finalResult.savedFrames;
            }
            if ((i10 & 4) != 0) {
                lVar = finalResult.averageFrameRate;
            }
            return finalResult.copy(str, map, lVar);
        }

        public final String component1() {
            return this.pan;
        }

        public final Map<h, List<g>> component2() {
            return this.savedFrames;
        }

        public final l component3() {
            return this.averageFrameRate;
        }

        public final FinalResult copy(String pan, Map<h, ? extends List<g>> savedFrames, l averageFrameRate) {
            m.g(pan, "pan");
            m.g(savedFrames, "savedFrames");
            m.g(averageFrameRate, "averageFrameRate");
            return new FinalResult(pan, savedFrames, averageFrameRate);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof FinalResult)) {
                return false;
            }
            FinalResult finalResult = (FinalResult) obj;
            return m.b(this.pan, finalResult.pan) && m.b(this.savedFrames, finalResult.savedFrames) && m.b(this.averageFrameRate, finalResult.averageFrameRate);
        }

        public final l getAverageFrameRate() {
            return this.averageFrameRate;
        }

        public final String getPan() {
            return this.pan;
        }

        public final Map<h, List<g>> getSavedFrames() {
            return this.savedFrames;
        }

        public int hashCode() {
            return (((this.pan.hashCode() * 31) + this.savedFrames.hashCode()) * 31) + this.averageFrameRate.hashCode();
        }

        public String toString() {
            return "FinalResult(pan=" + this.pan + ", savedFrames=" + this.savedFrames + ", averageFrameRate=" + this.averageFrameRate + ')';
        }
    }

    @Keep
    public static final class InterimResult {
        private final b.c analyzerResult;
        private final b.C0209b frame;
        private final com.getbouncer.cardscan.ui.result.a state;

        public InterimResult(b.c analyzerResult, b.C0209b frame, com.getbouncer.cardscan.ui.result.a state) {
            m.g(analyzerResult, "analyzerResult");
            m.g(frame, "frame");
            m.g(state, "state");
            this.analyzerResult = analyzerResult;
            this.frame = frame;
            this.state = state;
        }

        public static /* synthetic */ InterimResult copy$default(InterimResult interimResult, b.c cVar, b.C0209b c0209b, com.getbouncer.cardscan.ui.result.a aVar, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                cVar = interimResult.analyzerResult;
            }
            if ((i10 & 2) != 0) {
                c0209b = interimResult.frame;
            }
            if ((i10 & 4) != 0) {
                aVar = interimResult.state;
            }
            return interimResult.copy(cVar, c0209b, aVar);
        }

        public final b.c component1() {
            return this.analyzerResult;
        }

        public final b.C0209b component2() {
            return this.frame;
        }

        public final com.getbouncer.cardscan.ui.result.a component3() {
            return this.state;
        }

        public final InterimResult copy(b.c analyzerResult, b.C0209b frame, com.getbouncer.cardscan.ui.result.a state) {
            m.g(analyzerResult, "analyzerResult");
            m.g(frame, "frame");
            m.g(state, "state");
            return new InterimResult(analyzerResult, frame, state);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof InterimResult)) {
                return false;
            }
            InterimResult interimResult = (InterimResult) obj;
            return m.b(this.analyzerResult, interimResult.analyzerResult) && m.b(this.frame, interimResult.frame) && m.b(this.state, interimResult.state);
        }

        public final b.c getAnalyzerResult() {
            return this.analyzerResult;
        }

        public final b.C0209b getFrame() {
            return this.frame;
        }

        public final com.getbouncer.cardscan.ui.result.a getState() {
            return this.state;
        }

        public int hashCode() {
            return (((this.analyzerResult.hashCode() * 31) + this.frame.hashCode()) * 31) + this.state.hashCode();
        }

        public String toString() {
            return "InterimResult(analyzerResult=" + this.analyzerResult + ", frame=" + this.frame + ", state=" + this.state + ')';
        }
    }

    static final class a extends d {

        /* renamed from: a, reason: collision with root package name */
        Object f7016a;

        /* renamed from: b, reason: collision with root package name */
        Object f7017b;

        /* renamed from: c, reason: collision with root package name */
        Object f7018c;

        /* renamed from: d, reason: collision with root package name */
        Object f7019d;

        /* renamed from: e, reason: collision with root package name */
        /* synthetic */ Object f7020e;

        /* renamed from: g, reason: collision with root package name */
        int f7022g;

        a(wc.d dVar) {
            super(dVar);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final Object invokeSuspend(Object obj) {
            this.f7020e = obj;
            this.f7022g |= LinearLayoutManager.INVALID_OFFSET;
            return MainLoopAggregator.this.k(null, null, this);
        }
    }

    public static final class b extends f {
        b() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // q3.f
        /* renamed from: g, reason: merged with bridge method [inline-methods] */
        public int a(h savedFrameIdentifier) {
            m.g(savedFrameIdentifier, "savedFrameIdentifier");
            return 6;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // q3.f
        /* renamed from: h, reason: merged with bridge method [inline-methods] */
        public h b(g frame, InterimResult metaData) throws IOException {
            m.g(frame, "frame");
            m.g(metaData, "metaData");
            boolean zB = m.b(metaData.getAnalyzerResult().c(), Boolean.TRUE);
            k.d dVarB = metaData.getAnalyzerResult().b();
            boolean zD = t3.h.d(dVarB != null ? dVarB.b() : null);
            if (zB || zD) {
                return new h(zB, zD);
            }
            return null;
        }
    }

    static final class c extends kotlin.coroutines.jvm.internal.l implements p {

        /* renamed from: a, reason: collision with root package name */
        int f7023a;

        c(wc.d dVar) {
            super(2, dVar);
        }

        @Override // ed.p
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Object invoke(k0 k0Var, wc.d dVar) {
            return ((c) create(k0Var, dVar)).invokeSuspend(x.f21992a);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final wc.d create(Object obj, wc.d dVar) {
            return MainLoopAggregator.this.new c(dVar);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final Object invokeSuspend(Object obj) throws Throwable {
            Object objC = xc.d.c();
            int i10 = this.f7023a;
            if (i10 == 0) {
                q.b(obj);
                b bVar = MainLoopAggregator.this.f7015i;
                this.f7023a = 1;
                if (bVar.d(this) == objC) {
                    return objC;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                q.b(obj);
            }
            return x.f21992a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainLoopAggregator(k3.a listener) {
        super(listener, new a.c());
        m.g(listener, "listener");
        this.f7015i = new b();
    }

    @Override // com.getbouncer.scan.framework.ResultAggregator, k3.u
    protected void d() {
        super.d();
        nd.h.b(null, new c(null), 1, null);
    }

    /* JADX WARN: Removed duplicated region for block: B:65:0x012f  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x0163  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0019  */
    @Override // com.getbouncer.scan.framework.ResultAggregator
    /* renamed from: o, reason: merged with bridge method [inline-methods] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object k(f3.b.C0209b r18, f3.b.c r19, wc.d r20) throws java.lang.Throwable {
        /*
            Method dump skipped, instructions count: 367
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getbouncer.cardscan.ui.result.MainLoopAggregator.k(f3.b$b, f3.b$c, wc.d):java.lang.Object");
    }
}
