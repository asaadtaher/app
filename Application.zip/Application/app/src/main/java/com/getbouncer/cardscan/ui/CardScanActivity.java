package com.getbouncer.cardscan.ui;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.getbouncer.cardscan.ui.c;
import com.payment.paymentsdk.R;
import ed.p;
import f3.a;
import java.util.Collection;
import kotlin.jvm.internal.m;
import kotlin.jvm.internal.n;
import nd.f0;
import nd.k0;
import nd.y0;
import tc.o;
import tc.q;
import tc.u;
import tc.x;
import x3.s;

/* loaded from: classes.dex */
public class CardScanActivity extends e3.c implements h3.b {

    /* renamed from: j0, reason: collision with root package name */
    private String f6932j0;

    /* renamed from: a0, reason: collision with root package name */
    private final tc.i f6923a0 = tc.k.a(new h());

    /* renamed from: b0, reason: collision with root package name */
    private final tc.i f6924b0 = tc.k.a(new i());

    /* renamed from: c0, reason: collision with root package name */
    private final tc.i f6925c0 = tc.k.a(new j());

    /* renamed from: d0, reason: collision with root package name */
    private final tc.i f6926d0 = tc.k.a(new a());

    /* renamed from: e0, reason: collision with root package name */
    private final tc.i f6927e0 = tc.k.a(new l());

    /* renamed from: f0, reason: collision with root package name */
    private final tc.i f6928f0 = tc.k.a(new g());

    /* renamed from: g0, reason: collision with root package name */
    private final tc.i f6929g0 = tc.k.a(new b());

    /* renamed from: h0, reason: collision with root package name */
    private final tc.i f6930h0 = tc.k.a(new d());

    /* renamed from: i0, reason: collision with root package name */
    private final tc.i f6931i0 = tc.k.a(new c());

    /* renamed from: k0, reason: collision with root package name */
    private final e3.a f6933k0 = new k();

    static final class a extends n implements ed.a {
        a() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final ImageView invoke() {
            return new ImageView(CardScanActivity.this);
        }
    }

    static final class b extends n implements ed.a {
        b() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final Boolean invoke() {
            return Boolean.valueOf(CardScanActivity.this.Q1().b());
        }
    }

    static final class c extends n implements ed.a {
        c() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final Boolean invoke() {
            return Boolean.valueOf(CardScanActivity.this.Q1().h());
        }
    }

    static final class d extends n implements ed.a {
        d() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final Boolean invoke() {
            return Boolean.valueOf(CardScanActivity.this.Q1().i());
        }
    }

    static final class e extends kotlin.coroutines.jvm.internal.l implements p {

        /* renamed from: a, reason: collision with root package name */
        int f6938a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ h3.c f6939b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ CardScanActivity f6940c;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        e(h3.c cVar, CardScanActivity cardScanActivity, wc.d dVar) {
            super(2, dVar);
            this.f6939b = cVar;
            this.f6940c = cardScanActivity;
        }

        @Override // ed.p
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Object invoke(k0 k0Var, wc.d dVar) {
            return ((e) create(k0Var, dVar)).invokeSuspend(x.f21992a);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final wc.d create(Object obj, wc.d dVar) {
            return new e(this.f6939b, this.f6940c, dVar);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final Object invokeSuspend(Object obj) throws Throwable {
            xc.d.c();
            if (this.f6938a != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            q.b(obj);
            String strB = this.f6939b.b();
            if (strB == null) {
                strB = "";
            }
            String strC = this.f6939b.c();
            o oVarA = t3.a.i(null, strB, strC != null ? strC : "") ? u.a(this.f6939b.b(), this.f6939b.c()) : u.a(null, null);
            this.f6940c.B1().c(new e3.i(this.f6940c.f6932j0, null, (String) oVarA.a(), (String) oVarA.b(), t3.h.a(this.f6940c.f6932j0).b(), null, this.f6939b.d(), this.f6939b.a()));
            return x.f21992a;
        }
    }

    static final class f extends kotlin.coroutines.jvm.internal.l implements p {

        /* renamed from: a, reason: collision with root package name */
        int f6941a;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ e3.g f6943c;

        static final class a extends kotlin.coroutines.jvm.internal.l implements p {

            /* renamed from: a, reason: collision with root package name */
            int f6944a;

            /* renamed from: b, reason: collision with root package name */
            final /* synthetic */ e3.g f6945b;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(e3.g gVar, wc.d dVar) {
                super(2, dVar);
                this.f6945b = gVar;
            }

            @Override // ed.p
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final Object invoke(k0 k0Var, wc.d dVar) {
                return ((a) create(k0Var, dVar)).invokeSuspend(x.f21992a);
            }

            @Override // kotlin.coroutines.jvm.internal.a
            public final wc.d create(Object obj, wc.d dVar) {
                return new a(this.f6945b, dVar);
            }

            @Override // kotlin.coroutines.jvm.internal.a
            public final Object invokeSuspend(Object obj) throws Throwable {
                xc.d.c();
                if (this.f6944a != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                q.b(obj);
                return r3.a.a((Bitmap) this.f6945b.a().a().a().a(), this.f6945b.a().a().b(), this.f6945b.a().b());
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        f(e3.g gVar, wc.d dVar) {
            super(2, dVar);
            this.f6943c = gVar;
        }

        @Override // ed.p
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Object invoke(k0 k0Var, wc.d dVar) {
            return ((f) create(k0Var, dVar)).invokeSuspend(x.f21992a);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final wc.d create(Object obj, wc.d dVar) {
            return CardScanActivity.this.new f(this.f6943c, dVar);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final Object invokeSuspend(Object obj) throws Throwable {
            Object objC = xc.d.c();
            int i10 = this.f6941a;
            if (i10 == 0) {
                q.b(obj);
                if (k3.h.c()) {
                    f0 f0VarA = y0.a();
                    a aVar = new a(this.f6943c, null);
                    this.f6941a = 1;
                    obj = nd.g.e(f0VarA, aVar, this);
                    if (obj == objC) {
                        return objC;
                    }
                }
                return x.f21992a;
            }
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            q.b(obj);
            CardScanActivity.this.N1().setImageBitmap((Bitmap) obj);
            return x.f21992a;
        }
    }

    static final class g extends n implements ed.a {
        g() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final e3.f invoke() {
            e3.f fVar = (e3.f) CardScanActivity.this.getIntent().getParcelableExtra("request");
            return fVar == null ? new e3.f(true, false, false) : fVar;
        }
    }

    static final class h extends n implements ed.a {
        h() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final View invoke() {
            return new View(CardScanActivity.this);
        }
    }

    static final class i extends n implements ed.a {
        i() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final ProgressBar invoke() {
            return new ProgressBar(CardScanActivity.this);
        }
    }

    static final class j extends n implements ed.a {
        j() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final TextView invoke() {
            return new TextView(CardScanActivity.this);
        }
    }

    public static final class k implements e3.a {

        static final class a extends kotlin.coroutines.jvm.internal.l implements p {

            /* renamed from: a, reason: collision with root package name */
            int f6951a;

            /* renamed from: b, reason: collision with root package name */
            final /* synthetic */ CardScanActivity f6952b;

            /* renamed from: c, reason: collision with root package name */
            final /* synthetic */ Collection f6953c;

            /* renamed from: d, reason: collision with root package name */
            final /* synthetic */ boolean f6954d;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(CardScanActivity cardScanActivity, Collection collection, boolean z10, wc.d dVar) {
                super(2, dVar);
                this.f6952b = cardScanActivity;
                this.f6953c = collection;
                this.f6954d = z10;
            }

            @Override // ed.p
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final Object invoke(k0 k0Var, wc.d dVar) {
                return ((a) create(k0Var, dVar)).invokeSuspend(x.f21992a);
            }

            @Override // kotlin.coroutines.jvm.internal.a
            public final wc.d create(Object obj, wc.d dVar) {
                return new a(this.f6952b, this.f6953c, this.f6954d, dVar);
            }

            @Override // kotlin.coroutines.jvm.internal.a
            public final Object invokeSuspend(Object obj) throws Throwable {
                xc.d.c();
                if (this.f6951a != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                q.b(obj);
                com.getbouncer.cardscan.ui.a aVarP0 = this.f6952b.p0();
                CardScanActivity cardScanActivity = this.f6952b;
                aVarP0.d(cardScanActivity, cardScanActivity, this.f6953c, this.f6954d, cardScanActivity);
                return x.f21992a;
            }
        }

        k() {
        }

        @Override // x3.m
        public void a(Throwable th) {
            Intent intent = new Intent();
            if (th == null) {
                th = new g3.a(null, 1, null);
            }
            Intent intentPutExtra = intent.putExtra("result", new c.C0122c(th));
            m.f(intentPutExtra, "putExtra(...)");
            CardScanActivity.this.setResult(0, intentPutExtra);
        }

        @Override // x3.m
        public void b(x3.c reason) {
            m.g(reason, "reason");
            Intent intentPutExtra = new Intent().putExtra("result", new c.a(reason));
            m.f(intentPutExtra, "putExtra(...)");
            CardScanActivity.this.setResult(0, intentPutExtra);
        }

        @Override // e3.a
        public void c(e3.i scannedCard) {
            m.g(scannedCard, "scannedCard");
            Intent intentPutExtra = new Intent().putExtra("result", new c.b(scannedCard));
            m.f(intentPutExtra, "putExtra(...)");
            CardScanActivity.this.setResult(-1, intentPutExtra);
            CardScanActivity.this.c();
        }

        @Override // e3.e
        public void d(String str, Collection frames, boolean z10) {
            m.g(frames, "frames");
            CardScanActivity.this.f6932j0 = str;
            nd.i.b(CardScanActivity.this, y0.a(), null, new a(CardScanActivity.this, frames, z10, null), 2, null);
        }
    }

    static final class l extends n implements ed.a {
        l() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final com.getbouncer.cardscan.ui.a invoke() {
            boolean zP1 = CardScanActivity.this.P1();
            boolean zO1 = CardScanActivity.this.O1();
            CardScanActivity cardScanActivity = CardScanActivity.this;
            return new com.getbouncer.cardscan.ui.a(zP1, zO1, cardScanActivity, cardScanActivity);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final e3.f Q1() {
        return (e3.f) this.f6928f0.getValue();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // x3.s
    /* renamed from: C1, reason: merged with bridge method [inline-methods] */
    public com.getbouncer.cardscan.ui.a p0() {
        return (com.getbouncer.cardscan.ui.a) this.f6927e0.getValue();
    }

    protected void D1() {
        N1().setContentDescription(getString(R.string.bouncer_debug_description));
        y3.a.c(N1(), k3.h.c());
    }

    protected void E1() {
        R1().setLayoutParams(new ConstraintLayout.b(-1, -1));
        M0(R1());
    }

    protected void F1() {
        R1().setBackgroundColor(y3.a.f(this, R.color.bouncerProcessingBackground));
    }

    protected void G1() {
        S1().setLayoutParams(new ConstraintLayout.b(-2, -2));
        M0(S1());
    }

    protected void H1() {
        T1().setLayoutParams(new ConstraintLayout.b(0, -2));
        TextView textViewT1 = T1();
        androidx.constraintlayout.widget.e eVar = new androidx.constraintlayout.widget.e();
        eVar.m(n0());
        eVar.p(textViewT1.getId(), 3, S1().getId(), 4);
        eVar.p(textViewT1.getId(), 6, 0, 6);
        eVar.p(textViewT1.getId(), 7, 0, 7);
        eVar.i(n0());
    }

    protected void I1() {
        T1().setText(getString(R.string.bouncer_processing_card));
        y3.a.e(T1(), R.dimen.bouncerProcessingTextSize);
        T1().setTextColor(y3.a.f(this, R.color.bouncerProcessingText));
        T1().setGravity(17);
    }

    @Override // x3.s
    protected void N0(s.b newState, s.b bVar) {
        m.g(newState, "newState");
        super.N0(newState, bVar);
        if ((newState instanceof s.b.d) || m.b(newState, s.b.c.f23593b) || m.b(newState, s.b.C0423b.f23592b) || m.b(newState, s.b.e.f23595b)) {
            y3.a.g(R1());
            y3.a.g(S1());
            y3.a.g(T1());
        } else if (newState instanceof s.b.a) {
            y3.a.j(R1());
            y3.a.j(S1());
            y3.a.j(T1());
        }
    }

    protected ImageView N1() {
        return (ImageView) this.f6926d0.getValue();
    }

    protected boolean O1() {
        return ((Boolean) this.f6931i0.getValue()).booleanValue();
    }

    protected boolean P1() {
        return ((Boolean) this.f6930h0.getValue()).booleanValue();
    }

    protected View R1() {
        return (View) this.f6923a0.getValue();
    }

    protected ProgressBar S1() {
        return (ProgressBar) this.f6924b0.getValue();
    }

    protected TextView T1() {
        return (TextView) this.f6925c0.getValue();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // x3.k
    /* renamed from: U1, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
    public e3.a T() {
        return this.f6933k0;
    }

    protected void V1() {
        ImageView imageViewN1 = N1();
        Resources resources = getResources();
        int i10 = R.dimen.bouncerDebugWindowWidth;
        imageViewN1.setLayoutParams(new ConstraintLayout.b(resources.getDimensionPixelSize(i10), getResources().getDimensionPixelSize(i10)));
        ImageView imageViewN12 = N1();
        androidx.constraintlayout.widget.e eVar = new androidx.constraintlayout.widget.e();
        eVar.m(n0());
        eVar.p(imageViewN12.getId(), 7, 0, 7);
        eVar.p(imageViewN12.getId(), 4, 0, 4);
        eVar.i(n0());
    }

    @Override // e3.c, x3.s
    protected void b1() {
        super.b1();
        F1();
        I1();
        D1();
    }

    @Override // e3.c, x3.s
    protected void c1() {
        super.c1();
        E1();
        G1();
        H1();
        V1();
    }

    @Override // h3.b
    public void f(a.b result, e3.g frame) {
        m.g(result, "result");
        m.g(frame, "frame");
        nd.i.b(this, y0.c(), null, new f(frame, null), 2, null);
    }

    @Override // h3.b
    public void g(h3.c result) {
        m.g(result, "result");
        nd.i.b(this, y0.c(), null, new e(result, this, null), 2, null);
    }

    @Override // e3.c, x3.s
    protected void h1() {
        super.h1();
        Q0(R1(), S1(), T1(), N1());
    }

    @Override // e3.c
    protected boolean z1() {
        return ((Boolean) this.f6929g0.getValue()).booleanValue();
    }
}
