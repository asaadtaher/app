package com.getbouncer.cardscan.ui;

import android.content.Context;
import android.graphics.Rect;
import androidx.lifecycle.n;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.getbouncer.cardscan.ui.result.MainLoopAggregator;
import e3.h;
import ed.p;
import f3.a;
import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import k3.f;
import k3.g;
import k3.q;
import kotlin.jvm.internal.m;
import nd.i;
import nd.k0;
import nd.s1;
import nd.y0;
import tc.x;
import wc.d;
import x3.l;

/* loaded from: classes.dex */
public class a implements l {

    /* renamed from: m, reason: collision with root package name */
    public static final C0114a f6956m = new C0114a(null);

    /* renamed from: a, reason: collision with root package name */
    private final boolean f6957a;

    /* renamed from: b, reason: collision with root package name */
    private final boolean f6958b;

    /* renamed from: c, reason: collision with root package name */
    private final k3.a f6959c;

    /* renamed from: d, reason: collision with root package name */
    private final f f6960d;

    /* renamed from: e, reason: collision with root package name */
    private boolean f6961e;

    /* renamed from: f, reason: collision with root package name */
    private g f6962f;

    /* renamed from: g, reason: collision with root package name */
    private MainLoopAggregator f6963g;

    /* renamed from: h, reason: collision with root package name */
    private q f6964h;

    /* renamed from: i, reason: collision with root package name */
    private s1 f6965i;

    /* renamed from: j, reason: collision with root package name */
    private g f6966j;

    /* renamed from: k, reason: collision with root package name */
    private k3.l f6967k;

    /* renamed from: l, reason: collision with root package name */
    private s1 f6968l;

    /* renamed from: com.getbouncer.cardscan.ui.a$a, reason: collision with other inner class name */
    public static final class C0114a {
        private C0114a() {
        }

        public /* synthetic */ C0114a(kotlin.jvm.internal.g gVar) {
            this();
        }
    }

    static final class b extends kotlin.coroutines.jvm.internal.l implements p {

        /* renamed from: a, reason: collision with root package name */
        Object f6969a;

        /* renamed from: b, reason: collision with root package name */
        Object f6970b;

        /* renamed from: c, reason: collision with root package name */
        Object f6971c;

        /* renamed from: d, reason: collision with root package name */
        Object f6972d;

        /* renamed from: e, reason: collision with root package name */
        int f6973e;

        /* renamed from: g, reason: collision with root package name */
        final /* synthetic */ Context f6975g;

        /* renamed from: h, reason: collision with root package name */
        final /* synthetic */ boolean f6976h;

        /* renamed from: i, reason: collision with root package name */
        final /* synthetic */ h3.b f6977i;

        /* renamed from: j, reason: collision with root package name */
        final /* synthetic */ Collection f6978j;

        /* renamed from: k, reason: collision with root package name */
        final /* synthetic */ k0 f6979k;

        /* renamed from: com.getbouncer.cardscan.ui.a$b$a, reason: collision with other inner class name */
        public static final class C0115a implements h3.b {

            /* renamed from: a, reason: collision with root package name */
            final /* synthetic */ a f6980a;

            /* renamed from: b, reason: collision with root package name */
            final /* synthetic */ h3.b f6981b;

            C0115a(a aVar, h3.b bVar) {
                this.f6980a = aVar;
                this.f6981b = bVar;
            }

            @Override // h3.b
            public void f(a.b result, e3.g frame) {
                m.g(result, "result");
                m.g(frame, "frame");
                this.f6981b.f(result, frame);
            }

            @Override // h3.b
            public void g(h3.c result) throws IOException {
                m.g(result, "result");
                this.f6980a.f6967k = null;
                g gVar = this.f6980a.f6966j;
                if (gVar != null) {
                    gVar.a();
                }
                this.f6980a.f6966j = null;
                s1 s1Var = this.f6980a.f6968l;
                if (s1Var != null && s1Var.d()) {
                    s1.a.a(s1Var, null, 1, null);
                }
                this.f6980a.f6968l = null;
                this.f6981b.g(result);
            }
        }

        /* renamed from: com.getbouncer.cardscan.ui.a$b$b, reason: collision with other inner class name */
        public static final class C0116b implements f {

            /* renamed from: a, reason: collision with root package name */
            final /* synthetic */ h3.b f6982a;

            C0116b(h3.b bVar) {
                this.f6982a = bVar;
            }

            @Override // k3.f
            public boolean a(Throwable t10) {
                m.g(t10, "t");
                this.f6982a.g(new h3.c(null, null, null, null, 15, null));
                return true;
            }

            @Override // k3.f
            public boolean b(Throwable t10) {
                m.g(t10, "t");
                this.f6982a.g(new h3.c(null, null, null, null, 15, null));
                return true;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        b(Context context, boolean z10, h3.b bVar, Collection collection, k0 k0Var, d dVar) {
            super(2, dVar);
            this.f6975g = context;
            this.f6976h = z10;
            this.f6977i = bVar;
            this.f6978j = collection;
            this.f6979k = k0Var;
        }

        @Override // ed.p
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Object invoke(k0 k0Var, d dVar) {
            return ((b) create(k0Var, dVar)).invokeSuspend(x.f21992a);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final d create(Object obj, d dVar) {
            return a.this.new b(this.f6975g, this.f6976h, this.f6977i, this.f6978j, this.f6979k, dVar);
        }

        /* JADX WARN: Removed duplicated region for block: B:28:0x00c6 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:29:0x00c7  */
        /* JADX WARN: Removed duplicated region for block: B:35:0x00e7  */
        /* JADX WARN: Removed duplicated region for block: B:38:0x0115 A[RETURN] */
        @Override // kotlin.coroutines.jvm.internal.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r18) throws java.lang.Throwable {
            /*
                Method dump skipped, instructions count: 338
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getbouncer.cardscan.ui.a.b.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    static final class c extends kotlin.coroutines.jvm.internal.l implements p {

        /* renamed from: a, reason: collision with root package name */
        Object f6983a;

        /* renamed from: b, reason: collision with root package name */
        Object f6984b;

        /* renamed from: c, reason: collision with root package name */
        Object f6985c;

        /* renamed from: d, reason: collision with root package name */
        Object f6986d;

        /* renamed from: e, reason: collision with root package name */
        Object f6987e;

        /* renamed from: f, reason: collision with root package name */
        Object f6988f;

        /* renamed from: g, reason: collision with root package name */
        Object f6989g;

        /* renamed from: h, reason: collision with root package name */
        Object f6990h;

        /* renamed from: i, reason: collision with root package name */
        Object f6991i;

        /* renamed from: j, reason: collision with root package name */
        Object f6992j;

        /* renamed from: k, reason: collision with root package name */
        int f6993k;

        /* renamed from: r, reason: collision with root package name */
        final /* synthetic */ n f6995r;

        /* renamed from: s, reason: collision with root package name */
        final /* synthetic */ Context f6996s;

        /* renamed from: t, reason: collision with root package name */
        final /* synthetic */ qd.c f6997t;

        /* renamed from: u, reason: collision with root package name */
        final /* synthetic */ k0 f6998u;

        /* renamed from: v, reason: collision with root package name */
        final /* synthetic */ Rect f6999v;

        /* renamed from: com.getbouncer.cardscan.ui.a$c$a, reason: collision with other inner class name */
        public static final class C0117a implements qd.c {

            /* renamed from: a, reason: collision with root package name */
            final /* synthetic */ qd.c f7000a;

            /* renamed from: b, reason: collision with root package name */
            final /* synthetic */ Rect f7001b;

            /* renamed from: com.getbouncer.cardscan.ui.a$c$a$a, reason: collision with other inner class name */
            public static final class C0118a implements qd.d {

                /* renamed from: a, reason: collision with root package name */
                final /* synthetic */ qd.d f7002a;

                /* renamed from: b, reason: collision with root package name */
                final /* synthetic */ Rect f7003b;

                /* renamed from: com.getbouncer.cardscan.ui.a$c$a$a$a, reason: collision with other inner class name */
                public static final class C0119a extends kotlin.coroutines.jvm.internal.d {

                    /* renamed from: a, reason: collision with root package name */
                    /* synthetic */ Object f7004a;

                    /* renamed from: b, reason: collision with root package name */
                    int f7005b;

                    public C0119a(d dVar) {
                        super(dVar);
                    }

                    @Override // kotlin.coroutines.jvm.internal.a
                    public final Object invokeSuspend(Object obj) {
                        this.f7004a = obj;
                        this.f7005b |= LinearLayoutManager.INVALID_OFFSET;
                        return C0118a.this.emit(null, this);
                    }
                }

                public C0118a(qd.d dVar, Rect rect) {
                    this.f7002a = dVar;
                    this.f7003b = rect;
                }

                /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
                @Override // qd.d
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct code enable 'Show inconsistent code' option in preferences
                */
                public final java.lang.Object emit(java.lang.Object r6, wc.d r7) throws java.lang.Throwable {
                    /*
                        r5 = this;
                        boolean r0 = r7 instanceof com.getbouncer.cardscan.ui.a.c.C0117a.C0118a.C0119a
                        if (r0 == 0) goto L13
                        r0 = r7
                        com.getbouncer.cardscan.ui.a$c$a$a$a r0 = (com.getbouncer.cardscan.ui.a.c.C0117a.C0118a.C0119a) r0
                        int r1 = r0.f7005b
                        r2 = -2147483648(0xffffffff80000000, float:-0.0)
                        r3 = r1 & r2
                        if (r3 == 0) goto L13
                        int r1 = r1 - r2
                        r0.f7005b = r1
                        goto L18
                    L13:
                        com.getbouncer.cardscan.ui.a$c$a$a$a r0 = new com.getbouncer.cardscan.ui.a$c$a$a$a
                        r0.<init>(r7)
                    L18:
                        java.lang.Object r7 = r0.f7004a
                        java.lang.Object r1 = xc.b.c()
                        int r2 = r0.f7005b
                        r3 = 1
                        if (r2 == 0) goto L31
                        if (r2 != r3) goto L29
                        tc.q.b(r7)
                        goto L48
                    L29:
                        java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                        java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
                        r6.<init>(r7)
                        throw r6
                    L31:
                        tc.q.b(r7)
                        qd.d r7 = r5.f7002a
                        i3.h r6 = (i3.h) r6
                        f3.b$b r2 = new f3.b$b
                        android.graphics.Rect r4 = r5.f7003b
                        r2.<init>(r6, r4)
                        r0.f7005b = r3
                        java.lang.Object r6 = r7.emit(r2, r0)
                        if (r6 != r1) goto L48
                        return r1
                    L48:
                        tc.x r6 = tc.x.f21992a
                        return r6
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getbouncer.cardscan.ui.a.c.C0117a.C0118a.emit(java.lang.Object, wc.d):java.lang.Object");
                }
            }

            public C0117a(qd.c cVar, Rect rect) {
                this.f7000a = cVar;
                this.f7001b = rect;
            }

            @Override // qd.c
            public Object a(qd.d dVar, d dVar2) {
                Object objA = this.f7000a.a(new C0118a(dVar, this.f7001b), dVar2);
                return objA == xc.d.c() ? objA : x.f21992a;
            }
        }

        public static final class b implements k3.a {

            /* renamed from: a, reason: collision with root package name */
            final /* synthetic */ a f7007a;

            b(a aVar) {
                this.f7007a = aVar;
            }

            @Override // k3.a
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public Object e(MainLoopAggregator.FinalResult finalResult, d dVar) throws IOException {
                q qVar = this.f7007a.f6964h;
                if (qVar != null) {
                    qVar.q();
                }
                this.f7007a.f6964h = null;
                s1 s1Var = this.f7007a.f6965i;
                if (s1Var != null && s1Var.d()) {
                    s1.a.a(s1Var, null, 1, null);
                }
                this.f7007a.f6965i = null;
                this.f7007a.f6963g = null;
                g gVar = this.f7007a.f6962f;
                if (gVar != null) {
                    gVar.a();
                }
                this.f7007a.f6962f = null;
                Object objE = this.f7007a.f6959c.e(finalResult, dVar);
                return objE == xc.d.c() ? objE : x.f21992a;
            }

            @Override // k3.a
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public Object c(MainLoopAggregator.InterimResult interimResult, d dVar) {
                Object objC = this.f7007a.f6959c.c(interimResult, dVar);
                return objC == xc.d.c() ? objC : x.f21992a;
            }

            @Override // k3.a
            public Object d(d dVar) {
                Object objD = this.f7007a.f6959c.d(dVar);
                return objD == xc.d.c() ? objD : x.f21992a;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        c(n nVar, Context context, qd.c cVar, k0 k0Var, Rect rect, d dVar) {
            super(2, dVar);
            this.f6995r = nVar;
            this.f6996s = context;
            this.f6997t = cVar;
            this.f6998u = k0Var;
            this.f6999v = rect;
        }

        @Override // ed.p
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Object invoke(k0 k0Var, d dVar) {
            return ((c) create(k0Var, dVar)).invokeSuspend(x.f21992a);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final d create(Object obj, d dVar) {
            return a.this.new c(this.f6995r, this.f6996s, this.f6997t, this.f6998u, this.f6999v, dVar);
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Removed duplicated region for block: B:26:0x0187 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:27:0x0188  */
        /* JADX WARN: Type inference failed for: r4v7, types: [k3.d] */
        @Override // kotlin.coroutines.jvm.internal.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r25) throws java.lang.Throwable {
            /*
                Method dump skipped, instructions count: 433
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getbouncer.cardscan.ui.a.c.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    public a(boolean z10, boolean z11, k3.a scanResultListener, f scanErrorListener) {
        m.g(scanResultListener, "scanResultListener");
        m.g(scanErrorListener, "scanErrorListener");
        this.f6957a = z10;
        this.f6958b = z11;
        this.f6959c = scanResultListener;
        this.f6960d = scanErrorListener;
    }

    private static final List c(Map map, h hVar) {
        List list = (List) map.get(hVar);
        return list == null ? uc.p.g() : list;
    }

    @Override // x3.l
    public void a() throws IOException {
        this.f6961e = true;
        MainLoopAggregator mainLoopAggregator = this.f6963g;
        if (mainLoopAggregator != null) {
            mainLoopAggregator.l();
        }
        this.f6963g = null;
        q qVar = this.f6964h;
        if (qVar != null) {
            qVar.q();
        }
        this.f6964h = null;
        g gVar = this.f6962f;
        if (gVar != null) {
            gVar.a();
        }
        this.f6962f = null;
        s1 s1Var = this.f6965i;
        if (s1Var != null && s1Var.d()) {
            s1.a.a(s1Var, null, 1, null);
        }
        this.f6965i = null;
        k3.l lVar = this.f6967k;
        if (lVar != null) {
            lVar.r();
        }
        this.f6967k = null;
        g gVar2 = this.f6966j;
        if (gVar2 != null) {
            gVar2.a();
        }
        this.f6966j = null;
        s1 s1Var2 = this.f6968l;
        if (s1Var2 != null && s1Var2.d()) {
            s1.a.a(s1Var2, null, 1, null);
        }
        this.f6968l = null;
    }

    @Override // x3.l
    public void a(Context context, qd.c imageStream, Rect viewFinder, n lifecycleOwner, k0 coroutineScope) {
        m.g(context, "context");
        m.g(imageStream, "imageStream");
        m.g(viewFinder, "viewFinder");
        m.g(lifecycleOwner, "lifecycleOwner");
        m.g(coroutineScope, "coroutineScope");
        i.b(coroutineScope, y0.c(), null, new c(lifecycleOwner, context, imageStream, coroutineScope, viewFinder, null), 2, null);
    }

    public Collection b(p3.l frameRate, Map frames) {
        m.g(frameRate, "frameRate");
        m.g(frames, "frames");
        List listC = c(frames, new h(true, true));
        List listC2 = c(frames, new h(true, false));
        return uc.x.d0(uc.x.U(uc.x.U(listC, listC2), c(frames, new h(false, true))), (frameRate.c().compareTo(p3.c.f18846a.b()) <= 0 || frameRate.compareTo(k3.h.b()) > 0) ? 8 : 5);
    }

    public void d(Context context, h3.b completionResultListener, Collection savedFrames, boolean z10, k0 coroutineScope) {
        m.g(context, "context");
        m.g(completionResultListener, "completionResultListener");
        m.g(savedFrames, "savedFrames");
        m.g(coroutineScope, "coroutineScope");
        i.b(coroutineScope, null, null, new b(context, z10, completionResultListener, savedFrames, coroutineScope, null), 3, null);
    }
}
