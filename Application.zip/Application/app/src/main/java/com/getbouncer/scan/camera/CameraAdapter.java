package com.getbouncer.scan.camera;

import android.content.Context;
import android.graphics.PointF;
import android.util.Log;
import androidx.lifecycle.h;
import androidx.lifecycle.m;
import androidx.lifecycle.n;
import androidx.lifecycle.u;
import ed.p;
import k3.h;
import kotlin.coroutines.jvm.internal.l;
import nd.k0;
import pd.d;
import pd.g;
import pd.h;
import pd.t;
import qd.e;
import tc.q;
import tc.x;

/* loaded from: classes.dex */
public abstract class CameraAdapter<CameraOutput> implements m {

    /* renamed from: c, reason: collision with root package name */
    public static final a f7060c = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private final d f7061a = g.b(0, null, null, 6, null);

    /* renamed from: b, reason: collision with root package name */
    private int f7062b;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.jvm.internal.g gVar) {
            this();
        }

        public final int a(int i10) {
            return i10 * 90;
        }

        public final boolean b(Context context) {
            kotlin.jvm.internal.m.g(context, "context");
            boolean zHasSystemFeature = context.getPackageManager().hasSystemFeature("android.hardware.camera.any");
            if (!zHasSystemFeature) {
                Log.e(h.a(), "System feature 'FEATURE_CAMERA_ANY' is unavailable");
            }
            return zHasSystemFeature;
        }
    }

    static final class b extends l implements p {

        /* renamed from: a, reason: collision with root package name */
        int f7063a;

        b(wc.d dVar) {
            super(2, dVar);
        }

        @Override // ed.p
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Object invoke(k0 k0Var, wc.d dVar) {
            return ((b) create(k0Var, dVar)).invokeSuspend(x.f21992a);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final wc.d create(Object obj, wc.d dVar) {
            return new b(dVar);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final Object invokeSuspend(Object obj) throws Throwable {
            xc.d.c();
            if (this.f7063a != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            q.b(obj);
            return kotlin.coroutines.jvm.internal.b.a(t.a.a(CameraAdapter.this.f7061a, null, 1, null));
        }
    }

    protected final Object a(Object obj) {
        int iE;
        try {
            Object objH = this.f7061a.h(obj);
            if (objH instanceof h.a) {
                Log.w(k3.h.a(), "Attempted to send image to closed channel", pd.h.e(objH));
            }
            if (objH instanceof h.c) {
                pd.h.e(objH);
            }
            return pd.h.b(objH);
        } catch (pd.m unused) {
            iE = Log.w(k3.h.a(), "Attempted to send image to closed channel");
            return Integer.valueOf(iE);
        } catch (Throwable th) {
            iE = Log.e(k3.h.a(), "Unable to send image to channel", th);
            return Integer.valueOf(iE);
        }
    }

    public abstract void c();

    public abstract void d(PointF pointF);

    public void f(n lifecycleOwner) {
        kotlin.jvm.internal.m.g(lifecycleOwner, "lifecycleOwner");
        lifecycleOwner.getLifecycle().a(this);
        this.f7062b++;
    }

    public abstract void g(ed.l lVar);

    public abstract void h(boolean z10);

    public final qd.c i() {
        return e.d(this.f7061a);
    }

    public void k(n lifecycleOwner) {
        kotlin.jvm.internal.m.g(lifecycleOwner, "lifecycleOwner");
        lifecycleOwner.getLifecycle().c(this);
        int i10 = this.f7062b - 1;
        this.f7062b = i10;
        if (i10 < 0) {
            Log.e(k3.h.a(), "Bound lifecycle count " + this.f7062b + " is below 0");
            this.f7062b = 0;
        }
        onPause();
    }

    public abstract void l(ed.l lVar);

    public boolean m() {
        return this.f7062b > 0;
    }

    public abstract boolean n();

    @u(h.a.ON_DESTROY)
    public final void onDestroyed() {
        nd.h.b(null, new b(null), 1, null);
    }

    @u(h.a.ON_PAUSE)
    public void onPause() {
    }
}
