package com.getbouncer.scan.camera.extension;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.PointF;
import android.os.Build;
import android.os.Handler;
import android.renderscript.RenderScript;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Size;
import android.view.Display;
import android.view.ViewGroup;
import androidx.camera.core.f;
import androidx.camera.core.o;
import androidx.camera.core.s;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.h;
import androidx.lifecycle.n;
import androidx.lifecycle.u;
import com.getbouncer.scan.camera.CameraAdapter;
import com.getbouncer.scan.camera.extension.CameraAdapterImpl;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import k3.y;
import kotlin.jvm.internal.m;
import o.l;
import o.p;
import o.s;
import tc.x;

/* loaded from: classes.dex */
public final class CameraAdapterImpl extends CameraAdapter<i3.h> {
    public static final /* synthetic */ int B = 0;
    private final tc.i A;

    /* renamed from: d, reason: collision with root package name */
    private final Activity f7072d;

    /* renamed from: e, reason: collision with root package name */
    private final ViewGroup f7073e;

    /* renamed from: f, reason: collision with root package name */
    private final Size f7074f;

    /* renamed from: g, reason: collision with root package name */
    private final i3.g f7075g;

    /* renamed from: h, reason: collision with root package name */
    private final String f7076h;

    /* renamed from: i, reason: collision with root package name */
    private int f7077i;

    /* renamed from: j, reason: collision with root package name */
    private final Handler f7078j;

    /* renamed from: k, reason: collision with root package name */
    private s f7079k;

    /* renamed from: l, reason: collision with root package name */
    private androidx.camera.core.f f7080l;

    /* renamed from: r, reason: collision with root package name */
    private o.f f7081r;

    /* renamed from: s, reason: collision with root package name */
    private final com.google.common.util.concurrent.d f7082s;

    /* renamed from: t, reason: collision with root package name */
    private n f7083t;

    /* renamed from: u, reason: collision with root package name */
    private final List f7084u;

    /* renamed from: v, reason: collision with root package name */
    private ExecutorService f7085v;

    /* renamed from: w, reason: collision with root package name */
    private final tc.i f7086w;

    /* renamed from: x, reason: collision with root package name */
    private final tc.i f7087x;

    /* renamed from: y, reason: collision with root package name */
    private final tc.i f7088y;

    /* renamed from: z, reason: collision with root package name */
    private final tc.i f7089z;

    static final class a extends kotlin.jvm.internal.n implements ed.l {
        a() {
            super(1);
        }

        public final void a(androidx.camera.lifecycle.e it) {
            m.g(it, "it");
            CameraAdapterImpl cameraAdapterImpl = CameraAdapterImpl.this;
            int i10 = 1;
            if ((cameraAdapterImpl.f7077i == 1 && CameraAdapterImpl.this.H(it)) || ((CameraAdapterImpl.this.f7077i != 0 || !CameraAdapterImpl.this.D(it)) && !CameraAdapterImpl.this.D(it) && CameraAdapterImpl.this.H(it))) {
                i10 = 0;
            }
            cameraAdapterImpl.f7077i = i10;
            CameraAdapterImpl.this.t(it);
        }

        @Override // ed.l
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((androidx.camera.lifecycle.e) obj);
            return x.f21992a;
        }
    }

    static final class b extends kotlin.jvm.internal.n implements ed.a {
        b() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final Display invoke() {
            Display display = Build.VERSION.SDK_INT >= 30 ? CameraAdapterImpl.this.f7072d.getDisplay() : null;
            return display == null ? CameraAdapterImpl.this.f7072d.getWindowManager().getDefaultDisplay() : display;
        }
    }

    static final class c extends kotlin.jvm.internal.n implements ed.a {
        c() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final DisplayMetrics invoke() {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            CameraAdapterImpl.this.L().getRealMetrics(displayMetrics);
            return displayMetrics;
        }
    }

    static final class d extends kotlin.jvm.internal.n implements ed.a {
        d() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final Integer invoke() {
            return Integer.valueOf(CameraAdapterImpl.this.L().getRotation());
        }
    }

    static final class e extends kotlin.jvm.internal.n implements ed.a {
        e() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final Size invoke() {
            return new Size(CameraAdapterImpl.this.N().widthPixels, CameraAdapterImpl.this.N().heightPixels);
        }
    }

    static final class f extends kotlin.jvm.internal.n implements ed.l {
        f() {
            super(1);
        }

        public final void a(androidx.camera.lifecycle.e it) {
            m.g(it, "it");
            it.q();
            ExecutorService executorService = CameraAdapterImpl.this.f7085v;
            if (executorService == null) {
                m.u("cameraExecutor");
                executorService = null;
            }
            executorService.shutdown();
        }

        @Override // ed.l
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((androidx.camera.lifecycle.e) obj);
            return x.f21992a;
        }
    }

    static final class g extends kotlin.jvm.internal.n implements ed.a {
        g() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final androidx.camera.view.h invoke() {
            return new androidx.camera.view.h(CameraAdapterImpl.this.f7072d);
        }
    }

    static final class h extends kotlin.jvm.internal.n implements ed.l {
        h() {
            super(1);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void d(CameraAdapterImpl this$0) {
            m.g(this$0, "this$0");
            this$0.f7075g.a(new IllegalStateException("No camera is available"));
        }

        public final void c(androidx.camera.lifecycle.e it) {
            m.g(it, "it");
            CameraAdapterImpl cameraAdapterImpl = CameraAdapterImpl.this;
            int i10 = 1;
            if (!cameraAdapterImpl.D(it)) {
                if (CameraAdapterImpl.this.H(it)) {
                    i10 = 0;
                } else {
                    Handler handler = CameraAdapterImpl.this.f7078j;
                    final CameraAdapterImpl cameraAdapterImpl2 = CameraAdapterImpl.this;
                    handler.post(new Runnable() { // from class: com.getbouncer.scan.camera.extension.a
                        @Override // java.lang.Runnable
                        public final void run() {
                            CameraAdapterImpl.h.d(cameraAdapterImpl2);
                        }
                    });
                }
            }
            cameraAdapterImpl.f7077i = i10;
            CameraAdapterImpl.this.t(it);
        }

        @Override // ed.l
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            c((androidx.camera.lifecycle.e) obj);
            return x.f21992a;
        }
    }

    static final class i extends kotlin.jvm.internal.n implements ed.l {
        i() {
            super(1);
        }

        public final void a(androidx.camera.lifecycle.e cameraProvider) {
            m.g(cameraProvider, "cameraProvider");
            s sVar = CameraAdapterImpl.this.f7079k;
            if (sVar != null) {
                cameraProvider.p(sVar);
            }
        }

        @Override // ed.l
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((androidx.camera.lifecycle.e) obj);
            return x.f21992a;
        }
    }

    static final class j extends kotlin.jvm.internal.n implements ed.l {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ed.l f7099a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        j(ed.l lVar) {
            super(1);
            this.f7099a = lVar;
        }

        public final void a(o.f it) {
            m.g(it, "it");
            this.f7099a.invoke(it);
        }

        @Override // ed.l
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((o.f) obj);
            return x.f21992a;
        }
    }

    static final class k extends kotlin.jvm.internal.n implements ed.l {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ed.l f7100a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        k(ed.l lVar) {
            super(1);
            this.f7100a = lVar;
        }

        public final void a(o.f it) {
            m.g(it, "it");
            this.f7100a.invoke(Boolean.valueOf(it.a().h()));
        }

        @Override // ed.l
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((o.f) obj);
            return x.f21992a;
        }
    }

    static final class l extends kotlin.jvm.internal.n implements ed.l {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ed.l f7101a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ CameraAdapterImpl f7102b;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        l(ed.l lVar, CameraAdapterImpl cameraAdapterImpl) {
            super(1);
            this.f7101a = lVar;
            this.f7102b = cameraAdapterImpl;
        }

        public final void a(androidx.camera.lifecycle.e it) {
            m.g(it, "it");
            this.f7101a.invoke(Boolean.valueOf(this.f7102b.D(it) && this.f7102b.H(it)));
        }

        @Override // ed.l
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((androidx.camera.lifecycle.e) obj);
            return x.f21992a;
        }
    }

    public CameraAdapterImpl(Activity activity, ViewGroup previewView, Size minimumResolution, i3.g cameraErrorListener) {
        m.g(activity, "activity");
        m.g(previewView, "previewView");
        m.g(minimumResolution, "minimumResolution");
        m.g(cameraErrorListener, "cameraErrorListener");
        this.f7072d = activity;
        this.f7073e = previewView;
        this.f7074f = minimumResolution;
        this.f7075g = cameraErrorListener;
        this.f7076h = "CameraX";
        this.f7077i = 1;
        this.f7078j = new Handler(activity.getMainLooper());
        com.google.common.util.concurrent.d<androidx.camera.lifecycle.e> dVarG = androidx.camera.lifecycle.e.g(activity);
        m.f(dVarG, "getInstance(...)");
        this.f7082s = dVarG;
        this.f7084u = new ArrayList();
        this.f7086w = tc.k.a(new b());
        this.f7087x = tc.k.a(new d());
        this.f7088y = tc.k.a(new c());
        this.f7089z = tc.k.a(new e());
        this.A = tc.k.a(new g());
    }

    private final void A(Executor executor, final ed.l lVar) {
        this.f7082s.a(new Runnable() { // from class: j3.d
            @Override // java.lang.Runnable
            public final void run() throws ExecutionException, InterruptedException {
                CameraAdapterImpl.z(lVar, this);
            }
        }, executor);
    }

    private final void B(o.f fVar) {
        Iterator it = this.f7084u.iterator();
        while (it.hasNext()) {
            ((ed.l) it.next()).invoke(fVar);
            it.remove();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean D(androidx.camera.lifecycle.e eVar) {
        return eVar.i(o.l.f18393c);
    }

    private final synchronized void G(ed.l lVar) {
        o.f fVar = this.f7081r;
        if (fVar != null) {
            lVar.invoke(fVar);
        } else {
            this.f7084u.add(new j(lVar));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean H(androidx.camera.lifecycle.e eVar) {
        return eVar.i(o.l.f18392b);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Display L() {
        return (Display) this.f7086w.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final DisplayMetrics N() {
        return (DisplayMetrics) this.f7088y.getValue();
    }

    private final int O() {
        return ((Number) this.f7087x.getValue()).intValue();
    }

    private final Size Q() {
        return (Size) this.f7089z.getValue();
    }

    private final androidx.camera.view.h S() {
        return (androidx.camera.view.h) this.A.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void T(CameraAdapterImpl this$0) {
        m.g(this$0, "this$0");
        this$0.f7073e.removeAllViews();
        this$0.f7073e.addView(this$0.S());
        ViewGroup.LayoutParams layoutParams = this$0.S().getLayoutParams();
        layoutParams.width = -1;
        layoutParams.height = -1;
        this$0.S().requestLayout();
        this$0.U();
    }

    private final void U() {
        y(this, null, new h(), 1, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final synchronized void t(androidx.camera.lifecycle.e eVar) {
        o.l lVarB = new l.a().d(this.f7077i).b();
        m.f(lVarB, "build(...)");
        this.f7079k = new s.a().m(O()).l(j3.f.a(this.f7074f, Q())).c();
        androidx.camera.core.f fVarC = new f.c().q(O()).p(j3.f.a(this.f7074f, Q())).f(0).j(1).c();
        ExecutorService executorService = this.f7085v;
        n nVar = null;
        if (executorService == null) {
            m.u("cameraExecutor");
            executorService = null;
        }
        fVarC.f0(executorService, new f.a() { // from class: j3.a
            @Override // androidx.camera.core.f.a
            public final void a(o oVar) {
                CameraAdapterImpl.v(this.f16605a, oVar);
            }

            @Override // androidx.camera.core.f.a
            public /* synthetic */ Size b() {
                return o.x.a(this);
            }
        });
        this.f7080l = fVarC;
        eVar.q();
        try {
            n nVar2 = this.f7083t;
            if (nVar2 == null) {
                m.u("lifecycleOwner");
            } else {
                nVar = nVar2;
            }
            o.f fVarE = eVar.e(nVar, lVarB, this.f7079k, this.f7080l);
            m.f(fVarE, "bindToLifecycle(...)");
            B(fVarE);
            this.f7081r = fVarE;
            s sVar = this.f7079k;
            if (sVar != null) {
                sVar.f0(S().getSurfaceProvider());
            }
        } catch (Throwable th) {
            Log.e(k3.h.a(), "Use case camera binding failed", th);
            this.f7078j.post(new Runnable() { // from class: j3.c
                @Override // java.lang.Runnable
                public final void run() {
                    CameraAdapterImpl.x(this.f16607a, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void v(CameraAdapterImpl this$0, o image) {
        m.g(this$0, "this$0");
        m.g(image, "image");
        Object objInvoke = m3.e.a().invoke(this$0.f7072d);
        m.f(objInvoke, "invoke(...)");
        Bitmap bitmapA = m3.a.a(j3.e.a(image, (RenderScript) objInvoke), image.A().d());
        image.close();
        this$0.a(new i3.h(new y(bitmapA), q3.i.f(q3.i.p(q3.i.m(this$0.f7073e), q3.i.a(m3.a.e(bitmapA))), q3.i.n(this$0.Q()))));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void x(CameraAdapterImpl this$0, Throwable t10) {
        m.g(this$0, "this$0");
        m.g(t10, "$t");
        this$0.f7075g.b(t10);
    }

    static /* synthetic */ void y(CameraAdapterImpl cameraAdapterImpl, Executor executor, ed.l lVar, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            executor = androidx.core.content.a.i(cameraAdapterImpl.f7072d);
            m.f(executor, "getMainExecutor(...)");
        }
        cameraAdapterImpl.A(executor, lVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void z(ed.l task, CameraAdapterImpl this$0) throws ExecutionException, InterruptedException {
        m.g(task, "$task");
        m.g(this$0, "this$0");
        V v10 = this$0.f7082s.get();
        m.f(v10, "get(...)");
        task.invoke(v10);
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void c() {
        y(this, null, new a(), 1, null);
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void d(PointF point) {
        m.g(point, "point");
        o.f fVar = this.f7081r;
        if (fVar != null) {
            o.s sVarB = new s.a(new p(L(), fVar.a(), Q().getWidth(), Q().getHeight()).b(point.x, point.y)).b();
            m.f(sVarB, "build(...)");
            fVar.c().h(sVarB);
        }
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void f(n lifecycleOwner) {
        m.g(lifecycleOwner, "lifecycleOwner");
        super.f(lifecycleOwner);
        this.f7083t = lifecycleOwner;
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void g(ed.l task) {
        m.g(task, "task");
        G(new k(task));
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void h(boolean z10) {
        o.g gVarC;
        o.f fVar = this.f7081r;
        if (fVar == null || (gVarC = fVar.c()) == null) {
            return;
        }
        gVarC.i(z10);
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void k(n lifecycleOwner) {
        m.g(lifecycleOwner, "lifecycleOwner");
        super.k(lifecycleOwner);
        y(this, null, new i(), 1, null);
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void l(ed.l task) {
        m.g(task, "task");
        y(this, null, new l(task, this), 1, null);
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public boolean n() {
        o.k kVarA;
        LiveData<Integer> liveDataF;
        Integer value;
        o.f fVar = this.f7081r;
        return (fVar == null || (kVarA = fVar.a()) == null || (liveDataF = kVarA.f()) == null || (value = liveDataF.getValue()) == null || value.intValue() != 1) ? false : true;
    }

    @u(h.a.ON_CREATE)
    public final void onCreate() {
        ExecutorService executorServiceNewSingleThreadExecutor = Executors.newSingleThreadExecutor();
        m.f(executorServiceNewSingleThreadExecutor, "newSingleThreadExecutor(...)");
        this.f7085v = executorServiceNewSingleThreadExecutor;
        this.f7073e.post(new Runnable() { // from class: j3.b
            @Override // java.lang.Runnable
            public final void run() {
                CameraAdapterImpl.T(this.f16606a);
            }
        });
    }

    @u(h.a.ON_DESTROY)
    public final void onDestroy() {
        y(this, null, new f(), 1, null);
    }
}
