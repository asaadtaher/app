package com.getbouncer.scan.framework;

import androidx.lifecycle.h;
import androidx.lifecycle.m;
import ed.p;
import k3.u;
import kotlin.coroutines.jvm.internal.l;
import kotlin.jvm.internal.n;
import nd.g;
import nd.k0;
import nd.y0;
import q3.e;
import tc.i;
import tc.k;
import tc.q;
import tc.x;
import wc.d;

/* loaded from: classes.dex */
public abstract class ResultAggregator<DataFrame, State, AnalyzerResult, InterimResult, FinalResult> extends u implements m {

    /* renamed from: c, reason: collision with root package name */
    private final k3.a f7104c;

    /* renamed from: d, reason: collision with root package name */
    private final Object f7105d;

    /* renamed from: e, reason: collision with root package name */
    private boolean f7106e;

    /* renamed from: f, reason: collision with root package name */
    private boolean f7107f;

    /* renamed from: g, reason: collision with root package name */
    private boolean f7108g;

    /* renamed from: h, reason: collision with root package name */
    private final i f7109h;

    static final class a extends n implements ed.a {
        a() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final e invoke() {
            String simpleName = ResultAggregator.this.getClass().getSimpleName();
            kotlin.jvm.internal.m.f(simpleName, "getSimpleName(...)");
            return new e(simpleName, null, null, 6, null);
        }
    }

    static final class b extends l implements p {

        /* renamed from: a, reason: collision with root package name */
        int f7111a;

        /* renamed from: b, reason: collision with root package name */
        private /* synthetic */ Object f7112b;

        /* renamed from: d, reason: collision with root package name */
        final /* synthetic */ Object f7114d;

        /* renamed from: e, reason: collision with root package name */
        final /* synthetic */ Object f7115e;

        static final class a extends l implements p {

            /* renamed from: a, reason: collision with root package name */
            int f7116a;

            /* renamed from: b, reason: collision with root package name */
            final /* synthetic */ ResultAggregator f7117b;

            /* renamed from: c, reason: collision with root package name */
            final /* synthetic */ Object f7118c;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(ResultAggregator resultAggregator, Object obj, d dVar) {
                super(2, dVar);
                this.f7117b = resultAggregator;
                this.f7118c = obj;
            }

            @Override // ed.p
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final Object invoke(k0 k0Var, d dVar) {
                return ((a) create(k0Var, dVar)).invokeSuspend(x.f21992a);
            }

            @Override // kotlin.coroutines.jvm.internal.a
            public final d create(Object obj, d dVar) {
                return new a(this.f7117b, this.f7118c, dVar);
            }

            @Override // kotlin.coroutines.jvm.internal.a
            public final Object invokeSuspend(Object obj) throws Throwable {
                Object objC = xc.d.c();
                int i10 = this.f7116a;
                if (i10 == 0) {
                    q.b(obj);
                    k3.a aVar = this.f7117b.f7104c;
                    Object obj2 = this.f7118c;
                    this.f7116a = 1;
                    if (aVar.c(obj2, this) == objC) {
                        return objC;
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    q.b(obj);
                }
                return x.f21992a;
            }
        }

        /* renamed from: com.getbouncer.scan.framework.ResultAggregator$b$b, reason: collision with other inner class name */
        static final class C0126b extends l implements p {

            /* renamed from: a, reason: collision with root package name */
            int f7119a;

            /* renamed from: b, reason: collision with root package name */
            final /* synthetic */ ResultAggregator f7120b;

            /* renamed from: c, reason: collision with root package name */
            final /* synthetic */ Object f7121c;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C0126b(ResultAggregator resultAggregator, Object obj, d dVar) {
                super(2, dVar);
                this.f7120b = resultAggregator;
                this.f7121c = obj;
            }

            @Override // ed.p
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final Object invoke(k0 k0Var, d dVar) {
                return ((C0126b) create(k0Var, dVar)).invokeSuspend(x.f21992a);
            }

            @Override // kotlin.coroutines.jvm.internal.a
            public final d create(Object obj, d dVar) {
                return new C0126b(this.f7120b, this.f7121c, dVar);
            }

            @Override // kotlin.coroutines.jvm.internal.a
            public final Object invokeSuspend(Object obj) throws Throwable {
                Object objC = xc.d.c();
                int i10 = this.f7119a;
                if (i10 == 0) {
                    q.b(obj);
                    k3.a aVar = this.f7120b.f7104c;
                    Object obj2 = this.f7121c;
                    this.f7119a = 1;
                    if (aVar.e(obj2, this) == objC) {
                        return objC;
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    q.b(obj);
                }
                return x.f21992a;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        b(Object obj, Object obj2, d dVar) {
            super(2, dVar);
            this.f7114d = obj;
            this.f7115e = obj2;
        }

        @Override // ed.p
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Object invoke(k0 k0Var, d dVar) {
            return ((b) create(k0Var, dVar)).invokeSuspend(x.f21992a);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final d create(Object obj, d dVar) {
            b bVar = new b(this.f7114d, this.f7115e, dVar);
            bVar.f7112b = obj;
            return bVar;
        }

        /* JADX WARN: Removed duplicated region for block: B:19:0x006e  */
        /* JADX WARN: Removed duplicated region for block: B:20:0x0081  */
        /* JADX WARN: Removed duplicated region for block: B:23:0x0085  */
        @Override // kotlin.coroutines.jvm.internal.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final java.lang.Object invokeSuspend(java.lang.Object r12) throws java.lang.Throwable {
            /*
                r11 = this;
                java.lang.Object r0 = xc.b.c()
                int r1 = r11.f7111a
                r2 = 2
                r3 = 1
                if (r1 == 0) goto L27
                if (r1 == r3) goto L1e
                if (r1 != r2) goto L16
                java.lang.Object r0 = r11.f7112b
                nd.k0 r0 = (nd.k0) r0
                tc.q.b(r12)
                goto L52
            L16:
                java.lang.IllegalStateException r12 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r12.<init>(r0)
                throw r12
            L1e:
                java.lang.Object r1 = r11.f7112b
                nd.k0 r1 = (nd.k0) r1
                tc.q.b(r12)
                r12 = r1
                goto L3f
            L27:
                tc.q.b(r12)
                java.lang.Object r12 = r11.f7112b
                nd.k0 r12 = (nd.k0) r12
                com.getbouncer.scan.framework.ResultAggregator r1 = com.getbouncer.scan.framework.ResultAggregator.this
                q3.e r1 = r1.m()
                r11.f7112b = r12
                r11.f7111a = r3
                java.lang.Object r1 = r1.a(r11)
                if (r1 != r0) goto L3f
                return r0
            L3f:
                com.getbouncer.scan.framework.ResultAggregator r1 = com.getbouncer.scan.framework.ResultAggregator.this
                java.lang.Object r4 = r11.f7114d
                java.lang.Object r5 = r11.f7115e
                r11.f7112b = r12
                r11.f7111a = r2
                java.lang.Object r1 = r1.k(r4, r5, r11)
                if (r1 != r0) goto L50
                return r0
            L50:
                r0 = r12
                r12 = r1
            L52:
                tc.o r12 = (tc.o) r12
                java.lang.Object r1 = r12.a()
                java.lang.Object r12 = r12.b()
                com.getbouncer.scan.framework.ResultAggregator$b$a r7 = new com.getbouncer.scan.framework.ResultAggregator$b$a
                com.getbouncer.scan.framework.ResultAggregator r2 = com.getbouncer.scan.framework.ResultAggregator.this
                r10 = 0
                r7.<init>(r2, r1, r10)
                r5 = 0
                r6 = 0
                r8 = 3
                r9 = 0
                r4 = r0
                nd.g.b(r4, r5, r6, r7, r8, r9)
                if (r12 == 0) goto L81
                com.getbouncer.scan.framework.ResultAggregator r1 = com.getbouncer.scan.framework.ResultAggregator.this
                com.getbouncer.scan.framework.ResultAggregator.i(r1, r3)
                com.getbouncer.scan.framework.ResultAggregator$b$b r7 = new com.getbouncer.scan.framework.ResultAggregator$b$b
                r7.<init>(r1, r12, r10)
                r5 = 0
                r6 = 0
                r8 = 3
                r9 = 0
                r4 = r0
                nd.g.b(r4, r5, r6, r7, r8, r9)
                goto L82
            L81:
                r12 = r10
            L82:
                if (r12 == 0) goto L85
                goto L86
            L85:
                r3 = 0
            L86:
                java.lang.Boolean r12 = kotlin.coroutines.jvm.internal.b.a(r3)
                return r12
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getbouncer.scan.framework.ResultAggregator.b.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    static final class c extends l implements p {

        /* renamed from: a, reason: collision with root package name */
        int f7122a;

        c(d dVar) {
            super(2, dVar);
        }

        @Override // ed.p
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public final Object invoke(k0 k0Var, d dVar) {
            return ((c) create(k0Var, dVar)).invokeSuspend(x.f21992a);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final d create(Object obj, d dVar) {
            return new c(dVar);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final Object invokeSuspend(Object obj) throws Throwable {
            Object objC = xc.d.c();
            int i10 = this.f7122a;
            if (i10 == 0) {
                q.b(obj);
                k3.a aVar = ResultAggregator.this.f7104c;
                this.f7122a = 1;
                if (aVar.d(this) == objC) {
                    return objC;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                q.b(obj);
            }
            return x.f21992a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ResultAggregator(k3.a listener, Object obj) {
        super(obj);
        kotlin.jvm.internal.m.g(listener, "listener");
        this.f7104c = listener;
        this.f7105d = obj;
        this.f7109h = k.a(new a());
    }

    static /* synthetic */ Object f(ResultAggregator resultAggregator, Object obj, Object obj2, d dVar) {
        boolean z10;
        if (resultAggregator.f7107f) {
            z10 = false;
        } else {
            if (!resultAggregator.f7106e && !resultAggregator.f7108g) {
                return g.e(y0.a(), new b(obj2, obj, null), dVar);
            }
            z10 = true;
        }
        return kotlin.coroutines.jvm.internal.b.a(z10);
    }

    @androidx.lifecycle.u(h.a.ON_PAUSE)
    private final void resetAndPause() {
        d();
        this.f7107f = true;
    }

    @androidx.lifecycle.u(h.a.ON_RESUME)
    private final void resume() {
        this.f7107f = false;
    }

    @Override // k3.s
    public Object b(Object obj, Object obj2, d dVar) {
        return f(this, obj, obj2, dVar);
    }

    @Override // k3.u
    protected void d() {
        super.d();
        this.f7107f = false;
        this.f7106e = false;
        this.f7108g = false;
        c(this.f7105d);
        m().d();
        nd.h.b(null, new c(null), 1, null);
    }

    public void h(androidx.lifecycle.n lifecycleOwner) {
        kotlin.jvm.internal.m.g(lifecycleOwner, "lifecycleOwner");
        lifecycleOwner.getLifecycle().a(this);
    }

    public abstract Object k(Object obj, Object obj2, d dVar);

    public final void l() {
        d();
        this.f7106e = true;
    }

    protected e m() {
        return (e) this.f7109h.getValue();
    }
}
