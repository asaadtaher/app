package com.getbouncer.cardscan.ui.result;

import androidx.recyclerview.widget.LinearLayoutManager;
import f3.b;
import k3.o;
import kotlin.jvm.internal.m;
import q3.g;
import q3.h;
import u3.k;

/* loaded from: classes.dex */
public abstract class a extends o {

    /* renamed from: b, reason: collision with root package name */
    private final boolean f7025b;

    /* renamed from: c, reason: collision with root package name */
    private final boolean f7026c;

    /* renamed from: com.getbouncer.cardscan.ui.result.a$a, reason: collision with other inner class name */
    public static final class C0123a extends a {

        /* renamed from: d, reason: collision with root package name */
        private final h f7027d;

        /* renamed from: com.getbouncer.cardscan.ui.result.a$a$a, reason: collision with other inner class name */
        static final class C0124a extends kotlin.coroutines.jvm.internal.d {

            /* renamed from: a, reason: collision with root package name */
            Object f7028a;

            /* renamed from: b, reason: collision with root package name */
            /* synthetic */ Object f7029b;

            /* renamed from: d, reason: collision with root package name */
            int f7031d;

            C0124a(wc.d dVar) {
                super(dVar);
            }

            @Override // kotlin.coroutines.jvm.internal.a
            public final Object invokeSuspend(Object obj) {
                this.f7029b = obj;
                this.f7031d |= LinearLayoutManager.INVALID_OFFSET;
                return C0123a.this.b(null, this);
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public C0123a(h panCounter) {
            super(true, false, null);
            m.g(panCounter, "panCounter");
            this.f7027d = panCounter;
        }

        private final boolean f() {
            tc.o oVarA = g.a.a(this.f7027d, 0, 1, null);
            return (oVarA != null ? ((Number) oVarA.c()).intValue() : 0) >= h3.d.a();
        }

        /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
        @Override // com.getbouncer.cardscan.ui.result.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public java.lang.Object b(f3.b.c r5, wc.d r6) throws java.lang.Throwable {
            /*
                r4 = this;
                boolean r0 = r6 instanceof com.getbouncer.cardscan.ui.result.a.C0123a.C0124a
                if (r0 == 0) goto L13
                r0 = r6
                com.getbouncer.cardscan.ui.result.a$a$a r0 = (com.getbouncer.cardscan.ui.result.a.C0123a.C0124a) r0
                int r1 = r0.f7031d
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f7031d = r1
                goto L18
            L13:
                com.getbouncer.cardscan.ui.result.a$a$a r0 = new com.getbouncer.cardscan.ui.result.a$a$a
                r0.<init>(r6)
            L18:
                java.lang.Object r6 = r0.f7029b
                java.lang.Object r1 = xc.b.c()
                int r2 = r0.f7031d
                r3 = 1
                if (r2 == 0) goto L35
                if (r2 != r3) goto L2d
                java.lang.Object r5 = r0.f7028a
                com.getbouncer.cardscan.ui.result.a$a r5 = (com.getbouncer.cardscan.ui.result.a.C0123a) r5
                tc.q.b(r6)
                goto L6a
            L2d:
                java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
                r5.<init>(r6)
                throw r5
            L35:
                tc.q.b(r6)
                u3.k$d r6 = r5.b()
                if (r6 == 0) goto L43
                java.lang.String r6 = r6.b()
                goto L44
            L43:
                r6 = 0
            L44:
                if (r6 == 0) goto L69
                u3.k$d r6 = r5.b()
                java.lang.String r6 = r6.b()
                boolean r6 = t3.h.d(r6)
                if (r6 == 0) goto L69
                q3.h r6 = r4.f7027d
                u3.k$d r5 = r5.b()
                java.lang.String r5 = r5.b()
                r0.f7028a = r4
                r0.f7031d = r3
                java.lang.Object r5 = r6.c(r5, r0)
                if (r5 != r1) goto L69
                return r1
            L69:
                r5 = r4
            L6a:
                boolean r6 = r5.f()
                java.lang.String r0 = ""
                if (r6 == 0) goto L81
                com.getbouncer.cardscan.ui.result.a$b r6 = new com.getbouncer.cardscan.ui.result.a$b
                java.lang.String r5 = r5.e()
                if (r5 != 0) goto L7b
                goto L7c
            L7b:
                r0 = r5
            L7c:
                r6.<init>(r0)
            L7f:
                r5 = r6
                goto La1
            L81:
                p3.b r6 = r5.a()
                p3.c r6 = r6.a()
                p3.c r1 = h3.d.e()
                int r6 = r6.compareTo(r1)
                if (r6 < 0) goto La1
                com.getbouncer.cardscan.ui.result.a$b r6 = new com.getbouncer.cardscan.ui.result.a$b
                java.lang.String r5 = r5.e()
                if (r5 != 0) goto L9c
                goto L9d
            L9c:
                r0 = r5
            L9d:
                r6.<init>(r0)
                goto L7f
            La1:
                return r5
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getbouncer.cardscan.ui.result.a.C0123a.b(f3.b$c, wc.d):java.lang.Object");
        }

        public final String e() {
            tc.o oVarA = g.a.a(this.f7027d, 0, 1, null);
            if (oVarA != null) {
                return (String) oVarA.d();
            }
            return null;
        }
    }

    public static final class b extends a {

        /* renamed from: d, reason: collision with root package name */
        private final String f7032d;

        /* JADX WARN: Illegal instructions before constructor call */
        public b(String pan) {
            m.g(pan, "pan");
            boolean z10 = false;
            super(z10, z10, null);
            this.f7032d = pan;
        }

        @Override // com.getbouncer.cardscan.ui.result.a
        public Object b(b.c cVar, wc.d dVar) {
            return this;
        }

        public final String e() {
            return this.f7032d;
        }
    }

    public static final class c extends a {
        public c() {
            super(true, false, null);
        }

        @Override // com.getbouncer.cardscan.ui.result.a
        public Object b(b.c cVar, wc.d dVar) {
            String strB;
            k.d dVarB = cVar.b();
            if (!t3.h.d(dVarB != null ? dVarB.b() : null)) {
                return this;
            }
            k.d dVarB2 = cVar.b();
            if (dVarB2 == null || (strB = dVarB2.b()) == null) {
                strB = "";
            }
            return new d(new h(strB));
        }
    }

    public static final class d extends a {

        /* renamed from: d, reason: collision with root package name */
        private final h f7033d;

        /* renamed from: e, reason: collision with root package name */
        private int f7034e;

        /* renamed from: com.getbouncer.cardscan.ui.result.a$d$a, reason: collision with other inner class name */
        static final class C0125a extends kotlin.coroutines.jvm.internal.d {

            /* renamed from: a, reason: collision with root package name */
            Object f7035a;

            /* renamed from: b, reason: collision with root package name */
            Object f7036b;

            /* renamed from: c, reason: collision with root package name */
            /* synthetic */ Object f7037c;

            /* renamed from: e, reason: collision with root package name */
            int f7039e;

            C0125a(wc.d dVar) {
                super(dVar);
            }

            @Override // kotlin.coroutines.jvm.internal.a
            public final Object invokeSuspend(Object obj) {
                this.f7037c = obj;
                this.f7039e |= LinearLayoutManager.INVALID_OFFSET;
                return d.this.b(null, this);
            }
        }

        /* JADX WARN: Illegal instructions before constructor call */
        public d(h panCounter) {
            m.g(panCounter, "panCounter");
            boolean z10 = true;
            super(z10, z10, null);
            this.f7033d = panCounter;
        }

        private final boolean f() {
            return this.f7034e >= h3.d.b();
        }

        private final boolean g() {
            tc.o oVarA = g.a.a(this.f7033d, 0, 1, null);
            if ((oVarA != null ? ((Number) oVarA.c()).intValue() : 0) < h3.d.a()) {
                tc.o oVarA2 = g.a.a(this.f7033d, 0, 1, null);
                if ((oVarA2 != null ? ((Number) oVarA2.c()).intValue() : 0) < h3.d.c() || a().a().compareTo(h3.d.e()) <= 0) {
                    return false;
                }
            }
            return true;
        }

        /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
        @Override // com.getbouncer.cardscan.ui.result.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public java.lang.Object b(f3.b.c r6, wc.d r7) throws java.lang.Throwable {
            /*
                r5 = this;
                boolean r0 = r7 instanceof com.getbouncer.cardscan.ui.result.a.d.C0125a
                if (r0 == 0) goto L13
                r0 = r7
                com.getbouncer.cardscan.ui.result.a$d$a r0 = (com.getbouncer.cardscan.ui.result.a.d.C0125a) r0
                int r1 = r0.f7039e
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f7039e = r1
                goto L18
            L13:
                com.getbouncer.cardscan.ui.result.a$d$a r0 = new com.getbouncer.cardscan.ui.result.a$d$a
                r0.<init>(r7)
            L18:
                java.lang.Object r7 = r0.f7037c
                java.lang.Object r1 = xc.b.c()
                int r2 = r0.f7039e
                java.lang.String r3 = ""
                r4 = 1
                if (r2 == 0) goto L3b
                if (r2 != r4) goto L33
                java.lang.Object r6 = r0.f7036b
                f3.b$c r6 = (f3.b.c) r6
                java.lang.Object r0 = r0.f7035a
                com.getbouncer.cardscan.ui.result.a$d r0 = (com.getbouncer.cardscan.ui.result.a.d) r0
                tc.q.b(r7)
                goto L6d
            L33:
                java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
                r6.<init>(r7)
                throw r6
            L3b:
                tc.q.b(r7)
                u3.k$d r7 = r6.b()
                if (r7 == 0) goto L49
                java.lang.String r7 = r7.b()
                goto L4a
            L49:
                r7 = 0
            L4a:
                boolean r7 = t3.h.d(r7)
                if (r7 == 0) goto L6c
                q3.h r7 = r5.f7033d
                u3.k$d r2 = r6.b()
                if (r2 == 0) goto L5e
                java.lang.String r2 = r2.b()
                if (r2 != 0) goto L5f
            L5e:
                r2 = r3
            L5f:
                r0.f7035a = r5
                r0.f7036b = r6
                r0.f7039e = r4
                java.lang.Object r7 = r7.c(r2, r0)
                if (r7 != r1) goto L6c
                return r1
            L6c:
                r0 = r5
            L6d:
                java.lang.Boolean r6 = r6.c()
                java.lang.Boolean r7 = kotlin.coroutines.jvm.internal.b.a(r4)
                boolean r6 = kotlin.jvm.internal.m.b(r6, r7)
                if (r6 == 0) goto L80
                int r6 = r0.f7034e
                int r6 = r6 + r4
                r0.f7034e = r6
            L80:
                p3.b r6 = r0.a()
                p3.c r6 = r6.a()
                p3.c r7 = h3.d.d()
                int r6 = r6.compareTo(r7)
                if (r6 <= 0) goto La1
                com.getbouncer.cardscan.ui.result.a$b r6 = new com.getbouncer.cardscan.ui.result.a$b
                java.lang.String r7 = r0.e()
                if (r7 != 0) goto L9b
                goto L9c
            L9b:
                r3 = r7
            L9c:
                r6.<init>(r3)
            L9f:
                r0 = r6
                goto Ldf
            La1:
                boolean r6 = r0.f()
                if (r6 == 0) goto Lbb
                boolean r6 = r0.g()
                if (r6 == 0) goto Lbb
                com.getbouncer.cardscan.ui.result.a$b r6 = new com.getbouncer.cardscan.ui.result.a$b
                java.lang.String r7 = r0.e()
                if (r7 != 0) goto Lb6
                goto Lb7
            Lb6:
                r3 = r7
            Lb7:
                r6.<init>(r3)
                goto L9f
            Lbb:
                boolean r6 = r0.f()
                if (r6 == 0) goto Lc9
                com.getbouncer.cardscan.ui.result.a$a r6 = new com.getbouncer.cardscan.ui.result.a$a
                q3.h r7 = r0.f7033d
                r6.<init>(r7)
                goto L9f
            Lc9:
                boolean r6 = r0.g()
                if (r6 == 0) goto Ldf
                com.getbouncer.cardscan.ui.result.a$e r6 = new com.getbouncer.cardscan.ui.result.a$e
                java.lang.String r7 = r0.e()
                if (r7 != 0) goto Ld8
                goto Ld9
            Ld8:
                r3 = r7
            Ld9:
                int r7 = r0.f7034e
                r6.<init>(r3, r7)
                goto L9f
            Ldf:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getbouncer.cardscan.ui.result.a.d.b(f3.b$c, wc.d):java.lang.Object");
        }

        public final String e() {
            tc.o oVarA = g.a.a(this.f7033d, 0, 1, null);
            if (oVarA != null) {
                return (String) oVarA.d();
            }
            return null;
        }
    }

    public static final class e extends a {

        /* renamed from: d, reason: collision with root package name */
        private final String f7040d;

        /* renamed from: e, reason: collision with root package name */
        private int f7041e;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(String pan, int i10) {
            super(false, true, null);
            m.g(pan, "pan");
            this.f7040d = pan;
            this.f7041e = i10;
        }

        private final boolean f() {
            return this.f7041e >= h3.d.b();
        }

        @Override // com.getbouncer.cardscan.ui.result.a
        public Object b(b.c cVar, wc.d dVar) {
            if (m.b(cVar.c(), kotlin.coroutines.jvm.internal.b.a(true))) {
                this.f7041e++;
            }
            if (a().a().compareTo(h3.d.e()) <= 0 && !f()) {
                return this;
            }
            return new b(this.f7040d);
        }

        public final String e() {
            return this.f7040d;
        }
    }

    private a(boolean z10, boolean z11) {
        this.f7025b = z10;
        this.f7026c = z11;
    }

    public /* synthetic */ a(boolean z10, boolean z11, kotlin.jvm.internal.g gVar) {
        this(z10, z11);
    }

    public abstract Object b(b.c cVar, wc.d dVar);

    public final boolean c() {
        return this.f7026c;
    }

    public final boolean d() {
        return this.f7025b;
    }
}
