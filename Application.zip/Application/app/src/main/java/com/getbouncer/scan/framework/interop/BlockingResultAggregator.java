package com.getbouncer.scan.framework.interop;

import com.getbouncer.scan.framework.ResultAggregator;
import tc.o;
import wc.d;

/* loaded from: classes.dex */
public abstract class BlockingResultAggregator<DataFrame, State, AnalyzerResult, InterimResult, FinalResult> extends ResultAggregator<DataFrame, State, AnalyzerResult, InterimResult, FinalResult> {
    static /* synthetic */ Object n(BlockingResultAggregator blockingResultAggregator, Object obj, Object obj2, d dVar) {
        return blockingResultAggregator.o(obj, obj2);
    }

    @Override // com.getbouncer.scan.framework.ResultAggregator
    public Object k(Object obj, Object obj2, d dVar) {
        return n(this, obj, obj2, dVar);
    }

    public abstract o o(Object obj, Object obj2);
}
