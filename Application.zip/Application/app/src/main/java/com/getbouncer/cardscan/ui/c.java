package com.getbouncer.cardscan.ui;

import android.os.Parcel;
import android.os.Parcelable;
import e3.i;
import kotlin.jvm.internal.m;

/* loaded from: classes.dex */
public interface c extends Parcelable {

    public static final class a implements c {
        public static final Parcelable.Creator<a> CREATOR = new C0121a();

        /* renamed from: a, reason: collision with root package name */
        private final x3.c f7012a;

        /* renamed from: com.getbouncer.cardscan.ui.c$a$a, reason: collision with other inner class name */
        public static final class C0121a implements Parcelable.Creator {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final a createFromParcel(Parcel parcel) {
                m.g(parcel, "parcel");
                return new a((x3.c) parcel.readParcelable(a.class.getClassLoader()));
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final a[] newArray(int i10) {
                return new a[i10];
            }
        }

        public a(x3.c reason) {
            m.g(reason, "reason");
            this.f7012a = reason;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof a) && m.b(this.f7012a, ((a) obj).f7012a);
        }

        public int hashCode() {
            return this.f7012a.hashCode();
        }

        public String toString() {
            return "Canceled(reason=" + this.f7012a + ')';
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int i10) {
            m.g(out, "out");
            out.writeParcelable(this.f7012a, i10);
        }
    }

    public static final class b implements c {
        public static final Parcelable.Creator<b> CREATOR = new a();

        /* renamed from: a, reason: collision with root package name */
        private final i f7013a;

        public static final class a implements Parcelable.Creator {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final b createFromParcel(Parcel parcel) {
                m.g(parcel, "parcel");
                return new b(i.CREATOR.createFromParcel(parcel));
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final b[] newArray(int i10) {
                return new b[i10];
            }
        }

        public b(i scannedCard) {
            m.g(scannedCard, "scannedCard");
            this.f7013a = scannedCard;
        }

        public final i b() {
            return this.f7013a;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof b) && m.b(this.f7013a, ((b) obj).f7013a);
        }

        public int hashCode() {
            return this.f7013a.hashCode();
        }

        public String toString() {
            return "Completed(scannedCard=" + this.f7013a + ')';
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int i10) {
            m.g(out, "out");
            this.f7013a.writeToParcel(out, i10);
        }
    }

    /* renamed from: com.getbouncer.cardscan.ui.c$c, reason: collision with other inner class name */
    public static final class C0122c implements c {
        public static final Parcelable.Creator<C0122c> CREATOR = new a();

        /* renamed from: a, reason: collision with root package name */
        private final Throwable f7014a;

        /* renamed from: com.getbouncer.cardscan.ui.c$c$a */
        public static final class a implements Parcelable.Creator {
            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public final C0122c createFromParcel(Parcel parcel) {
                m.g(parcel, "parcel");
                return new C0122c((Throwable) parcel.readSerializable());
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public final C0122c[] newArray(int i10) {
                return new C0122c[i10];
            }
        }

        public C0122c(Throwable error) {
            m.g(error, "error");
            this.f7014a = error;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof C0122c) && m.b(this.f7014a, ((C0122c) obj).f7014a);
        }

        public int hashCode() {
            return this.f7014a.hashCode();
        }

        public String toString() {
            return "Failed(error=" + this.f7014a + ')';
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel out, int i10) {
            m.g(out, "out");
            out.writeSerializable(this.f7014a);
        }
    }
}
