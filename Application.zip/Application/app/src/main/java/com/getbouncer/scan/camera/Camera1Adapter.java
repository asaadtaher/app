package com.getbouncer.scan.camera;

import android.app.Activity;
import android.graphics.ImageFormat;
import android.graphics.PointF;
import android.graphics.Rect;
import android.hardware.Camera;
import android.os.Handler;
import android.os.HandlerThread;
import android.renderscript.RenderScript;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Size;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup;
import androidx.lifecycle.h;
import androidx.lifecycle.u;
import com.getbouncer.scan.camera.Camera1Adapter;
import ed.l;
import i3.f;
import i3.g;
import i3.h;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import k3.y;
import kotlin.jvm.internal.m;
import kotlin.jvm.internal.n;
import m3.d;
import m3.e;
import q3.k;
import tc.x;

/* loaded from: classes.dex */
public final class Camera1Adapter extends CameraAdapter<h> implements Camera.PreviewCallback {

    /* renamed from: d, reason: collision with root package name */
    private final Activity f7042d;

    /* renamed from: e, reason: collision with root package name */
    private final ViewGroup f7043e;

    /* renamed from: f, reason: collision with root package name */
    private final Size f7044f;

    /* renamed from: g, reason: collision with root package name */
    private final g f7045g;

    /* renamed from: h, reason: collision with root package name */
    private final String f7046h;

    /* renamed from: i, reason: collision with root package name */
    private Camera f7047i;

    /* renamed from: j, reason: collision with root package name */
    private a f7048j;

    /* renamed from: k, reason: collision with root package name */
    private int f7049k;

    /* renamed from: l, reason: collision with root package name */
    private WeakReference f7050l;

    /* renamed from: r, reason: collision with root package name */
    private int f7051r;

    /* renamed from: s, reason: collision with root package name */
    private final Handler f7052s;

    /* renamed from: t, reason: collision with root package name */
    private HandlerThread f7053t;

    /* renamed from: u, reason: collision with root package name */
    private Handler f7054u;

    /* JADX INFO: Access modifiers changed from: private */
    final class a extends SurfaceView implements Camera.AutoFocusCallback, SurfaceHolder.Callback {

        /* renamed from: a, reason: collision with root package name */
        private final Camera.PreviewCallback f7055a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ Camera1Adapter f7056b;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Removed duplicated region for block: B:6:0x002e A[PHI: r1
  0x002e: PHI (r1v2 java.lang.String) = (r1v0 java.lang.String), (r1v1 java.lang.String) binds: [B:5:0x002c, B:8:0x0038] A[DONT_GENERATE, DONT_INLINE]] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public a(com.getbouncer.scan.camera.Camera1Adapter r4, android.content.Context r5, android.hardware.Camera.PreviewCallback r6) {
            /*
                r3 = this;
                java.lang.String r0 = "context"
                kotlin.jvm.internal.m.g(r5, r0)
                java.lang.String r0 = "mPreviewCallback"
                kotlin.jvm.internal.m.g(r6, r0)
                r3.f7056b = r4
                r3.<init>(r5)
                r3.f7055a = r6
                android.view.SurfaceHolder r5 = r3.getHolder()
                r5.addCallback(r3)
                android.hardware.Camera r5 = com.getbouncer.scan.camera.Camera1Adapter.E(r4)
                if (r5 == 0) goto L45
                android.hardware.Camera$Parameters r6 = r5.getParameters()
                java.util.List r0 = r6.getSupportedFocusModes()
                java.lang.String r1 = "continuous-picture"
                boolean r2 = r0.contains(r1)
                if (r2 == 0) goto L32
            L2e:
                r6.setFocusMode(r1)
                goto L3b
            L32:
                java.lang.String r1 = "continuous-video"
                boolean r0 = r0.contains(r1)
                if (r0 == 0) goto L3b
                goto L2e
            L3b:
                r0 = 1
                r6.setRecordingHint(r0)
                kotlin.jvm.internal.m.d(r6)
                com.getbouncer.scan.camera.Camera1Adapter.y(r4, r5, r6)
            L45:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getbouncer.scan.camera.Camera1Adapter.a.<init>(com.getbouncer.scan.camera.Camera1Adapter, android.content.Context, android.hardware.Camera$PreviewCallback):void");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void c(Camera1Adapter this$0, Throwable t10) {
            m.g(this$0, "this$0");
            m.g(t10, "$t");
            this$0.f7045g.b(t10);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void d(Camera1Adapter this$0, Throwable t10) {
            m.g(this$0, "this$0");
            m.g(t10, "$t");
            this$0.f7045g.b(t10);
        }

        @Override // android.hardware.Camera.AutoFocusCallback
        public void onAutoFocus(boolean z10, Camera camera) {
            m.g(camera, "camera");
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceChanged(SurfaceHolder holder, int i10, int i11, int i12) {
            m.g(holder, "holder");
            if (getHolder().getSurface() == null) {
                return;
            }
            try {
                Camera camera = this.f7056b.f7047i;
                if (camera != null) {
                    camera.stopPreview();
                }
            } catch (Throwable unused) {
            }
            try {
                Camera camera2 = this.f7056b.f7047i;
                if (camera2 != null) {
                    camera2.setPreviewDisplay(getHolder());
                }
                int bitsPerPixel = ((i11 * i12) * ImageFormat.getBitsPerPixel(i10)) / 8;
                for (int i13 = 0; i13 < 3; i13++) {
                    Camera camera3 = this.f7056b.f7047i;
                    if (camera3 != null) {
                        camera3.addCallbackBuffer(new byte[bitsPerPixel]);
                    }
                }
                Camera camera4 = this.f7056b.f7047i;
                if (camera4 != null) {
                    camera4.setPreviewCallbackWithBuffer(this.f7055a);
                }
                this.f7056b.K();
            } catch (Throwable th) {
                Handler handler = this.f7056b.f7052s;
                final Camera1Adapter camera1Adapter = this.f7056b;
                handler.post(new Runnable() { // from class: com.getbouncer.scan.camera.b
                    @Override // java.lang.Runnable
                    public final void run() {
                        Camera1Adapter.a.c(camera1Adapter, th);
                    }
                });
            }
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceCreated(SurfaceHolder holder) {
            m.g(holder, "holder");
            try {
                Camera camera = this.f7056b.f7047i;
                if (camera != null) {
                    camera.setPreviewDisplay(getHolder());
                }
                Camera camera2 = this.f7056b.f7047i;
                if (camera2 != null) {
                    camera2.setPreviewCallbackWithBuffer(this.f7055a);
                }
                this.f7056b.K();
            } catch (Throwable th) {
                Handler handler = this.f7056b.f7052s;
                final Camera1Adapter camera1Adapter = this.f7056b;
                handler.post(new Runnable() { // from class: com.getbouncer.scan.camera.c
                    @Override // java.lang.Runnable
                    public final void run() {
                        Camera1Adapter.a.d(camera1Adapter, th);
                    }
                });
            }
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceDestroyed(SurfaceHolder holder) {
            m.g(holder, "holder");
        }
    }

    static final class b extends n implements ed.a {
        b() {
            super(0);
        }

        @Override // ed.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public final x invoke() {
            Camera camera = Camera1Adapter.this.f7047i;
            if (camera == null) {
                return null;
            }
            camera.startPreview();
            return x.f21992a;
        }
    }

    static final class c extends n implements l {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ l f7058a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ Camera1Adapter f7059b;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        c(l lVar, Camera1Adapter camera1Adapter) {
            super(1);
            this.f7058a = lVar;
            this.f7059b = camera1Adapter;
        }

        public final void a(Camera cam) {
            m.g(cam, "cam");
            this.f7058a.invoke(Boolean.valueOf(this.f7059b.C(cam)));
        }

        @Override // ed.l
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((Camera) obj);
            return x.f21992a;
        }
    }

    public Camera1Adapter(Activity activity, ViewGroup previewView, Size minimumResolution, g cameraErrorListener) {
        m.g(activity, "activity");
        m.g(previewView, "previewView");
        m.g(minimumResolution, "minimumResolution");
        m.g(cameraErrorListener, "cameraErrorListener");
        this.f7042d = activity;
        this.f7043e = previewView;
        this.f7044f = minimumResolution;
        this.f7045g = cameraErrorListener;
        this.f7046h = "Camera1";
        this.f7050l = new WeakReference(null);
        this.f7052s = new Handler(activity.getMainLooper());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void A(Camera1Adapter this$0, InterruptedException e10) {
        m.g(this$0, "this$0");
        m.g(e10, "$e");
        this$0.f7045g.b(e10);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void B(Camera1Adapter this$0, Throwable t10) {
        m.g(this$0, "this$0");
        m.g(t10, "$t");
        this$0.f7045g.b(t10);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean C(Camera camera) {
        List<String> supportedFlashModes;
        Camera.Parameters parameters = camera.getParameters();
        return (parameters == null || (supportedFlashModes = parameters.getSupportedFlashModes()) == null || !supportedFlashModes.contains("torch")) ? false : true;
    }

    private final void F(final Camera camera) {
        if (camera == null) {
            this.f7052s.post(new Runnable() { // from class: i3.c
                @Override // java.lang.Runnable
                public final void run() {
                    Camera1Adapter.J(this.f13376a);
                }
            });
            return;
        }
        this.f7047i = camera;
        w(this.f7042d);
        I();
        final a aVar = new a(this, this.f7042d, this);
        aVar.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        this.f7052s.post(new Runnable() { // from class: com.getbouncer.scan.camera.a
            @Override // java.lang.Runnable
            public final void run() {
                Camera1Adapter.z(this.f7065a, aVar, camera);
            }
        });
        this.f7048j = aVar;
    }

    private final void I() {
        Camera camera = this.f7047i;
        if (camera != null) {
            Camera.Parameters parameters = camera.getParameters();
            parameters.setPreviewFormat(17);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            this.f7042d.getWindowManager().getDefaultDisplay().getRealMetrics(displayMetrics);
            int iMax = Math.max(displayMetrics.heightPixels, displayMetrics.widthPixels);
            int iMin = Math.min(displayMetrics.heightPixels, displayMetrics.widthPixels);
            int height = this.f7044f.getHeight();
            Camera.Size sizeU = u(parameters.getSupportedPreviewSizes(), (iMax * height) / iMin, height);
            if (sizeU != null) {
                parameters.setPreviewSize(sizeU.width, sizeU.height);
            }
            m.d(parameters);
            x(camera, parameters);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void J(Camera1Adapter this$0) {
        m.g(this$0, "this$0");
        a aVar = this$0.f7048j;
        if (aVar != null) {
            aVar.getHolder().removeCallback(aVar);
        }
        this$0.f7045g.b(null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void K() {
        Handler handler = this.f7054u;
        if (handler != null) {
            handler.post(new Runnable() { // from class: i3.b
                @Override // java.lang.Runnable
                public final void run() {
                    Camera1Adapter.N(this.f13375a);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void L(Camera1Adapter this$0) {
        Camera cameraOpen;
        m.g(this$0, "this$0");
        try {
            try {
                cameraOpen = Camera.open(this$0.f7051r);
            } catch (Throwable th) {
                this$0.f7045g.b(th);
                cameraOpen = null;
            }
            this$0.F(cameraOpen);
        } catch (Throwable th2) {
            this$0.f7045g.b(th2);
        }
    }

    private final void M() {
        HandlerThread handlerThread = new HandlerThread("CameraBackground");
        handlerThread.start();
        this.f7053t = handlerThread;
        this.f7054u = new Handler(handlerThread.getLooper());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void N(final Camera1Adapter this$0) {
        m.g(this$0, "this$0");
        try {
            k.b(5, null, this$0.new b(), 2, null);
        } catch (Throwable th) {
            this$0.f7052s.post(new Runnable() { // from class: i3.e
                @Override // java.lang.Runnable
                public final void run() {
                    Camera1Adapter.B(this.f13379a, th);
                }
            });
        }
    }

    private final void O() throws InterruptedException {
        HandlerThread handlerThread = this.f7053t;
        if (handlerThread != null) {
            handlerThread.quitSafely();
        }
        try {
            HandlerThread handlerThread2 = this.f7053t;
            if (handlerThread2 != null) {
                handlerThread2.join();
            }
            this.f7053t = null;
            this.f7054u = null;
        } catch (InterruptedException e10) {
            this.f7052s.post(new Runnable() { // from class: i3.d
                @Override // java.lang.Runnable
                public final void run() {
                    Camera1Adapter.A(this.f13377a, e10);
                }
            });
        }
    }

    private final Camera.Size u(List list, int i10, int i11) {
        double d10 = i10 / i11;
        Camera.Size size = null;
        if (list == null) {
            return null;
        }
        Iterator it = list.iterator();
        while (it.hasNext()) {
            Camera.Size size2 = (Camera.Size) it.next();
            if (Math.abs((size2.width / size2.height) - d10) <= 0.2d && size2.height >= i11) {
                size = size2;
            }
        }
        if (size == null) {
            double d11 = Double.MAX_VALUE;
            Iterator it2 = list.iterator();
            while (it2.hasNext()) {
                Camera.Size size3 = (Camera.Size) it2.next();
                double dAbs = Math.abs((size3.width / size3.height) - d10);
                int i12 = size3.height;
                if (i12 >= i11 && dAbs <= d11 && i12 <= f.f13381a.getHeight() && size3.width <= f.f13381a.getWidth()) {
                    size = size3;
                    d11 = dAbs;
                }
            }
        }
        if (size == null) {
            Iterator it3 = list.iterator();
            while (it3.hasNext()) {
                Camera.Size size4 = (Camera.Size) it3.next();
                if (size4.height >= i11) {
                    size = size4;
                }
            }
        }
        return size;
    }

    private final void w(Activity activity) {
        Camera camera = this.f7047i;
        if (camera == null) {
            return;
        }
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        Camera.getCameraInfo(0, cameraInfo);
        int iA = CameraAdapter.f7060c.a(activity.getWindowManager().getDefaultDisplay().getRotation());
        int i10 = cameraInfo.facing;
        int i11 = cameraInfo.orientation;
        int i12 = i10 == 1 ? (360 - ((i11 + iA) % 360)) % 360 : ((i11 - iA) + 360) % 360;
        try {
            camera.stopPreview();
        } catch (Exception unused) {
        }
        try {
            camera.setDisplayOrientation(i12);
        } catch (Throwable unused2) {
        }
        K();
        this.f7049k = i12;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void x(Camera camera, Camera.Parameters parameters) {
        try {
            camera.setParameters(parameters);
        } catch (Throwable th) {
            Log.w(k3.h.a(), "Error setting camera parameters", th);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void z(Camera1Adapter this$0, a cameraPreview, Camera camera) {
        m.g(this$0, "this$0");
        m.g(cameraPreview, "$cameraPreview");
        l lVar = (l) this$0.f7050l.get();
        if (lVar != null) {
            lVar.invoke(camera);
        }
        this$0.f7050l.clear();
        this$0.f7043e.removeAllViews();
        this$0.f7043e.addView(cameraPreview);
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void c() throws InterruptedException {
        int i10 = this.f7051r + 1;
        this.f7051r = i10;
        if (i10 >= Camera.getNumberOfCameras()) {
            this.f7051r = 0;
        }
        onPause();
        onResume();
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void d(PointF point) {
        m.g(point, "point");
        Camera camera = this.f7047i;
        if (camera != null) {
            Camera.Parameters parameters = camera.getParameters();
            if (parameters.getMaxNumFocusAreas() > 0) {
                int i10 = (int) point.x;
                int i11 = (int) point.y;
                Rect rect = new Rect(i10 - 150, i11 - 150, i10 + 150, i11 + 150);
                ArrayList arrayList = new ArrayList();
                arrayList.add(new Camera.Area(rect, 1000));
                parameters.setFocusAreas(arrayList);
                m.d(parameters);
                x(camera, parameters);
            }
        }
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void g(l task) {
        x xVar;
        m.g(task, "task");
        Camera camera = this.f7047i;
        if (camera != null) {
            task.invoke(Boolean.valueOf(C(camera)));
            xVar = x.f21992a;
        } else {
            xVar = null;
        }
        if (xVar == null) {
            this.f7050l = new WeakReference(new c(task, this));
        }
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void h(boolean z10) {
        Camera camera = this.f7047i;
        if (camera != null) {
            Camera.Parameters parameters = camera.getParameters();
            parameters.setFlashMode(z10 ? "torch" : "off");
            m.d(parameters);
            x(camera, parameters);
            K();
        }
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public void l(l task) {
        m.g(task, "task");
        task.invoke(Boolean.valueOf(Camera.getNumberOfCameras() > 1));
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    public boolean n() {
        Camera.Parameters parameters;
        Camera camera = this.f7047i;
        return m.b((camera == null || (parameters = camera.getParameters()) == null) ? null : parameters.getFlashMode(), "torch");
    }

    @Override // com.getbouncer.scan.camera.CameraAdapter
    @u(h.a.ON_PAUSE)
    public void onPause() throws InterruptedException {
        super.onPause();
        Camera camera = this.f7047i;
        if (camera != null) {
            camera.stopPreview();
        }
        Camera camera2 = this.f7047i;
        if (camera2 != null) {
            camera2.setPreviewCallbackWithBuffer(null);
        }
        Camera camera3 = this.f7047i;
        if (camera3 != null) {
            camera3.release();
        }
        this.f7047i = null;
        a aVar = this.f7048j;
        if (aVar != null) {
            aVar.getHolder().removeCallback(aVar);
        }
        this.f7048j = null;
        O();
    }

    @Override // android.hardware.Camera.PreviewCallback
    public void onPreviewFrame(byte[] bArr, Camera camera) {
        m.g(camera, "camera");
        try {
            int i10 = camera.getParameters().getPreviewSize().width;
            int i11 = camera.getParameters().getPreviewSize().height;
            if (bArr == null) {
                camera.addCallbackBuffer(new byte[gd.c.a(i10 * i11 * 1.5d)]);
                return;
            }
            try {
                d dVar = new d(i10, i11, bArr);
                Object objInvoke = e.a().invoke(this.f7042d);
                m.f(objInvoke, "invoke(...)");
                a(new i3.h(new y(m3.a.a(dVar.a((RenderScript) objInvoke), this.f7049k)), new Rect(0, 0, this.f7043e.getWidth(), this.f7043e.getHeight())));
            } finally {
                try {
                } finally {
                }
            }
        } catch (Throwable unused) {
        }
    }

    @u(h.a.ON_RESUME)
    public final void onResume() {
        M();
        this.f7052s.post(new Runnable() { // from class: i3.a
            @Override // java.lang.Runnable
            public final void run() {
                Camera1Adapter.L(this.f13374a);
            }
        });
    }
}
