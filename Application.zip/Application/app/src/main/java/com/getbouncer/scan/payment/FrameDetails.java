package com.getbouncer.scan.payment;

import androidx.annotation.Keep;
import androidx.window.embedding.a;

@Keep
/* loaded from: classes.dex */
public final class FrameDetails {
    private final boolean hasPan;
    private final float noCardConfidence;
    private final float noPanSideConfidence;
    private final float panSideConfidence;

    public FrameDetails(float f10, float f11, float f12, boolean z10) {
        this.panSideConfidence = f10;
        this.noPanSideConfidence = f11;
        this.noCardConfidence = f12;
        this.hasPan = z10;
    }

    public static /* synthetic */ FrameDetails copy$default(FrameDetails frameDetails, float f10, float f11, float f12, boolean z10, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            f10 = frameDetails.panSideConfidence;
        }
        if ((i10 & 2) != 0) {
            f11 = frameDetails.noPanSideConfidence;
        }
        if ((i10 & 4) != 0) {
            f12 = frameDetails.noCardConfidence;
        }
        if ((i10 & 8) != 0) {
            z10 = frameDetails.hasPan;
        }
        return frameDetails.copy(f10, f11, f12, z10);
    }

    public final float component1() {
        return this.panSideConfidence;
    }

    public final float component2() {
        return this.noPanSideConfidence;
    }

    public final float component3() {
        return this.noCardConfidence;
    }

    public final boolean component4() {
        return this.hasPan;
    }

    public final FrameDetails copy(float f10, float f11, float f12, boolean z10) {
        return new FrameDetails(f10, f11, f12, z10);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FrameDetails)) {
            return false;
        }
        FrameDetails frameDetails = (FrameDetails) obj;
        return Float.compare(this.panSideConfidence, frameDetails.panSideConfidence) == 0 && Float.compare(this.noPanSideConfidence, frameDetails.noPanSideConfidence) == 0 && Float.compare(this.noCardConfidence, frameDetails.noCardConfidence) == 0 && this.hasPan == frameDetails.hasPan;
    }

    public final boolean getHasPan() {
        return this.hasPan;
    }

    public final float getNoCardConfidence() {
        return this.noCardConfidence;
    }

    public final float getNoPanSideConfidence() {
        return this.noPanSideConfidence;
    }

    public final float getPanSideConfidence() {
        return this.panSideConfidence;
    }

    public int hashCode() {
        return (((((Float.floatToIntBits(this.panSideConfidence) * 31) + Float.floatToIntBits(this.noPanSideConfidence)) * 31) + Float.floatToIntBits(this.noCardConfidence)) * 31) + a.a(this.hasPan);
    }

    public String toString() {
        return "FrameDetails(panSideConfidence=" + this.panSideConfidence + ", noPanSideConfidence=" + this.noPanSideConfidence + ", noCardConfidence=" + this.noCardConfidence + ", hasPan=" + this.hasPan + ')';
    }
}
