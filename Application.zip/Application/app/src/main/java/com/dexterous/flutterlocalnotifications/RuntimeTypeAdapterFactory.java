package com.dexterous.flutterlocalnotifications;

import androidx.annotation.Keep;
import java.util.LinkedHashMap;
import java.util.Map;
import p9.e;
import p9.k;
import p9.n;
import p9.o;
import p9.p;
import p9.x;
import p9.y;
import r9.m;

@Keep
/* loaded from: classes.dex */
public final class RuntimeTypeAdapterFactory<T> implements y {
    private final Class<?> baseType;
    private final Map<String, Class<?>> labelToSubtype = new LinkedHashMap();
    private final Map<Class<?>, String> subtypeToLabel = new LinkedHashMap();
    private final String typeFieldName;

    /* JADX INFO: Add missing generic type declarations: [R] */
    class a<R> extends x<R> {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ Map f6881a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ Map f6882b;

        a(Map map, Map map2) {
            this.f6881a = map;
            this.f6882b = map2;
        }

        @Override // p9.x
        public R c(w9.a aVar) {
            k kVarA = m.a(aVar);
            k kVarZ = kVarA.k().z(RuntimeTypeAdapterFactory.this.typeFieldName);
            if (kVarZ == null) {
                throw new o("cannot deserialize " + RuntimeTypeAdapterFactory.this.baseType + " because it does not define a field named " + RuntimeTypeAdapterFactory.this.typeFieldName);
            }
            String strP = kVarZ.p();
            x xVar = (x) this.f6881a.get(strP);
            if (xVar != null) {
                return (R) xVar.a(kVarA);
            }
            throw new o("cannot deserialize " + RuntimeTypeAdapterFactory.this.baseType + " subtype named " + strP + "; did you forget to register a subtype?");
        }

        @Override // p9.x
        public void e(w9.c cVar, R r10) {
            Class<?> cls = r10.getClass();
            String str = (String) RuntimeTypeAdapterFactory.this.subtypeToLabel.get(cls);
            x xVar = (x) this.f6882b.get(cls);
            if (xVar == null) {
                throw new o("cannot serialize " + cls.getName() + "; did you forget to register a subtype?");
            }
            n nVarK = xVar.d(r10).k();
            if (nVarK.y(RuntimeTypeAdapterFactory.this.typeFieldName)) {
                throw new o("cannot serialize " + cls.getName() + " because it already defines a field named " + RuntimeTypeAdapterFactory.this.typeFieldName);
            }
            n nVar = new n();
            nVar.w(RuntimeTypeAdapterFactory.this.typeFieldName, new p(str));
            for (Map.Entry<String, k> entry : nVarK.x()) {
                nVar.w(entry.getKey(), entry.getValue());
            }
            m.b(nVar, cVar);
        }
    }

    private RuntimeTypeAdapterFactory(Class<?> cls, String str) {
        if (str == null || cls == null) {
            throw null;
        }
        this.baseType = cls;
        this.typeFieldName = str;
    }

    public static <T> RuntimeTypeAdapterFactory<T> of(Class<T> cls) {
        return new RuntimeTypeAdapterFactory<>(cls, "type");
    }

    public static <T> RuntimeTypeAdapterFactory<T> of(Class<T> cls, String str) {
        return new RuntimeTypeAdapterFactory<>(cls, str);
    }

    @Override // p9.y
    public <R> x<R> create(e eVar, com.google.gson.reflect.a<R> aVar) {
        if (aVar.getRawType() != this.baseType) {
            return null;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        LinkedHashMap linkedHashMap2 = new LinkedHashMap();
        for (Map.Entry<String, Class<?>> entry : this.labelToSubtype.entrySet()) {
            x<T> xVarN = eVar.n(this, com.google.gson.reflect.a.get((Class) entry.getValue()));
            linkedHashMap.put(entry.getKey(), xVarN);
            linkedHashMap2.put(entry.getValue(), xVarN);
        }
        return new a(linkedHashMap, linkedHashMap2).b();
    }

    public RuntimeTypeAdapterFactory<T> registerSubtype(Class<? extends T> cls) {
        return registerSubtype(cls, cls.getSimpleName());
    }

    public RuntimeTypeAdapterFactory<T> registerSubtype(Class<? extends T> cls, String str) {
        if (cls == null || str == null) {
            throw null;
        }
        if (this.subtypeToLabel.containsKey(cls) || this.labelToSubtype.containsKey(str)) {
            throw new IllegalArgumentException("types and labels must be unique");
        }
        this.labelToSubtype.put(str, cls);
        this.subtypeToLabel.put(cls, str);
        return this;
    }
}
