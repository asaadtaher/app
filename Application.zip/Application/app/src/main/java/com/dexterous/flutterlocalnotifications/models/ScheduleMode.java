package com.dexterous.flutterlocalnotifications.models;

import androidx.annotation.Keep;
import java.lang.reflect.Type;
import p9.i;
import p9.j;
import p9.k;

@Keep
/* loaded from: classes.dex */
public enum ScheduleMode {
    alarmClock,
    exact,
    exactAllowWhileIdle,
    inexact,
    inexactAllowWhileIdle;

    public static class a implements j<ScheduleMode> {
        @Override // p9.j
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public ScheduleMode a(k kVar, Type type, i iVar) {
            try {
                return ScheduleMode.valueOf(kVar.p());
            } catch (Exception unused) {
                return kVar.b() ? ScheduleMode.exactAllowWhileIdle : ScheduleMode.exact;
            }
        }
    }

    public boolean useAlarmClock() {
        return this == alarmClock;
    }

    public boolean useAllowWhileIdle() {
        return this == exactAllowWhileIdle || this == inexactAllowWhileIdle;
    }

    public boolean useExactAlarm() {
        return this == exact || this == exactAllowWhileIdle;
    }
}
