package com.dexterous.flutterlocalnotifications;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import androidx.annotation.Keep;
import androidx.core.app.p;
import gb.a;
import ib.f;
import io.flutter.view.FlutterCallbackInformation;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import tb.d;

/* loaded from: classes.dex */
public class ActionBroadcastReceiver extends BroadcastReceiver {

    /* renamed from: b, reason: collision with root package name */
    private static b f6864b;

    /* renamed from: c, reason: collision with root package name */
    private static io.flutter.embedding.engine.a f6865c;

    /* renamed from: a, reason: collision with root package name */
    y1.a f6866a;

    private static class b implements d.InterfaceC0377d {

        /* renamed from: a, reason: collision with root package name */
        final List<Map<String, Object>> f6867a;

        /* renamed from: b, reason: collision with root package name */
        private d.b f6868b;

        private b() {
            this.f6867a = new ArrayList();
        }

        @Override // tb.d.InterfaceC0377d
        public void a(Object obj, d.b bVar) {
            Iterator<Map<String, Object>> it = this.f6867a.iterator();
            while (it.hasNext()) {
                bVar.a(it.next());
            }
            this.f6867a.clear();
            this.f6868b = bVar;
        }

        @Override // tb.d.InterfaceC0377d
        public void b(Object obj) {
            this.f6868b = null;
        }

        public void c(Map<String, Object> map) {
            d.b bVar = this.f6868b;
            if (bVar != null) {
                bVar.a(map);
            } else {
                this.f6867a.add(map);
            }
        }
    }

    @Keep
    public ActionBroadcastReceiver() {
    }

    private void a(gb.a aVar) {
        new d(aVar.l(), "dexterous.com/flutter/local_notifications/actions").d(f6864b);
    }

    private void b(Context context) {
        if (f6865c != null) {
            Log.e("ActionBroadcastReceiver", "Engine is already initialised");
            return;
        }
        f fVarC = fb.a.e().c();
        fVarC.q(context);
        fVarC.g(context, null);
        f6865c = new io.flutter.embedding.engine.a(context);
        FlutterCallbackInformation flutterCallbackInformationD = this.f6866a.d();
        if (flutterCallbackInformationD == null) {
            Log.w("ActionBroadcastReceiver", "Callback information could not be retrieved");
            return;
        }
        gb.a aVarH = f6865c.h();
        a(aVarH);
        aVarH.j(new a.b(context.getAssets(), fVarC.i(), flutterCallbackInformationD));
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if ("com.dexterous.flutterlocalnotifications.ActionBroadcastReceiver.ACTION_TAPPED".equalsIgnoreCase(intent.getAction())) {
            y1.a aVar = this.f6866a;
            if (aVar == null) {
                aVar = new y1.a(context);
            }
            this.f6866a = aVar;
            Map<String, Object> mapExtractNotificationResponseMap = FlutterLocalNotificationsPlugin.extractNotificationResponseMap(intent);
            if (intent.getBooleanExtra("cancelNotification", false)) {
                p.f(context).b(((Integer) mapExtractNotificationResponseMap.get("notificationId")).intValue());
            }
            if (f6864b == null) {
                f6864b = new b();
            }
            f6864b.c(mapExtractNotificationResponseMap);
            b(context);
        }
    }
}
