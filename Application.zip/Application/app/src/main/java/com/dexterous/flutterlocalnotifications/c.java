package com.dexterous.flutterlocalnotifications;

/* loaded from: classes.dex */
interface c {
    void a(String str);

    void b(boolean z10);
}
