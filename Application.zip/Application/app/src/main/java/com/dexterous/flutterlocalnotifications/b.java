package com.dexterous.flutterlocalnotifications;

import com.dexterous.flutterlocalnotifications.models.NotificationDetails;
import java.io.Serializable;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class b implements Serializable {

    /* renamed from: a, reason: collision with root package name */
    public final NotificationDetails f6885a;

    /* renamed from: b, reason: collision with root package name */
    public final int f6886b;

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList<Integer> f6887c;

    public b(NotificationDetails notificationDetails, int i10, ArrayList<Integer> arrayList) {
        this.f6885a = notificationDetails;
        this.f6886b = i10;
        this.f6887c = arrayList;
    }

    public String toString() {
        return "ForegroundServiceStartParameter{notificationData=" + this.f6885a + ", startMode=" + this.f6886b + ", foregroundServiceTypes=" + this.f6887c + '}';
    }
}
