package com.android.installreferrer.api;

/* loaded from: classes.dex */
public interface InstallReferrerStateListener {
    void a(int i10);

    void b();
}
