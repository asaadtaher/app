package com.android.installreferrer.api;

import android.os.Bundle;

/* loaded from: classes.dex */
public class ReferrerDetails {

    /* renamed from: a, reason: collision with root package name */
    private final Bundle f6799a;

    public ReferrerDetails(Bundle bundle) {
        this.f6799a = bundle;
    }

    public String a() {
        return this.f6799a.getString("install_referrer");
    }
}
