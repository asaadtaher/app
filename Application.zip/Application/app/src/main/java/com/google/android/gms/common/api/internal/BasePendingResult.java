package com.google.android.gms.common.api.internal;

import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.api.Status;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import y4.h;
import y4.m;

@KeepName
/* loaded from: classes.dex */
public abstract class BasePendingResult<R extends y4.m> extends y4.h<R> {

    /* renamed from: p, reason: collision with root package name */
    static final ThreadLocal f7260p = new r1();

    /* renamed from: q, reason: collision with root package name */
    public static final /* synthetic */ int f7261q = 0;

    /* renamed from: a, reason: collision with root package name */
    private final Object f7262a;

    /* renamed from: b, reason: collision with root package name */
    protected final a f7263b;

    /* renamed from: c, reason: collision with root package name */
    protected final WeakReference f7264c;

    /* renamed from: d, reason: collision with root package name */
    private final CountDownLatch f7265d;

    /* renamed from: e, reason: collision with root package name */
    private final ArrayList f7266e;

    /* renamed from: f, reason: collision with root package name */
    private y4.n f7267f;

    /* renamed from: g, reason: collision with root package name */
    private final AtomicReference f7268g;

    /* renamed from: h, reason: collision with root package name */
    private y4.m f7269h;

    /* renamed from: i, reason: collision with root package name */
    private Status f7270i;

    /* renamed from: j, reason: collision with root package name */
    private volatile boolean f7271j;

    /* renamed from: k, reason: collision with root package name */
    private boolean f7272k;

    /* renamed from: l, reason: collision with root package name */
    private boolean f7273l;

    /* renamed from: m, reason: collision with root package name */
    private a5.l f7274m;

    @KeepName
    private s1 mResultGuardian;

    /* renamed from: n, reason: collision with root package name */
    private volatile d1 f7275n;

    /* renamed from: o, reason: collision with root package name */
    private boolean f7276o;

    public static class a<R extends y4.m> extends m5.n {
        public a(Looper looper) {
            super(looper);
        }

        public final void a(y4.n nVar, y4.m mVar) {
            int i10 = BasePendingResult.f7261q;
            sendMessage(obtainMessage(1, new Pair((y4.n) a5.r.k(nVar), mVar)));
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // android.os.Handler
        public final void handleMessage(Message message) {
            int i10 = message.what;
            if (i10 == 1) {
                Pair pair = (Pair) message.obj;
                y4.n nVar = (y4.n) pair.first;
                y4.m mVar = (y4.m) pair.second;
                try {
                    nVar.a(mVar);
                    return;
                } catch (RuntimeException e10) {
                    BasePendingResult.m(mVar);
                    throw e10;
                }
            }
            if (i10 == 2) {
                ((BasePendingResult) message.obj).e(Status.f7251j);
                return;
            }
            Log.wtf("BasePendingResult", "Don't know how to handle message: " + i10, new Exception());
        }
    }

    @Deprecated
    BasePendingResult() {
        this.f7262a = new Object();
        this.f7265d = new CountDownLatch(1);
        this.f7266e = new ArrayList();
        this.f7268g = new AtomicReference();
        this.f7276o = false;
        this.f7263b = new a(Looper.getMainLooper());
        this.f7264c = new WeakReference(null);
    }

    protected BasePendingResult(y4.f fVar) {
        this.f7262a = new Object();
        this.f7265d = new CountDownLatch(1);
        this.f7266e = new ArrayList();
        this.f7268g = new AtomicReference();
        this.f7276o = false;
        this.f7263b = new a(fVar != null ? fVar.l() : Looper.getMainLooper());
        this.f7264c = new WeakReference(fVar);
    }

    private final y4.m i() {
        y4.m mVar;
        synchronized (this.f7262a) {
            a5.r.n(!this.f7271j, "Result has already been consumed.");
            a5.r.n(g(), "Result is not ready.");
            mVar = this.f7269h;
            this.f7269h = null;
            this.f7267f = null;
            this.f7271j = true;
        }
        e1 e1Var = (e1) this.f7268g.getAndSet(null);
        if (e1Var != null) {
            e1Var.f7347a.f7354a.remove(this);
        }
        return (y4.m) a5.r.k(mVar);
    }

    private final void j(y4.m mVar) {
        this.f7269h = mVar;
        this.f7270i = mVar.h();
        z4.p0 p0Var = null;
        this.f7274m = null;
        this.f7265d.countDown();
        if (this.f7272k) {
            this.f7267f = null;
        } else {
            y4.n nVar = this.f7267f;
            if (nVar != null) {
                this.f7263b.removeMessages(2);
                this.f7263b.a(nVar, i());
            } else if (this.f7269h instanceof y4.j) {
                this.mResultGuardian = new s1(this, p0Var);
            }
        }
        ArrayList arrayList = this.f7266e;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((h.a) arrayList.get(i10)).a(this.f7270i);
        }
        this.f7266e.clear();
    }

    public static void m(y4.m mVar) {
        if (mVar instanceof y4.j) {
            try {
                ((y4.j) mVar).a();
            } catch (RuntimeException e10) {
                Log.w("BasePendingResult", "Unable to release ".concat(String.valueOf(mVar)), e10);
            }
        }
    }

    @Override // y4.h
    public final void a(h.a aVar) {
        a5.r.b(aVar != null, "Callback cannot be null.");
        synchronized (this.f7262a) {
            if (g()) {
                aVar.a(this.f7270i);
            } else {
                this.f7266e.add(aVar);
            }
        }
    }

    @Override // y4.h
    public final R b(long j10, TimeUnit timeUnit) {
        if (j10 > 0) {
            a5.r.j("await must not be called on the UI thread when time is greater than zero.");
        }
        a5.r.n(!this.f7271j, "Result has already been consumed.");
        a5.r.n(this.f7275n == null, "Cannot await if then() has been called.");
        try {
            if (!this.f7265d.await(j10, timeUnit)) {
                e(Status.f7251j);
            }
        } catch (InterruptedException unused) {
            e(Status.f7249h);
        }
        a5.r.n(g(), "Result is not ready.");
        return (R) i();
    }

    public void c() {
        synchronized (this.f7262a) {
            if (!this.f7272k && !this.f7271j) {
                a5.l lVar = this.f7274m;
                if (lVar != null) {
                    try {
                        lVar.cancel();
                    } catch (RemoteException unused) {
                    }
                }
                m(this.f7269h);
                this.f7272k = true;
                j(d(Status.f7252k));
            }
        }
    }

    protected abstract R d(Status status);

    @Deprecated
    public final void e(Status status) {
        synchronized (this.f7262a) {
            if (!g()) {
                h(d(status));
                this.f7273l = true;
            }
        }
    }

    public final boolean f() {
        boolean z10;
        synchronized (this.f7262a) {
            z10 = this.f7272k;
        }
        return z10;
    }

    public final boolean g() {
        return this.f7265d.getCount() == 0;
    }

    public final void h(R r10) {
        synchronized (this.f7262a) {
            if (this.f7273l || this.f7272k) {
                m(r10);
                return;
            }
            g();
            a5.r.n(!g(), "Results have already been set");
            a5.r.n(!this.f7271j, "Result has already been consumed");
            j(r10);
        }
    }

    public final void l() {
        boolean z10 = true;
        if (!this.f7276o && !((Boolean) f7260p.get()).booleanValue()) {
            z10 = false;
        }
        this.f7276o = z10;
    }

    public final boolean n() {
        boolean zF;
        synchronized (this.f7262a) {
            if (((y4.f) this.f7264c.get()) == null || !this.f7276o) {
                c();
            }
            zF = f();
        }
        return zF;
    }

    public final void o(e1 e1Var) {
        this.f7268g.set(e1Var);
    }
}
