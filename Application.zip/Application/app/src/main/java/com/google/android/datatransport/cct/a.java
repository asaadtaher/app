package com.google.android.datatransport.cct;

import b4.g;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/* loaded from: classes.dex */
public final class a implements g {

    /* renamed from: c, reason: collision with root package name */
    static final String f7124c;

    /* renamed from: d, reason: collision with root package name */
    static final String f7125d;

    /* renamed from: e, reason: collision with root package name */
    private static final String f7126e;

    /* renamed from: f, reason: collision with root package name */
    private static final Set<z3.b> f7127f;

    /* renamed from: g, reason: collision with root package name */
    public static final a f7128g;

    /* renamed from: h, reason: collision with root package name */
    public static final a f7129h;

    /* renamed from: a, reason: collision with root package name */
    private final String f7130a;

    /* renamed from: b, reason: collision with root package name */
    private final String f7131b;

    static {
        String strA = e.a("hts/frbslgiggolai.o/0clgbthfra=snpoo", "tp:/ieaeogn.ogepscmvc/o/ac?omtjo_rt3");
        f7124c = strA;
        String strA2 = e.a("hts/frbslgigp.ogepscmv/ieo/eaybtho", "tp:/ieaeogn-agolai.o/1frlglgc/aclg");
        f7125d = strA2;
        String strA3 = e.a("AzSCki82AwsLzKd5O8zo", "IayckHiZRO1EFl1aGoK");
        f7126e = strA3;
        f7127f = Collections.unmodifiableSet(new HashSet(Arrays.asList(z3.b.b("proto"), z3.b.b("json"))));
        f7128g = new a(strA, null);
        f7129h = new a(strA2, strA3);
    }

    public a(String str, String str2) {
        this.f7130a = str;
        this.f7131b = str2;
    }

    public static a e(byte[] bArr) {
        String str = new String(bArr, Charset.forName("UTF-8"));
        if (!str.startsWith("1$")) {
            throw new IllegalArgumentException("Version marker missing from extras");
        }
        String[] strArrSplit = str.substring(2).split(Pattern.quote("\\"), 2);
        if (strArrSplit.length != 2) {
            throw new IllegalArgumentException("Extra is not a valid encoded LegacyFlgDestination");
        }
        String str2 = strArrSplit[0];
        if (str2.isEmpty()) {
            throw new IllegalArgumentException("Missing endpoint in CCTDestination extras");
        }
        String str3 = strArrSplit[1];
        if (str3.isEmpty()) {
            str3 = null;
        }
        return new a(str2, str3);
    }

    @Override // b4.g
    public Set<z3.b> a() {
        return f7127f;
    }

    @Override // b4.f
    public String b() {
        return "cct";
    }

    @Override // b4.f
    public byte[] c() {
        return d();
    }

    public byte[] d() {
        String str = this.f7131b;
        if (str == null && this.f7130a == null) {
            return null;
        }
        Object[] objArr = new Object[4];
        objArr[0] = "1$";
        objArr[1] = this.f7130a;
        objArr[2] = "\\";
        if (str == null) {
            str = "";
        }
        objArr[3] = str;
        return String.format("%s%s%s%s", objArr).getBytes(Charset.forName("UTF-8"));
    }

    public String f() {
        return this.f7131b;
    }

    public String g() {
        return this.f7130a;
    }
}
