package com.google.android.gms.auth.api.credentials;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;

@Deprecated
/* loaded from: classes.dex */
public final class CredentialPickerConfig extends b5.a implements ReflectedParcelable {
    public static final Parcelable.Creator<CredentialPickerConfig> CREATOR = new b();

    /* renamed from: a, reason: collision with root package name */
    final int f7163a;

    /* renamed from: b, reason: collision with root package name */
    private final boolean f7164b;

    /* renamed from: c, reason: collision with root package name */
    private final boolean f7165c;

    /* renamed from: d, reason: collision with root package name */
    private final int f7166d;

    public static class a {

        /* renamed from: a, reason: collision with root package name */
        private boolean f7167a = false;

        /* renamed from: b, reason: collision with root package name */
        private boolean f7168b = true;

        /* renamed from: c, reason: collision with root package name */
        private int f7169c = 1;

        public CredentialPickerConfig a() {
            return new CredentialPickerConfig(2, this.f7167a, this.f7168b, false, this.f7169c);
        }
    }

    CredentialPickerConfig(int i10, boolean z10, boolean z11, boolean z12, int i11) {
        this.f7163a = i10;
        this.f7164b = z10;
        this.f7165c = z11;
        if (i10 < 2) {
            this.f7166d = true == z12 ? 3 : 1;
        } else {
            this.f7166d = i11;
        }
    }

    @Deprecated
    public boolean j() {
        return this.f7166d == 3;
    }

    public boolean k() {
        return this.f7164b;
    }

    public boolean l() {
        return this.f7165c;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.c(parcel, 1, k());
        b5.c.c(parcel, 2, l());
        b5.c.c(parcel, 3, j());
        b5.c.k(parcel, 4, this.f7166d);
        b5.c.k(parcel, 1000, this.f7163a);
        b5.c.b(parcel, iA);
    }
}
