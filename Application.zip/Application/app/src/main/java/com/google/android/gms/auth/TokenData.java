package com.google.android.gms.auth;

import a5.p;
import a5.r;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import b5.c;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.List;

/* loaded from: classes.dex */
public class TokenData extends b5.a implements ReflectedParcelable {
    public static final Parcelable.Creator<TokenData> CREATOR = new a();

    /* renamed from: a, reason: collision with root package name */
    final int f7147a;

    /* renamed from: b, reason: collision with root package name */
    private final String f7148b;

    /* renamed from: c, reason: collision with root package name */
    private final Long f7149c;

    /* renamed from: d, reason: collision with root package name */
    private final boolean f7150d;

    /* renamed from: e, reason: collision with root package name */
    private final boolean f7151e;

    /* renamed from: f, reason: collision with root package name */
    private final List f7152f;

    /* renamed from: g, reason: collision with root package name */
    private final String f7153g;

    TokenData(int i10, String str, Long l10, boolean z10, boolean z11, List list, String str2) {
        this.f7147a = i10;
        this.f7148b = r.g(str);
        this.f7149c = l10;
        this.f7150d = z10;
        this.f7151e = z11;
        this.f7152f = list;
        this.f7153g = str2;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof TokenData)) {
            return false;
        }
        TokenData tokenData = (TokenData) obj;
        return TextUtils.equals(this.f7148b, tokenData.f7148b) && p.b(this.f7149c, tokenData.f7149c) && this.f7150d == tokenData.f7150d && this.f7151e == tokenData.f7151e && p.b(this.f7152f, tokenData.f7152f) && p.b(this.f7153g, tokenData.f7153g);
    }

    public final int hashCode() {
        return p.c(this.f7148b, this.f7149c, Boolean.valueOf(this.f7150d), Boolean.valueOf(this.f7151e), this.f7152f, this.f7153g);
    }

    public final String j() {
        return this.f7148b;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int iA = c.a(parcel);
        c.k(parcel, 1, this.f7147a);
        c.r(parcel, 2, this.f7148b, false);
        c.p(parcel, 3, this.f7149c, false);
        c.c(parcel, 4, this.f7150d);
        c.c(parcel, 5, this.f7151e);
        c.t(parcel, 6, this.f7152f, false);
        c.r(parcel, 7, this.f7153g, false);
        c.b(parcel, iA);
    }
}
