package com.google.android.gms.auth.api.credentials;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class c implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b5.b.z(parcel);
        CredentialPickerConfig credentialPickerConfig = null;
        String[] strArrF = null;
        String strE = null;
        String strE2 = null;
        int iS = 0;
        boolean zL = false;
        boolean zL2 = false;
        boolean zL3 = false;
        while (parcel.dataPosition() < iZ) {
            int iQ = b5.b.q(parcel);
            int iK = b5.b.k(iQ);
            if (iK != 1000) {
                switch (iK) {
                    case 1:
                        credentialPickerConfig = (CredentialPickerConfig) b5.b.d(parcel, iQ, CredentialPickerConfig.CREATOR);
                        break;
                    case 2:
                        zL = b5.b.l(parcel, iQ);
                        break;
                    case 3:
                        zL2 = b5.b.l(parcel, iQ);
                        break;
                    case 4:
                        strArrF = b5.b.f(parcel, iQ);
                        break;
                    case 5:
                        zL3 = b5.b.l(parcel, iQ);
                        break;
                    case 6:
                        strE = b5.b.e(parcel, iQ);
                        break;
                    case 7:
                        strE2 = b5.b.e(parcel, iQ);
                        break;
                    default:
                        b5.b.y(parcel, iQ);
                        break;
                }
            } else {
                iS = b5.b.s(parcel, iQ);
            }
        }
        b5.b.j(parcel, iZ);
        return new HintRequest(iS, credentialPickerConfig, zL, zL2, strArrF, zL3, strE, strE2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new HintRequest[i10];
    }
}
