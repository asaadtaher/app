package com.google.android.gms.common.api.internal;

/* loaded from: classes.dex */
abstract class b0 implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ c0 f7288a;

    protected abstract void a();

    @Override // java.lang.Runnable
    public final void run() {
        this.f7288a.f7311b.lock();
        try {
            try {
                if (!Thread.interrupted()) {
                    a();
                }
            } catch (RuntimeException e10) {
                this.f7288a.f7310a.p(e10);
            }
        } finally {
            this.f7288a.f7311b.unlock();
        }
    }
}
