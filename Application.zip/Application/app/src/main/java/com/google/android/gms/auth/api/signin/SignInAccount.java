package com.google.android.gms.auth.api.signin;

import a5.r;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;

/* loaded from: classes.dex */
public class SignInAccount extends b5.a implements ReflectedParcelable {
    public static final Parcelable.Creator<SignInAccount> CREATOR = new g();

    /* renamed from: a, reason: collision with root package name */
    @Deprecated
    final String f7229a;

    /* renamed from: b, reason: collision with root package name */
    private final GoogleSignInAccount f7230b;

    /* renamed from: c, reason: collision with root package name */
    @Deprecated
    final String f7231c;

    SignInAccount(String str, GoogleSignInAccount googleSignInAccount, String str2) {
        this.f7230b = googleSignInAccount;
        this.f7229a = r.h(str, "8.3 and 8.4 SDKs require non-null email");
        this.f7231c = r.h(str2, "8.3 and 8.4 SDKs require non-null userId");
    }

    public final GoogleSignInAccount j() {
        return this.f7230b;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.r(parcel, 4, this.f7229a, false);
        b5.c.q(parcel, 7, this.f7230b, i10, false);
        b5.c.r(parcel, 8, this.f7231c, false);
        b5.c.b(parcel, iA);
    }
}
