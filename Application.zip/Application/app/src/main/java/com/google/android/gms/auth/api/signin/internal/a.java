package com.google.android.gms.auth.api.signin.internal;

import android.os.Bundle;
import androidx.loader.app.a;
import c1.b;
import u4.g;
import u4.z;
import y4.f;

/* loaded from: classes.dex */
final class a implements a.InterfaceC0068a {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ SignInHubActivity f7242a;

    /* synthetic */ a(SignInHubActivity signInHubActivity, z zVar) {
        this.f7242a = signInHubActivity;
    }

    @Override // androidx.loader.app.a.InterfaceC0068a
    public final /* bridge */ /* synthetic */ void a(b bVar, Object obj) {
        SignInHubActivity signInHubActivity = this.f7242a;
        signInHubActivity.setResult(signInHubActivity.f7240w, signInHubActivity.f7241x);
        this.f7242a.finish();
    }

    @Override // androidx.loader.app.a.InterfaceC0068a
    public final void b(b bVar) {
    }

    @Override // androidx.loader.app.a.InterfaceC0068a
    public final b c(int i10, Bundle bundle) {
        return new g(this.f7242a, f.i());
    }
}
