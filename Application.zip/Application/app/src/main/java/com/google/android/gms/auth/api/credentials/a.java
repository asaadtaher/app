package com.google.android.gms.auth.api.credentials;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class a implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b5.b.z(parcel);
        String strE = null;
        String strE2 = null;
        Uri uri = null;
        ArrayList arrayListI = null;
        String strE3 = null;
        String strE4 = null;
        String strE5 = null;
        String strE6 = null;
        while (parcel.dataPosition() < iZ) {
            int iQ = b5.b.q(parcel);
            switch (b5.b.k(iQ)) {
                case 1:
                    strE = b5.b.e(parcel, iQ);
                    break;
                case 2:
                    strE2 = b5.b.e(parcel, iQ);
                    break;
                case 3:
                    uri = (Uri) b5.b.d(parcel, iQ, Uri.CREATOR);
                    break;
                case 4:
                    arrayListI = b5.b.i(parcel, iQ, IdToken.CREATOR);
                    break;
                case 5:
                    strE3 = b5.b.e(parcel, iQ);
                    break;
                case 6:
                    strE4 = b5.b.e(parcel, iQ);
                    break;
                case 7:
                case 8:
                default:
                    b5.b.y(parcel, iQ);
                    break;
                case 9:
                    strE5 = b5.b.e(parcel, iQ);
                    break;
                case 10:
                    strE6 = b5.b.e(parcel, iQ);
                    break;
            }
        }
        b5.b.j(parcel, iZ);
        return new Credential(strE, strE2, uri, arrayListI, strE3, strE4, strE5, strE6);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new Credential[i10];
    }
}
