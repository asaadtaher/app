package com.google.android.gms.auth.api.credentials;

import a5.r;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.CredentialPickerConfig;
import com.google.android.gms.common.internal.ReflectedParcelable;

@Deprecated
/* loaded from: classes.dex */
public final class HintRequest extends b5.a implements ReflectedParcelable {
    public static final Parcelable.Creator<HintRequest> CREATOR = new c();

    /* renamed from: a, reason: collision with root package name */
    final int f7170a;

    /* renamed from: b, reason: collision with root package name */
    private final CredentialPickerConfig f7171b;

    /* renamed from: c, reason: collision with root package name */
    private final boolean f7172c;

    /* renamed from: d, reason: collision with root package name */
    private final boolean f7173d;

    /* renamed from: e, reason: collision with root package name */
    private final String[] f7174e;

    /* renamed from: f, reason: collision with root package name */
    private final boolean f7175f;

    /* renamed from: g, reason: collision with root package name */
    private final String f7176g;

    /* renamed from: h, reason: collision with root package name */
    private final String f7177h;

    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        private boolean f7178a;

        /* renamed from: b, reason: collision with root package name */
        private boolean f7179b;

        /* renamed from: c, reason: collision with root package name */
        private String[] f7180c;

        /* renamed from: d, reason: collision with root package name */
        private CredentialPickerConfig f7181d = new CredentialPickerConfig.a().a();

        /* renamed from: e, reason: collision with root package name */
        private boolean f7182e = false;

        /* renamed from: f, reason: collision with root package name */
        private String f7183f;

        /* renamed from: g, reason: collision with root package name */
        private String f7184g;

        public HintRequest a() {
            if (this.f7180c == null) {
                this.f7180c = new String[0];
            }
            if (this.f7178a || this.f7179b || this.f7180c.length != 0) {
                return new HintRequest(2, this.f7181d, this.f7178a, this.f7179b, this.f7180c, this.f7182e, this.f7183f, this.f7184g);
            }
            throw new IllegalStateException("At least one authentication method must be specified");
        }

        public a b(boolean z10) {
            this.f7179b = z10;
            return this;
        }
    }

    HintRequest(int i10, CredentialPickerConfig credentialPickerConfig, boolean z10, boolean z11, String[] strArr, boolean z12, String str, String str2) {
        this.f7170a = i10;
        this.f7171b = (CredentialPickerConfig) r.k(credentialPickerConfig);
        this.f7172c = z10;
        this.f7173d = z11;
        this.f7174e = (String[]) r.k(strArr);
        if (i10 < 2) {
            this.f7175f = true;
            this.f7176g = null;
            this.f7177h = null;
        } else {
            this.f7175f = z12;
            this.f7176g = str;
            this.f7177h = str2;
        }
    }

    public String[] j() {
        return this.f7174e;
    }

    public CredentialPickerConfig k() {
        return this.f7171b;
    }

    public String l() {
        return this.f7177h;
    }

    public String m() {
        return this.f7176g;
    }

    public boolean n() {
        return this.f7172c;
    }

    public boolean o() {
        return this.f7175f;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.q(parcel, 1, k(), i10, false);
        b5.c.c(parcel, 2, n());
        b5.c.c(parcel, 3, this.f7173d);
        b5.c.s(parcel, 4, j(), false);
        b5.c.c(parcel, 5, o());
        b5.c.r(parcel, 6, m(), false);
        b5.c.r(parcel, 7, l(), false);
        b5.c.k(parcel, 1000, this.f7170a);
        b5.c.b(parcel, iA);
    }
}
