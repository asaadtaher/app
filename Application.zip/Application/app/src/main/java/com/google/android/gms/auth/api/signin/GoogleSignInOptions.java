package com.google.android.gms.auth.api.signin;

import a5.r;
import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import y4.a;

/* loaded from: classes.dex */
public class GoogleSignInOptions extends b5.a implements a.d, ReflectedParcelable {
    public static final Parcelable.Creator<GoogleSignInOptions> CREATOR;

    /* renamed from: l, reason: collision with root package name */
    public static final GoogleSignInOptions f7201l;

    /* renamed from: r, reason: collision with root package name */
    public static final GoogleSignInOptions f7202r;

    /* renamed from: s, reason: collision with root package name */
    public static final Scope f7203s = new Scope("profile");

    /* renamed from: t, reason: collision with root package name */
    public static final Scope f7204t = new Scope("email");

    /* renamed from: u, reason: collision with root package name */
    public static final Scope f7205u = new Scope("openid");

    /* renamed from: v, reason: collision with root package name */
    public static final Scope f7206v;

    /* renamed from: w, reason: collision with root package name */
    public static final Scope f7207w;

    /* renamed from: x, reason: collision with root package name */
    private static Comparator f7208x;

    /* renamed from: a, reason: collision with root package name */
    final int f7209a;

    /* renamed from: b, reason: collision with root package name */
    private final ArrayList f7210b;

    /* renamed from: c, reason: collision with root package name */
    private Account f7211c;

    /* renamed from: d, reason: collision with root package name */
    private boolean f7212d;

    /* renamed from: e, reason: collision with root package name */
    private final boolean f7213e;

    /* renamed from: f, reason: collision with root package name */
    private final boolean f7214f;

    /* renamed from: g, reason: collision with root package name */
    private String f7215g;

    /* renamed from: h, reason: collision with root package name */
    private String f7216h;

    /* renamed from: i, reason: collision with root package name */
    private ArrayList f7217i;

    /* renamed from: j, reason: collision with root package name */
    private String f7218j;

    /* renamed from: k, reason: collision with root package name */
    private Map f7219k;

    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        private Set f7220a;

        /* renamed from: b, reason: collision with root package name */
        private boolean f7221b;

        /* renamed from: c, reason: collision with root package name */
        private boolean f7222c;

        /* renamed from: d, reason: collision with root package name */
        private boolean f7223d;

        /* renamed from: e, reason: collision with root package name */
        private String f7224e;

        /* renamed from: f, reason: collision with root package name */
        private Account f7225f;

        /* renamed from: g, reason: collision with root package name */
        private String f7226g;

        /* renamed from: h, reason: collision with root package name */
        private Map f7227h;

        /* renamed from: i, reason: collision with root package name */
        private String f7228i;

        public a() {
            this.f7220a = new HashSet();
            this.f7227h = new HashMap();
        }

        public a(GoogleSignInOptions googleSignInOptions) {
            this.f7220a = new HashSet();
            this.f7227h = new HashMap();
            r.k(googleSignInOptions);
            this.f7220a = new HashSet(googleSignInOptions.f7210b);
            this.f7221b = googleSignInOptions.f7213e;
            this.f7222c = googleSignInOptions.f7214f;
            this.f7223d = googleSignInOptions.f7212d;
            this.f7224e = googleSignInOptions.f7215g;
            this.f7225f = googleSignInOptions.f7211c;
            this.f7226g = googleSignInOptions.f7216h;
            this.f7227h = GoogleSignInOptions.G(googleSignInOptions.f7217i);
            this.f7228i = googleSignInOptions.f7218j;
        }

        private final String k(String str) {
            r.g(str);
            String str2 = this.f7224e;
            boolean z10 = true;
            if (str2 != null && !str2.equals(str)) {
                z10 = false;
            }
            r.b(z10, "two different server client ids provided");
            return str;
        }

        public GoogleSignInOptions a() {
            if (this.f7220a.contains(GoogleSignInOptions.f7207w)) {
                Set set = this.f7220a;
                Scope scope = GoogleSignInOptions.f7206v;
                if (set.contains(scope)) {
                    this.f7220a.remove(scope);
                }
            }
            if (this.f7223d && (this.f7225f == null || !this.f7220a.isEmpty())) {
                c();
            }
            return new GoogleSignInOptions(new ArrayList(this.f7220a), this.f7225f, this.f7223d, this.f7221b, this.f7222c, this.f7224e, this.f7226g, this.f7227h, this.f7228i);
        }

        public a b() {
            this.f7220a.add(GoogleSignInOptions.f7204t);
            return this;
        }

        public a c() {
            this.f7220a.add(GoogleSignInOptions.f7205u);
            return this;
        }

        public a d(String str) {
            this.f7223d = true;
            k(str);
            this.f7224e = str;
            return this;
        }

        public a e() {
            this.f7220a.add(GoogleSignInOptions.f7203s);
            return this;
        }

        public a f(Scope scope, Scope... scopeArr) {
            this.f7220a.add(scope);
            this.f7220a.addAll(Arrays.asList(scopeArr));
            return this;
        }

        public a g(String str, boolean z10) {
            this.f7221b = true;
            k(str);
            this.f7224e = str;
            this.f7222c = z10;
            return this;
        }

        public a h(String str) {
            this.f7225f = new Account(r.g(str), "com.google");
            return this;
        }

        public a i(String str) {
            this.f7226g = r.g(str);
            return this;
        }

        public a j(String str) {
            this.f7228i = str;
            return this;
        }
    }

    static {
        Scope scope = new Scope("https://www.googleapis.com/auth/games_lite");
        f7206v = scope;
        f7207w = new Scope("https://www.googleapis.com/auth/games");
        a aVar = new a();
        aVar.c();
        aVar.e();
        f7201l = aVar.a();
        a aVar2 = new a();
        aVar2.f(scope, new Scope[0]);
        f7202r = aVar2.a();
        CREATOR = new e();
        f7208x = new d();
    }

    GoogleSignInOptions(int i10, ArrayList arrayList, Account account, boolean z10, boolean z11, boolean z12, String str, String str2, ArrayList arrayList2, String str3) {
        this(i10, arrayList, account, z10, z11, z12, str, str2, G(arrayList2), str3);
    }

    private GoogleSignInOptions(int i10, ArrayList arrayList, Account account, boolean z10, boolean z11, boolean z12, String str, String str2, Map map, String str3) {
        this.f7209a = i10;
        this.f7210b = arrayList;
        this.f7211c = account;
        this.f7212d = z10;
        this.f7213e = z11;
        this.f7214f = z12;
        this.f7215g = str;
        this.f7216h = str2;
        this.f7217i = new ArrayList(map.values());
        this.f7219k = map;
        this.f7218j = str3;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static Map G(List list) {
        HashMap map = new HashMap();
        if (list == null) {
            return map;
        }
        Iterator it = list.iterator();
        while (it.hasNext()) {
            u4.a aVar = (u4.a) it.next();
            map.put(Integer.valueOf(aVar.j()), aVar);
        }
        return map;
    }

    public static GoogleSignInOptions v(String str) throws JSONException {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(str);
        HashSet hashSet = new HashSet();
        JSONArray jSONArray = jSONObject.getJSONArray("scopes");
        int length = jSONArray.length();
        for (int i10 = 0; i10 < length; i10++) {
            hashSet.add(new Scope(jSONArray.getString(i10)));
        }
        String strOptString = jSONObject.has("accountName") ? jSONObject.optString("accountName") : null;
        return new GoogleSignInOptions(3, new ArrayList(hashSet), !TextUtils.isEmpty(strOptString) ? new Account(strOptString, "com.google") : null, jSONObject.getBoolean("idTokenRequested"), jSONObject.getBoolean("serverAuthRequested"), jSONObject.getBoolean("forceCodeForRefreshToken"), jSONObject.has("serverClientId") ? jSONObject.optString("serverClientId") : null, jSONObject.has("hostedDomain") ? jSONObject.optString("hostedDomain") : null, new HashMap(), (String) null);
    }

    public Account b() {
        return this.f7211c;
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0052 A[Catch: ClassCastException -> 0x0090, TryCatch #0 {ClassCastException -> 0x0090, blocks: (B:5:0x0004, B:7:0x000e, B:10:0x0018, B:12:0x0028, B:15:0x0035, B:17:0x0039, B:22:0x004a, B:24:0x0052, B:30:0x006a, B:32:0x0072, B:34:0x007a, B:36:0x0082, B:27:0x005d, B:20:0x0040), top: B:42:0x0004 }] */
    /* JADX WARN: Removed duplicated region for block: B:27:0x005d A[Catch: ClassCastException -> 0x0090, TryCatch #0 {ClassCastException -> 0x0090, blocks: (B:5:0x0004, B:7:0x000e, B:10:0x0018, B:12:0x0028, B:15:0x0035, B:17:0x0039, B:22:0x004a, B:24:0x0052, B:30:0x006a, B:32:0x0072, B:34:0x007a, B:36:0x0082, B:27:0x005d, B:20:0x0040), top: B:42:0x0004 }] */
    /* JADX WARN: Removed duplicated region for block: B:38:0x008e A[RETURN] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean equals(java.lang.Object r4) {
        /*
            r3 = this;
            r0 = 0
            if (r4 != 0) goto L4
            return r0
        L4:
            com.google.android.gms.auth.api.signin.GoogleSignInOptions r4 = (com.google.android.gms.auth.api.signin.GoogleSignInOptions) r4     // Catch: java.lang.ClassCastException -> L90
            java.util.ArrayList r1 = r3.f7217i     // Catch: java.lang.ClassCastException -> L90
            int r1 = r1.size()     // Catch: java.lang.ClassCastException -> L90
            if (r1 > 0) goto L90
            java.util.ArrayList r1 = r4.f7217i     // Catch: java.lang.ClassCastException -> L90
            int r1 = r1.size()     // Catch: java.lang.ClassCastException -> L90
            if (r1 <= 0) goto L18
            goto L90
        L18:
            java.util.ArrayList r1 = r3.f7210b     // Catch: java.lang.ClassCastException -> L90
            int r1 = r1.size()     // Catch: java.lang.ClassCastException -> L90
            java.util.ArrayList r2 = r4.l()     // Catch: java.lang.ClassCastException -> L90
            int r2 = r2.size()     // Catch: java.lang.ClassCastException -> L90
            if (r1 != r2) goto L90
            java.util.ArrayList r1 = r3.f7210b     // Catch: java.lang.ClassCastException -> L90
            java.util.ArrayList r2 = r4.l()     // Catch: java.lang.ClassCastException -> L90
            boolean r1 = r1.containsAll(r2)     // Catch: java.lang.ClassCastException -> L90
            if (r1 != 0) goto L35
            goto L90
        L35:
            android.accounts.Account r1 = r3.f7211c     // Catch: java.lang.ClassCastException -> L90
            if (r1 != 0) goto L40
            android.accounts.Account r1 = r4.b()     // Catch: java.lang.ClassCastException -> L90
            if (r1 != 0) goto L90
            goto L4a
        L40:
            android.accounts.Account r2 = r4.b()     // Catch: java.lang.ClassCastException -> L90
            boolean r1 = r1.equals(r2)     // Catch: java.lang.ClassCastException -> L90
            if (r1 == 0) goto L90
        L4a:
            java.lang.String r1 = r3.f7215g     // Catch: java.lang.ClassCastException -> L90
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch: java.lang.ClassCastException -> L90
            if (r1 == 0) goto L5d
            java.lang.String r1 = r4.m()     // Catch: java.lang.ClassCastException -> L90
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch: java.lang.ClassCastException -> L90
            if (r1 == 0) goto L90
            goto L6a
        L5d:
            java.lang.String r1 = r3.f7215g     // Catch: java.lang.ClassCastException -> L90
            java.lang.String r2 = r4.m()     // Catch: java.lang.ClassCastException -> L90
            boolean r1 = r1.equals(r2)     // Catch: java.lang.ClassCastException -> L90
            if (r1 != 0) goto L6a
            goto L90
        L6a:
            boolean r1 = r3.f7214f     // Catch: java.lang.ClassCastException -> L90
            boolean r2 = r4.n()     // Catch: java.lang.ClassCastException -> L90
            if (r1 != r2) goto L90
            boolean r1 = r3.f7212d     // Catch: java.lang.ClassCastException -> L90
            boolean r2 = r4.o()     // Catch: java.lang.ClassCastException -> L90
            if (r1 != r2) goto L90
            boolean r1 = r3.f7213e     // Catch: java.lang.ClassCastException -> L90
            boolean r2 = r4.q()     // Catch: java.lang.ClassCastException -> L90
            if (r1 != r2) goto L90
            java.lang.String r1 = r3.f7218j     // Catch: java.lang.ClassCastException -> L90
            java.lang.String r4 = r4.k()     // Catch: java.lang.ClassCastException -> L90
            boolean r4 = android.text.TextUtils.equals(r1, r4)     // Catch: java.lang.ClassCastException -> L90
            if (r4 == 0) goto L90
            r4 = 1
            return r4
        L90:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.auth.api.signin.GoogleSignInOptions.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = this.f7210b;
        int size = arrayList2.size();
        for (int i10 = 0; i10 < size; i10++) {
            arrayList.add(((Scope) arrayList2.get(i10)).j());
        }
        Collections.sort(arrayList);
        u4.b bVar = new u4.b();
        bVar.a(arrayList);
        bVar.a(this.f7211c);
        bVar.a(this.f7215g);
        bVar.c(this.f7214f);
        bVar.c(this.f7212d);
        bVar.c(this.f7213e);
        bVar.a(this.f7218j);
        return bVar.b();
    }

    public ArrayList<u4.a> j() {
        return this.f7217i;
    }

    public String k() {
        return this.f7218j;
    }

    public ArrayList<Scope> l() {
        return new ArrayList<>(this.f7210b);
    }

    public String m() {
        return this.f7215g;
    }

    public boolean n() {
        return this.f7214f;
    }

    public boolean o() {
        return this.f7212d;
    }

    public boolean q() {
        return this.f7213e;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.k(parcel, 1, this.f7209a);
        b5.c.v(parcel, 2, l(), false);
        b5.c.q(parcel, 3, b(), i10, false);
        b5.c.c(parcel, 4, o());
        b5.c.c(parcel, 5, q());
        b5.c.c(parcel, 6, n());
        b5.c.r(parcel, 7, m(), false);
        b5.c.r(parcel, 8, this.f7216h, false);
        b5.c.v(parcel, 9, j(), false);
        b5.c.r(parcel, 10, k(), false);
        b5.c.b(parcel, iA);
    }

    public final String z() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        try {
            JSONArray jSONArray = new JSONArray();
            Collections.sort(this.f7210b, f7208x);
            Iterator it = this.f7210b.iterator();
            while (it.hasNext()) {
                jSONArray.put(((Scope) it.next()).j());
            }
            jSONObject.put("scopes", jSONArray);
            Account account = this.f7211c;
            if (account != null) {
                jSONObject.put("accountName", account.name);
            }
            jSONObject.put("idTokenRequested", this.f7212d);
            jSONObject.put("forceCodeForRefreshToken", this.f7214f);
            jSONObject.put("serverAuthRequested", this.f7213e);
            if (!TextUtils.isEmpty(this.f7215g)) {
                jSONObject.put("serverClientId", this.f7215g);
            }
            if (!TextUtils.isEmpty(this.f7216h)) {
                jSONObject.put("hostedDomain", this.f7216h);
            }
            return jSONObject.toString();
        } catch (JSONException e10) {
            throw new RuntimeException(e10);
        }
    }
}
