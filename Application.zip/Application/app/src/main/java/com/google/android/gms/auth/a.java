package com.google.android.gms.auth;

import android.os.Parcel;
import android.os.Parcelable;
import b5.b;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class a implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b.z(parcel);
        String strE = null;
        Long lW = null;
        ArrayList<String> arrayListG = null;
        String strE2 = null;
        int iS = 0;
        boolean zL = false;
        boolean zL2 = false;
        while (parcel.dataPosition() < iZ) {
            int iQ = b.q(parcel);
            switch (b.k(iQ)) {
                case 1:
                    iS = b.s(parcel, iQ);
                    break;
                case 2:
                    strE = b.e(parcel, iQ);
                    break;
                case 3:
                    lW = b.w(parcel, iQ);
                    break;
                case 4:
                    zL = b.l(parcel, iQ);
                    break;
                case 5:
                    zL2 = b.l(parcel, iQ);
                    break;
                case 6:
                    arrayListG = b.g(parcel, iQ);
                    break;
                case 7:
                    strE2 = b.e(parcel, iQ);
                    break;
                default:
                    b.y(parcel, iQ);
                    break;
            }
        }
        b.j(parcel, iZ);
        return new TokenData(iS, strE, lW, zL, zL2, arrayListG, strE2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new TokenData[i10];
    }
}
