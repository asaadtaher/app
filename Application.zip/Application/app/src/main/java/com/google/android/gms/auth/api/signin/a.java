package com.google.android.gms.auth.api.signin;

import a5.r;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import b6.i;
import b6.l;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import java.util.Collections;
import java.util.HashSet;
import u4.q;

/* loaded from: classes.dex */
public final class a {
    public static b a(Context context, GoogleSignInOptions googleSignInOptions) {
        return new b(context, (GoogleSignInOptions) r.k(googleSignInOptions));
    }

    public static GoogleSignInAccount b(Context context) {
        return u4.r.c(context).a();
    }

    public static i<GoogleSignInAccount> c(Intent intent) {
        t4.b bVarD = q.d(intent);
        GoogleSignInAccount googleSignInAccountA = bVarD.a();
        return (!bVarD.h().n() || googleSignInAccountA == null) ? l.d(a5.b.a(bVarD.h())) : l.e(googleSignInAccountA);
    }

    public static boolean d(GoogleSignInAccount googleSignInAccount, Scope... scopeArr) {
        if (googleSignInAccount == null) {
            return false;
        }
        HashSet hashSet = new HashSet();
        Collections.addAll(hashSet, scopeArr);
        return googleSignInAccount.n().containsAll(hashSet);
    }

    public static void e(Activity activity, int i10, GoogleSignInAccount googleSignInAccount, Scope... scopeArr) {
        r.l(activity, "Please provide a non-null Activity");
        r.l(scopeArr, "Please provide at least one scope");
        activity.startActivityForResult(f(activity, googleSignInAccount, scopeArr), i10);
    }

    private static Intent f(Activity activity, GoogleSignInAccount googleSignInAccount, Scope... scopeArr) {
        GoogleSignInOptions.a aVar = new GoogleSignInOptions.a();
        if (scopeArr.length > 0) {
            aVar.f(scopeArr[0], scopeArr);
        }
        if (googleSignInAccount != null && !TextUtils.isEmpty(googleSignInAccount.k())) {
            aVar.h((String) r.k(googleSignInAccount.k()));
        }
        return new b(activity, aVar.a()).A();
    }
}
