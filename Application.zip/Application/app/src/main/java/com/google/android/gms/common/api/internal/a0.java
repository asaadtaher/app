package com.google.android.gms.common.api.internal;

import android.os.Bundle;
import y4.f;

/* loaded from: classes.dex */
final class a0 implements f.b, f.c {

    /* renamed from: c, reason: collision with root package name */
    final /* synthetic */ c0 f7283c;

    /* synthetic */ a0(c0 c0Var, z4.p pVar) {
        this.f7283c = c0Var;
    }

    @Override // z4.c
    public final void R(Bundle bundle) {
        ((y5.f) a5.r.k(this.f7283c.f7320k)).c(new z(this.f7283c));
    }

    @Override // z4.h
    public final void r(x4.b bVar) {
        this.f7283c.f7311b.lock();
        try {
            if (this.f7283c.q(bVar)) {
                this.f7283c.i();
                this.f7283c.n();
            } else {
                this.f7283c.l(bVar);
            }
        } finally {
            this.f7283c.f7311b.unlock();
        }
    }

    @Override // z4.c
    public final void y(int i10) {
    }
}
