package com.google.android.gms.auth.api.signin;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class g implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b5.b.z(parcel);
        String strE = "";
        GoogleSignInAccount googleSignInAccount = null;
        String strE2 = "";
        while (parcel.dataPosition() < iZ) {
            int iQ = b5.b.q(parcel);
            int iK = b5.b.k(iQ);
            if (iK == 4) {
                strE = b5.b.e(parcel, iQ);
            } else if (iK == 7) {
                googleSignInAccount = (GoogleSignInAccount) b5.b.d(parcel, iQ, GoogleSignInAccount.CREATOR);
            } else if (iK != 8) {
                b5.b.y(parcel, iQ);
            } else {
                strE2 = b5.b.e(parcel, iQ);
            }
        }
        b5.b.j(parcel, iZ);
        return new SignInAccount(strE, googleSignInAccount, strE2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new SignInAccount[i10];
    }
}
