package com.google.android.gms.auth.api.signin;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import b6.i;
import com.google.android.gms.dynamite.DynamiteModule;
import u4.q;
import y4.e;

/* loaded from: classes.dex */
public class b extends y4.e<GoogleSignInOptions> {

    /* renamed from: k, reason: collision with root package name */
    private static final f f7232k = new f(null);

    /* renamed from: l, reason: collision with root package name */
    static int f7233l = 1;

    b(Activity activity, GoogleSignInOptions googleSignInOptions) {
        super(activity, p4.a.f18911c, googleSignInOptions, new z4.a());
    }

    b(Context context, GoogleSignInOptions googleSignInOptions) {
        super(context, p4.a.f18911c, googleSignInOptions, new e.a.C0431a().c(new z4.a()).a());
    }

    private final synchronized int E() {
        int i10;
        i10 = f7233l;
        if (i10 == 1) {
            Context contextS = s();
            x4.e eVarP = x4.e.p();
            int i11 = eVarP.i(contextS, 12451000);
            if (i11 == 0) {
                f7233l = 4;
                i10 = 4;
            } else if (eVarP.c(contextS, i11, null) != null || DynamiteModule.a(contextS, "com.google.android.gms.auth.api.fallback") == 0) {
                f7233l = 2;
                i10 = 2;
            } else {
                f7233l = 3;
                i10 = 3;
            }
        }
        return i10;
    }

    public Intent A() {
        Context contextS = s();
        int iE = E();
        int i10 = iE - 1;
        if (iE != 0) {
            return i10 != 2 ? i10 != 3 ? q.b(contextS, r()) : q.c(contextS, r()) : q.a(contextS, r());
        }
        throw null;
    }

    public i<Void> B() {
        return a5.q.b(q.f(h(), s(), E() == 3));
    }

    public i<Void> C() {
        return a5.q.b(q.g(h(), s(), E() == 3));
    }

    public i<GoogleSignInAccount> D() {
        return a5.q.a(q.e(h(), s(), r(), E() == 3), f7232k);
    }
}
