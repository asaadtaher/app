package com.google.android.datatransport.cct;

import androidx.annotation.Keep;
import c4.h;
import c4.m;

@Keep
/* loaded from: classes.dex */
public class CctBackendFactory implements c4.d {
    @Override // c4.d
    public m create(h hVar) {
        return new d(hVar.b(), hVar.e(), hVar.d());
    }
}
