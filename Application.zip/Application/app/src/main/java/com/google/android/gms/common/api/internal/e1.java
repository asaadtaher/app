package com.google.android.gms.common.api.internal;

/* loaded from: classes.dex */
final class e1 {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ f1 f7347a;

    e1(f1 f1Var) {
        this.f7347a = f1Var;
    }
}
