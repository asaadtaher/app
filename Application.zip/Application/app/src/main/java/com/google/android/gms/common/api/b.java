package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class b implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b5.b.z(parcel);
        String strE = null;
        PendingIntent pendingIntent = null;
        x4.b bVar = null;
        int iS = 0;
        int iS2 = 0;
        while (parcel.dataPosition() < iZ) {
            int iQ = b5.b.q(parcel);
            int iK = b5.b.k(iQ);
            if (iK == 1) {
                iS2 = b5.b.s(parcel, iQ);
            } else if (iK == 2) {
                strE = b5.b.e(parcel, iQ);
            } else if (iK == 3) {
                pendingIntent = (PendingIntent) b5.b.d(parcel, iQ, PendingIntent.CREATOR);
            } else if (iK == 4) {
                bVar = (x4.b) b5.b.d(parcel, iQ, x4.b.CREATOR);
            } else if (iK != 1000) {
                b5.b.y(parcel, iQ);
            } else {
                iS = b5.b.s(parcel, iQ);
            }
        }
        b5.b.j(parcel, iZ);
        return new Status(iS, iS2, strE, pendingIntent, bVar);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new Status[i10];
    }
}
