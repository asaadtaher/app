package com.google.android.gms.common.api.internal;

import android.util.Log;
import com.google.android.gms.common.api.Status;
import java.lang.ref.WeakReference;
import y4.m;

/* loaded from: classes.dex */
public final class d1<R extends y4.m> extends y4.q<R> implements y4.n<R> {

    /* renamed from: a, reason: collision with root package name */
    private y4.p f7338a;

    /* renamed from: b, reason: collision with root package name */
    private d1 f7339b;

    /* renamed from: c, reason: collision with root package name */
    private volatile y4.o f7340c;

    /* renamed from: d, reason: collision with root package name */
    private final Object f7341d;

    /* renamed from: e, reason: collision with root package name */
    private Status f7342e;

    /* renamed from: f, reason: collision with root package name */
    private final WeakReference f7343f;

    /* renamed from: g, reason: collision with root package name */
    private final b1 f7344g;

    private final void g(Status status) {
        synchronized (this.f7341d) {
            this.f7342e = status;
            h(status);
        }
    }

    private final void h(Status status) {
        synchronized (this.f7341d) {
            y4.p pVar = this.f7338a;
            if (pVar != null) {
                ((d1) a5.r.k(this.f7339b)).g((Status) a5.r.l(pVar.a(status), "onFailure must not return null"));
            } else if (i()) {
                ((y4.o) a5.r.k(this.f7340c)).b(status);
            }
        }
    }

    private final boolean i() {
        return (this.f7340c == null || ((y4.f) this.f7343f.get()) == null) ? false : true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void j(y4.m mVar) {
        if (mVar instanceof y4.j) {
            try {
                ((y4.j) mVar).a();
            } catch (RuntimeException e10) {
                Log.w("TransformedResultImpl", "Unable to release ".concat(String.valueOf(mVar)), e10);
            }
        }
    }

    @Override // y4.n
    public final void a(y4.m mVar) {
        synchronized (this.f7341d) {
            if (!mVar.h().n()) {
                g(mVar.h());
                j(mVar);
            } else if (this.f7338a != null) {
                z4.i0.a().submit(new a1(this, mVar));
            } else if (i()) {
                ((y4.o) a5.r.k(this.f7340c)).c(mVar);
            }
        }
    }

    final void f() {
        this.f7340c = null;
    }
}
