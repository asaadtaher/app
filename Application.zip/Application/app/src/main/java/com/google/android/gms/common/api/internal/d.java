package com.google.android.gms.common.api.internal;

import android.os.Looper;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class d<L> {

    /* renamed from: a, reason: collision with root package name */
    private final Executor f7332a;

    /* renamed from: b, reason: collision with root package name */
    private volatile Object f7333b;

    /* renamed from: c, reason: collision with root package name */
    private volatile a f7334c;

    public static final class a<L> {

        /* renamed from: a, reason: collision with root package name */
        private final Object f7335a;

        /* renamed from: b, reason: collision with root package name */
        private final String f7336b;

        a(L l10, String str) {
            this.f7335a = l10;
            this.f7336b = str;
        }

        public String a() {
            return this.f7336b + "@" + System.identityHashCode(this.f7335a);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.f7335a == aVar.f7335a && this.f7336b.equals(aVar.f7336b);
        }

        public int hashCode() {
            return (System.identityHashCode(this.f7335a) * 31) + this.f7336b.hashCode();
        }
    }

    public interface b<L> {
        void a(L l10);

        void b();
    }

    d(Looper looper, L l10, String str) {
        this.f7332a = new g5.a(looper);
        this.f7333b = a5.r.l(l10, "Listener must not be null");
        this.f7334c = new a(l10, a5.r.g(str));
    }

    public void a() {
        this.f7333b = null;
        this.f7334c = null;
    }

    public a<L> b() {
        return this.f7334c;
    }

    public void c(final b<? super L> bVar) {
        a5.r.l(bVar, "Notifier must not be null");
        this.f7332a.execute(new Runnable() { // from class: com.google.android.gms.common.api.internal.u0
            @Override // java.lang.Runnable
            public final void run() {
                this.f7503a.d(bVar);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    final void d(b bVar) {
        Object obj = this.f7333b;
        if (obj == null) {
            bVar.b();
            return;
        }
        try {
            bVar.a(obj);
        } catch (RuntimeException e10) {
            bVar.b();
            throw e10;
        }
    }
}
