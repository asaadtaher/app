package com.google.android.gms.common.api.internal;

import android.app.PendingIntent;
import android.os.DeadObjectException;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import y4.a;
import y4.a.b;
import y4.m;

/* loaded from: classes.dex */
public abstract class b<R extends y4.m, A extends a.b> extends BasePendingResult<R> {

    /* renamed from: r, reason: collision with root package name */
    private final a.c<A> f7286r;

    /* renamed from: s, reason: collision with root package name */
    private final y4.a<?> f7287s;

    protected b(y4.a<?> aVar, y4.f fVar) {
        super((y4.f) a5.r.l(fVar, "GoogleApiClient must not be null"));
        a5.r.l(aVar, "Api must not be null");
        this.f7286r = aVar.b();
        this.f7287s = aVar;
    }

    private void u(RemoteException remoteException) {
        v(new Status(8, remoteException.getLocalizedMessage(), (PendingIntent) null));
    }

    protected abstract void p(A a10);

    public final y4.a<?> q() {
        return this.f7287s;
    }

    public final a.c<A> r() {
        return this.f7286r;
    }

    protected void s(R r10) {
    }

    public final void t(A a10) throws DeadObjectException {
        try {
            p(a10);
        } catch (DeadObjectException e10) {
            u(e10);
            throw e10;
        } catch (RemoteException e11) {
            u(e11);
        }
    }

    public final void v(Status status) {
        a5.r.b(!status.n(), "Failed result must not be success");
        R rD = d(status);
        h(rD);
        s(rD);
    }
}
