package com.google.android.gms.auth.api.credentials;

import a5.p;
import a5.r;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.gms.common.internal.ReflectedParcelable;

@Deprecated
/* loaded from: classes.dex */
public final class IdToken extends b5.a implements ReflectedParcelable {
    public static final Parcelable.Creator<IdToken> CREATOR = new q4.b();

    /* renamed from: a, reason: collision with root package name */
    private final String f7185a;

    /* renamed from: b, reason: collision with root package name */
    private final String f7186b;

    public IdToken(String str, String str2) {
        r.b(!TextUtils.isEmpty(str), "account type string cannot be null or empty");
        r.b(!TextUtils.isEmpty(str2), "id token string cannot be null or empty");
        this.f7185a = str;
        this.f7186b = str2;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof IdToken)) {
            return false;
        }
        IdToken idToken = (IdToken) obj;
        return p.b(this.f7185a, idToken.f7185a) && p.b(this.f7186b, idToken.f7186b);
    }

    public String j() {
        return this.f7185a;
    }

    public String k() {
        return this.f7186b;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.r(parcel, 1, j(), false);
        b5.c.r(parcel, 2, k(), false);
        b5.c.b(parcel, iA);
    }
}
