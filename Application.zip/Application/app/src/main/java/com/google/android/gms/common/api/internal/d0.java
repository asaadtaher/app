package com.google.android.gms.common.api.internal;

import android.os.Bundle;
import java.util.Collections;
import java.util.Iterator;
import y4.a;

/* loaded from: classes.dex */
public final class d0 implements z4.r {

    /* renamed from: a, reason: collision with root package name */
    private final k0 f7337a;

    public d0(k0 k0Var) {
        this.f7337a = k0Var;
    }

    @Override // z4.r
    public final void a(Bundle bundle) {
    }

    @Override // z4.r
    public final void b(int i10) {
    }

    @Override // z4.r
    public final void c() {
        Iterator it = this.f7337a.f7428h.values().iterator();
        while (it.hasNext()) {
            ((a.f) it.next()).r();
        }
        this.f7337a.f7436p.f7389p = Collections.emptySet();
    }

    @Override // z4.r
    public final void d() {
        this.f7337a.m();
    }

    @Override // z4.r
    public final b e(b bVar) {
        this.f7337a.f7436p.f7381h.add(bVar);
        return bVar;
    }

    @Override // z4.r
    public final boolean f() {
        return true;
    }

    @Override // z4.r
    public final void g(x4.b bVar, y4.a aVar, boolean z10) {
    }

    @Override // z4.r
    public final b h(b bVar) {
        throw new IllegalStateException("GoogleApiClient is not connected yet.");
    }
}
