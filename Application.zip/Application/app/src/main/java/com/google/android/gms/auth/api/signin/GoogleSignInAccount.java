package com.google.android.gms.auth.api.signin;

import a5.r;
import android.accounts.Account;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class GoogleSignInAccount extends b5.a implements ReflectedParcelable {
    public static final Parcelable.Creator<GoogleSignInAccount> CREATOR = new c();

    /* renamed from: s, reason: collision with root package name */
    public static f5.e f7187s = f5.g.c();

    /* renamed from: a, reason: collision with root package name */
    final int f7188a;

    /* renamed from: b, reason: collision with root package name */
    private String f7189b;

    /* renamed from: c, reason: collision with root package name */
    private String f7190c;

    /* renamed from: d, reason: collision with root package name */
    private String f7191d;

    /* renamed from: e, reason: collision with root package name */
    private String f7192e;

    /* renamed from: f, reason: collision with root package name */
    private Uri f7193f;

    /* renamed from: g, reason: collision with root package name */
    private String f7194g;

    /* renamed from: h, reason: collision with root package name */
    private long f7195h;

    /* renamed from: i, reason: collision with root package name */
    private String f7196i;

    /* renamed from: j, reason: collision with root package name */
    List f7197j;

    /* renamed from: k, reason: collision with root package name */
    private String f7198k;

    /* renamed from: l, reason: collision with root package name */
    private String f7199l;

    /* renamed from: r, reason: collision with root package name */
    private Set f7200r = new HashSet();

    GoogleSignInAccount(int i10, String str, String str2, String str3, String str4, Uri uri, String str5, long j10, String str6, List list, String str7, String str8) {
        this.f7188a = i10;
        this.f7189b = str;
        this.f7190c = str2;
        this.f7191d = str3;
        this.f7192e = str4;
        this.f7193f = uri;
        this.f7194g = str5;
        this.f7195h = j10;
        this.f7196i = str6;
        this.f7197j = list;
        this.f7198k = str7;
        this.f7199l = str8;
    }

    public static GoogleSignInAccount y(String str, String str2, String str3, String str4, String str5, String str6, Uri uri, Long l10, String str7, Set set) {
        return new GoogleSignInAccount(3, str, str2, str3, str4, uri, null, l10.longValue(), r.g(str7), new ArrayList((Collection) r.k(set)), str5, str6);
    }

    public static GoogleSignInAccount z(String str) throws JSONException, NumberFormatException {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(str);
        String strOptString = jSONObject.optString("photoUrl");
        Uri uri = !TextUtils.isEmpty(strOptString) ? Uri.parse(strOptString) : null;
        long j10 = Long.parseLong(jSONObject.getString("expirationTime"));
        HashSet hashSet = new HashSet();
        JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
        int length = jSONArray.length();
        for (int i10 = 0; i10 < length; i10++) {
            hashSet.add(new Scope(jSONArray.getString(i10)));
        }
        GoogleSignInAccount googleSignInAccountY = y(jSONObject.optString("id"), jSONObject.has("tokenId") ? jSONObject.optString("tokenId") : null, jSONObject.has("email") ? jSONObject.optString("email") : null, jSONObject.has("displayName") ? jSONObject.optString("displayName") : null, jSONObject.has("givenName") ? jSONObject.optString("givenName") : null, jSONObject.has("familyName") ? jSONObject.optString("familyName") : null, uri, Long.valueOf(j10), jSONObject.getString("obfuscatedIdentifier"), hashSet);
        googleSignInAccountY.f7194g = jSONObject.has("serverAuthCode") ? jSONObject.optString("serverAuthCode") : null;
        return googleSignInAccountY;
    }

    public final String A() {
        return this.f7196i;
    }

    public final String B() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        try {
            if (o() != null) {
                jSONObject.put("id", o());
            }
            if (q() != null) {
                jSONObject.put("tokenId", q());
            }
            if (k() != null) {
                jSONObject.put("email", k());
            }
            if (j() != null) {
                jSONObject.put("displayName", j());
            }
            if (m() != null) {
                jSONObject.put("givenName", m());
            }
            if (l() != null) {
                jSONObject.put("familyName", l());
            }
            Uri uriS = s();
            if (uriS != null) {
                jSONObject.put("photoUrl", uriS.toString());
            }
            if (w() != null) {
                jSONObject.put("serverAuthCode", w());
            }
            jSONObject.put("expirationTime", this.f7195h);
            jSONObject.put("obfuscatedIdentifier", this.f7196i);
            JSONArray jSONArray = new JSONArray();
            List list = this.f7197j;
            Scope[] scopeArr = (Scope[]) list.toArray(new Scope[list.size()]);
            Arrays.sort(scopeArr, new Comparator() { // from class: t4.c
                @Override // java.util.Comparator
                public final int compare(Object obj, Object obj2) {
                    Parcelable.Creator<GoogleSignInAccount> creator = GoogleSignInAccount.CREATOR;
                    return ((Scope) obj).j().compareTo(((Scope) obj2).j());
                }
            });
            for (Scope scope : scopeArr) {
                jSONArray.put(scope.j());
            }
            jSONObject.put("grantedScopes", jSONArray);
            jSONObject.remove("serverAuthCode");
            return jSONObject.toString();
        } catch (JSONException e10) {
            throw new RuntimeException(e10);
        }
    }

    public Account b() {
        String str = this.f7191d;
        if (str == null) {
            return null;
        }
        return new Account(str, "com.google");
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof GoogleSignInAccount)) {
            return false;
        }
        GoogleSignInAccount googleSignInAccount = (GoogleSignInAccount) obj;
        return googleSignInAccount.f7196i.equals(this.f7196i) && googleSignInAccount.v().equals(v());
    }

    public int hashCode() {
        return ((this.f7196i.hashCode() + 527) * 31) + v().hashCode();
    }

    public String j() {
        return this.f7192e;
    }

    public String k() {
        return this.f7191d;
    }

    public String l() {
        return this.f7199l;
    }

    public String m() {
        return this.f7198k;
    }

    public Set<Scope> n() {
        return new HashSet(this.f7197j);
    }

    public String o() {
        return this.f7189b;
    }

    public String q() {
        return this.f7190c;
    }

    public Uri s() {
        return this.f7193f;
    }

    public Set<Scope> v() {
        HashSet hashSet = new HashSet(this.f7197j);
        hashSet.addAll(this.f7200r);
        return hashSet;
    }

    public String w() {
        return this.f7194g;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.k(parcel, 1, this.f7188a);
        b5.c.r(parcel, 2, o(), false);
        b5.c.r(parcel, 3, q(), false);
        b5.c.r(parcel, 4, k(), false);
        b5.c.r(parcel, 5, j(), false);
        b5.c.q(parcel, 6, s(), i10, false);
        b5.c.r(parcel, 7, w(), false);
        b5.c.o(parcel, 8, this.f7195h);
        b5.c.r(parcel, 9, this.f7196i, false);
        b5.c.v(parcel, 10, this.f7197j, false);
        b5.c.r(parcel, 11, m(), false);
        b5.c.r(parcel, 12, l(), false);
        b5.c.b(parcel, iA);
    }

    public boolean x() {
        return f7187s.a() / 1000 >= this.f7195h + (-300);
    }
}
