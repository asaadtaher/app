package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class c implements Parcelable.Creator {
    @Override // android.os.Parcelable.Creator
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int iZ = b5.b.z(parcel);
        String strE = null;
        String strE2 = null;
        String strE3 = null;
        String strE4 = null;
        Uri uri = null;
        String strE5 = null;
        String strE6 = null;
        ArrayList arrayListI = null;
        String strE7 = null;
        String strE8 = null;
        long jV = 0;
        int iS = 0;
        while (parcel.dataPosition() < iZ) {
            int iQ = b5.b.q(parcel);
            switch (b5.b.k(iQ)) {
                case 1:
                    iS = b5.b.s(parcel, iQ);
                    break;
                case 2:
                    strE = b5.b.e(parcel, iQ);
                    break;
                case 3:
                    strE2 = b5.b.e(parcel, iQ);
                    break;
                case 4:
                    strE3 = b5.b.e(parcel, iQ);
                    break;
                case 5:
                    strE4 = b5.b.e(parcel, iQ);
                    break;
                case 6:
                    uri = (Uri) b5.b.d(parcel, iQ, Uri.CREATOR);
                    break;
                case 7:
                    strE5 = b5.b.e(parcel, iQ);
                    break;
                case 8:
                    jV = b5.b.v(parcel, iQ);
                    break;
                case 9:
                    strE6 = b5.b.e(parcel, iQ);
                    break;
                case 10:
                    arrayListI = b5.b.i(parcel, iQ, Scope.CREATOR);
                    break;
                case 11:
                    strE7 = b5.b.e(parcel, iQ);
                    break;
                case 12:
                    strE8 = b5.b.e(parcel, iQ);
                    break;
                default:
                    b5.b.y(parcel, iQ);
                    break;
            }
        }
        b5.b.j(parcel, iZ);
        return new GoogleSignInAccount(iS, strE, strE2, strE3, strE4, uri, strE5, jV, strE6, arrayListI, strE7, strE8);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Object[] newArray(int i10) {
        return new GoogleSignInAccount[i10];
    }
}
