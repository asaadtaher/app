package com.google.android.gms.auth.api.signin.internal;

import a5.r;
import android.os.Parcel;
import android.os.Parcelable;
import b5.c;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.internal.ReflectedParcelable;
import u4.b;
import u4.y;

/* loaded from: classes.dex */
public final class SignInConfiguration extends b5.a implements ReflectedParcelable {
    public static final Parcelable.Creator<SignInConfiguration> CREATOR = new y();

    /* renamed from: a, reason: collision with root package name */
    private final String f7234a;

    /* renamed from: b, reason: collision with root package name */
    private final GoogleSignInOptions f7235b;

    public SignInConfiguration(String str, GoogleSignInOptions googleSignInOptions) {
        this.f7234a = r.g(str);
        this.f7235b = googleSignInOptions;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof SignInConfiguration)) {
            return false;
        }
        SignInConfiguration signInConfiguration = (SignInConfiguration) obj;
        if (this.f7234a.equals(signInConfiguration.f7234a)) {
            GoogleSignInOptions googleSignInOptions = this.f7235b;
            GoogleSignInOptions googleSignInOptions2 = signInConfiguration.f7235b;
            if (googleSignInOptions == null) {
                if (googleSignInOptions2 == null) {
                    return true;
                }
            } else if (googleSignInOptions.equals(googleSignInOptions2)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return new b().a(this.f7234a).a(this.f7235b).b();
    }

    public final GoogleSignInOptions j() {
        return this.f7235b;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        int iA = c.a(parcel);
        c.r(parcel, 2, this.f7234a, false);
        c.q(parcel, 5, this.f7235b, i10, false);
        c.b(parcel, iA);
    }
}
