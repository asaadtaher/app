package com.google.android.gms.common.api.internal;

import android.os.Looper;
import com.google.android.gms.common.api.internal.d;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public class e {

    /* renamed from: a, reason: collision with root package name */
    private final Set f7345a = Collections.newSetFromMap(new WeakHashMap());

    public static <L> d<L> a(L l10, Looper looper, String str) {
        a5.r.l(l10, "Listener must not be null");
        a5.r.l(looper, "Looper must not be null");
        a5.r.l(str, "Listener type must not be null");
        return new d<>(looper, l10, str);
    }

    public static <L> d.a<L> b(L l10, String str) {
        a5.r.l(l10, "Listener must not be null");
        a5.r.l(str, "Listener type must not be null");
        a5.r.h(str, "Listener type must not be empty");
        return new d.a<>(l10, str);
    }

    public final void c() {
        Iterator it = this.f7345a.iterator();
        while (it.hasNext()) {
            ((d) it.next()).a();
        }
        this.f7345a.clear();
    }
}
