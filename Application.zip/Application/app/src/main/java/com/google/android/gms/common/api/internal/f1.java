package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.api.Status;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class f1 {

    /* renamed from: c, reason: collision with root package name */
    public static final Status f7353c = new Status(8, "The connection to Google Play services was lost");

    /* renamed from: a, reason: collision with root package name */
    final Set f7354a = Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap()));

    /* renamed from: b, reason: collision with root package name */
    private final e1 f7355b = new e1(this);

    final void a(BasePendingResult basePendingResult) {
        this.f7354a.add(basePendingResult);
        basePendingResult.o(this.f7355b);
    }

    public final void b() {
        for (BasePendingResult basePendingResult : (BasePendingResult[]) this.f7354a.toArray(new BasePendingResult[0])) {
            basePendingResult.o(null);
            if (basePendingResult.n()) {
                this.f7354a.remove(basePendingResult);
            }
        }
    }
}
