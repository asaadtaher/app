package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.api.internal.d;
import y4.a;
import y4.a.b;

/* loaded from: classes.dex */
public abstract class f<A extends a.b, L> {

    /* renamed from: a, reason: collision with root package name */
    private final d f7348a;

    /* renamed from: b, reason: collision with root package name */
    private final x4.d[] f7349b;

    /* renamed from: c, reason: collision with root package name */
    private final boolean f7350c;

    /* renamed from: d, reason: collision with root package name */
    private final int f7351d;

    protected f(d<L> dVar, x4.d[] dVarArr, boolean z10, int i10) {
        this.f7348a = dVar;
        this.f7349b = dVarArr;
        this.f7350c = z10;
        this.f7351d = i10;
    }

    public void a() {
        this.f7348a.a();
    }

    public d.a<L> b() {
        return this.f7348a.b();
    }

    public x4.d[] c() {
        return this.f7349b;
    }

    protected abstract void d(A a10, b6.j<Void> jVar);

    public final int e() {
        return this.f7351d;
    }

    public final boolean f() {
        return this.f7350c;
    }
}
