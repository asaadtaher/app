package com.google.android.gms.common.api.internal;

import android.os.Looper;
import android.os.Message;
import android.util.Log;

/* loaded from: classes.dex */
final class f0 extends m5.n {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ h0 f7352a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    f0(h0 h0Var, Looper looper) {
        super(looper);
        this.f7352a = h0Var;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        int i10 = message.what;
        if (i10 == 1) {
            h0.x(this.f7352a);
            return;
        }
        if (i10 == 2) {
            h0.w(this.f7352a);
            return;
        }
        Log.w("GoogleApiClientImpl", "Unknown message id: " + i10);
    }
}
