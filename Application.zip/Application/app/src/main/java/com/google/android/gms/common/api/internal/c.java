package com.google.android.gms.common.api.internal;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.d;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.dex */
public class c implements Handler.Callback {

    /* renamed from: r, reason: collision with root package name */
    public static final Status f7289r = new Status(4, "Sign-out occurred while this API call was in progress.");

    /* renamed from: s, reason: collision with root package name */
    private static final Status f7290s = new Status(4, "The user must be signed in to make this API call.");

    /* renamed from: t, reason: collision with root package name */
    private static final Object f7291t = new Object();

    /* renamed from: u, reason: collision with root package name */
    private static c f7292u;

    /* renamed from: e, reason: collision with root package name */
    private a5.v f7297e;

    /* renamed from: f, reason: collision with root package name */
    private a5.x f7298f;

    /* renamed from: g, reason: collision with root package name */
    private final Context f7299g;

    /* renamed from: h, reason: collision with root package name */
    private final x4.e f7300h;

    /* renamed from: i, reason: collision with root package name */
    private final a5.m0 f7301i;

    /* renamed from: p, reason: collision with root package name */
    private final Handler f7308p;

    /* renamed from: q, reason: collision with root package name */
    private volatile boolean f7309q;

    /* renamed from: a, reason: collision with root package name */
    private long f7293a = 5000;

    /* renamed from: b, reason: collision with root package name */
    private long f7294b = 120000;

    /* renamed from: c, reason: collision with root package name */
    private long f7295c = 10000;

    /* renamed from: d, reason: collision with root package name */
    private boolean f7296d = false;

    /* renamed from: j, reason: collision with root package name */
    private final AtomicInteger f7302j = new AtomicInteger(1);

    /* renamed from: k, reason: collision with root package name */
    private final AtomicInteger f7303k = new AtomicInteger(0);

    /* renamed from: l, reason: collision with root package name */
    private final Map f7304l = new ConcurrentHashMap(5, 0.75f, 1);

    /* renamed from: m, reason: collision with root package name */
    private n f7305m = null;

    /* renamed from: n, reason: collision with root package name */
    private final Set f7306n = new f0.b();

    /* renamed from: o, reason: collision with root package name */
    private final Set f7307o = new f0.b();

    private c(Context context, Looper looper, x4.e eVar) {
        this.f7309q = true;
        this.f7299g = context;
        m5.n nVar = new m5.n(looper, this);
        this.f7308p = nVar;
        this.f7300h = eVar;
        this.f7301i = new a5.m0(eVar);
        if (f5.h.a(context)) {
            this.f7309q = false;
        }
        nVar.sendMessage(nVar.obtainMessage(6));
    }

    public static void a() {
        synchronized (f7291t) {
            c cVar = f7292u;
            if (cVar != null) {
                cVar.f7303k.incrementAndGet();
                Handler handler = cVar.f7308p;
                handler.sendMessageAtFrontOfQueue(handler.obtainMessage(10));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static Status i(z4.b bVar, x4.b bVar2) {
        return new Status(bVar2, "API: " + bVar.b() + " is not available on this device. Connection failed with: " + String.valueOf(bVar2));
    }

    private final q0 j(y4.e eVar) {
        z4.b bVarQ = eVar.q();
        q0 q0Var = (q0) this.f7304l.get(bVarQ);
        if (q0Var == null) {
            q0Var = new q0(this, eVar);
            this.f7304l.put(bVarQ, q0Var);
        }
        if (q0Var.O()) {
            this.f7307o.add(bVarQ);
        }
        q0Var.D();
        return q0Var;
    }

    private final a5.x k() {
        if (this.f7298f == null) {
            this.f7298f = a5.w.a(this.f7299g);
        }
        return this.f7298f;
    }

    private final void l() {
        a5.v vVar = this.f7297e;
        if (vVar != null) {
            if (vVar.j() > 0 || g()) {
                k().g(vVar);
            }
            this.f7297e = null;
        }
    }

    private final void m(b6.j jVar, int i10, y4.e eVar) {
        v0 v0VarB;
        if (i10 == 0 || (v0VarB = v0.b(this, i10, eVar.q())) == null) {
            return;
        }
        b6.i iVarA = jVar.a();
        final Handler handler = this.f7308p;
        handler.getClass();
        iVarA.c(new Executor() { // from class: z4.t
            @Override // java.util.concurrent.Executor
            public final void execute(Runnable runnable) {
                handler.post(runnable);
            }
        }, v0VarB);
    }

    public static c y(Context context) {
        c cVar;
        synchronized (f7291t) {
            if (f7292u == null) {
                f7292u = new c(context.getApplicationContext(), a5.i.d().getLooper(), x4.e.p());
            }
            cVar = f7292u;
        }
        return cVar;
    }

    public final b6.i A(y4.e eVar, f fVar, i iVar, Runnable runnable) {
        b6.j jVar = new b6.j();
        m(jVar, fVar.e(), eVar);
        h1 h1Var = new h1(new z4.e0(fVar, iVar, runnable), jVar);
        Handler handler = this.f7308p;
        handler.sendMessage(handler.obtainMessage(8, new z4.d0(h1Var, this.f7303k.get(), eVar)));
        return jVar.a();
    }

    public final b6.i B(y4.e eVar, d.a aVar, int i10) {
        b6.j jVar = new b6.j();
        m(jVar, i10, eVar);
        j1 j1Var = new j1(aVar, jVar);
        Handler handler = this.f7308p;
        handler.sendMessage(handler.obtainMessage(13, new z4.d0(j1Var, this.f7303k.get(), eVar)));
        return jVar.a();
    }

    public final void G(y4.e eVar, int i10, b bVar) {
        g1 g1Var = new g1(i10, bVar);
        Handler handler = this.f7308p;
        handler.sendMessage(handler.obtainMessage(4, new z4.d0(g1Var, this.f7303k.get(), eVar)));
    }

    public final void H(y4.e eVar, int i10, h hVar, b6.j jVar, z4.l lVar) {
        m(jVar, hVar.d(), eVar);
        i1 i1Var = new i1(i10, hVar, jVar, lVar);
        Handler handler = this.f7308p;
        handler.sendMessage(handler.obtainMessage(4, new z4.d0(i1Var, this.f7303k.get(), eVar)));
    }

    final void I(a5.o oVar, int i10, long j10, int i11) {
        Handler handler = this.f7308p;
        handler.sendMessage(handler.obtainMessage(18, new w0(oVar, i10, j10, i11)));
    }

    public final void J(x4.b bVar, int i10) {
        if (h(bVar, i10)) {
            return;
        }
        Handler handler = this.f7308p;
        handler.sendMessage(handler.obtainMessage(5, i10, 0, bVar));
    }

    public final void b() {
        Handler handler = this.f7308p;
        handler.sendMessage(handler.obtainMessage(3));
    }

    public final void c(y4.e eVar) {
        Handler handler = this.f7308p;
        handler.sendMessage(handler.obtainMessage(7, eVar));
    }

    public final void d(n nVar) {
        synchronized (f7291t) {
            if (this.f7305m != nVar) {
                this.f7305m = nVar;
                this.f7306n.clear();
            }
            this.f7306n.addAll(nVar.t());
        }
    }

    final void e(n nVar) {
        synchronized (f7291t) {
            if (this.f7305m == nVar) {
                this.f7305m = null;
                this.f7306n.clear();
            }
        }
    }

    final boolean g() {
        if (this.f7296d) {
            return false;
        }
        a5.t tVarA = a5.s.b().a();
        if (tVarA != null && !tVarA.l()) {
            return false;
        }
        int iA = this.f7301i.a(this.f7299g, 203400000);
        return iA == -1 || iA == 0;
    }

    final boolean h(x4.b bVar, int i10) {
        return this.f7300h.z(this.f7299g, bVar, i10);
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        b6.j jVarB;
        Boolean boolValueOf;
        int i10 = message.what;
        q0 q0Var = null;
        switch (i10) {
            case 1:
                this.f7295c = true == ((Boolean) message.obj).booleanValue() ? 10000L : 300000L;
                this.f7308p.removeMessages(12);
                for (z4.b bVar : this.f7304l.keySet()) {
                    Handler handler = this.f7308p;
                    handler.sendMessageDelayed(handler.obtainMessage(12, bVar), this.f7295c);
                }
                return true;
            case 2:
                z4.o0 o0Var = (z4.o0) message.obj;
                Iterator it = o0Var.a().iterator();
                while (true) {
                    if (it.hasNext()) {
                        z4.b bVar2 = (z4.b) it.next();
                        q0 q0Var2 = (q0) this.f7304l.get(bVar2);
                        if (q0Var2 == null) {
                            o0Var.b(bVar2, new x4.b(13), null);
                        } else if (q0Var2.N()) {
                            o0Var.b(bVar2, x4.b.f23623e, q0Var2.t().p());
                        } else {
                            x4.b bVarQ = q0Var2.q();
                            if (bVarQ != null) {
                                o0Var.b(bVar2, bVarQ, null);
                            } else {
                                q0Var2.I(o0Var);
                                q0Var2.D();
                            }
                        }
                    }
                }
                return true;
            case 3:
                for (q0 q0Var3 : this.f7304l.values()) {
                    q0Var3.C();
                    q0Var3.D();
                }
                return true;
            case 4:
            case 8:
            case 13:
                z4.d0 d0Var = (z4.d0) message.obj;
                q0 q0VarJ = (q0) this.f7304l.get(d0Var.f24961c.q());
                if (q0VarJ == null) {
                    q0VarJ = j(d0Var.f24961c);
                }
                if (!q0VarJ.O() || this.f7303k.get() == d0Var.f24960b) {
                    q0VarJ.E(d0Var.f24959a);
                } else {
                    d0Var.f24959a.a(f7289r);
                    q0VarJ.K();
                }
                return true;
            case 5:
                int i11 = message.arg1;
                x4.b bVar3 = (x4.b) message.obj;
                Iterator it2 = this.f7304l.values().iterator();
                while (true) {
                    if (it2.hasNext()) {
                        q0 q0Var4 = (q0) it2.next();
                        if (q0Var4.o() == i11) {
                            q0Var = q0Var4;
                        }
                    }
                }
                if (q0Var == null) {
                    Log.wtf("GoogleApiManager", "Could not find API instance " + i11 + " while trying to fail enqueued calls.", new Exception());
                } else if (bVar3.j() == 13) {
                    q0Var.d(new Status(17, "Error resolution was canceled by the user, original error message: " + this.f7300h.f(bVar3.j()) + ": " + bVar3.k()));
                } else {
                    q0Var.d(i(q0Var.f7468e, bVar3));
                }
                return true;
            case 6:
                if (this.f7299g.getApplicationContext() instanceof Application) {
                    a.c((Application) this.f7299g.getApplicationContext());
                    a.b().a(new l0(this));
                    if (!a.b().e(true)) {
                        this.f7295c = 300000L;
                    }
                }
                return true;
            case 7:
                j((y4.e) message.obj);
                return true;
            case 9:
                if (this.f7304l.containsKey(message.obj)) {
                    ((q0) this.f7304l.get(message.obj)).J();
                }
                return true;
            case 10:
                Iterator it3 = this.f7307o.iterator();
                while (it3.hasNext()) {
                    q0 q0Var5 = (q0) this.f7304l.remove((z4.b) it3.next());
                    if (q0Var5 != null) {
                        q0Var5.K();
                    }
                }
                this.f7307o.clear();
                return true;
            case 11:
                if (this.f7304l.containsKey(message.obj)) {
                    ((q0) this.f7304l.get(message.obj)).L();
                }
                return true;
            case 12:
                if (this.f7304l.containsKey(message.obj)) {
                    ((q0) this.f7304l.get(message.obj)).a();
                }
                return true;
            case 14:
                o oVar = (o) message.obj;
                z4.b bVarA = oVar.a();
                if (this.f7304l.containsKey(bVarA)) {
                    boolean zN = ((q0) this.f7304l.get(bVarA)).n(false);
                    jVarB = oVar.b();
                    boolValueOf = Boolean.valueOf(zN);
                } else {
                    jVarB = oVar.b();
                    boolValueOf = Boolean.FALSE;
                }
                jVarB.c(boolValueOf);
                return true;
            case 15:
                r0 r0Var = (r0) message.obj;
                if (this.f7304l.containsKey(r0Var.f7485a)) {
                    q0.A((q0) this.f7304l.get(r0Var.f7485a), r0Var);
                }
                return true;
            case 16:
                r0 r0Var2 = (r0) message.obj;
                if (this.f7304l.containsKey(r0Var2.f7485a)) {
                    q0.B((q0) this.f7304l.get(r0Var2.f7485a), r0Var2);
                }
                return true;
            case 17:
                l();
                return true;
            case 18:
                w0 w0Var = (w0) message.obj;
                if (w0Var.f7517c == 0) {
                    k().g(new a5.v(w0Var.f7516b, Arrays.asList(w0Var.f7515a)));
                } else {
                    a5.v vVar = this.f7297e;
                    if (vVar != null) {
                        List listK = vVar.k();
                        if (vVar.j() != w0Var.f7516b || (listK != null && listK.size() >= w0Var.f7518d)) {
                            this.f7308p.removeMessages(17);
                            l();
                        } else {
                            this.f7297e.l(w0Var.f7515a);
                        }
                    }
                    if (this.f7297e == null) {
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(w0Var.f7515a);
                        this.f7297e = new a5.v(w0Var.f7516b, arrayList);
                        Handler handler2 = this.f7308p;
                        handler2.sendMessageDelayed(handler2.obtainMessage(17), w0Var.f7517c);
                    }
                }
                return true;
            case 19:
                this.f7296d = false;
                return true;
            default:
                Log.w("GoogleApiManager", "Unknown message id: " + i10);
                return false;
        }
    }

    public final int n() {
        return this.f7302j.getAndIncrement();
    }

    final q0 x(z4.b bVar) {
        return (q0) this.f7304l.get(bVar);
    }
}
