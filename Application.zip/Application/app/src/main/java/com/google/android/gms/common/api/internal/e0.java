package com.google.android.gms.common.api.internal;

/* loaded from: classes.dex */
final class e0 implements a5.k0 {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ h0 f7346a;

    e0(h0 h0Var) {
        this.f7346a = h0Var;
    }

    @Override // a5.k0
    public final boolean a() {
        return this.f7346a.s();
    }
}
