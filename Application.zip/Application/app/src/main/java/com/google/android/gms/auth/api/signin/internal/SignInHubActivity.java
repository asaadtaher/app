package com.google.android.gms.auth.api.signin.internal;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import androidx.fragment.app.s;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.SignInAccount;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.api.Status;
import java.util.Objects;
import u4.r;

@KeepName
/* loaded from: classes.dex */
public class SignInHubActivity extends s {

    /* renamed from: y, reason: collision with root package name */
    private static boolean f7236y = false;

    /* renamed from: t, reason: collision with root package name */
    private boolean f7237t = false;

    /* renamed from: u, reason: collision with root package name */
    private SignInConfiguration f7238u;

    /* renamed from: v, reason: collision with root package name */
    private boolean f7239v;

    /* renamed from: w, reason: collision with root package name */
    private int f7240w;

    /* renamed from: x, reason: collision with root package name */
    private Intent f7241x;

    private final void w() {
        getSupportLoaderManager().c(0, null, new a(this, null));
        f7236y = false;
    }

    private final void x(int i10) {
        Status status = new Status(i10);
        Intent intent = new Intent();
        intent.putExtra("googleSignInStatus", status);
        setResult(0, intent);
        finish();
        f7236y = false;
    }

    private final void y(String str) {
        Intent intent = new Intent(str);
        intent.setPackage(str.equals("com.google.android.gms.auth.GOOGLE_SIGN_IN") ? "com.google.android.gms" : getPackageName());
        intent.putExtra("config", this.f7238u);
        try {
            startActivityForResult(intent, 40962);
        } catch (ActivityNotFoundException unused) {
            this.f7237t = true;
            Log.w("AuthSignInClient", "Could not launch sign in Intent. Google Play Service is probably being updated...");
            x(17);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return true;
    }

    @Override // androidx.fragment.app.s, androidx.activity.ComponentActivity, android.app.Activity
    protected final void onActivityResult(int i10, int i11, Intent intent) {
        if (this.f7237t) {
            return;
        }
        setResult(0);
        if (i10 != 40962) {
            return;
        }
        if (intent != null) {
            SignInAccount signInAccount = (SignInAccount) intent.getParcelableExtra("signInAccount");
            if (signInAccount != null && signInAccount.j() != null) {
                GoogleSignInAccount googleSignInAccountJ = signInAccount.j();
                r rVarC = r.c(this);
                GoogleSignInOptions googleSignInOptionsJ = this.f7238u.j();
                Objects.requireNonNull(googleSignInAccountJ);
                rVarC.e(googleSignInOptionsJ, googleSignInAccountJ);
                intent.removeExtra("signInAccount");
                intent.putExtra("googleSignInAccount", googleSignInAccountJ);
                this.f7239v = true;
                this.f7240w = i11;
                this.f7241x = intent;
                w();
                return;
            }
            if (intent.hasExtra("errorCode")) {
                int intExtra = intent.getIntExtra("errorCode", 8);
                if (intExtra == 13) {
                    intExtra = 12501;
                }
                x(intExtra);
                return;
            }
        }
        x(8);
    }

    @Override // androidx.fragment.app.s, androidx.activity.ComponentActivity, androidx.core.app.i, android.app.Activity
    protected final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = getIntent();
        String action = intent.getAction();
        Objects.requireNonNull(action);
        if ("com.google.android.gms.auth.NO_IMPL".equals(action)) {
            x(12500);
            return;
        }
        if (!action.equals("com.google.android.gms.auth.GOOGLE_SIGN_IN") && !action.equals("com.google.android.gms.auth.APPAUTH_SIGN_IN")) {
            Log.e("AuthSignInClient", "Unknown action: ".concat(String.valueOf(intent.getAction())));
            finish();
            return;
        }
        Bundle bundleExtra = intent.getBundleExtra("config");
        Objects.requireNonNull(bundleExtra);
        SignInConfiguration signInConfiguration = (SignInConfiguration) bundleExtra.getParcelable("config");
        if (signInConfiguration == null) {
            Log.e("AuthSignInClient", "Activity started with invalid configuration.");
            setResult(0);
            finish();
            return;
        }
        this.f7238u = signInConfiguration;
        if (bundle == null) {
            if (f7236y) {
                setResult(0);
                x(12502);
                return;
            } else {
                f7236y = true;
                y(action);
                return;
            }
        }
        boolean z10 = bundle.getBoolean("signingInGoogleApiClients");
        this.f7239v = z10;
        if (z10) {
            this.f7240w = bundle.getInt("signInResultCode");
            Intent intent2 = (Intent) bundle.getParcelable("signInResultData");
            Objects.requireNonNull(intent2);
            this.f7241x = intent2;
            w();
        }
    }

    @Override // androidx.fragment.app.s, android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        f7236y = false;
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.i, android.app.Activity
    protected final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putBoolean("signingInGoogleApiClients", this.f7239v);
        if (this.f7239v) {
            bundle.putInt("signInResultCode", this.f7240w);
            bundle.putParcelable("signInResultData", this.f7241x);
        }
    }
}
