package com.google.android.gms.common.api.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.locks.Lock;
import y4.a;

/* loaded from: classes.dex */
public final class c0 implements z4.r {

    /* renamed from: a, reason: collision with root package name */
    private final k0 f7310a;

    /* renamed from: b, reason: collision with root package name */
    private final Lock f7311b;

    /* renamed from: c, reason: collision with root package name */
    private final Context f7312c;

    /* renamed from: d, reason: collision with root package name */
    private final x4.f f7313d;

    /* renamed from: e, reason: collision with root package name */
    private x4.b f7314e;

    /* renamed from: f, reason: collision with root package name */
    private int f7315f;

    /* renamed from: h, reason: collision with root package name */
    private int f7317h;

    /* renamed from: k, reason: collision with root package name */
    private y5.f f7320k;

    /* renamed from: l, reason: collision with root package name */
    private boolean f7321l;

    /* renamed from: m, reason: collision with root package name */
    private boolean f7322m;

    /* renamed from: n, reason: collision with root package name */
    private boolean f7323n;

    /* renamed from: o, reason: collision with root package name */
    private a5.k f7324o;

    /* renamed from: p, reason: collision with root package name */
    private boolean f7325p;

    /* renamed from: q, reason: collision with root package name */
    private boolean f7326q;

    /* renamed from: r, reason: collision with root package name */
    private final a5.e f7327r;

    /* renamed from: s, reason: collision with root package name */
    private final Map f7328s;

    /* renamed from: t, reason: collision with root package name */
    private final a.AbstractC0429a f7329t;

    /* renamed from: g, reason: collision with root package name */
    private int f7316g = 0;

    /* renamed from: i, reason: collision with root package name */
    private final Bundle f7318i = new Bundle();

    /* renamed from: j, reason: collision with root package name */
    private final Set f7319j = new HashSet();

    /* renamed from: u, reason: collision with root package name */
    private final ArrayList f7330u = new ArrayList();

    public c0(k0 k0Var, a5.e eVar, Map map, x4.f fVar, a.AbstractC0429a abstractC0429a, Lock lock, Context context) {
        this.f7310a = k0Var;
        this.f7327r = eVar;
        this.f7328s = map;
        this.f7313d = fVar;
        this.f7329t = abstractC0429a;
        this.f7311b = lock;
        this.f7312c = context;
    }

    static /* bridge */ /* synthetic */ void B(c0 c0Var, z5.l lVar) {
        if (c0Var.o(0)) {
            x4.b bVarJ = lVar.j();
            if (!bVarJ.n()) {
                if (!c0Var.q(bVarJ)) {
                    c0Var.l(bVarJ);
                    return;
                } else {
                    c0Var.i();
                    c0Var.n();
                    return;
                }
            }
            a5.u0 u0Var = (a5.u0) a5.r.k(lVar.k());
            x4.b bVarJ2 = u0Var.j();
            if (!bVarJ2.n()) {
                String strValueOf = String.valueOf(bVarJ2);
                Log.wtf("GACConnecting", "Sign-in succeeded with resolve account failure: ".concat(strValueOf), new Exception());
                c0Var.l(bVarJ2);
                return;
            }
            c0Var.f7323n = true;
            c0Var.f7324o = (a5.k) a5.r.k(u0Var.k());
            c0Var.f7325p = u0Var.l();
            c0Var.f7326q = u0Var.m();
            c0Var.n();
        }
    }

    private final void J() {
        ArrayList arrayList = this.f7330u;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((Future) arrayList.get(i10)).cancel(true);
        }
        this.f7330u.clear();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void i() {
        this.f7322m = false;
        this.f7310a.f7436p.f7389p = Collections.emptySet();
        for (a.c cVar : this.f7319j) {
            if (!this.f7310a.f7429i.containsKey(cVar)) {
                this.f7310a.f7429i.put(cVar, new x4.b(17, null));
            }
        }
    }

    private final void j(boolean z10) {
        y5.f fVar = this.f7320k;
        if (fVar != null) {
            if (fVar.a() && z10) {
                fVar.b();
            }
            fVar.r();
            this.f7324o = null;
        }
    }

    private final void k() {
        this.f7310a.l();
        z4.s.a().execute(new s(this));
        y5.f fVar = this.f7320k;
        if (fVar != null) {
            if (this.f7325p) {
                fVar.k((a5.k) a5.r.k(this.f7324o), this.f7326q);
            }
            j(false);
        }
        Iterator it = this.f7310a.f7429i.keySet().iterator();
        while (it.hasNext()) {
            ((a.f) a5.r.k((a.f) this.f7310a.f7428h.get((a.c) it.next()))).r();
        }
        this.f7310a.f7437q.a(this.f7318i.isEmpty() ? null : this.f7318i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void l(x4.b bVar) {
        J();
        j(!bVar.m());
        this.f7310a.n(bVar);
        this.f7310a.f7437q.b(bVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void m(x4.b bVar, y4.a aVar, boolean z10) {
        int iB = aVar.c().b();
        if ((!z10 || bVar.m() || this.f7313d.b(bVar.j()) != null) && (this.f7314e == null || iB < this.f7315f)) {
            this.f7314e = bVar;
            this.f7315f = iB;
        }
        this.f7310a.f7429i.put(aVar.b(), bVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void n() {
        if (this.f7317h != 0) {
            return;
        }
        if (!this.f7322m || this.f7323n) {
            ArrayList arrayList = new ArrayList();
            this.f7316g = 1;
            this.f7317h = this.f7310a.f7428h.size();
            for (a.c cVar : this.f7310a.f7428h.keySet()) {
                if (!this.f7310a.f7429i.containsKey(cVar)) {
                    arrayList.add((a.f) this.f7310a.f7428h.get(cVar));
                } else if (p()) {
                    k();
                }
            }
            if (arrayList.isEmpty()) {
                return;
            }
            this.f7330u.add(z4.s.a().submit(new x(this, arrayList)));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean o(int i10) {
        if (this.f7316g == i10) {
            return true;
        }
        Log.w("GACConnecting", this.f7310a.f7436p.u());
        Log.w("GACConnecting", "Unexpected callback in ".concat(toString()));
        Log.w("GACConnecting", "mRemainingConnections=" + this.f7317h);
        Log.e("GACConnecting", "GoogleApiClient connecting is in step " + r(this.f7316g) + " but received callback for step " + r(i10), new Exception());
        l(new x4.b(8, null));
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean p() {
        x4.b bVar;
        int i10 = this.f7317h - 1;
        this.f7317h = i10;
        if (i10 > 0) {
            return false;
        }
        if (i10 < 0) {
            Log.w("GACConnecting", this.f7310a.f7436p.u());
            Log.wtf("GACConnecting", "GoogleApiClient received too many callbacks for the given step. Clients may be in an unexpected state; GoogleApiClient will now disconnect.", new Exception());
            bVar = new x4.b(8, null);
        } else {
            bVar = this.f7314e;
            if (bVar == null) {
                return true;
            }
            this.f7310a.f7435o = this.f7315f;
        }
        l(bVar);
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean q(x4.b bVar) {
        return this.f7321l && !bVar.m();
    }

    private static final String r(int i10) {
        return i10 != 0 ? "STEP_GETTING_REMOTE_SERVICE" : "STEP_SERVICE_BINDINGS_AND_SIGN_IN";
    }

    static /* bridge */ /* synthetic */ Set y(c0 c0Var) {
        a5.e eVar = c0Var.f7327r;
        if (eVar == null) {
            return Collections.emptySet();
        }
        HashSet hashSet = new HashSet(eVar.g());
        Map mapK = c0Var.f7327r.k();
        for (y4.a aVar : mapK.keySet()) {
            if (!c0Var.f7310a.f7429i.containsKey(aVar.b())) {
                hashSet.addAll(((a5.d0) mapK.get(aVar)).f217a);
            }
        }
        return hashSet;
    }

    @Override // z4.r
    public final void a(Bundle bundle) {
        if (o(1)) {
            if (bundle != null) {
                this.f7318i.putAll(bundle);
            }
            if (p()) {
                k();
            }
        }
    }

    @Override // z4.r
    public final void b(int i10) {
        l(new x4.b(8, null));
    }

    /* JADX WARN: Type inference failed for: r0v13, types: [y4.a$f, y5.f] */
    @Override // z4.r
    public final void c() {
        this.f7310a.f7429i.clear();
        this.f7322m = false;
        z4.p pVar = null;
        this.f7314e = null;
        this.f7316g = 0;
        this.f7321l = true;
        this.f7323n = false;
        this.f7325p = false;
        HashMap map = new HashMap();
        boolean z10 = false;
        for (y4.a aVar : this.f7328s.keySet()) {
            a.f fVar = (a.f) a5.r.k((a.f) this.f7310a.f7428h.get(aVar.b()));
            z10 |= aVar.c().b() == 1;
            boolean zBooleanValue = ((Boolean) this.f7328s.get(aVar)).booleanValue();
            if (fVar.t()) {
                this.f7322m = true;
                if (zBooleanValue) {
                    this.f7319j.add(aVar.b());
                } else {
                    this.f7321l = false;
                }
            }
            map.put(fVar, new t(this, aVar, zBooleanValue));
        }
        if (z10) {
            this.f7322m = false;
        }
        if (this.f7322m) {
            a5.r.k(this.f7327r);
            a5.r.k(this.f7329t);
            this.f7327r.l(Integer.valueOf(System.identityHashCode(this.f7310a.f7436p)));
            a0 a0Var = new a0(this, pVar);
            a.AbstractC0429a abstractC0429a = this.f7329t;
            Context context = this.f7312c;
            Looper looperL = this.f7310a.f7436p.l();
            a5.e eVar = this.f7327r;
            this.f7320k = abstractC0429a.c(context, looperL, eVar, eVar.h(), a0Var, a0Var);
        }
        this.f7317h = this.f7310a.f7428h.size();
        this.f7330u.add(z4.s.a().submit(new w(this, map)));
    }

    @Override // z4.r
    public final void d() {
    }

    @Override // z4.r
    public final b e(b bVar) {
        this.f7310a.f7436p.f7381h.add(bVar);
        return bVar;
    }

    @Override // z4.r
    public final boolean f() {
        J();
        j(true);
        this.f7310a.n(null);
        return true;
    }

    @Override // z4.r
    public final void g(x4.b bVar, y4.a aVar, boolean z10) {
        if (o(1)) {
            m(bVar, aVar, z10);
            if (p()) {
                k();
            }
        }
    }

    @Override // z4.r
    public final b h(b bVar) {
        throw new IllegalStateException("GoogleApiClient is not connected yet.");
    }
}
