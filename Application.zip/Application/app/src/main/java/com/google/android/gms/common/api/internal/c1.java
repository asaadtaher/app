package com.google.android.gms.common.api.internal;

import android.os.DeadObjectException;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;

/* loaded from: classes.dex */
abstract class c1 extends z4.z {

    /* renamed from: b, reason: collision with root package name */
    protected final b6.j f7331b;

    public c1(int i10, b6.j jVar) {
        super(i10);
        this.f7331b = jVar;
    }

    @Override // com.google.android.gms.common.api.internal.k1
    public final void a(Status status) {
        this.f7331b.d(new y4.b(status));
    }

    @Override // com.google.android.gms.common.api.internal.k1
    public final void b(Exception exc) {
        this.f7331b.d(exc);
    }

    @Override // com.google.android.gms.common.api.internal.k1
    public final void c(q0 q0Var) throws DeadObjectException {
        try {
            h(q0Var);
        } catch (DeadObjectException e10) {
            a(k1.e(e10));
            throw e10;
        } catch (RemoteException e11) {
            a(k1.e(e11));
        } catch (RuntimeException e12) {
            this.f7331b.d(e12);
        }
    }

    protected abstract void h(q0 q0Var);
}
