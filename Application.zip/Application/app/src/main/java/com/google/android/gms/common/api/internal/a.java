package com.google.android.gms.common.api.internal;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.content.ComponentCallbacks2;
import android.content.res.Configuration;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes.dex */
public final class a implements Application.ActivityLifecycleCallbacks, ComponentCallbacks2 {

    /* renamed from: e, reason: collision with root package name */
    private static final a f7278e = new a();

    /* renamed from: a, reason: collision with root package name */
    private final AtomicBoolean f7279a = new AtomicBoolean();

    /* renamed from: b, reason: collision with root package name */
    private final AtomicBoolean f7280b = new AtomicBoolean();

    /* renamed from: c, reason: collision with root package name */
    private final ArrayList f7281c = new ArrayList();

    /* renamed from: d, reason: collision with root package name */
    private boolean f7282d = false;

    /* renamed from: com.google.android.gms.common.api.internal.a$a, reason: collision with other inner class name */
    public interface InterfaceC0127a {
        void a(boolean z10);
    }

    private a() {
    }

    public static a b() {
        return f7278e;
    }

    public static void c(Application application) {
        a aVar = f7278e;
        synchronized (aVar) {
            if (!aVar.f7282d) {
                application.registerActivityLifecycleCallbacks(aVar);
                application.registerComponentCallbacks(aVar);
                aVar.f7282d = true;
            }
        }
    }

    private final void f(boolean z10) {
        synchronized (f7278e) {
            Iterator it = this.f7281c.iterator();
            while (it.hasNext()) {
                ((InterfaceC0127a) it.next()).a(z10);
            }
        }
    }

    public void a(InterfaceC0127a interfaceC0127a) {
        synchronized (f7278e) {
            this.f7281c.add(interfaceC0127a);
        }
    }

    public boolean d() {
        return this.f7279a.get();
    }

    public boolean e(boolean z10) {
        if (!this.f7280b.get()) {
            if (!f5.k.b()) {
                return z10;
            }
            ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
            ActivityManager.getMyMemoryState(runningAppProcessInfo);
            if (!this.f7280b.getAndSet(true) && runningAppProcessInfo.importance > 100) {
                this.f7279a.set(true);
            }
        }
        return d();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityCreated(Activity activity, Bundle bundle) {
        boolean zCompareAndSet = this.f7279a.compareAndSet(true, false);
        this.f7280b.set(true);
        if (zCompareAndSet) {
            f(false);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityDestroyed(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityPaused(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityResumed(Activity activity) {
        boolean zCompareAndSet = this.f7279a.compareAndSet(true, false);
        this.f7280b.set(true);
        if (zCompareAndSet) {
            f(false);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStarted(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStopped(Activity activity) {
    }

    @Override // android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
    }

    @Override // android.content.ComponentCallbacks
    public final void onLowMemory() {
    }

    @Override // android.content.ComponentCallbacks2
    public final void onTrimMemory(int i10) {
        if (i10 == 20 && this.f7279a.compareAndSet(false, true)) {
            this.f7280b.set(true);
            f(true);
        }
    }
}
