package com.google.android.gms.auth.api.signin;

import a5.q;
import y4.m;

/* loaded from: classes.dex */
final class f implements q.a {
    /* synthetic */ f(t4.e eVar) {
    }

    @Override // a5.q.a
    public final /* synthetic */ Object a(m mVar) {
        return ((t4.b) mVar).a();
    }
}
