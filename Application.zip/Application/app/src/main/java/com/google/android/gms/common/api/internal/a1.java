package com.google.android.gms.common.api.internal;

/* loaded from: classes.dex */
final class a1 implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    final /* synthetic */ y4.m f7284a;

    /* renamed from: b, reason: collision with root package name */
    final /* synthetic */ d1 f7285b;

    a1(d1 d1Var, y4.m mVar) {
        this.f7285b = d1Var;
        this.f7284a = mVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            try {
                BasePendingResult.f7260p.set(Boolean.TRUE);
                ((y4.p) a5.r.k(this.f7285b.f7338a)).b(this.f7284a);
                d1 d1Var = this.f7285b;
                b1 unused = d1Var.f7344g;
                b1 unused2 = d1Var.f7344g;
                throw null;
            } catch (RuntimeException unused3) {
                d1 d1Var2 = this.f7285b;
                b1 unused4 = d1Var2.f7344g;
                b1 unused5 = d1Var2.f7344g;
                throw null;
            }
        } catch (Throwable th) {
            BasePendingResult.f7260p.set(Boolean.FALSE);
            d1 d1Var3 = this.f7285b;
            d1.j(this.f7284a);
            y4.f fVar = (y4.f) this.f7285b.f7343f.get();
            if (fVar != null) {
                fVar.q(this.f7285b);
            }
            throw th;
        }
    }
}
