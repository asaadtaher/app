package com.google.android.gms.auth.api.credentials;

import a5.p;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.List;

@Deprecated
/* loaded from: classes.dex */
public class Credential extends b5.a implements ReflectedParcelable {
    public static final Parcelable.Creator<Credential> CREATOR = new a();

    /* renamed from: a, reason: collision with root package name */
    private final String f7155a;

    /* renamed from: b, reason: collision with root package name */
    private final String f7156b;

    /* renamed from: c, reason: collision with root package name */
    private final Uri f7157c;

    /* renamed from: d, reason: collision with root package name */
    private final List f7158d;

    /* renamed from: e, reason: collision with root package name */
    private final String f7159e;

    /* renamed from: f, reason: collision with root package name */
    private final String f7160f;

    /* renamed from: g, reason: collision with root package name */
    private final String f7161g;

    /* renamed from: h, reason: collision with root package name */
    private final String f7162h;

    /* JADX WARN: Removed duplicated region for block: B:12:0x002d  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x007b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    Credential(java.lang.String r4, java.lang.String r5, android.net.Uri r6, java.util.List r7, java.lang.String r8, java.lang.String r9, java.lang.String r10, java.lang.String r11) {
        /*
            r3 = this;
            r3.<init>()
            java.lang.String r0 = "credential identifier cannot be null"
            java.lang.Object r4 = a5.r.l(r4, r0)
            java.lang.String r4 = (java.lang.String) r4
            java.lang.String r4 = r4.trim()
            java.lang.String r0 = "credential identifier cannot be empty"
            a5.r.h(r4, r0)
            if (r8 == 0) goto L25
            boolean r0 = android.text.TextUtils.isEmpty(r8)
            if (r0 != 0) goto L1d
            goto L25
        L1d:
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
            java.lang.String r5 = "Password must not be empty if set"
            r4.<init>(r5)
            throw r4
        L25:
            if (r9 == 0) goto L83
            boolean r0 = android.text.TextUtils.isEmpty(r9)
            if (r0 == 0) goto L30
        L2d:
            java.lang.Boolean r0 = java.lang.Boolean.FALSE
            goto L74
        L30:
            android.net.Uri r0 = android.net.Uri.parse(r9)
            boolean r1 = r0.isAbsolute()
            if (r1 == 0) goto L2d
            boolean r1 = r0.isHierarchical()
            if (r1 == 0) goto L2d
            java.lang.String r1 = r0.getScheme()
            boolean r1 = android.text.TextUtils.isEmpty(r1)
            if (r1 != 0) goto L2d
            java.lang.String r1 = r0.getAuthority()
            boolean r1 = android.text.TextUtils.isEmpty(r1)
            if (r1 == 0) goto L55
            goto L2d
        L55:
            java.lang.String r1 = r0.getScheme()
            java.lang.String r2 = "http"
            boolean r1 = r2.equalsIgnoreCase(r1)
            r2 = 1
            if (r1 != 0) goto L70
            java.lang.String r0 = r0.getScheme()
            java.lang.String r1 = "https"
            boolean r0 = r1.equalsIgnoreCase(r0)
            if (r0 == 0) goto L6f
            goto L70
        L6f:
            r2 = 0
        L70:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r2)
        L74:
            boolean r0 = r0.booleanValue()
            if (r0 == 0) goto L7b
            goto L83
        L7b:
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
            java.lang.String r5 = "Account type must be a valid Http/Https URI"
            r4.<init>(r5)
            throw r4
        L83:
            boolean r0 = android.text.TextUtils.isEmpty(r9)
            if (r0 != 0) goto L98
            boolean r0 = android.text.TextUtils.isEmpty(r8)
            if (r0 == 0) goto L90
            goto L98
        L90:
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
            java.lang.String r5 = "Password and AccountType are mutually exclusive"
            r4.<init>(r5)
            throw r4
        L98:
            if (r5 == 0) goto La5
            java.lang.String r0 = r5.trim()
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 == 0) goto La5
            r5 = 0
        La5:
            r3.f7156b = r5
            r3.f7157c = r6
            if (r7 != 0) goto Lb0
            java.util.List r5 = java.util.Collections.emptyList()
            goto Lb4
        Lb0:
            java.util.List r5 = java.util.Collections.unmodifiableList(r7)
        Lb4:
            r3.f7158d = r5
            r3.f7155a = r4
            r3.f7159e = r8
            r3.f7160f = r9
            r3.f7161g = r10
            r3.f7162h = r11
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.auth.api.credentials.Credential.<init>(java.lang.String, java.lang.String, android.net.Uri, java.util.List, java.lang.String, java.lang.String, java.lang.String, java.lang.String):void");
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Credential)) {
            return false;
        }
        Credential credential = (Credential) obj;
        return TextUtils.equals(this.f7155a, credential.f7155a) && TextUtils.equals(this.f7156b, credential.f7156b) && p.b(this.f7157c, credential.f7157c) && TextUtils.equals(this.f7159e, credential.f7159e) && TextUtils.equals(this.f7160f, credential.f7160f);
    }

    public int hashCode() {
        return p.c(this.f7155a, this.f7156b, this.f7157c, this.f7159e, this.f7160f);
    }

    public String j() {
        return this.f7160f;
    }

    public String k() {
        return this.f7162h;
    }

    public String l() {
        return this.f7161g;
    }

    public String m() {
        return this.f7155a;
    }

    public List<IdToken> n() {
        return this.f7158d;
    }

    public String o() {
        return this.f7156b;
    }

    public String q() {
        return this.f7159e;
    }

    public Uri s() {
        return this.f7157c;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        int iA = b5.c.a(parcel);
        b5.c.r(parcel, 1, m(), false);
        b5.c.r(parcel, 2, o(), false);
        b5.c.q(parcel, 3, s(), i10, false);
        b5.c.v(parcel, 4, n(), false);
        b5.c.r(parcel, 5, q(), false);
        b5.c.r(parcel, 6, j(), false);
        b5.c.r(parcel, 9, l(), false);
        b5.c.r(parcel, 10, k(), false);
        b5.c.b(parcel, iA);
    }
}
