package b0;

import androidx.camera.core.impl.utils.h;
import r.k1;

/* loaded from: classes.dex */
public class h implements r.i {

    /* renamed from: a, reason: collision with root package name */
    private final r.i f5312a;

    /* renamed from: b, reason: collision with root package name */
    private final k1 f5313b;

    /* renamed from: c, reason: collision with root package name */
    private final long f5314c;

    private h(r.i iVar, k1 k1Var, long j10) {
        this.f5312a = iVar;
        this.f5313b = k1Var;
        this.f5314c = j10;
    }

    public h(k1 k1Var, long j10) {
        this(null, k1Var, j10);
    }

    @Override // r.i
    public k1 a() {
        return this.f5313b;
    }

    @Override // r.i
    public /* synthetic */ void b(h.b bVar) throws NumberFormatException {
        r.h.a(this, bVar);
    }

    @Override // r.i
    public long c() {
        r.i iVar = this.f5312a;
        if (iVar != null) {
            return iVar.c();
        }
        long j10 = this.f5314c;
        if (j10 != -1) {
            return j10;
        }
        throw new IllegalStateException("No timestamp is available.");
    }

    @Override // r.i
    public r.g d() {
        r.i iVar = this.f5312a;
        return iVar != null ? iVar.d() : r.g.UNKNOWN;
    }
}
