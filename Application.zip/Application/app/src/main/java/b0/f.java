package b0;

import android.util.Range;
import android.util.Size;
import androidx.camera.core.w;
import java.util.List;
import java.util.Set;
import r.a0;
import r.c1;
import r.g1;
import r.l0;
import r.l1;
import r.m1;
import r.n0;
import r.n1;
import r.o0;
import r.x;
import r.y0;
import u.k;
import u.l;

/* loaded from: classes.dex */
public class f implements m1<d>, o0, k {
    static final a0.a<List<n1.b>> H = a0.a.a("camerax.core.streamSharing.captureTypes", List.class);
    private final y0 G;

    f(y0 y0Var) {
        this.G = y0Var;
    }

    @Override // r.a0
    public /* synthetic */ a0.b A(a0.a aVar) {
        return c1.b(this, aVar);
    }

    @Override // r.o0
    public /* synthetic */ Size B(Size size) {
        return n0.j(this, size);
    }

    @Override // r.o0
    public /* synthetic */ int C(int i10) {
        return n0.a(this, i10);
    }

    @Override // u.i
    public /* synthetic */ String D(String str) {
        return u.h.a(this, str);
    }

    @Override // u.m
    public /* synthetic */ w.b E(w.b bVar) {
        return l.a(this, bVar);
    }

    @Override // r.o0
    public /* synthetic */ int F(int i10) {
        return n0.k(this, i10);
    }

    @Override // r.o0
    public /* synthetic */ int G(int i10) {
        return n0.e(this, i10);
    }

    @Override // r.m1
    public /* synthetic */ x.b I(x.b bVar) {
        return l1.b(this, bVar);
    }

    @Override // r.d1, r.a0
    public /* synthetic */ Object a(a0.a aVar, Object obj) {
        return c1.f(this, aVar, obj);
    }

    @Override // r.d1, r.a0
    public /* synthetic */ Object b(a0.a aVar) {
        return c1.e(this, aVar);
    }

    @Override // r.d1, r.a0
    public /* synthetic */ boolean c(a0.a aVar) {
        return c1.a(this, aVar);
    }

    @Override // r.d1, r.a0
    public /* synthetic */ Set d() {
        return c1.d(this);
    }

    @Override // r.o0
    public /* synthetic */ Size e(Size size) {
        return n0.d(this, size);
    }

    @Override // r.m1
    public /* synthetic */ n1.b g() {
        return l1.c(this);
    }

    @Override // r.m1
    public /* synthetic */ Range h(Range range) {
        return l1.f(this, range);
    }

    @Override // r.o0
    public /* synthetic */ a0.c j(a0.c cVar) {
        return n0.g(this, cVar);
    }

    @Override // r.o0
    public /* synthetic */ List k(List list) {
        return n0.h(this, list);
    }

    @Override // r.m1
    public /* synthetic */ o.l l(o.l lVar) {
        return l1.a(this, lVar);
    }

    @Override // r.o0
    public /* synthetic */ boolean m() {
        return n0.l(this);
    }

    @Override // r.o0
    public /* synthetic */ int n() {
        return n0.i(this);
    }

    @Override // r.o0
    public /* synthetic */ a0.c p() {
        return n0.f(this);
    }

    @Override // r.d1
    public a0 q() {
        return this.G;
    }

    @Override // r.o0
    public /* synthetic */ List r(List list) {
        return n0.b(this, list);
    }

    @Override // r.m0
    public /* synthetic */ int s() {
        return l0.a(this);
    }

    @Override // r.m1
    public /* synthetic */ g1.d t(g1.d dVar) {
        return l1.d(this, dVar);
    }

    @Override // r.m1
    public /* synthetic */ boolean u(boolean z10) {
        return l1.g(this, z10);
    }

    @Override // r.a0
    public /* synthetic */ Set v(a0.a aVar) {
        return c1.c(this, aVar);
    }

    @Override // r.a0
    public /* synthetic */ Object x(a0.a aVar, a0.b bVar) {
        return c1.g(this, aVar, bVar);
    }

    @Override // r.o0
    public /* synthetic */ Size y(Size size) {
        return n0.c(this, size);
    }

    @Override // r.m1
    public /* synthetic */ int z() {
        return l1.e(this);
    }
}
