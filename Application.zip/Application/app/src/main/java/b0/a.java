package b0;

import android.util.Size;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import r.m1;
import r.o0;

/* loaded from: classes.dex */
class a {
    static List<Size> a(List<Size> list, Size size, Set<m1<?>> set) {
        Iterator<m1<?>> it = set.iterator();
        while (it.hasNext()) {
            List<Size> list2 = (List) it.next().a(o0.f20025q, null);
            if (list2 != null) {
                return list2;
            }
        }
        return list;
    }
}
