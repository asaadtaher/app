package b0;

import java.util.UUID;
import r.m1;
import r.t0;
import r.u0;
import r.y0;

/* loaded from: classes.dex */
class e implements m1.a<d, f, e> {

    /* renamed from: a, reason: collision with root package name */
    private final u0 f5303a;

    e() {
        this(u0.O());
    }

    e(u0 u0Var) {
        this.f5303a = u0Var;
        Class cls = (Class) u0Var.a(u.i.D, null);
        if (cls == null || cls.equals(d.class)) {
            d(d.class);
            return;
        }
        throw new IllegalArgumentException("Invalid target class configuration for " + this + ": " + cls);
    }

    @Override // o.r
    public t0 a() {
        return this.f5303a;
    }

    @Override // r.m1.a
    /* renamed from: c, reason: merged with bridge method [inline-methods] */
    public f b() {
        return new f(y0.M(this.f5303a));
    }

    public e d(Class<d> cls) {
        a().i(u.i.D, cls);
        if (a().a(u.i.C, null) == null) {
            e(cls.getCanonicalName() + "-" + UUID.randomUUID());
        }
        return this;
    }

    public e e(String str) {
        a().i(u.i.C, str);
        return this;
    }
}
