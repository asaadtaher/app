package b0;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.util.Log;
import android.util.Size;
import androidx.camera.core.impl.utils.o;
import androidx.camera.core.impl.utils.p;
import androidx.camera.core.w;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import r.a0;
import r.g1;
import r.i1;
import r.m0;
import r.m1;
import r.n1;
import r.s;
import r.t0;
import r.u;
import r.u0;
import r.y0;
import r.z;
import z.o0;
import z.u;
import z.w0;

/* loaded from: classes.dex */
public class d extends w {

    /* renamed from: n, reason: collision with root package name */
    private final f f5296n;

    /* renamed from: o, reason: collision with root package name */
    private final g f5297o;

    /* renamed from: p, reason: collision with root package name */
    private w0 f5298p;

    /* renamed from: q, reason: collision with root package name */
    private w0 f5299q;

    /* renamed from: r, reason: collision with root package name */
    private o0 f5300r;

    /* renamed from: s, reason: collision with root package name */
    private o0 f5301s;

    /* renamed from: t, reason: collision with root package name */
    g1.b f5302t;

    interface a {
        com.google.common.util.concurrent.d<Void> a(int i10, int i11);
    }

    public d(u uVar, Set<w> set, n1 n1Var) {
        super(Y(set));
        this.f5296n = Y(set);
        this.f5297o = new g(uVar, set, n1Var, new a() { // from class: b0.b
            @Override // b0.d.a
            public final com.google.common.util.concurrent.d a(int i10, int i11) {
                return this.f5291a.b0(i10, i11);
            }
        });
    }

    private void T(g1.b bVar, final String str, final m1<?> m1Var, final i1 i1Var) {
        bVar.a(new g1.c() { // from class: b0.c
            @Override // r.g1.c
            public final void a(g1 g1Var, g1.f fVar) {
                this.f5292a.a0(str, m1Var, i1Var, g1Var, fVar);
            }
        });
    }

    private void U() {
        o0 o0Var = this.f5300r;
        if (o0Var != null) {
            o0Var.i();
            this.f5300r = null;
        }
        o0 o0Var2 = this.f5301s;
        if (o0Var2 != null) {
            o0Var2.i();
            this.f5301s = null;
        }
        w0 w0Var = this.f5299q;
        if (w0Var != null) {
            w0Var.i();
            this.f5299q = null;
        }
        w0 w0Var2 = this.f5298p;
        if (w0Var2 != null) {
            w0Var2.i();
            this.f5298p = null;
        }
    }

    private g1 V(String str, m1<?> m1Var, i1 i1Var) {
        o.a();
        u uVar = (u) androidx.core.util.h.k(f());
        Matrix matrixQ = q();
        boolean zI = uVar.i();
        Rect rectX = X(i1Var.d());
        Objects.requireNonNull(rectX);
        o0 o0Var = new o0(3, 34, i1Var, matrixQ, zI, rectX, o(uVar), -1, y(uVar));
        this.f5300r = o0Var;
        this.f5301s = Z(o0Var, uVar);
        this.f5299q = new w0(uVar, u.a.a(i1Var.a()));
        Map<w, w0.d> mapX = this.f5297o.x(this.f5301s);
        w0.c cVarM = this.f5299q.m(w0.b.c(this.f5301s, new ArrayList(mapX.values())));
        HashMap map = new HashMap();
        for (Map.Entry<w, w0.d> entry : mapX.entrySet()) {
            map.put(entry.getKey(), cVarM.get(entry.getValue()));
        }
        this.f5297o.E(map);
        g1.b bVarI = g1.b.i(m1Var, i1Var.d());
        bVarI.f(this.f5300r.o());
        bVarI.e(this.f5297o.z());
        if (i1Var.c() != null) {
            bVarI.b(i1Var.c());
        }
        T(bVarI, str, m1Var, i1Var);
        this.f5302t = bVarI;
        return bVarI.h();
    }

    private Rect X(Size size) {
        return v() != null ? v() : new Rect(0, 0, size.getWidth(), size.getHeight());
    }

    private static f Y(Set<w> set) {
        t0 t0VarA = new e().a();
        t0VarA.i(m0.f19995f, 34);
        t0VarA.i(m1.A, n1.b.STREAM_SHARING);
        ArrayList arrayList = new ArrayList();
        for (w wVar : set) {
            if (wVar.i().c(m1.A)) {
                arrayList.add(wVar.i().g());
            } else {
                Log.e("StreamSharing", "A child does not have capture type.");
            }
        }
        t0VarA.i(f.H, arrayList);
        t0VarA.i(r.o0.f20019k, 2);
        return new f(y0.M(t0VarA));
    }

    private o0 Z(o0 o0Var, r.u uVar) {
        if (k() == null) {
            return o0Var;
        }
        this.f5298p = new w0(uVar, k().a());
        w0.d dVarH = w0.d.h(o0Var.u(), o0Var.p(), o0Var.n(), p.e(o0Var.n(), 0), 0, false);
        o0 o0Var2 = this.f5298p.m(w0.b.c(o0Var, Collections.singletonList(dVarH))).get(dVarH);
        Objects.requireNonNull(o0Var2);
        return o0Var2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a0(String str, m1 m1Var, i1 i1Var, g1 g1Var, g1.f fVar) {
        U();
        if (w(str)) {
            O(V(str, m1Var, i1Var));
            C();
            this.f5297o.D();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ com.google.common.util.concurrent.d b0(int i10, int i11) {
        w0 w0Var = this.f5299q;
        return w0Var != null ? w0Var.e().c(i10, i11) : t.f.f(new Exception("Failed to take picture: pipeline is not ready."));
    }

    @Override // androidx.camera.core.w
    public void E() {
        super.E();
        this.f5297o.p();
    }

    @Override // androidx.camera.core.w
    protected m1<?> F(s sVar, m1.a<?, ?, ?> aVar) {
        this.f5297o.C(aVar.a());
        return aVar.b();
    }

    @Override // androidx.camera.core.w
    protected i1 G(a0 a0Var) {
        this.f5302t.b(a0Var);
        O(this.f5302t.h());
        d().e();
        throw null;
    }

    @Override // androidx.camera.core.w
    protected i1 H(i1 i1Var) {
        O(V(h(), i(), i1Var));
        A();
        return i1Var;
    }

    @Override // androidx.camera.core.w
    public void I() {
        super.I();
        U();
        this.f5297o.F();
    }

    public Set<w> W() {
        return this.f5297o.w();
    }

    @Override // androidx.camera.core.w
    public m1<?> j(boolean z10, n1 n1Var) {
        a0 a0VarA = n1Var.a(this.f5296n.g(), 1);
        if (z10) {
            a0VarA = z.b(a0VarA, this.f5296n.q());
        }
        if (a0VarA == null) {
            return null;
        }
        return u(a0VarA).b();
    }

    @Override // androidx.camera.core.w
    public Set<Integer> s() {
        HashSet hashSet = new HashSet();
        hashSet.add(3);
        return hashSet;
    }

    @Override // androidx.camera.core.w
    public m1.a<?, ?, ?> u(a0 a0Var) {
        return new e(u0.P(a0Var));
    }
}
