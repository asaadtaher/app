package b0;

import b0.d;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import r.g0;
import r.p;
import r.x;

/* loaded from: classes.dex */
public class i extends g0 {

    /* renamed from: c, reason: collision with root package name */
    private final d.a f5315c;

    i(p pVar, d.a aVar) {
        super(pVar);
        this.f5315c = aVar;
    }

    private int j(x xVar) {
        Integer num = (Integer) xVar.a().a(x.f20034j, 100);
        Objects.requireNonNull(num);
        return num.intValue();
    }

    private int k(x xVar) {
        Integer num = (Integer) xVar.a().a(x.f20033i, 0);
        Objects.requireNonNull(num);
        return num.intValue();
    }

    @Override // r.g0, r.p
    public com.google.common.util.concurrent.d<List<Void>> b(List<x> list, int i10, int i11) {
        androidx.core.util.h.b(list.size() == 1, "Only support one capture config.");
        return t.f.c(Collections.singletonList(this.f5315c.a(j(list.get(0)), k(list.get(0)))));
    }
}
