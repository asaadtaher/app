package b0;

import androidx.camera.core.impl.utils.o;
import androidx.camera.core.impl.utils.p;
import androidx.camera.core.n;
import androidx.camera.core.s;
import androidx.camera.core.w;
import b0.d;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import o.k;
import r.e0;
import r.g1;
import r.m1;
import r.n1;
import r.t;
import r.t0;
import r.u;
import r.w0;
import z.o0;
import z.w0;

/* loaded from: classes.dex */
class g implements u {

    /* renamed from: a, reason: collision with root package name */
    final Set<w> f5304a;

    /* renamed from: d, reason: collision with root package name */
    private final n1 f5307d;

    /* renamed from: e, reason: collision with root package name */
    private final u f5308e;

    /* renamed from: g, reason: collision with root package name */
    private final i f5310g;

    /* renamed from: b, reason: collision with root package name */
    final Map<w, o0> f5305b = new HashMap();

    /* renamed from: c, reason: collision with root package name */
    final Map<w, Boolean> f5306c = new HashMap();

    /* renamed from: f, reason: collision with root package name */
    private final r.f f5309f = q();

    class a extends r.f {
        a() {
        }
    }

    g(u uVar, Set<w> set, n1 n1Var, d.a aVar) {
        this.f5308e = uVar;
        this.f5307d = n1Var;
        this.f5304a = set;
        this.f5310g = new i(uVar.n(), aVar);
        Iterator<w> it = set.iterator();
        while (it.hasNext()) {
            this.f5306c.put(it.next(), Boolean.FALSE);
        }
    }

    private o0 A(w wVar) {
        o0 o0Var = this.f5305b.get(wVar);
        Objects.requireNonNull(o0Var);
        return o0Var;
    }

    private boolean B(w wVar) {
        Boolean bool = this.f5306c.get(wVar);
        Objects.requireNonNull(bool);
        return bool.booleanValue();
    }

    private void r(o0 o0Var, e0 e0Var, g1 g1Var) {
        o0Var.w();
        try {
            o0Var.C(e0Var);
        } catch (e0.a unused) {
            Iterator<g1.c> it = g1Var.b().iterator();
            while (it.hasNext()) {
                it.next().a(g1Var, g1.f.SESSION_ERROR_SURFACE_NEEDS_RESET);
            }
        }
    }

    private static int s(w wVar) {
        return wVar instanceof n ? 256 : 34;
    }

    private int t(w wVar) {
        if (wVar instanceof s) {
            return this.f5308e.a().g(((s) wVar).Y());
        }
        return 0;
    }

    static e0 u(w wVar) {
        boolean z10 = wVar instanceof n;
        g1 g1VarR = wVar.r();
        List<e0> listE = z10 ? g1VarR.e() : g1VarR.d().b();
        androidx.core.util.h.m(listE.size() <= 1);
        if (listE.size() == 1) {
            return listE.get(0);
        }
        return null;
    }

    private static int v(w wVar) {
        if (wVar instanceof s) {
            return 1;
        }
        return wVar instanceof n ? 4 : 2;
    }

    private static int y(Set<m1<?>> set) {
        Iterator<m1<?>> it = set.iterator();
        int iMax = 0;
        while (it.hasNext()) {
            iMax = Math.max(iMax, it.next().z());
        }
        return iMax;
    }

    void C(t0 t0Var) {
        HashSet hashSet = new HashSet();
        for (w wVar : this.f5304a) {
            hashSet.add(wVar.z(this.f5308e.k(), null, wVar.j(true, this.f5307d)));
        }
        t0Var.i(r.o0.f20025q, b0.a.a(new ArrayList(this.f5308e.k().j(34)), p.j(this.f5308e.n().d()), hashSet));
        t0Var.i(m1.f20001v, Integer.valueOf(y(hashSet)));
    }

    void D() {
        o.a();
        Iterator<w> it = this.f5304a.iterator();
        while (it.hasNext()) {
            j(it.next());
        }
    }

    void E(Map<w, o0> map) {
        this.f5305b.clear();
        this.f5305b.putAll(map);
        for (Map.Entry<w, o0> entry : this.f5305b.entrySet()) {
            w key = entry.getKey();
            o0 value = entry.getValue();
            key.M(value.n());
            key.L(value.s());
            key.P(value.t());
            key.D();
        }
    }

    void F() {
        Iterator<w> it = this.f5304a.iterator();
        while (it.hasNext()) {
            it.next().N(this);
        }
    }

    @Override // r.u, o.f
    public /* synthetic */ k a() {
        return t.b(this);
    }

    @Override // r.u
    public /* synthetic */ void b(boolean z10) {
        t.e(this, z10);
    }

    @Override // o.f
    public /* synthetic */ o.g c() {
        return t.a(this);
    }

    @Override // r.u
    public /* synthetic */ void d(r.k kVar) {
        t.f(this, kVar);
    }

    @Override // androidx.camera.core.w.d
    public void e(w wVar) {
        o.a();
        if (B(wVar)) {
            return;
        }
        this.f5306c.put(wVar, Boolean.TRUE);
        e0 e0VarU = u(wVar);
        if (e0VarU != null) {
            r(A(wVar), e0VarU, wVar.r());
        }
    }

    @Override // r.u
    public void f(Collection<w> collection) {
        throw new UnsupportedOperationException("Operation not supported by VirtualCamera.");
    }

    @Override // r.u
    public void g(Collection<w> collection) {
        throw new UnsupportedOperationException("Operation not supported by VirtualCamera.");
    }

    @Override // r.u
    public /* synthetic */ boolean h() {
        return t.d(this);
    }

    @Override // r.u
    public boolean i() {
        return false;
    }

    @Override // androidx.camera.core.w.d
    public void j(w wVar) {
        e0 e0VarU;
        o.a();
        o0 o0VarA = A(wVar);
        o0VarA.w();
        if (B(wVar) && (e0VarU = u(wVar)) != null) {
            r(o0VarA, e0VarU, wVar.r());
        }
    }

    @Override // r.u
    public r.s k() {
        return this.f5308e.k();
    }

    @Override // androidx.camera.core.w.d
    public void l(w wVar) {
        o.a();
        if (B(wVar)) {
            this.f5306c.put(wVar, Boolean.FALSE);
            A(wVar).l();
        }
    }

    @Override // r.u
    public w0<Object> m() {
        return this.f5308e.m();
    }

    @Override // r.u
    public r.p n() {
        return this.f5310g;
    }

    @Override // r.u
    public /* synthetic */ r.k o() {
        return t.c(this);
    }

    void p() {
        for (w wVar : this.f5304a) {
            wVar.b(this, null, wVar.j(true, this.f5307d));
        }
    }

    r.f q() {
        return new a();
    }

    Set<w> w() {
        return this.f5304a;
    }

    Map<w, w0.d> x(o0 o0Var) {
        HashMap map = new HashMap();
        for (w wVar : this.f5304a) {
            int iT = t(wVar);
            map.put(wVar, w0.d.h(v(wVar), s(wVar), o0Var.n(), p.e(o0Var.n(), iT), iT, wVar.y(this)));
        }
        return map;
    }

    r.f z() {
        return this.f5309f;
    }
}
