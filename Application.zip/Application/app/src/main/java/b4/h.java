package b4;

import java.util.Arrays;
import java.util.Objects;

/* loaded from: classes.dex */
public final class h {

    /* renamed from: a, reason: collision with root package name */
    private final z3.b f5903a;

    /* renamed from: b, reason: collision with root package name */
    private final byte[] f5904b;

    public h(z3.b bVar, byte[] bArr) {
        Objects.requireNonNull(bVar, "encoding is null");
        Objects.requireNonNull(bArr, "bytes is null");
        this.f5903a = bVar;
        this.f5904b = bArr;
    }

    public byte[] a() {
        return this.f5904b;
    }

    public z3.b b() {
        return this.f5903a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof h)) {
            return false;
        }
        h hVar = (h) obj;
        if (this.f5903a.equals(hVar.f5903a)) {
            return Arrays.equals(this.f5904b, hVar.f5904b);
        }
        return false;
    }

    public int hashCode() {
        return ((this.f5903a.hashCode() ^ 1000003) * 1000003) ^ Arrays.hashCode(this.f5904b);
    }

    public String toString() {
        return "EncodedPayload{encoding=" + this.f5903a + ", bytes=[...]}";
    }
}
