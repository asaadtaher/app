package b4;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
class m implements Executor {

    /* renamed from: a, reason: collision with root package name */
    private final Executor f5907a;

    static class a implements Runnable {

        /* renamed from: a, reason: collision with root package name */
        private final Runnable f5908a;

        a(Runnable runnable) {
            this.f5908a = runnable;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                this.f5908a.run();
            } catch (Exception e10) {
                f4.a.d("Executor", "Background execution failure.", e10);
            }
        }
    }

    m(Executor executor) {
        this.f5907a = executor;
    }

    @Override // java.util.concurrent.Executor
    public void execute(Runnable runnable) {
        this.f5907a.execute(new a(runnable));
    }
}
