package b4;

/* loaded from: classes.dex */
interface s {
    void a(n nVar, z3.h hVar);
}
