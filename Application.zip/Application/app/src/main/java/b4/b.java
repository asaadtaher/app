package b4;

import b4.i;
import java.util.Map;
import java.util.Objects;

/* loaded from: classes.dex */
final class b extends i {

    /* renamed from: a, reason: collision with root package name */
    private final String f5861a;

    /* renamed from: b, reason: collision with root package name */
    private final Integer f5862b;

    /* renamed from: c, reason: collision with root package name */
    private final h f5863c;

    /* renamed from: d, reason: collision with root package name */
    private final long f5864d;

    /* renamed from: e, reason: collision with root package name */
    private final long f5865e;

    /* renamed from: f, reason: collision with root package name */
    private final Map<String, String> f5866f;

    /* renamed from: b4.b$b, reason: collision with other inner class name */
    static final class C0091b extends i.a {

        /* renamed from: a, reason: collision with root package name */
        private String f5867a;

        /* renamed from: b, reason: collision with root package name */
        private Integer f5868b;

        /* renamed from: c, reason: collision with root package name */
        private h f5869c;

        /* renamed from: d, reason: collision with root package name */
        private Long f5870d;

        /* renamed from: e, reason: collision with root package name */
        private Long f5871e;

        /* renamed from: f, reason: collision with root package name */
        private Map<String, String> f5872f;

        C0091b() {
        }

        @Override // b4.i.a
        public i d() {
            String str = "";
            if (this.f5867a == null) {
                str = " transportName";
            }
            if (this.f5869c == null) {
                str = str + " encodedPayload";
            }
            if (this.f5870d == null) {
                str = str + " eventMillis";
            }
            if (this.f5871e == null) {
                str = str + " uptimeMillis";
            }
            if (this.f5872f == null) {
                str = str + " autoMetadata";
            }
            if (str.isEmpty()) {
                return new b(this.f5867a, this.f5868b, this.f5869c, this.f5870d.longValue(), this.f5871e.longValue(), this.f5872f);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // b4.i.a
        protected Map<String, String> e() {
            Map<String, String> map = this.f5872f;
            if (map != null) {
                return map;
            }
            throw new IllegalStateException("Property \"autoMetadata\" has not been set");
        }

        @Override // b4.i.a
        protected i.a f(Map<String, String> map) {
            Objects.requireNonNull(map, "Null autoMetadata");
            this.f5872f = map;
            return this;
        }

        @Override // b4.i.a
        public i.a g(Integer num) {
            this.f5868b = num;
            return this;
        }

        @Override // b4.i.a
        public i.a h(h hVar) {
            Objects.requireNonNull(hVar, "Null encodedPayload");
            this.f5869c = hVar;
            return this;
        }

        @Override // b4.i.a
        public i.a i(long j10) {
            this.f5870d = Long.valueOf(j10);
            return this;
        }

        @Override // b4.i.a
        public i.a j(String str) {
            Objects.requireNonNull(str, "Null transportName");
            this.f5867a = str;
            return this;
        }

        @Override // b4.i.a
        public i.a k(long j10) {
            this.f5871e = Long.valueOf(j10);
            return this;
        }
    }

    private b(String str, Integer num, h hVar, long j10, long j11, Map<String, String> map) {
        this.f5861a = str;
        this.f5862b = num;
        this.f5863c = hVar;
        this.f5864d = j10;
        this.f5865e = j11;
        this.f5866f = map;
    }

    @Override // b4.i
    protected Map<String, String> c() {
        return this.f5866f;
    }

    @Override // b4.i
    public Integer d() {
        return this.f5862b;
    }

    @Override // b4.i
    public h e() {
        return this.f5863c;
    }

    public boolean equals(Object obj) {
        Integer num;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return this.f5861a.equals(iVar.j()) && ((num = this.f5862b) != null ? num.equals(iVar.d()) : iVar.d() == null) && this.f5863c.equals(iVar.e()) && this.f5864d == iVar.f() && this.f5865e == iVar.k() && this.f5866f.equals(iVar.c());
    }

    @Override // b4.i
    public long f() {
        return this.f5864d;
    }

    public int hashCode() {
        int iHashCode = (this.f5861a.hashCode() ^ 1000003) * 1000003;
        Integer num = this.f5862b;
        int iHashCode2 = (((iHashCode ^ (num == null ? 0 : num.hashCode())) * 1000003) ^ this.f5863c.hashCode()) * 1000003;
        long j10 = this.f5864d;
        int i10 = (iHashCode2 ^ ((int) (j10 ^ (j10 >>> 32)))) * 1000003;
        long j11 = this.f5865e;
        return ((i10 ^ ((int) (j11 ^ (j11 >>> 32)))) * 1000003) ^ this.f5866f.hashCode();
    }

    @Override // b4.i
    public String j() {
        return this.f5861a;
    }

    @Override // b4.i
    public long k() {
        return this.f5865e;
    }

    public String toString() {
        return "EventInternal{transportName=" + this.f5861a + ", code=" + this.f5862b + ", encodedPayload=" + this.f5863c + ", eventMillis=" + this.f5864d + ", uptimeMillis=" + this.f5865e + ", autoMetadata=" + this.f5866f + "}";
    }
}
