package b4;

/* loaded from: classes.dex */
public final class a implements l8.a {

    /* renamed from: a, reason: collision with root package name */
    public static final l8.a f5839a = new a();

    /* renamed from: b4.a$a, reason: collision with other inner class name */
    private static final class C0090a implements k8.d<e4.a> {

        /* renamed from: a, reason: collision with root package name */
        static final C0090a f5840a = new C0090a();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f5841b = k8.c.a("window").b(n8.a.b().c(1).a()).a();

        /* renamed from: c, reason: collision with root package name */
        private static final k8.c f5842c = k8.c.a("logSourceMetrics").b(n8.a.b().c(2).a()).a();

        /* renamed from: d, reason: collision with root package name */
        private static final k8.c f5843d = k8.c.a("globalMetrics").b(n8.a.b().c(3).a()).a();

        /* renamed from: e, reason: collision with root package name */
        private static final k8.c f5844e = k8.c.a("appNamespace").b(n8.a.b().c(4).a()).a();

        private C0090a() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(e4.a aVar, k8.e eVar) {
            eVar.a(f5841b, aVar.d());
            eVar.a(f5842c, aVar.c());
            eVar.a(f5843d, aVar.b());
            eVar.a(f5844e, aVar.a());
        }
    }

    private static final class b implements k8.d<e4.b> {

        /* renamed from: a, reason: collision with root package name */
        static final b f5845a = new b();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f5846b = k8.c.a("storageMetrics").b(n8.a.b().c(1).a()).a();

        private b() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(e4.b bVar, k8.e eVar) {
            eVar.a(f5846b, bVar.a());
        }
    }

    private static final class c implements k8.d<e4.c> {

        /* renamed from: a, reason: collision with root package name */
        static final c f5847a = new c();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f5848b = k8.c.a("eventsDroppedCount").b(n8.a.b().c(1).a()).a();

        /* renamed from: c, reason: collision with root package name */
        private static final k8.c f5849c = k8.c.a("reason").b(n8.a.b().c(3).a()).a();

        private c() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(e4.c cVar, k8.e eVar) {
            eVar.d(f5848b, cVar.a());
            eVar.a(f5849c, cVar.b());
        }
    }

    private static final class d implements k8.d<e4.d> {

        /* renamed from: a, reason: collision with root package name */
        static final d f5850a = new d();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f5851b = k8.c.a("logSource").b(n8.a.b().c(1).a()).a();

        /* renamed from: c, reason: collision with root package name */
        private static final k8.c f5852c = k8.c.a("logEventDropped").b(n8.a.b().c(2).a()).a();

        private d() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(e4.d dVar, k8.e eVar) {
            eVar.a(f5851b, dVar.b());
            eVar.a(f5852c, dVar.a());
        }
    }

    private static final class e implements k8.d<l> {

        /* renamed from: a, reason: collision with root package name */
        static final e f5853a = new e();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f5854b = k8.c.d("clientMetrics");

        private e() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(l lVar, k8.e eVar) {
            eVar.a(f5854b, lVar.b());
        }
    }

    private static final class f implements k8.d<e4.e> {

        /* renamed from: a, reason: collision with root package name */
        static final f f5855a = new f();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f5856b = k8.c.a("currentCacheSizeBytes").b(n8.a.b().c(1).a()).a();

        /* renamed from: c, reason: collision with root package name */
        private static final k8.c f5857c = k8.c.a("maxCacheSizeBytes").b(n8.a.b().c(2).a()).a();

        private f() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(e4.e eVar, k8.e eVar2) {
            eVar2.d(f5856b, eVar.a());
            eVar2.d(f5857c, eVar.b());
        }
    }

    private static final class g implements k8.d<e4.f> {

        /* renamed from: a, reason: collision with root package name */
        static final g f5858a = new g();

        /* renamed from: b, reason: collision with root package name */
        private static final k8.c f5859b = k8.c.a("startMs").b(n8.a.b().c(1).a()).a();

        /* renamed from: c, reason: collision with root package name */
        private static final k8.c f5860c = k8.c.a("endMs").b(n8.a.b().c(2).a()).a();

        private g() {
        }

        @Override // k8.d
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(e4.f fVar, k8.e eVar) {
            eVar.d(f5859b, fVar.b());
            eVar.d(f5860c, fVar.a());
        }
    }

    private a() {
    }

    @Override // l8.a
    public void a(l8.b<?> bVar) {
        bVar.a(l.class, e.f5853a);
        bVar.a(e4.a.class, C0090a.f5840a);
        bVar.a(e4.f.class, g.f5858a);
        bVar.a(e4.d.class, d.f5850a);
        bVar.a(e4.c.class, c.f5847a);
        bVar.a(e4.b.class, b.f5845a);
        bVar.a(e4.e.class, f.f5855a);
    }
}
