package b4;

import b4.c;

/* loaded from: classes.dex */
abstract class n {

    public static abstract class a {
        public abstract n a();

        abstract a b(z3.b bVar);

        abstract a c(z3.c<?> cVar);

        abstract a d(z3.e<?, byte[]> eVar);

        public abstract a e(o oVar);

        public abstract a f(String str);
    }

    n() {
    }

    public static a a() {
        return new c.b();
    }

    public abstract z3.b b();

    abstract z3.c<?> c();

    public byte[] d() {
        return e().a(c().b());
    }

    abstract z3.e<?, byte[]> e();

    public abstract o f();

    public abstract String g();
}
