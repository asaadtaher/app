package b4;

/* loaded from: classes.dex */
final class r<T> implements z3.f<T> {

    /* renamed from: a, reason: collision with root package name */
    private final o f5913a;

    /* renamed from: b, reason: collision with root package name */
    private final String f5914b;

    /* renamed from: c, reason: collision with root package name */
    private final z3.b f5915c;

    /* renamed from: d, reason: collision with root package name */
    private final z3.e<T, byte[]> f5916d;

    /* renamed from: e, reason: collision with root package name */
    private final s f5917e;

    r(o oVar, String str, z3.b bVar, z3.e<T, byte[]> eVar, s sVar) {
        this.f5913a = oVar;
        this.f5914b = str;
        this.f5915c = bVar;
        this.f5916d = eVar;
        this.f5917e = sVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void c(Exception exc) {
    }

    @Override // z3.f
    public void a(z3.c<T> cVar) {
        d(cVar, new z3.h() { // from class: b4.q
            @Override // z3.h
            public final void a(Exception exc) {
                r.c(exc);
            }
        });
    }

    public void d(z3.c<T> cVar, z3.h hVar) {
        this.f5917e.a(n.a().e(this.f5913a).c(cVar).f(this.f5914b).d(this.f5916d).b(this.f5915c).a(), hVar);
    }
}
