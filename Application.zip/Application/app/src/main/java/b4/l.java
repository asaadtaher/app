package b4;

/* loaded from: classes.dex */
public abstract class l {

    /* renamed from: a, reason: collision with root package name */
    private static final n8.h f5906a = n8.h.a().d(a.f5839a).c();

    private l() {
    }

    public static byte[] a(Object obj) {
        return f5906a.c(obj);
    }

    public abstract e4.a b();
}
