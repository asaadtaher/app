package b4;

import b4.n;
import java.util.Objects;

/* loaded from: classes.dex */
final class c extends n {

    /* renamed from: a, reason: collision with root package name */
    private final o f5873a;

    /* renamed from: b, reason: collision with root package name */
    private final String f5874b;

    /* renamed from: c, reason: collision with root package name */
    private final z3.c<?> f5875c;

    /* renamed from: d, reason: collision with root package name */
    private final z3.e<?, byte[]> f5876d;

    /* renamed from: e, reason: collision with root package name */
    private final z3.b f5877e;

    static final class b extends n.a {

        /* renamed from: a, reason: collision with root package name */
        private o f5878a;

        /* renamed from: b, reason: collision with root package name */
        private String f5879b;

        /* renamed from: c, reason: collision with root package name */
        private z3.c<?> f5880c;

        /* renamed from: d, reason: collision with root package name */
        private z3.e<?, byte[]> f5881d;

        /* renamed from: e, reason: collision with root package name */
        private z3.b f5882e;

        b() {
        }

        @Override // b4.n.a
        public n a() {
            String str = "";
            if (this.f5878a == null) {
                str = " transportContext";
            }
            if (this.f5879b == null) {
                str = str + " transportName";
            }
            if (this.f5880c == null) {
                str = str + " event";
            }
            if (this.f5881d == null) {
                str = str + " transformer";
            }
            if (this.f5882e == null) {
                str = str + " encoding";
            }
            if (str.isEmpty()) {
                return new c(this.f5878a, this.f5879b, this.f5880c, this.f5881d, this.f5882e);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // b4.n.a
        n.a b(z3.b bVar) {
            Objects.requireNonNull(bVar, "Null encoding");
            this.f5882e = bVar;
            return this;
        }

        @Override // b4.n.a
        n.a c(z3.c<?> cVar) {
            Objects.requireNonNull(cVar, "Null event");
            this.f5880c = cVar;
            return this;
        }

        @Override // b4.n.a
        n.a d(z3.e<?, byte[]> eVar) {
            Objects.requireNonNull(eVar, "Null transformer");
            this.f5881d = eVar;
            return this;
        }

        @Override // b4.n.a
        public n.a e(o oVar) {
            Objects.requireNonNull(oVar, "Null transportContext");
            this.f5878a = oVar;
            return this;
        }

        @Override // b4.n.a
        public n.a f(String str) {
            Objects.requireNonNull(str, "Null transportName");
            this.f5879b = str;
            return this;
        }
    }

    private c(o oVar, String str, z3.c<?> cVar, z3.e<?, byte[]> eVar, z3.b bVar) {
        this.f5873a = oVar;
        this.f5874b = str;
        this.f5875c = cVar;
        this.f5876d = eVar;
        this.f5877e = bVar;
    }

    @Override // b4.n
    public z3.b b() {
        return this.f5877e;
    }

    @Override // b4.n
    z3.c<?> c() {
        return this.f5875c;
    }

    @Override // b4.n
    z3.e<?, byte[]> e() {
        return this.f5876d;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof n)) {
            return false;
        }
        n nVar = (n) obj;
        return this.f5873a.equals(nVar.f()) && this.f5874b.equals(nVar.g()) && this.f5875c.equals(nVar.c()) && this.f5876d.equals(nVar.e()) && this.f5877e.equals(nVar.b());
    }

    @Override // b4.n
    public o f() {
        return this.f5873a;
    }

    @Override // b4.n
    public String g() {
        return this.f5874b;
    }

    public int hashCode() {
        return ((((((((this.f5873a.hashCode() ^ 1000003) * 1000003) ^ this.f5874b.hashCode()) * 1000003) ^ this.f5875c.hashCode()) * 1000003) ^ this.f5876d.hashCode()) * 1000003) ^ this.f5877e.hashCode();
    }

    public String toString() {
        return "SendRequest{transportContext=" + this.f5873a + ", transportName=" + this.f5874b + ", event=" + this.f5875c + ", transformer=" + this.f5876d + ", encoding=" + this.f5877e + "}";
    }
}
