package b4;

import android.content.Context;
import i4.w;
import java.util.Collections;
import java.util.Set;

/* loaded from: classes.dex */
public class t implements s {

    /* renamed from: e, reason: collision with root package name */
    private static volatile u f5918e;

    /* renamed from: a, reason: collision with root package name */
    private final l4.a f5919a;

    /* renamed from: b, reason: collision with root package name */
    private final l4.a f5920b;

    /* renamed from: c, reason: collision with root package name */
    private final h4.e f5921c;

    /* renamed from: d, reason: collision with root package name */
    private final i4.s f5922d;

    t(l4.a aVar, l4.a aVar2, h4.e eVar, i4.s sVar, w wVar) {
        this.f5919a = aVar;
        this.f5920b = aVar2;
        this.f5921c = eVar;
        this.f5922d = sVar;
        wVar.c();
    }

    private i b(n nVar) {
        return i.a().i(this.f5919a.a()).k(this.f5920b.a()).j(nVar.g()).h(new h(nVar.b(), nVar.d())).g(nVar.c().a()).d();
    }

    public static t c() {
        u uVar = f5918e;
        if (uVar != null) {
            return uVar.d();
        }
        throw new IllegalStateException("Not initialized!");
    }

    private static Set<z3.b> d(f fVar) {
        return fVar instanceof g ? Collections.unmodifiableSet(((g) fVar).a()) : Collections.singleton(z3.b.b("proto"));
    }

    public static void f(Context context) {
        if (f5918e == null) {
            synchronized (t.class) {
                if (f5918e == null) {
                    f5918e = e.f().a(context).b();
                }
            }
        }
    }

    @Override // b4.s
    public void a(n nVar, z3.h hVar) {
        this.f5921c.a(nVar.f().f(nVar.c().c()), b(nVar), hVar);
    }

    public i4.s e() {
        return this.f5922d;
    }

    public z3.g g(f fVar) {
        return new p(d(fVar), o.a().b(fVar.b()).c(fVar.c()).a(), this);
    }
}
