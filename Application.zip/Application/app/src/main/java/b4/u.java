package b4;

import android.content.Context;
import java.io.Closeable;
import java.io.IOException;

/* loaded from: classes.dex */
abstract class u implements Closeable {

    interface a {
        a a(Context context);

        u b();
    }

    u() {
    }

    abstract j4.d b();

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        b().close();
    }

    abstract t d();
}
