package b4;

import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class k implements d4.b<Executor> {

    private static final class a {

        /* renamed from: a, reason: collision with root package name */
        private static final k f5905a = new k();
    }

    public static k a() {
        return a.f5905a;
    }

    public static Executor b() {
        return (Executor) d4.d.c(j.a(), "Cannot return null from a non-@Nullable @Provides method");
    }

    @Override // sc.a
    /* renamed from: c, reason: merged with bridge method [inline-methods] */
    public Executor get() {
        return b();
    }
}
