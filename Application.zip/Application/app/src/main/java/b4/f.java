package b4;

/* loaded from: classes.dex */
public interface f {
    String b();

    byte[] c();
}
