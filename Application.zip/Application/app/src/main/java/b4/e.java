package b4;

import android.content.Context;
import b4.u;
import i4.w;
import i4.x;
import i4.y;
import j4.m0;
import j4.n0;
import j4.u0;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
final class e extends u {

    /* renamed from: a, reason: collision with root package name */
    private sc.a<Executor> f5889a;

    /* renamed from: b, reason: collision with root package name */
    private sc.a<Context> f5890b;

    /* renamed from: c, reason: collision with root package name */
    private sc.a f5891c;

    /* renamed from: d, reason: collision with root package name */
    private sc.a f5892d;

    /* renamed from: e, reason: collision with root package name */
    private sc.a f5893e;

    /* renamed from: f, reason: collision with root package name */
    private sc.a<String> f5894f;

    /* renamed from: g, reason: collision with root package name */
    private sc.a<m0> f5895g;

    /* renamed from: h, reason: collision with root package name */
    private sc.a<i4.g> f5896h;

    /* renamed from: i, reason: collision with root package name */
    private sc.a<y> f5897i;

    /* renamed from: j, reason: collision with root package name */
    private sc.a<h4.c> f5898j;

    /* renamed from: k, reason: collision with root package name */
    private sc.a<i4.s> f5899k;

    /* renamed from: l, reason: collision with root package name */
    private sc.a<w> f5900l;

    /* renamed from: r, reason: collision with root package name */
    private sc.a<t> f5901r;

    private static final class b implements u.a {

        /* renamed from: a, reason: collision with root package name */
        private Context f5902a;

        private b() {
        }

        @Override // b4.u.a
        public u b() {
            d4.d.a(this.f5902a, Context.class);
            return new e(this.f5902a);
        }

        @Override // b4.u.a
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public b a(Context context) {
            this.f5902a = (Context) d4.d.b(context);
            return this;
        }
    }

    private e(Context context) {
        k(context);
    }

    public static u.a f() {
        return new b();
    }

    private void k(Context context) {
        this.f5889a = d4.a.a(k.a());
        d4.b bVarA = d4.c.a(context);
        this.f5890b = bVarA;
        c4.j jVarA = c4.j.a(bVarA, l4.c.a(), l4.d.a());
        this.f5891c = jVarA;
        this.f5892d = d4.a.a(c4.l.a(this.f5890b, jVarA));
        this.f5893e = u0.a(this.f5890b, j4.g.a(), j4.i.a());
        this.f5894f = d4.a.a(j4.h.a(this.f5890b));
        this.f5895g = d4.a.a(n0.a(l4.c.a(), l4.d.a(), j4.j.a(), this.f5893e, this.f5894f));
        h4.g gVarB = h4.g.b(l4.c.a());
        this.f5896h = gVarB;
        h4.i iVarA = h4.i.a(this.f5890b, this.f5895g, gVarB, l4.d.a());
        this.f5897i = iVarA;
        sc.a<Executor> aVar = this.f5889a;
        sc.a aVar2 = this.f5892d;
        sc.a<m0> aVar3 = this.f5895g;
        this.f5898j = h4.d.a(aVar, aVar2, iVarA, aVar3, aVar3);
        sc.a<Context> aVar4 = this.f5890b;
        sc.a aVar5 = this.f5892d;
        sc.a<m0> aVar6 = this.f5895g;
        this.f5899k = i4.t.a(aVar4, aVar5, aVar6, this.f5897i, this.f5889a, aVar6, l4.c.a(), l4.d.a(), this.f5895g);
        sc.a<Executor> aVar7 = this.f5889a;
        sc.a<m0> aVar8 = this.f5895g;
        this.f5900l = x.a(aVar7, aVar8, this.f5897i, aVar8);
        this.f5901r = d4.a.a(v.a(l4.c.a(), l4.d.a(), this.f5898j, this.f5899k, this.f5900l));
    }

    @Override // b4.u
    j4.d b() {
        return this.f5895g.get();
    }

    @Override // b4.u
    t d() {
        return this.f5901r.get();
    }
}
