package b4;

import i4.w;

/* loaded from: classes.dex */
public final class v implements d4.b<t> {

    /* renamed from: a, reason: collision with root package name */
    private final sc.a<l4.a> f5923a;

    /* renamed from: b, reason: collision with root package name */
    private final sc.a<l4.a> f5924b;

    /* renamed from: c, reason: collision with root package name */
    private final sc.a<h4.e> f5925c;

    /* renamed from: d, reason: collision with root package name */
    private final sc.a<i4.s> f5926d;

    /* renamed from: e, reason: collision with root package name */
    private final sc.a<w> f5927e;

    public v(sc.a<l4.a> aVar, sc.a<l4.a> aVar2, sc.a<h4.e> aVar3, sc.a<i4.s> aVar4, sc.a<w> aVar5) {
        this.f5923a = aVar;
        this.f5924b = aVar2;
        this.f5925c = aVar3;
        this.f5926d = aVar4;
        this.f5927e = aVar5;
    }

    public static v a(sc.a<l4.a> aVar, sc.a<l4.a> aVar2, sc.a<h4.e> aVar3, sc.a<i4.s> aVar4, sc.a<w> aVar5) {
        return new v(aVar, aVar2, aVar3, aVar4, aVar5);
    }

    public static t c(l4.a aVar, l4.a aVar2, h4.e eVar, i4.s sVar, w wVar) {
        return new t(aVar, aVar2, eVar, sVar, wVar);
    }

    @Override // sc.a
    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public t get() {
        return c(this.f5923a.get(), this.f5924b.get(), this.f5925c.get(), this.f5926d.get(), this.f5927e.get());
    }
}
