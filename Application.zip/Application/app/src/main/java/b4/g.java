package b4;

import java.util.Set;

/* loaded from: classes.dex */
public interface g extends f {
    Set<z3.b> a();
}
