package b4;

import java.util.Set;

/* loaded from: classes.dex */
final class p implements z3.g {

    /* renamed from: a, reason: collision with root package name */
    private final Set<z3.b> f5909a;

    /* renamed from: b, reason: collision with root package name */
    private final o f5910b;

    /* renamed from: c, reason: collision with root package name */
    private final s f5911c;

    p(Set<z3.b> set, o oVar, s sVar) {
        this.f5909a = set;
        this.f5910b = oVar;
        this.f5911c = sVar;
    }

    @Override // z3.g
    public <T> z3.f<T> a(String str, Class<T> cls, z3.b bVar, z3.e<T, byte[]> eVar) {
        if (this.f5909a.contains(bVar)) {
            return new r(this.f5910b, str, bVar, eVar, this.f5911c);
        }
        throw new IllegalArgumentException(String.format("%s is not supported byt this factory. Supported encodings are: %s.", bVar, this.f5909a));
    }
}
