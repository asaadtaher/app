package b4;

import b4.o;
import java.util.Arrays;
import java.util.Objects;

/* loaded from: classes.dex */
final class d extends o {

    /* renamed from: a, reason: collision with root package name */
    private final String f5883a;

    /* renamed from: b, reason: collision with root package name */
    private final byte[] f5884b;

    /* renamed from: c, reason: collision with root package name */
    private final z3.d f5885c;

    static final class b extends o.a {

        /* renamed from: a, reason: collision with root package name */
        private String f5886a;

        /* renamed from: b, reason: collision with root package name */
        private byte[] f5887b;

        /* renamed from: c, reason: collision with root package name */
        private z3.d f5888c;

        b() {
        }

        @Override // b4.o.a
        public o a() {
            String str = "";
            if (this.f5886a == null) {
                str = " backendName";
            }
            if (this.f5888c == null) {
                str = str + " priority";
            }
            if (str.isEmpty()) {
                return new d(this.f5886a, this.f5887b, this.f5888c);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // b4.o.a
        public o.a b(String str) {
            Objects.requireNonNull(str, "Null backendName");
            this.f5886a = str;
            return this;
        }

        @Override // b4.o.a
        public o.a c(byte[] bArr) {
            this.f5887b = bArr;
            return this;
        }

        @Override // b4.o.a
        public o.a d(z3.d dVar) {
            Objects.requireNonNull(dVar, "Null priority");
            this.f5888c = dVar;
            return this;
        }
    }

    private d(String str, byte[] bArr, z3.d dVar) {
        this.f5883a = str;
        this.f5884b = bArr;
        this.f5885c = dVar;
    }

    @Override // b4.o
    public String b() {
        return this.f5883a;
    }

    @Override // b4.o
    public byte[] c() {
        return this.f5884b;
    }

    @Override // b4.o
    public z3.d d() {
        return this.f5885c;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof o)) {
            return false;
        }
        o oVar = (o) obj;
        if (this.f5883a.equals(oVar.b())) {
            if (Arrays.equals(this.f5884b, oVar instanceof d ? ((d) oVar).f5884b : oVar.c()) && this.f5885c.equals(oVar.d())) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return ((((this.f5883a.hashCode() ^ 1000003) * 1000003) ^ Arrays.hashCode(this.f5884b)) * 1000003) ^ this.f5885c.hashCode();
    }
}
