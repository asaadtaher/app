package c3;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

/* loaded from: classes.dex */
public interface a extends IInterface {

    /* renamed from: c3.a$a, reason: collision with other inner class name */
    public static abstract class AbstractBinderC0105a extends Binder implements a {

        /* renamed from: c3.a$a$a, reason: collision with other inner class name */
        private static class C0106a implements a {

            /* renamed from: d, reason: collision with root package name */
            public static a f6258d;

            /* renamed from: c, reason: collision with root package name */
            private IBinder f6259c;

            C0106a(IBinder iBinder) {
                this.f6259c = iBinder;
            }

            @Override // c3.a
            public int G0(Bundle bundle) {
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("com.facebook.ppml.receiver.IReceiverService");
                    if (bundle != null) {
                        parcelObtain.writeInt(1);
                        bundle.writeToParcel(parcelObtain, 0);
                    } else {
                        parcelObtain.writeInt(0);
                    }
                    if (!this.f6259c.transact(1, parcelObtain, parcelObtain2, 0) && AbstractBinderC0105a.y() != null) {
                        return AbstractBinderC0105a.y().G0(bundle);
                    }
                    parcelObtain2.readException();
                    return parcelObtain2.readInt();
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.f6259c;
            }
        }

        public static a r(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.facebook.ppml.receiver.IReceiverService");
            return (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof a)) ? new C0106a(iBinder) : (a) iInterfaceQueryLocalInterface;
        }

        public static a y() {
            return C0106a.f6258d;
        }
    }

    int G0(Bundle bundle);
}
